
public class TableVals {
	String name;
	String desc;
	String submit;
	String email;
	String field;
	String when;
	
	public TableVals(String name, String desc, String submit, String email, String field, String when) {
		super();
		this.name = name;
		this.desc = desc;
		this.submit = submit;
		this.email = email;
		this.field = field;
		this.when = when;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getWhen() {
		return when;
	}

	public void setWhen(String when) {
		this.when = when;
	}

	@Override
	public String toString() {
		return "TableVals [name=" + name + ", desc=" + desc + ", submit=" + submit + ", email=" + email + ", field="
				+ field + ", when=" + when + "]";
	}
	
	

}

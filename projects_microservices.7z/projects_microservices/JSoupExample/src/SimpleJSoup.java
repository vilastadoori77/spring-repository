/*
 * Simple Jsoup Example
 */
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
 

public class SimpleJSoup {
 
    public static void main(String[] args) {
    	//String key = null;
    	//String value = null;
    	Map<String, String> hmData = new HashMap<String, String>();
    	String valName =null;
    	String valDesc=null;
    	String valSub=null;
    	String valEmail=null;
    	String valField=null;
    	String valWhen=null;
    	String valKey =null;
        String html = "<HTML><BODY BGCOLOR=\"#FFC080\"><H2>CGI Form Data:</H2>Submitted: 7-Oct-2018/19:23:34<P>REBOL Version: 2.6.2.4.2<P><TABLE BORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"5\"><TR><TD>Field:</TD><TD>\"PROD\"</TD></TR><TR><TD>Submit:</TD><TD>\"Submit\"</TD></TR><TR><TD>name:</TD><TD>\"Vilas\"</TD></TR><TR><TD>email:</TD><TD>\"swayam_58@yahoo.com\"</TD></TR><TR><TD>when:</TD><TD>\"NOW\"</TD></TR><TR><TD>description:</TD><TD>\"Test\"</TD></TR></TABLE></BODY></HTML>";
        Document doc = Jsoup.parse(html);
        Element table = doc.select("table").first();
        Iterator<Element> iterator = table.select("td").iterator();
        while(iterator.hasNext()){
        	
        	hmData.put(iterator.next().text(), iterator.next().text());
            //System.out.print("Key"+iterator.next().text()); //kolom -1     
            
            //System.out.println("Value"+iterator.next().text()); //kolom -2
        	//System.out.println(iterator.next().text()+ " "+ iterator.next().text()); //kolom -2
        	//hmData.put(iterator.next().text(), iterator.next().text());
        }
        
        System.out.println("THe values are" + hmData.size());
        StringBuilder sb = new StringBuilder();
        for(String key : hmData.keySet()) {
        
        	System.out.println(" The key is"+key+"The values are"+hmData.get(key));
        	sb.append(key+hmData.get(key));
        	sb.append(",");
        }
        List<String> elements = new ArrayList<String>();
        System.out.println("SB IS" + sb);
        String finalsb = sb.toString();

        	//System.out.println("The valName" + " "+ valName);
        	//System.out.println(" The key and value is " + key+ " "+ value);
        
        StringTokenizer st = new StringTokenizer(finalsb,","); 
       while(st.hasMoreTokens())
       {
    	   elements.add(st.nextToken());
       }
       
       System.out.println("\nPrinting elements in ArrayList ...");
       for(String element : elements) {
           //System.out.println(element);
           if(element.contains("name:")) {
        	   System.out.println(element);
        	   
        	   String subName = StringUtils.substringAfter(element, ":");
        	   System.out.println("Teh values of test is" + subName);
        	   
        	   		valName = subName;
        	   
           }
           
           if(element.contains("description:")) {
        	   String subDesc = StringUtils.substringAfter(element, ":");
        	   valDesc = subDesc;
           }
           
           if(element.contains("Submit:")) {
        	   String subSubmit = StringUtils.substringAfter(element, ":");
        	   valSub = subSubmit;
           }
           if(element.contains("email:")) {
        	   String subEmail = StringUtils.substringAfter(element, ":");
        	   valEmail = subEmail;
           }
           
           if(element.contains("Field:")) {
        	   String subField = StringUtils.substringAfter(element, ":");
        	   valField = subField;
           }
           if(element.contains("when")) {
        	   String subWhen = StringUtils.substringAfter(element, ":");
        	   valWhen = subWhen;
           }
       }
       
       System.out.println("THe name is" + valName);
       System.out.println("THe Desc is" + valDesc);
       System.out.println("THe Desc is" + valSub);
       System.out.println("THe Desc is" + valEmail);
       System.out.println("THe Desc is" + valField);
       System.out.println("THe Desc is" + valWhen);
       
       
       
       TableVals tv = new TableVals(valName,valDesc,valSub, valEmail, valField,valWhen );
       
       System.out.println("The value of TV is" + tv.toString());
        
    }
    
    //Construct the Object:
    
    
    
}
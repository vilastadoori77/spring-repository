# Getting Started

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)
* [Routing and Filtering](https://spring.io/guides/gs/routing-and-filtering/)


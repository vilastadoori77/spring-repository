package com.vilas.springrest.restful_webservices;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/main")
public class HelloController {
	
	
	@GetMapping("/swaggerhello")
	public String sayHello() {
		
		return "This is the first spring hello on swagger";
		
	}

}

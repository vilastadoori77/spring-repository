package com.vilas.springrest.restful_webservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vilas.springrest.restful_webservices.Model.User;

@RestController
@RequestMapping("/users")
public class UserController {
	
	private static Map<Long, User> users = new HashMap<Long, User>();
	 private static Long idIndex = 3L;
	
	
	static {
		User u1 = new User(1L, "sachin", "tendulkar", "mumbai");
		users.put(1L, u1);
	    User u2 = new User(2L, "Zak", "Jack", "mumbai");
	    users.put(2L, u2);
	    User u3 = new User(3L, "R", "Dravid", "blr");
	    users.put(3L, u3);
	  }
	
	
	
	
	@GetMapping("/all")
	public List<User> getUsers(){
		
		
	return new ArrayList<User>(users.values());
		
		
		
		
	}
	
	
	@GetMapping("/all/{id}")
	public User getUser(@PathVariable Long id) {
		
	return users.get(id);

}
	
	
	@PostMapping("/all")
	public List<User> addUser(@RequestBody User user){
		
		idIndex += idIndex;
		user.setId(idIndex);
		users.put(idIndex, user);
		
		return new ArrayList<User>(users.values());
		
	}
	
	
	
}

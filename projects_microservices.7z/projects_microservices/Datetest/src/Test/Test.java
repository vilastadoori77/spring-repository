package Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Properties;

public class Test {

	public static void main(String[] args) throws ParseException, IOException {
		// TODO Auto-generated method stub
		
		
		String dateString="2014-03-21";
	     DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	     Date date=df.parse(dateString);
	     System.out.println("date:"+date);
	     df=new SimpleDateFormat("dd-MMM-yyyy");
	     System.out.println("Formated Date:"+df.format(date));
	     //System.out.println("date.getTime"+date.getTime());
	     
	     DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-YYYY");
	 	LocalDate localDate = LocalDate.now();
	 	System.out.println(dtf.format(localDate)); //2016/11/16
	 	
	 	String datetest = dtf.format((localDate));
	 	System.out.println("The date test is" + datetest);
	 	
	 	String version = null;
	 	try{
	 	     version = getAppVersion();
	 	     
	 	}
	 	catch (IOException ioe){
	 	    ioe.printStackTrace();
	 	}
	 	
	 	System.out.println("The Version is " + " "+ version);

	}
	
	


public static String getAppVersion() throws IOException{

    String versionString = null;

    //to load application's properties, we use this class
    Properties mainProperties = new Properties();

    FileInputStream file;

    //the base folder is ./, the root of the main.properties file  
    String path = "c:\\temp\\main.properties";

    //load the file handle for main.properties
    file = new FileInputStream(path);

    //load all the properties from this file
    mainProperties.load(file);

    //we have loaded the properties, so close the file handle
    file.close();

    //retrieve the property we are intrested, the app.version
    versionString = mainProperties.getProperty("server.host");

    return versionString;
}

}

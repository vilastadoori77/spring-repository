package com.vilas.reservation.model;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reservation")
public class Reservation {
	
	@Id
	private Long id;
	@Column
	private String dt;
	@Column(name="user_id")
	private Long userId;
	@Column(name="restaurant_id	")
	private Long restaurantId;
	@Column(name="party_size")
	private int partySize;
	
	public Reservation() {
		
	}
	
	
	
	public Reservation(Long id, String dt, Long userId, Long restaurantId, int partySize) {
		super();
		this.id = id;
		this.dt = dt;
		this.userId = userId;
		this.restaurantId = restaurantId;
		this.partySize = partySize;
	}



	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDt() {
		return dt;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}
	public int getPartySize() {
		return partySize;
	}
	public void setPartySize(int partySize) {
		this.partySize = partySize;
	}
	
	

}

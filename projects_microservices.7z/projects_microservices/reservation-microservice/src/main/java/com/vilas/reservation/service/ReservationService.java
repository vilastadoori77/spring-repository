package com.vilas.reservation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vilas.reservation.model.Reservation;
import com.vilas.reservation.repository.ReservationRepository;

@Service
public class ReservationService {
	
	@Autowired
	private ReservationRepository reservationRepository;
	
	
	// Retrieve all rows from table and populate list with objects
		public List<Reservation> getAllReservations() {
			
			List<Reservation> reservations = new ArrayList<Reservation>();
			reservationRepository.findAll().forEach(reservations::add);
			
			return reservations;
		}
		// Retrieves one row from table based on given id
		public Reservation getReservation(Long id) {
			return reservationRepository.findOne(id);
		
		}
		
		//Adds Reservation
		
		public void addReservation(Reservation reservation) {
			reservationRepository.save(reservation);
		}
		
		//Update Reservation
		public void updateReservation(Long id, Reservation reservation) {
			reservationRepository.save(reservation);
		}
		
	
		//Delete Reservation
		public void deleteReservation(Long id ) {
			reservationRepository.delete(id);
		}

}

package com.vilas.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vilas.reservation.model.Reservation;
import com.vilas.reservation.service.ReservationService;

@RestController
@RequestMapping("/v1")
public class ReservationController {
	
	@Autowired
	private ReservationService reservationService;
	
	
	//Retrive all reservations
	
	@RequestMapping(value = "/reservations", method=RequestMethod.GET)
	public List<Reservation> getAllReservations(){
		
		return reservationService.getAllReservations();
		
	}
	
	
	//Retrive reservation based on the id produced
	@RequestMapping(value = "/reservations/{id}", method=RequestMethod.GET)
	public Reservation getReservation(@PathVariable Long id) {
		return reservationService.getReservation(id);
		
	}
	
	
	
	@RequestMapping(value = "/reservations", method=RequestMethod.POST)
	public void addReservation(@RequestBody Reservation reservation) {
		reservationService.addReservation(reservation);
	}
	
	
	@RequestMapping(value = "/reservations/{id}", method=RequestMethod.PUT)
	public void updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
		reservationService.updateReservation(id, reservation);
	}
	
	@RequestMapping(value = "/reservations/{id}", method=RequestMethod.DELETE)
	public void deleteReservation(@PathVariable Long id) {
		reservationService.deleteReservation(id);
	}
	
	

}

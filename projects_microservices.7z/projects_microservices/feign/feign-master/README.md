# feign
Example for creating a feign client

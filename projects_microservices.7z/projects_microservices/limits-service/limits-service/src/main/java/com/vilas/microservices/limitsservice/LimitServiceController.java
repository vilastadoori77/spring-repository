package com.vilas.microservices.limitsservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.vilas.microservices.limitsservice.bean.LimitConfiguration;

@RestController
public class LimitServiceController {
	
	@Autowired
	private Configuration configuration;
	
	@GetMapping("/limits")
	public LimitConfiguration retrieveLimitsFromConfigurations() {
		
		int minimum = configuration.getMinimum();
		int maximum = configuration.getMaximum();
		
		return new LimitConfiguration(maximum,minimum);
		
	}
	
	
	@GetMapping("/fault-tolerance-example")
	@HystrixCommand(fallbackMethod="fallBackRetriveConfiguration")
	public LimitConfiguration retreiveConfiguration() {
		
		throw new RuntimeException("Not Available");
		
	}
	
	
	public LimitConfiguration fallBackRetriveConfiguration() {
		return new LimitConfiguration(999,9);
	}

}

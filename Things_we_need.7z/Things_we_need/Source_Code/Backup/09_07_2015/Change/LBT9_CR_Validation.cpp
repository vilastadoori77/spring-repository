	
/******************************************************************************************

File			:	LBT9_CR_Validation.cpp

Description		:	Workflow action handlers for Libert

Author			:	Tanay Gupta

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Tanay Gupta	   		 		Inital version

01/06/2015		Tanay Gupta	                Added LBT9_CR_Validation

05/07/2015		Tanay Gupta					Added LBT9_Cancel_CR_Validation

******************************************************************************************/
#include "LBT9_Change_Handler.h"




/****************************************************************************************************
*	Handler name	:	LBT9_CR_Validation

*	Description		:	Rule Handler- used to validate the Change  Request Workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_CR_Validation(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	tag_t tRootTask			=	NULLTAG;
	tag_t *tAttchItemTag	=	NULL;
	int iTargetAttchmnt		=	0;
	int iImpactedItemCount	=	0;
	tag_t *tImpactedItemTag	=	NULL;
	logical validationFailed = false;
	logical all_ok = true;
	//Validate the Target Attachments as Change Request Revision or not
	//Validate the attached Change Request Revision is having Pending Status or not
	//Validate the attached Change Request have any items in its impacted item folder or not
	//vlaidate the impacted items are having Released status or not
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp("LBT9_ChgRequestRevision",cpObjectType) == 0)
		{
			logical UserIsOriginator = false;
			ITK(iFail,fnToCheckCurrentUserIsOriginator(tAttchItemTag[0],&UserIsOriginator));
			if(UserIsOriginator)
			{
				int iStatusCount = 0;
				tag_t *tStatusTags = NULL;
				char *cpStatusValue = NULL;
				ITK(iFail,AOM_ask_value_tags(tAttchItemTag[0],"release_status_list"	,&iStatusCount,&tStatusTags));
				if(iStatusCount > 0 && tStatusTags != NULL)
				{
					ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusValue));
					if(cpStatusValue != NULL && tc_strcmp(cpStatusValue,PENDING_STATUS) == 0)
					{
						ITK(iFail,LBT_get_related_objects(tAttchItemTag[0],"CMHasImpactedItem",&iImpactedItemCount,&tImpactedItemTag));
						EMR_free(tStatusTags);
						EMR_free(cpStatusValue);
						EMR_free(cpObjectType);
					}
					else
					{
						EMH_clear_errors();
						EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CR_IS_NOT_IN_PENDING,"");
						decision = EPM_nogo;
						validationFailed = true;
						EMR_free(tStatusTags);
						EMR_free(cpStatusValue);
						EMR_free(cpObjectType);
						EMR_free(tAttchItemTag);
						return decision;
					}
				}
			}
			else
			{
				EMH_clear_errors();
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CR_USER_IS_NOT_ORIGINATOR,"");
				decision = EPM_nogo;
				validationFailed = true;
				EMR_free(cpObjectType);
				EMR_free(tAttchItemTag);
				return decision;
			}
		}
		else
		{
			EMH_clear_errors();
			EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_ITEM_SELECTED_IS_NOT_CR,"");
			decision = EPM_nogo;
			validationFailed = true;
			EMR_free(cpObjectType);
			EMR_free(tAttchItemTag);
			return decision;
		}
	}
	//if(tImpactedItemTag == NULL && iImpactedItemCount == 0)
	//{
	//	EMH_clear_errors();
	//	EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_NO_IMPACTED_ITEMS,"");
	//	decision = EPM_nogo;
	//	validationFailed = true;
	//	EMR_free(tAttchItemTag);
	//	return decision;
	//}
	if(tImpactedItemTag != NULL && iImpactedItemCount > 0)
	{
		int iUnreleasedItemCount	= 0;
		tag_t *UnreleasedItemTags	= NULL;
		char * cpUnreleasedItemList = NULL;
		ITK(iFail,LBT_get_unreleased_impacted_items(iImpactedItemCount,tImpactedItemTag, &iUnreleasedItemCount, &UnreleasedItemTags));
		if(iUnreleasedItemCount > 0 && UnreleasedItemTags != NULL)
		{
			EMH_clear_errors();
			ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iUnreleasedItemCount,UnreleasedItemTags,&cpUnreleasedItemList));
			validationFailed = true;
		}
		if(validationFailed && tc_strlen(cpUnreleasedItemList) > 0 && cpUnreleasedItemList != NULL)
		{
			char *Temp = NULL;
			Temp = (char *)MEM_alloc(tc_strlen(cpUnreleasedItemList) + tc_strlen("\n") + 2);
			tc_strcpy(Temp,"\n");
			tc_strcat(Temp,cpUnreleasedItemList);
			EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_UNRELEASED_IMPACTED_ITEMS,Temp);
			EMR_free(Temp);
			decision = EPM_nogo;
		}
		EMR_free(UnreleasedItemTags);
		EMR_free(cpUnreleasedItemList);
	}
	EMR_free(tAttchItemTag);
	EMR_free(tImpactedItemTag);
	if(!validationFailed)
	{
		decision = EPM_go;
	}
	return decision;
}


/****************************************************************************************************
*	Handler name	:	LBT9_Cancel_CR_Validation

*	Description		:	Rule Handler- used to validate the Change CR Workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_Cancel_CR_Validation(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	char *cpUserId = NULL;
	char *cpStatus = NULL;
	tag_t tRootTask			=	NULLTAG;
	tag_t *tAttchItemTag	=	NULL;
	int iTargetAttchmnt		=	0;
	int iImpactedItemCount	=	0;
	tag_t *tImpactedItemTag	=	NULL;
	logical validationFailed = false;
	logical all_ok = true;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		tag_t tCurrentGrpMemberTag = NULLTAG;
	
		ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		ITK(iFail,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
		if(tCurrentGrpMemberTag != NULLTAG)
		{
			tag_t tUserTag	= NULLTAG;
			ITK(iFail,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
			if(tUserTag != NULLTAG)
			{
				ITK(iFail,SA_ask_user_identifier2(tUserTag,&cpUserId));
			}
		}
		//Cancel CR workflow should only work for the Change Request Revision
		if(cpObjectType != NULL && tc_strcmp("LBT9_ChgRequestRevision",cpObjectType) == 0)
		{
			validationFailed = true;
			EMR_free(cpObjectType);
		}
	}
	//Only Change Analyst and Originator of the CR are allowed to use this workflow
	if(validationFailed && cpUserId != NULL)
	{
		tag_t tOriginatorTag = NULLTAG;
		char *cpOriginatorId = NULL;
		char *cpAnalystId = NULL;
		ITK(iFail,AOM_ask_value_string(tAttchItemTag[0],"lbt9_Change_Analyst",&cpAnalystId));
		ITK(iFail,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
		if(tOriginatorTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
		}
		if(cpAnalystId != NULL && cpOriginatorId != NULL)
		{
			if(tc_strcmp(cpUserId,cpAnalystId) == 0 || tc_strcmp(cpUserId,cpOriginatorId) == 0)
			{
				all_ok = false;
			}
			else
			{
				all_ok = true;
			}
			EMR_free(cpAnalystId);
			EMR_free(cpOriginatorId);
		}
		EMR_free(cpUserId);
	}
	else if(!validationFailed)
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_WF_ITEM_IS_NOT_CR,"");
		decision = EPM_nogo;
		EMR_free(cpUserId);
		EMR_free(tAttchItemTag);
		return decision;
	}
	//Cancel CR workflow can only be used when CR is in release state
	if(!all_ok)
	{
		int iStatusCount = 0;
		tag_t *tStatusTags = NULL;
		ITK(iFail,AOM_ask_value_tags(tAttchItemTag[0],"release_status_list",&iStatusCount,&tStatusTags));
		if(tStatusTags != NULL && iStatusCount > 0)
		{
			ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatus));
			if(cpStatus != NULL && tc_strcmp(cpStatus,PENDING_STATUS) == 0)
			{
				decision =  EPM_go;
				EMR_free(cpStatus);
			}
			else
			{
				EMH_clear_errors();
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_WF_ITEM_STATUS_IS_INVALID,"");
				decision = EPM_nogo;
			}
			EMR_free(tStatusTags);
		}
		EMR_free(tAttchItemTag);
	}
	else
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_WF_USER_IS_NOT_AUTHORIZED,"");
		decision = EPM_nogo;
		EMR_free(tAttchItemTag);
	}
	return decision;
}
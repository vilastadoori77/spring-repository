/******************************************************************************************

File			:	LBT9_Save_Change_Note.cpp

Description		:	Functions for Save Change 

Author			:  Krupakar Reddy G

Date created	:   31/07/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

31/07/2015		Krupkar Reddy G		 		Inital version

31/07/2015		Krupkar Reddy G             Added deriveChange

31/07/2015		Krupkar Reddy G             Added fnCreateChgRequestFromChgNotice

31/07/2015		Krupkar Reddy G             Added fnCreateChgNoticeFromChgRequest

31/07/2015		Krupkar Reddy G             Added fnCreateChgRequestFromChgRequest

07/08/2015		Krupkar Reddy G             Added fnCreateChgNoticeFromChgNotice

31/07/2015		Krupkar Reddy G             Added fnGetTargetTypeRealName

31/07/2015		Krupkar Reddy G 			Added fnCreatingNewItem

31/07/2015		Krupkar Reddy G				Added fnAttachDatasets

31/07/2015      Krupkar Reddy G				Added commonForDatasets
		
******************************************************************************************/


#include "LBT9_Change_Handler.h"

/**************************************************************************************
*	Function name	:	deriveChange

*	Description		:	This Function is used for the Create New Object From another Object

***************************************************************************************/

extern int   deriveChange	(void *returnValueType				/* <I> */
						)
{
	int retcode = ITK_ok;
	
	tag_t revTag = NULLTAG;
	tag_t logged_in_group_member_tag = NULLTAG;
    char * Value			= NULL;
	char * cpNewObjectId	= NULL;
	char * selectedObjectId				= NULL;
	char * cptargetType					= NULL;
	char *isCommonPropertiesSelected	= NULL;
	char *isDatasetsSelected			= NULL;
	char recipient[64] = "";
	
	
	/* Get the selectedObjectId User*/
	ITK(retcode,USERARG_get_string_argument(&selectedObjectId));
	
	/* Get the targetType string */
	ITK(retcode,USERARG_get_string_argument(&cptargetType));
	
	/* Get the comments */
	ITK(retcode,USERARG_get_string_argument(&isCommonPropertiesSelected));
	
	/* Get if isOriginatorSelected or not*/
	ITK(retcode,USERARG_get_string_argument(&isDatasetsSelected));

	
	if ( selectedObjectId != NULL )
	{
		
		int iStringCount	=	0;
		char ** StringList	=	NULL;
		ITK(retcode,EPM__parse_string(selectedObjectId,"-",&iStringCount,&StringList));
	
		tag_t tItemTag		=	NULLTAG;
		tag_t tItemRevTag	=	NULLTAG;
		ITK(retcode,ITEM_find_item(StringList[iStringCount-1],&tItemTag));
		if(tItemTag !=  NULLTAG)
		{
			char * cpObjectType	=	NULL;
			ITK(retcode,ITEM_ask_latest_rev(tItemTag,&tItemRevTag));
			ITK(retcode,WSOM_ask_object_type2(tItemRevTag,&cpObjectType));
			if(cpObjectType != NULL && tc_strlen(cpObjectType) > 0)
			{
				if((tc_strcmp(cpObjectType,"LBT9_ECNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_DCNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_MCORevision")==0) && ((tc_strcmp(cptargetType,"Stop Ship")==0 ||tc_strcmp(cptargetType,"Deviation")==0 || tc_strcmp(cptargetType,"Change Request")==0)))
				{
					ITK(retcode,fnCreateChgRequestFromChgNotice(tItemRevTag,cptargetType,isDatasetsSelected,&Value));
				}
				if((tc_strcmp(cpObjectType,"LBT9_StopShipRevision")==0 || tc_strcmp(cpObjectType,"LBT9_DeviationRevision")==0 || tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision")==0) && ((tc_strcmp(cptargetType,"ECN")==0 ||tc_strcmp(cptargetType,"DCN")==0 || tc_strcmp(cptargetType,"MCO")==0)))
				{
					ITK(retcode,fnCreateChgNoticeFromChgRequest(tItemRevTag,cptargetType,isDatasetsSelected,&Value));
				}
				if((tc_strcmp(cpObjectType,"LBT9_StopShipRevision")==0 || tc_strcmp(cpObjectType,"LBT9_DeviationRevision")==0 || tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision")==0) && ((tc_strcmp(cptargetType,"Stop Ship")==0 ||tc_strcmp(cptargetType,"Deviation")==0 || tc_strcmp(cptargetType,"Change Request")==0)))
				{
					ITK(retcode,fnCreateChgRequestFromChgRequest(tItemRevTag,cptargetType,isDatasetsSelected,&Value));
				}
				if((tc_strcmp(cpObjectType,"LBT9_ECNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_DCNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_MCORevision")==0) && ((tc_strcmp(cptargetType,"ECN")==0 ||tc_strcmp(cptargetType,"MCO")==0 || tc_strcmp(cptargetType,"DCN")==0)))
				{
					ITK(retcode,fnCreateChgNoticeFromChgNotice(tItemRevTag,cptargetType,isDatasetsSelected,&Value));
				}
			}
		}
		cpNewObjectId = (char *)MEM_alloc(sizeof(char)*(tc_strlen(Value)));
		
		tc_strcpy(cpNewObjectId,Value);
		 *((char**)returnValueType) = cpNewObjectId;	

	}
	return retcode;
}
/**************************************************************************************
*	Function name	:	fnCreateChgRequestFromChgNotice

*	Description		:	This Function is used for the Creating ChgRequestObject From 
						ChangeNoticeObject

***************************************************************************************/
int fnCreateChgRequestFromChgNotice(tag_t  tChgNoticeRevTag,	/*< I >*/
									char * cptargetType,		/*< I >*/
									char * isDatasetsSelected,	/*< I >*/
									char ** cpNewObjectId		/*< O >*/
									)
{
	int iFail	= ITK_ok;
	tag_t tRelationTypeTag	=	NULLTAG;
	*cpNewObjectId = NULL;
	*cpNewObjectId = (char *)MEM_alloc(20);
	ITK(iFail,GRM_find_relation_type("CMHasSolutionItem",&tRelationTypeTag));
	if(tRelationTypeTag != NULLTAG)
	{
		int iSecObjCount			=	0;
		int iReleasedObjectCount	=	0;
		char * cpCreateType			=	NULL;
		tag_t * tSecObjTags			=	NULL;
		tag_t *tReleasedObjectTags	=   NULL;
	
		ITK(iFail,fnGetTargetTypeRealName(cptargetType,&cpCreateType));
		
		ITK(iFail,GRM_list_secondary_objects_only(tChgNoticeRevTag,tRelationTypeTag,&iSecObjCount,&tSecObjTags));
		if(iSecObjCount > 0 && tSecObjTags != NULL)
		{
			for(int i=0 ; i < iSecObjCount ; i++)
			{
				int iStatusCount	=	0;
				tag_t *tStatusTag	=	NULL;
				ITK(iFail,WSOM_ask_release_status_list(tSecObjTags[i],&iStatusCount,&tStatusTag));
				if(iStatusCount > 0 && tStatusTag != NULL)
				{
					char * cpStatusName	= NULL;
					ITK(iFail,AOM_ask_value_string(tStatusTag[iStatusCount-1],"object_name",&cpStatusName));
					if(cpStatusName != NULL && tc_strcmp(cpStatusName,"EMR_Released")==0)
					{
						tReleasedObjectTags = (tag_t *)MEM_realloc(tReleasedObjectTags,sizeof(tag_t)*(iReleasedObjectCount+1));
						tReleasedObjectTags[iReleasedObjectCount] = tSecObjTags[i];
						iReleasedObjectCount++;
					}
				}
			}
			
		}
		char * cpDescription	=	NULL;
		ITK(iFail,AOM_ask_value_string(tChgNoticeRevTag,"lbt9_Description",&cpDescription));
		tag_t tNewItemRevTag		=	NULLTAG;
		ITK(iFail,fnGetTargetTypeRealName(cptargetType,&cpCreateType));
		ITK(iFail,fnCreatingNewItem(tChgNoticeRevTag,cpCreateType,&tNewItemRevTag));
		if(tNewItemRevTag != NULLTAG)
		{	
			tag_t tRelationTypeTag1	=	NULLTAG;
			ITK(iFail,GRM_find_relation_type("CMHasImpactedItem",&tRelationTypeTag1));
			if(tRelationTypeTag1 != NULLTAG)
			{
				for(int k=0 ; k < iReleasedObjectCount ; k++)
				{
					tag_t tRelationTag	= NULLTAG;

					ITK(iFail,GRM_create_relation(tNewItemRevTag,tReleasedObjectTags[k],tRelationTypeTag1,NULLTAG,&tRelationTag));
					ITK(iFail,AOM_refresh(tNewItemRevTag,TRUE));
					ITK(iFail,GRM_save_relation(tRelationTag));
					ITK(iFail,AOM_save(tNewItemRevTag));
					ITK(iFail,AOM_refresh(tNewItemRevTag,TRUE));
				}
			}
			if(tc_strcmp(isDatasetsSelected,"Yes")==0)
			{
				ITK(iFail,fnAttachDatasets(tChgNoticeRevTag,tNewItemRevTag));
			}
			
			char * cpItemId	=	NULL;
			ITK(iFail,AOM_ask_value_string(tNewItemRevTag,"item_id",&cpItemId));
			tc_strcpy(*cpNewObjectId,cpItemId);
		}
	}
	
	return iFail;
}
/**************************************************************************************
*	Function name	:	fnCreateChgNoticeFromChgRequest

*	Description		:	This Function is used for the Creating ChgNoticeObject From 
						ChangeRequestObject

***************************************************************************************/

int fnCreateChgNoticeFromChgRequest(tag_t tChgRequestTag,		/*< I >*/
									char * cptargetType,		/*< I >*/
									char * isDatasetsSelected,	/*< I >*/
									char ** cpNewObjectId		/*< O >*/
									)
{
	int iFail					= ITK_ok;
	int iSecObjCount			=	0;
	int iLatestReleasedObjectCount	=	0;
	int iLatestRevCount			=	0;
	char * cpCreateType			=	NULL;
	char * cpObjectType			=	NULL;
	tag_t tImpItemTypeRelTag	=	NULLTAG;
	tag_t *tSecObjTags			=	NULL;
	tag_t * tLatestReleasedObjectTags	=	NULL;
	tag_t *  tLatestRevTags		=	NULL;
	*cpNewObjectId = NULL;
	*cpNewObjectId = (char *)MEM_alloc(20);
	
	tag_t tNewItemRevTag	=	NULLTAG;
	
	ITK(iFail,GRM_find_relation_type("CMHasImpactedItem",&tImpItemTypeRelTag));
	if(tImpItemTypeRelTag != NULLTAG)
	{
		ITK(iFail,GRM_list_secondary_objects_only(tChgRequestTag,tImpItemTypeRelTag,&iSecObjCount,&tSecObjTags));
		if(iSecObjCount > 0 && tSecObjTags != NULL)
		{
			//checking  latest released revision value and storing in one array 
			for(int i=0 ; i < iSecObjCount ; i++)
			{
				tag_t tSecItemTag	=	NULLTAG;
				tag_t tSecLRRTag	=	NULLTAG;
				ITK(iFail,ITEM_ask_item_of_rev(tSecObjTags[i],&tSecItemTag));
				if(tSecItemTag != NULLTAG)
				{
					ITK(iFail,fnToCheckLRRofItemMassChange(tSecItemTag,&tSecLRRTag));
					if(tSecLRRTag != NULLTAG)
					{
						//checking if the Item present in ChqRequest is LatestReleased,if it is latest then storing in array
						if(tSecLRRTag == tSecObjTags[i])
						{
							tLatestReleasedObjectTags = (tag_t *)MEM_realloc(tLatestReleasedObjectTags,sizeof(tag_t)*(iLatestReleasedObjectCount+1));
							tLatestReleasedObjectTags[iLatestReleasedObjectCount] = tSecObjTags[i];
							iLatestReleasedObjectCount++;
						}
					}
				}
			}
			// creating new revision from the latest released revision
			for(int j=0 ; j < iLatestReleasedObjectCount ; j++ )
			{
				tag_t tNewrevTag	=	NULLTAG;
				//ITEM_copy_rev(tLatestReleasedObjectTags[j],NULL,&tNewrevTag);
				 char * cpLRRevId	=	NULL;
				 tag_t tItemTag	=	NULLTAG;
				ITK(iFail,ITEM_ask_rev_id2(tLatestReleasedObjectTags[j],&cpLRRevId));

				ITK(iFail,ITEM_ask_item_of_rev(tLatestReleasedObjectTags[j],&tItemTag));

				if(cpLRRevId != NULL && tc_strcmp(cpLRRevId,"")!=0)
				{
				
					vector<char *> LRR;
					int iStrCount	=	0;
					char **LRRRevStrList	=	NULL;
					LRR.clear();
					ITK(iFail,EPM__parse_string(cpLRRevId,".",&iStrCount,&LRRRevStrList));
					for(int inx=0; inx < iStrCount; inx++)
					{
						LRR.push_back(LRRRevStrList[inx]);
					}
					logical  LRRIsMinorRev = false;

					if(LRR.size() > 1)
					{
						LRRIsMinorRev = true;
					}
					
	
					if(LRRIsMinorRev)
					{
						if(tc_strcmp(cptargetType,"MCO")==0)
						{
		
							char * cpNewRevId = NULL;
							cpNewRevId  = (char *)MEM_alloc(10);
							int x = atoi(LRR[0]);
							//x++;
							char* new_rev = (char *)MEM_alloc(tc_strlen(cpLRRevId)+2);
							itoa(x,new_rev,10);
							tc_strcat(new_rev,".M1");
							ITK(iFail,fnGetNewRevisionValue(new_rev,tItemTag,&cpNewRevId));
							ITK(iFail,ITEM_copy_rev(tLatestReleasedObjectTags[j],cpNewRevId,&tNewrevTag));
							EMR_free(new_rev);
							EMR_free(cpNewRevId);
							
						}
						else
						{
							char * cpNewRevId = NULL;
							cpNewRevId  = (char *)MEM_alloc(10);
							int x = 0;
							x = atoi(LRR[0]);
							x++;
							char* new_rev = (char *)MEM_alloc(tc_strlen(cpLRRevId)+2);
							itoa(x,new_rev,10);
							ITK(iFail,fnGetNewRevisionValue(new_rev,tItemTag,&cpNewRevId));
							ITK(iFail,ITEM_copy_rev(tLatestReleasedObjectTags[j],cpNewRevId,&tNewrevTag));
							EMR_free(new_rev);
							EMR_free(cpNewRevId);
						}
					}
					else
					{
						if(tc_strcmp(cptargetType,"ECN")==0 || tc_strcmp(cptargetType,"DCN")==0)
						{
							char * cpNewRevId = NULL;
							cpNewRevId  = (char *)MEM_alloc(10);
							int x = 0;
							x = atoi(LRR[0]);
							x++;
							char* new_rev = (char *)MEM_alloc(tc_strlen(cpLRRevId)+2);
							itoa(x,new_rev,10);
							ITK(iFail,fnGetNewRevisionValue(new_rev,tItemTag,&cpNewRevId));
							ITK(iFail,ITEM_copy_rev(tLatestReleasedObjectTags[j],cpNewRevId,&tNewrevTag));
							EMR_free(new_rev);
							EMR_free(cpNewRevId);
						}
						else
						{
							char * cpNewRevId = NULL;
							cpNewRevId  = (char *)MEM_alloc(10);
							int x = 0;
							x = atoi(LRR[0]);
							char* new_rev = (char *)MEM_alloc(tc_strlen(cpLRRevId)+2);
							itoa(x,new_rev,10);
							tc_strcat(new_rev,".M1");
							ITK(iFail,fnGetNewRevisionValue(new_rev,tItemTag,&cpNewRevId));
							ITK(iFail,ITEM_copy_rev(tLatestReleasedObjectTags[j],cpNewRevId,&tNewrevTag));
							EMR_free(new_rev);
							EMR_free(cpNewRevId);
							
						}
	
					}
	

				if(tNewrevTag != NULLTAG)
				{
					tLatestRevTags = (tag_t *)MEM_realloc(tLatestRevTags,sizeof(tag_t)*(iLatestRevCount+1));
					tLatestRevTags[iLatestRevCount] = tNewrevTag;
					iLatestRevCount++;
				}
				LBT9_MEM_free_Strings(LRRRevStrList,iStrCount);
				EMR_free(cpLRRevId);
			}
			
		  }
		}
		ITK(iFail,fnGetTargetTypeRealName(cptargetType,&cpCreateType));
		ITK(iFail,fnCreatingNewItem(tChgRequestTag,cpCreateType,&tNewItemRevTag));
			if(tNewItemRevTag != NULLTAG)
			{
				tag_t tRelationTypeTag1	=	NULLTAG;
				ITK(iFail,GRM_find_relation_type("CMHasSolutionItem",&tRelationTypeTag1));
				if(tRelationTypeTag1 != NULLTAG)
				{
					for(int m=0 ; m < iLatestRevCount ; m++)
					{
						tag_t tRelationTag	= NULLTAG;
						tag_t tTag			= NULLTAG;
						tag_t tItemTag		= NULLTAG;
						char * cpItemId		=	NULL;
						AOM_ask_value_string(tLatestRevTags[m],"item_id",&cpItemId);
						GRM_find_relation(tNewItemRevTag,tLatestRevTags[m],tRelationTypeTag1,&tTag);
						if(tTag == NULLTAG)
						{
							ITK(iFail,GRM_create_relation(tNewItemRevTag,tLatestRevTags[m],tRelationTypeTag1,NULLTAG,&tRelationTag));
							ITK(iFail,AOM_refresh(tNewItemRevTag,TRUE));
							ITK(iFail,GRM_save_relation(tRelationTag));
							ITK(iFail,AOM_save(tNewItemRevTag));
							ITK(iFail,AOM_refresh(tNewItemRevTag,FALSE));
						}
					
					}
				}

				if(tc_strcmp(isDatasetsSelected,"Yes")==0)
				{
					ITK(iFail,fnAttachDatasets(tChgRequestTag,tNewItemRevTag));
				}

				char * cpItemId	=	NULL;
				ITK(iFail,AOM_ask_value_string(tNewItemRevTag,"item_id",&cpItemId));
				tc_strcpy(*cpNewObjectId,cpItemId);
		}
	}
	

	return iFail;
}

/**************************************************************************************
*	Function name	:	fnCreateChgRequestFromChgRequest

*	Description		:	This Function is used for the Creating ChgRequestObject From 
						ChangeRequestObject

***************************************************************************************/
int fnCreateChgRequestFromChgRequest(tag_t  tChgRequestTag,		/*< I >*/
									 char * cptargetType,		/*< I >*/
									 char * isDatasetsSelected,	/*< I >*/
									 char ** cpNewObjectId		/*< O >*/
									)
{
	int iFail					=	ITK_ok;
	int iSecObjCount			=	0;
	int iReleasedObjectCount	=	0;
	char * cpCreateType			=	NULL;
	char * cpObjectType			=	NULL;
	tag_t tImpItemTypeRelTag	=	NULLTAG;
	tag_t *tSecObjTags			=	NULL;
	tag_t * tReleasedObjectTags	=	NULL;
	*cpNewObjectId = NULL;
	*cpNewObjectId = (char *)MEM_alloc(20);

	ITK(iFail,GRM_find_relation_type("CMHasImpactedItem",&tImpItemTypeRelTag));
	if(tImpItemTypeRelTag != NULLTAG)
	{
		ITK(iFail,GRM_list_secondary_objects_only(tChgRequestTag,tImpItemTypeRelTag,&iSecObjCount,&tSecObjTags));
		if(iSecObjCount > 0 && tSecObjTags != NULL)
		{
			for(int i=0 ; i < iSecObjCount ; i++)
			{
				tReleasedObjectTags = (tag_t *)MEM_realloc(tReleasedObjectTags,sizeof(tag_t)*(iReleasedObjectCount+1));
				tReleasedObjectTags[iReleasedObjectCount] = tSecObjTags[i];
				iReleasedObjectCount++;
			}
			
		}
		ITK(iFail,WSOM_ask_object_type2(tChgRequestTag,&cpObjectType));
		ITK(iFail,fnGetTargetTypeRealName(cptargetType,&cpCreateType));

		tag_t tNewItemRevTag		=	NULLTAG;
		ITK(iFail,fnCreatingNewItem(tChgRequestTag,cpCreateType,&tNewItemRevTag));

		if(tNewItemRevTag != NULLTAG)
		{
			tag_t tRelationTypeTag1	=	NULLTAG;
			ITK(iFail,GRM_find_relation_type("CMHasImpactedItem",&tRelationTypeTag1));
			if(tRelationTypeTag1 != NULLTAG)
			{
				for(int k=0 ; k < iReleasedObjectCount ; k++)
				{
					tag_t tRelationTag	= NULLTAG;

					ITK(iFail,GRM_create_relation(tNewItemRevTag,tReleasedObjectTags[k],tRelationTypeTag1,NULLTAG,&tRelationTag));
					ITK(iFail,AOM_refresh(tNewItemRevTag,TRUE));
					ITK(iFail,GRM_save_relation(tRelationTag));
					ITK(iFail,AOM_save(tNewItemRevTag));
					ITK(iFail,AOM_refresh(tNewItemRevTag,TRUE));
				}
			}

			if(tc_strcmp(isDatasetsSelected,"Yes")==0)
			{
				ITK(iFail,fnAttachDatasets(tChgRequestTag,tNewItemRevTag));
			}

			char * cpItemId	=	NULL;
			ITK(iFail,AOM_ask_value_string(tNewItemRevTag,"item_id",&cpItemId));
			tc_strcpy(*cpNewObjectId,cpItemId);
		}
	}

	return iFail;
}

/**************************************************************************************
*	Function name	:	fnCreateChgNoticeFromChgNotice

*	Description		:	This Function is used for the Creating ChgNoticeObject From 
						ChgNoticeObject

***************************************************************************************/
int fnCreateChgNoticeFromChgNotice	(tag_t tChgNoticeTag,		/*< I >*/
									char * cptargetType,		/*< I >*/
									char * isDatasetsSelected,	/*< I >*/
									char ** cpNewObjectId		/*< O >*/
									)
{
	int iFail	= ITK_ok;
	int iSecObjCount			=	0;
	int iLatestReleasedObjectCount	=	0;
	int iLatestRevCount			=	0;
	char * cpCreateType			=	NULL;
	char * cpObjectType			=	NULL;
	tag_t tImpItemTypeRelTag	=	NULLTAG;
	tag_t *tSecObjTags			=	NULL;
	tag_t * tLatestReleasedObjectTags	=	NULL;
	tag_t *  tLatestRevTags		=	NULL;
	*cpNewObjectId = NULL;
	*cpNewObjectId = (char *)MEM_alloc(20);

	if(tChgNoticeTag != NULLTAG)
	{
		ITK(iFail,WSOM_ask_object_type2(tChgNoticeTag,&cpObjectType));
		
		ITK(iFail,fnGetTargetTypeRealName(cptargetType,&cpCreateType));
		tag_t tNewItemRevTag		=	NULLTAG;
		ITK(iFail,fnCreatingNewItem(tChgNoticeTag,cpCreateType,&tNewItemRevTag));
		if(tNewItemRevTag != NULLTAG)
		{
			if(tc_strcmp(isDatasetsSelected,"Yes")==0)
			{
				ITK(iFail,fnAttachDatasets(tChgNoticeTag,tNewItemRevTag));
			}

			char * cpItemId	=	NULL;
			ITK(iFail,AOM_ask_value_string(tNewItemRevTag,"item_id",&cpItemId));
			tc_strcpy(*cpNewObjectId,cpItemId);
		}
	}
	return iFail;
}

/**************************************************************************************
*	Function name	:	fnGetTargetTypeRealName

*	Description		:	This Function is used for the getting the realtype Name

***************************************************************************************/
int fnGetTargetTypeRealName(char * cptargetType,		/*< I >*/
							char **cpRealname			/*< O >*/
							)
{
	int iFail			=	ITK_ok;
	*cpRealname = NULL;
	*cpRealname = (char *)MEM_alloc(20);

	if(cptargetType != NULL && tc_strcmp(cptargetType,"ECN")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_ECN");
	}
	if(cptargetType != NULL && tc_strcmp(cptargetType,"MCO")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_MCO");
	}
	if(cptargetType != NULL && tc_strcmp(cptargetType,"DCN")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_DCN");
	}
	if(cptargetType != NULL && tc_strcmp(cptargetType,"Deviation")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_Deviation");
	}
	if(cptargetType != NULL && tc_strcmp(cptargetType,"Stop Ship")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_StopShip");
	}
	if(cptargetType != NULL && tc_strcmp(cptargetType,"Change Request")==0)
	{
		tc_strcpy(*cpRealname,"LBT9_ChgRequest");
	}
	return iFail;
}

/**************************************************************************************
*	Function name	:	fnCreatingNewItem

*	Description		:	This Function is used for creating the New Item

***************************************************************************************/

int fnCreatingNewItem(tag_t ChangeObjectTag,	/* <I> */
					  char * cpCreateType,		/* <I> */
					  tag_t * tNewItemRevTag	/* <O> */
					 )
{
	int iFail		=	ITK_ok;
	tag_t tInputTag	=	NULLTAG;
	//tag_t tNewItemRevTag	= NULLTAG;
	*tNewItemRevTag	=	NULLTAG;
	char * RevType = NULL;
	char * cpObjectType	=	NULL;
	int iProdCount			=	0;
	int iPlantCount			=	0;
	int iPersonCount		=	0;
	char * cpDescription	=	NULL;
	char * cpChangeReason	=	NULL;
	char * cpReasonCode		=	NULL;
	char * cpCategory		=	NULL;
	char * cpRespGroup		=	NULL;
	char **cpRespPerson		=	NULL;
	char **cpProductLines	=	NULL;
	char **cpPlants			=	NULL;
	char * cpPreAppRqd		=	NULL;
	char * cpChangeAnalyst	=	NULL;
	char * cpPreAppReqd		=	NULL;

	if(ChangeObjectTag != NULLTAG)
	{
		ITK(iFail,WSOM_ask_object_type2(ChangeObjectTag,&cpObjectType));
		ITK(iFail,AOM_ask_value_string(ChangeObjectTag,"lbt9_Description",&cpDescription));
		ITK(iFail,AOM_ask_value_string(ChangeObjectTag,"lbt9_Change_Reason",&cpChangeReason));
		ITK(iFail,AOM_ask_value_strings(ChangeObjectTag,"lbt9_Plants_Affected",&iPlantCount,&cpPlants));
		ITK(iFail,AOM_ask_value_strings(ChangeObjectTag,"lbt9_Product_Lines",&iProdCount,&cpProductLines));
		ITK(iFail,AOM_ask_value_strings(ChangeObjectTag,"lbt9_Responsible_Person",&iPersonCount,&cpRespPerson));
		ITK(iFail,AOM_ask_value_string(ChangeObjectTag,"lbt9_Change_Analyst",&cpChangeAnalyst));
	}

	RevType = (char *)MEM_alloc(tc_strlen(cpCreateType)+tc_strlen("Revision")+2);
	ITK(iFail,TCTYPE_find_type(cpCreateType,NULL,&tInputTag));
	if(tInputTag != NULLTAG)
	{
		tag_t create_input_tag	=	NULLTAG;
		tag_t tNewItemTag		=	NULLTAG;
		
		ITK(iFail,TCTYPE_construct_create_input(tInputTag, &create_input_tag));
		
		if(create_input_tag != NULLTAG)
		{
				
			ITK(iFail,AOM_set_value_string(create_input_tag,"object_name",cpDescription));
			ITK(iFail,TCTYPE_create_object(create_input_tag,&tNewItemTag));
			ITK(iFail,AOM_save(tNewItemTag));
			if(tNewItemTag != NULLTAG)
			{
				tag_t tNewRevTag	=	NULLTAG;
				ITEM_ask_latest_rev(tNewItemTag,&tNewRevTag);
				if(tNewRevTag != NULLTAG)
				{
					ITK(iFail,WSOM_ask_object_type2(tNewRevTag,&cpObjectType));
					ITK(iFail,AOM_refresh(tNewRevTag,TRUE));
					ITK(iFail,AOM_set_value_string(tNewRevTag,"object_name",cpDescription));
					ITK(iFail,AOM_set_value_string(tNewRevTag,"lbt9_Description",cpDescription));
					ITK(iFail,AOM_set_value_string(tNewRevTag,"lbt9_Change_Reason",cpChangeReason));
					ITK(iFail,AOM_set_value_strings(tNewRevTag,"lbt9_Plants_Affected",iPlantCount,cpPlants));
					ITK(iFail,AOM_set_value_strings(tNewRevTag,"lbt9_Product_Lines",iProdCount,cpProductLines));
					if(iPersonCount > 0 && cpRespPerson != NULL)
					{
						ITK(iFail,AOM_set_value_strings(tNewRevTag,"lbt9_Responsible_Person",iPersonCount,cpRespPerson));
					}
					
					ITK(iFail,AOM_set_value_string(tNewRevTag,"lbt9_Change_Analyst",cpChangeAnalyst));

					if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_StopShipRevision") !=0 && tc_strcmp(cpObjectType,"LBT9_DeviationRevision") !=0))
					{
						ITK(iFail,AOM_set_value_string(tNewRevTag,"lbt9_Category","Normal"));
					}
					if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_StopShipRevision")!=0)
					{
						ITK(iFail,AOM_set_value_string(tNewRevTag,"lbt9_Pre_Approval_Required","YES"));
					}
		
					if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision")!=0)
					{
						//ITK(iFail,AOM_set_value_string(create_input_rev_tag,"lbt9_Reason_Code",cpReasonCode));
					}

					ITK(iFail,AOM_save(tNewRevTag));
					ITK(iFail,AOM_refresh(tNewRevTag,FALSE));
					*tNewItemRevTag	=	tNewRevTag;
					char * cpCOItemRevId	=	NULL;
					char * cpNewItemRevId	=	NULL;
					ITK(iFail,AOM_ask_value_string(ChangeObjectTag,"object_string",&cpCOItemRevId));
					ITK(iFail,AOM_ask_value_string(tNewRevTag,"object_string",&cpNewItemRevId));


					if(cpCOItemRevId != NULL && cpNewItemRevId != NULL && tc_strcmp(cpCOItemRevId,"") != 0 && tc_strcmp(cpNewItemRevId,"") != 0 )
					{
						int iDerivedCount	=	0;
						int iBasedOn		=	0;
						char ** cpDerivedList	=	NULL;
						char ** tBasedOnList	=	NULL;
				
						ITK(iFail,AOM_ask_value_strings(ChangeObjectTag,"lbt9_Derived_to",&iDerivedCount,&cpDerivedList));
						ITK(iFail,AOM_refresh(ChangeObjectTag,TRUE));
						ITK(iFail,AOM_set_value_string_at(ChangeObjectTag,"lbt9_Derived_to",iDerivedCount,cpNewItemRevId));
						ITK(iFail,AOM_save(ChangeObjectTag));
						ITK(iFail,AOM_refresh(ChangeObjectTag,FALSE));

						

						ITK(iFail,AOM_ask_value_strings(tNewRevTag,"lbt9_Based_On",&iBasedOn,&tBasedOnList));
						ITK(iFail,AOM_refresh(tNewRevTag,TRUE));
						ITK(iFail,AOM_set_value_string_at(tNewRevTag,"lbt9_Based_On",iBasedOn,cpCOItemRevId));
						ITK(iFail,AOM_save(tNewRevTag));
						ITK(iFail,AOM_refresh(tNewRevTag,FALSE));
						

						LBT9_MEM_free_Strings(cpDerivedList,iDerivedCount);
						LBT9_MEM_free_Strings(tBasedOnList,iBasedOn);
						
					}
					EMR_free(cpCOItemRevId);
					EMR_free(cpNewItemRevId);

					
				}
				
			}

		}
		EMR_free(cpDescription);
		EMR_free(cpChangeReason);
		EMR_free(cpChangeAnalyst);
		LBT9_MEM_free_Strings(cpPlants,iPlantCount);
		LBT9_MEM_free_Strings(cpProductLines,iProdCount);
		LBT9_MEM_free_Strings(cpRespPerson,iPersonCount);
		

	}
		return iFail;
}

/**************************************************************************************
*	Function name	:	fnAttachDatasets

*	Description		:	This Function is used attaching the datasets

***************************************************************************************/
int fnAttachDatasets(tag_t tChgObjectTag,     /* <I> */
					 tag_t tNewChgObjectTag   /* <I> */
					)
{
	int iFail		=	ITK_ok;

	tag_t tRefTypeTag	=	NULLTAG;
	ITK(iFail,GRM_find_relation_type("IMAN_reference",&tRefTypeTag));
	if(tRefTypeTag != NULLTAG)
	{
		ITK(iFail,commonForDatasets(tChgObjectTag,tNewChgObjectTag,tRefTypeTag));
	}

	return iFail;
}

int commonForDatasets(tag_t chgObjectRevTag,		/* <I> */
					  tag_t NewchgObjectRevTag,		/* <I> */
					  tag_t tTypeTag				/* <I> */
					  )
{
	int iFail		= ITK_ok;

	int iCount	=	0;
	tag_t * tDatasetsTags	=NULL;
	ITK(iFail,GRM_list_secondary_objects_only(chgObjectRevTag,tTypeTag,&iCount,&tDatasetsTags));
	if(iCount > 0 && tDatasetsTags != NULL)
	{
		for(int jnx=0;jnx<iCount;jnx++)
		{
			tag_t tIsExists	=	NULLTAG;
			ITK(iFail,GRM_find_relation(NewchgObjectRevTag,tDatasetsTags[jnx],tTypeTag,&tIsExists));
			if(tIsExists == NULLTAG)
			{
				tag_t tRelationTag		=	NULLTAG;
				ITK(iFail,AOM_refresh(NewchgObjectRevTag,TRUE));
				ITK(iFail,GRM_create_relation(NewchgObjectRevTag,tDatasetsTags[jnx],tTypeTag,NULLTAG,&tRelationTag));
				ITK(iFail,GRM_save_relation(tRelationTag));
				ITK(iFail,AOM_save(NewchgObjectRevTag));
				ITK(iFail,AOM_refresh(NewchgObjectRevTag,FALSE));
			}

		}
		EMR_free(tDatasetsTags);
	}

	return iFail;
}

/**************************************************************************************
*	Function name	:	fnGetNewRevisionValue

*	Description		:	This Function is used getting the New Revision Value  of Item

***************************************************************************************/
int fnGetNewRevisionValue (char * revid,			/* <I> */
						   tag_t tItemTag,			/* <I> */
						   char** NewRevisionId		/* <O> */
						  )
{
	int iFail = ITK_ok;
	logical revDoesntExist = true;
	char *cpRevisionID = NULL;
	char *cpCopyValue = NULL;
	while(revDoesntExist)
	{
		logical booleancheck = false;
		ITK(iFail,fnToCheckRevDoesNotExists(revid,tItemTag,&booleancheck));
		revDoesntExist = booleancheck;
		if(revDoesntExist)
		{
			ITK(iFail,fnToIncrementRevisionId(revid,tItemTag,&cpRevisionID));
			tc_strcpy(revid,cpRevisionID);
		}
		else
		{
			*NewRevisionId = (char *)MEM_alloc(tc_strlen(revid));
			tc_strcpy(*NewRevisionId ,revid);
			//*NewRevisionId = revid;
			break;
		}
	}
	return ITK_ok;
}

/**************************************************************************************
*	Function name	:	fnToCheckRevDoesNotExists

*	Description		:	This Function is used checking  the Revision  alredy exists or not

***************************************************************************************/

int fnToCheckRevDoesNotExists(	char * revid,			/* <I> */
				 				tag_t tItemTag,			/* <I> */
				 				logical* booleancheck	/* <O> */
				 			 )
{
	int		iFail		=	ITK_ok;
	int		inx			=	0;
	int iRevCount		=	0;
	int iStrCount		=	0;
	char **revIdArray	=	NULL;
	char ** StrList		=	NULL;
	tag_t * tRevTags	=	NULL;
	logical revExists	=	false;
	logical isMinorRev	=	false;
	* booleancheck	=	false;

	
	//get all revisions of item and checking
	ITK(iFail,ITEM_list_all_revs(tItemTag,&iRevCount,&tRevTags));
	if(iRevCount > 0 && tRevTags != NULL)
	{
		for(inx ; inx < iRevCount ; inx++)
		{
			char * cpAllRevId	=	NULL;
			ITK(iFail,ITEM_ask_rev_id2(tRevTags[inx],&cpAllRevId));
			if(cpAllRevId != NULL && tc_strcmp(cpAllRevId,revid) == 0)
			{
				* booleancheck = true;
				break;
			}
			EMR_free(cpAllRevId);
		}
	}
	
	return iFail;
}

/**************************************************************************************
*	Function name	:	fnToIncrementRevisionId

*	Description		:	This Function is used checking  increasing the revisionId value

***************************************************************************************/
int fnToIncrementRevisionId(char * revid,			/* <I> */
				 			tag_t tItemTag,			/* <I> */
				 			char ** NewRevid		/* <O> */
				 		   )
{
	int iFail = ITK_ok;
	int iStrCount		=	0;
	char ** StrList		=	NULL;
	logical isMinorRev	=	false;
	*NewRevid =	NULL;

	ITK(iFail,EPM__parse_string(revid,".",&iStrCount,&StrList));
	if(iStrCount > 1)
	{
		isMinorRev	=	true;
	}

	if(isMinorRev)
	{	
		int y = 0;
		y=strlen(StrList[1]);
		char cpIntValueIn[10];
		char * cpIncrementValue = (char *)MEM_alloc(10);
		ITK(iFail,fnsubStringForMinorRev(StrList[1],y,&cpIncrementValue));
		int latestrev = 0;
		latestrev = atoi(cpIncrementValue);
		latestrev++;
		char* new_rev_id = (char *)MEM_alloc(10);
		itoa(latestrev,new_rev_id,10); 


		char* new_rev = (char *)MEM_alloc(10);
		tc_strcpy(new_rev,StrList[0]);
		tc_strcat(new_rev,".M");
		tc_strcat(new_rev,new_rev_id);
		
		//itoa(latestrev,new_rev,10); 
		if(new_rev != NULL)
		{
			*NewRevid =(char *)MEM_alloc(tc_strlen(cpIntValueIn)+1);
			//*NewRevid	=	new_rev;
			tc_strcpy(cpIntValueIn,new_rev);
			tc_strcpy(*NewRevid,cpIntValueIn);
		}
		LBT9_MEM_free_Strings(StrList,iStrCount);
		EMR_free(cpIncrementValue);
		EMR_free(new_rev_id);
		EMR_free(new_rev);
		
	}
	else
	{
		int z = atoi(StrList[0]);
		z++;
		char new_rev[30];
		char* new_rev_id = (char *)MEM_alloc(tc_strlen(StrList[0]));
		itoa(z,new_rev_id,10);
		if(new_rev_id != NULL)
		{
			*NewRevid =(char *)MEM_alloc(tc_strlen(new_rev)+1);
			tc_strcpy(new_rev,new_rev_id);
			tc_strcpy(*NewRevid,new_rev);
			//*NewRevid	=	new_rev;
		}
		LBT9_MEM_free_Strings(StrList,iStrCount);
		EMR_free(new_rev_id);
	}

	return ITK_ok;
}


/**************************************************************************************
*	Function name	:	fnsubStringForMinorRev

*	Description		:	This Function is used for getting the substring of string

***************************************************************************************/

int  fnsubStringForMinorRev(char*  String,						/* <I> */ 
							int endvalue,						/* <I> */
							char ** subString					/* <OF> */
						   )
{
	int retcode =	ITK_ok;

	//char String[40];
	char finalsubString[30];
	*subString = NULL;
	int position=2;
	int c=0;
	while(c<endvalue)
	{
		finalsubString[c]=String[position+c-1];
		c++;
	}
	finalsubString[c] = '\0';
	*subString = (char *)MEM_alloc(tc_strlen(finalsubString));
	tc_strcpy(*subString,finalsubString);

	return retcode;
}
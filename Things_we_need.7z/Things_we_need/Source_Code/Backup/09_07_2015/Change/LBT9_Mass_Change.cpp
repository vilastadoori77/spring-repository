/******************************************************************************************

File			:	LBT9_Mass_Change.cpp

Description		:	CPP file for handling mass change related functions 

Author			:   Aravinth Rajendran

Date created	:   17/07/2015
	

*******************************************************************************************
History Log:

  Date            Author                    Action

  17/07/2015	  Aravinth Rajendran		Initial Version

  17/07/2015	  Aravinth Rajendran		processPartNumber

  18/07/2015	  Aravinth Rajendran		processBOMForAssemblyRev

  18/07/2015	  Aravinth Rajendran		fnToCheckLRRofItemMassChange
		
******************************************************************************************/
# include "LBT9_Change_Handler.h"

extern int performMassChange	(void *returnValueType) {
	int retcode = ITK_ok;
	
	int iCountOfPartTokens = 0;
	int iCountOfTokens = 0;
	char* strAssemblyString = NULL;char* strPartNumber = NULL;char* strMode = NULL;
	char* strReplacingPartNumber = NULL;char* strECNNumber = NULL;
	char** partstringarray = NULL;char** partarray = NULL;
	char* strPartString = NULL;char* strAssemblyPartNo = NULL;char* strAssemblyPartRev = NULL;
	tag_t ecn_tag = NULLTAG;tag_t ecn_rev_tag = NULLTAG;

	/* Get the Assembly String */
	/* Assembly String format: 200059,2000060,200032 */
	ITK(retcode,USERARG_get_string_argument(&strAssemblyString));

	/* Get the Part Number String */
	ITK(retcode,USERARG_get_string_argument(&strPartNumber));

	/* Get the Mode String */
	ITK(retcode,USERARG_get_string_argument(&strMode));

	/* Get the Replacing Part Number String */
	ITK(retcode,USERARG_get_string_argument(&strReplacingPartNumber));

	/* Get the ECN Number */
	ITK(retcode,USERARG_get_string_argument(&strECNNumber));

	// Step 1: Find the ECN Item Tag and from the ECN item tag, get the ECN item revision tag
	ITEM_find_item(strECNNumber,&ecn_tag);
	if(ecn_tag != NULLTAG) {
		ITEM_ask_latest_rev(ecn_tag,&ecn_rev_tag);

		// Step 2: Parse the list of assemblies using ,
		ITK(retcode,EPM__parse_string(strAssemblyString,",",&iCountOfPartTokens,&partstringarray));
	
		for(int iMasterIndex=0;iMasterIndex<iCountOfPartTokens;iMasterIndex++) {
			strAssemblyPartNo = partstringarray[iMasterIndex]; // 200059
			processPartNumber(strAssemblyPartNo,strPartNumber, ecn_rev_tag, strMode, strReplacingPartNumber);
		}
	}
	return 0;
}

/*******************************************************************************************
*	Function Name : processPartNumber

*	Description   :	This function finds the assembly to be processed and creates a new 
	                revision of the assembly. Invokes processBOMForAssemblyRev to make the
					required set of BOM changes and then connects the new revision of
					assembly to the ECN Revision
********************************************************************************************/

int processPartNumber(char* strAssemblyPartNo, char* strPartNumber, tag_t ecn_rev_tag, char* strMode, char* strReplacingPartNumber) {
	tag_t assembly_item_tag = NULLTAG;
	tag_t assembly_new_rev_tag = NULLTAG;
	tag_t tLatest_Assembly_Rev_Tag	=NULLTAG;
	// Step 1: Find the item tag of the assembly
	ITEM_find_item(strAssemblyPartNo,&assembly_item_tag);
	if(assembly_item_tag != NULLTAG) {
		// Step 2: Create new revision of the assembly
		fnToCheckLRRofItemMassChange(assembly_item_tag,&tLatest_Assembly_Rev_Tag);
		if(tLatest_Assembly_Rev_Tag != NULLTAG)
		{
			ITEM_copy_rev(tLatest_Assembly_Rev_Tag,NULL,&assembly_new_rev_tag);
		}
		else
		{
			ITEM_ask_latest_rev(assembly_item_tag,&assembly_new_rev_tag);
		}
		//ITEM_create_rev(assembly_item_tag,NULL,&assembly_new_rev_tag);
		if(assembly_new_rev_tag != NULLTAG) {
			// Step 3: Process BOM
			if(strMode != NULL &&(tc_strcmp(strMode,"Replace")==0 || tc_strcmp(strMode,"Remove")==0))
			{
				processBOMForAssemblyRev(assembly_new_rev_tag,assembly_item_tag,strPartNumber,strMode,strReplacingPartNumber);
			}
			

			// Step 4: Attach the new revision of assembly to ECN in CMHasSolutionItems relationship
			tag_t tRealtion_type_tag	=	NULLTAG;
			GRM_create_relation_type("CMHasSolutionItem",&tRealtion_type_tag);
			if(tRealtion_type_tag != NULLTAG)
			{
				tag_t RelationTag	=	NULLTAG;
				tag_t tIsExiststag	=	NULLTAG;
				GRM_create_relation(ecn_rev_tag,assembly_new_rev_tag,tRealtion_type_tag,NULLTAG,&RelationTag);
				AOM_refresh(ecn_rev_tag,TRUE);
				GRM_save_relation(RelationTag);
				AOM_save(ecn_rev_tag);
				AOM_refresh(ecn_rev_tag,FALSE);
				
			}
		}
	}
	return 0;
}


/*******************************************************************************************
*	Function Name : processBOMForAssemblyRev

*	Description   :	This function finds whether the part to be replaced or removed in the BOM
                    of the new revision of the assembly. Depending upon the mode, code either
					removes or replaces the part.												
********************************************************************************************/

int processBOMForAssemblyRev(tag_t assembly_new_rev_tag, tag_t assembly_item_tag, char* strPartNumber, char* strMode, char* strReplacingPartNumber) {

	int iBOMCount = 0;int iBOMIndex = 0;int iItemNoAttributeID = 0;
	char* bomline_item_id;char* bomline_attribute_name = "bl_item_item_id";
	tag_t bom_window_tag = NULLTAG;
	tag_t bom_top_line = NULLTAG;
	tag_t* bom_line_list = NULLTAG;
	tag_t bom_child_line = NULLTAG;
	tag_t replace_part_item_tag = NULLTAG;
	tag_t replace_part_rev_tag  = NULLTAG;

	BOM_create_window(&bom_window_tag);
	if(bom_window_tag != NULLTAG) {
		BOM_set_window_top_line(bom_window_tag,assembly_item_tag,assembly_new_rev_tag,NULLTAG,&bom_top_line);
		if(bom_top_line != NULLTAG) {
			BOM_line_ask_child_lines(bom_top_line,&iBOMCount,&bom_line_list);
			for(int iBOMIndex=0;iBOMIndex<iBOMCount;iBOMIndex++) {
				bom_child_line = bom_line_list[iBOMIndex];
				BOM_line_look_up_attribute(bomline_attribute_name,&iItemNoAttributeID);
				if(iItemNoAttributeID != 0) {
					BOM_line_ask_attribute_string(bom_child_line,iItemNoAttributeID,&bomline_item_id);
					if(bomline_item_id != NULL) {
						if(tc_strcmp(bomline_item_id, strPartNumber) == 0) {
							if(tc_strcmp(strMode, "Replace") == 0) {
								ITEM_find_item(strReplacingPartNumber,&replace_part_item_tag);
								if(replace_part_item_tag != NULLTAG) {
									fnToCheckLRRofItemMassChange(replace_part_item_tag,&replace_part_rev_tag);
									if(replace_part_rev_tag == NULLTAG) {
										
										ITEM_ask_latest_rev(replace_part_item_tag,&replace_part_rev_tag);
									}
									if(replace_part_rev_tag != NULLTAG) {
										
										BOM_line_replace(bom_child_line,replace_part_item_tag,replace_part_rev_tag,NULLTAG);
									} else {
										
										BOM_line_cut(bom_child_line);
									}
								}
							} else if(tc_strcmp(strMode, "Remove") == 0) {
								BOM_line_cut(bom_child_line);
							}
							break;
						}
					}
				}
			}
		}
		BOM_save_window(bom_window_tag);
		BOM_close_window(bom_window_tag);
		return 0;
	}
}


/*******************************************************************************************
*	Function Name : fnToCheckLRRofItemMassChange

*	Description   :	This function finds latest released revision of the given part or item
********************************************************************************************/
int fnToCheckLRRofItemMassChange	(tag_t tPartTag,							/* <I> */
									 tag_t *PartLRRTag							/* <O> */
									)
{
	int iFail = ITK_ok;
	int iStatusCount = 0;
	int iAllRevisionCount = 0;
	int iRevStatusCount = 0;
	tag_t *tRevStatusTags = NULL;
	tag_t *tStatusTags = NULL;
	tag_t *AllRevisionTags = NULL;
	logical LRRItemFound = false;
	logical DateValidation = false;
	int iPreviousDateCount = 0;
	*PartLRRTag = NULLTAG;
	std :: vector<date_t> AllPreviousRevisionDate; 
	date_t LRRRevisonDate;
	ITK(iFail,ITEM_list_all_revs(tPartTag,&iAllRevisionCount,&AllRevisionTags));
	if(AllRevisionTags != NULL && iAllRevisionCount > 0)
	{
		//getting the date of LRR and validating it with the previous released revisions 
		for(int i = iAllRevisionCount-1; i >= 0; i--)
		{
			ITK(iFail,AOM_ask_value_tags(AllRevisionTags[i],"release_status_list",&iStatusCount,&tStatusTags));
			if(tStatusTags != NULL && iStatusCount > 0)
			{
				char *cpStatusName = NULL;
				ITK(iFail,AOM_ask_value_string(tStatusTags[0],"object_name",&cpStatusName));
				if(cpStatusName != NULL && tc_strcmp(cpStatusName,"EMR_Released") == 0)
				{
					LRRItemFound = true;
					ITK(iFail,AOM_ask_value_date(tStatusTags[0],"date_released",&LRRRevisonDate));
					MEM_free(cpStatusName);
				}
			}
			if(LRRItemFound)
			{
				DateValidation = false;
				logical NoMoreRevisionExist = true;
				for(int j = i-1; j >= 0; j--)
				{
					NoMoreRevisionExist = false;
					ITK(iFail,AOM_ask_value_tags(AllRevisionTags[j],"release_status_list",&iRevStatusCount,&tRevStatusTags));
					if(tRevStatusTags != NULL && iRevStatusCount > 0)
					{
						char *cpRevStatusName = NULL;
						ITK(iFail,AOM_ask_value_string(tRevStatusTags[0],"object_name",&cpRevStatusName));
						if(cpRevStatusName != NULL && tc_strcmp(cpRevStatusName,"EMR_Released") == 0)
						{
							date_t PreviousRevisionDate;
							int answer = 0;
							ITK(iFail,AOM_ask_value_date(tRevStatusTags[0],"date_released",&PreviousRevisionDate));
							ITK(iFail,POM_compare_dates(LRRRevisonDate,PreviousRevisionDate,&answer));
							if(answer == 1 || answer > 1)
							{
								DateValidation = true;
							}
							MEM_free(cpRevStatusName);
						}
						else
						{
							DateValidation = true;
						}
					}
				}
				if(DateValidation || NoMoreRevisionExist)
				{
					*PartLRRTag = (tag_t) MEM_alloc(AllRevisionTags[i]*sizeof(tag_t));
					*PartLRRTag = AllRevisionTags[i];
					break;
				}
			}
		}
		MEM_free(tStatusTags);
		MEM_free(tRevStatusTags);
	}
	return ITK_ok;
}

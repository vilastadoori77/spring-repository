

/******************************************************************************************

File			:	LBRT_CR_Workflow.cpp

Description		:	Workflow action handlers for Libert

Author			:	Tanay Gupta			 		

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Tanay Gupta			 		Inital version

01/06/2015		Tanay Gupta			 		Added fnCRgetBUPreferenceValue

02/06/2015		Tanay Gupta			 		Added fnCRBodyForPreApprovalToPending

02/06/2015		Tanay Gupta			 		Added fnCRBodyForPreApprovalToSubmitted


******************************************************************************************/
#include "LBT9_Change_Handler.h"

using namespace std;


/**********************************************************************************************************************
*	Function name	:	fnCRgetBUPreferenceValue
*	Description		:	This Function is used to find the Change Analyst from the preference which is choosed based on the
						Business unit selected.												

***********************************************************************************************************************/



int fnCRgetBUPreferenceValue(char *BUValue,				/* <I> */
							 char **AnalystId			/* <OF> */
							 )
{

	int iFail = ITK_ok;
	*AnalystId	= NULL;
	char *cpAnalystId = NULL;
	if(tc_strcmp(BUValue,"Thermal Management") == 0)
	{
		ITK(iFail,PREF_ask_char_value("Thermal Management",0,&cpAnalystId));
		*AnalystId = (char *)MEM_alloc(tc_strlen(cpAnalystId) + 2);
		tc_strcpy(*AnalystId,cpAnalystId);
	}
	else if(tc_strcmp(BUValue,"AC Power") == 0)
	{
		ITK(iFail,PREF_ask_char_value("AC Power",0,&cpAnalystId));
		*AnalystId = (char *)MEM_alloc(tc_strlen(cpAnalystId) + 2);
		tc_strcpy(*AnalystId,cpAnalystId);
	}
	else if(tc_strcmp(BUValue,"Solutions") == 0)

	{
		ITK(iFail,PREF_ask_char_value("Solutions",0,&cpAnalystId));
		*AnalystId = (char *)MEM_alloc(tc_strlen(cpAnalystId) + 2);
		tc_strcpy(*AnalystId,cpAnalystId);
	}
	else if(tc_strcmp(BUValue,"Alber") == 0)
	{
		ITK(iFail,PREF_ask_char_value("Alber",0,&cpAnalystId));
		*AnalystId = (char *)MEM_alloc(tc_strlen(cpAnalystId) + 2);
		tc_strcpy(*AnalystId,cpAnalystId);
	}
	if(cpAnalystId != NULL)
	{
		EMR_free(cpAnalystId);
	}
	return ITK_ok;
}

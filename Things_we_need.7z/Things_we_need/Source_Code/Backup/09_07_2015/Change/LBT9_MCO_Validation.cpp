/*****************************************************************************************
           Copyright (c) 2015 Wipro Technologies Ltd.

******************************************************************************************
File        :	LBRT_action_handlers.c
Description :	Workflow action handlers for Libert Division 
				of Emerson Network Power.  

History Log:

Date          		Author                          Action
06/15/2015		Rahul Reddy A                Added functions as part of Implemented MCO W/F
					
******************************************************************************************/
#include "LBT9_Change_Handler.h"


//using namespace std;

/**
*	Function name	:	LBT9_VALIDATE_IMPLEMENT_MCO_WF
*	Description		:	Validate preconditions for MCO
*	Return type		:	int
*	Outputs 		:	N/A
*					 					  					 					  

******************************************************************************************/
extern EPM_decision_t LBT9_VALIDATE_IMPLEMENT_MCO_WF(EPM_rule_message_t message)
{
	int retcode = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	logical validationFailed = false;

	tag_t tRootTask				= NULLTAG;
	tag_t tMCORevTag			= NULLTAG;			
	tag_t *tsolutionRevTags		= NULL;
	tag_t *tMajorRevTags        = NULL;
	tag_t *tMinorRevTags		= NULL;
	tag_t *tSoultionItemsNoPreliminaryStatus = NULL;

	char *cpMajorRevList = NULL;
	int iSolutionRevsCount		= 0;
	int iMajorRevCount			= 0;
	int iMinorRevCount			= 0;
	int iSoultionItemsNoPreliminaryStatusCount = 0;

	logical Is_MCO_Validation_Ok = true;

	//vector<std::string> wrapper;
	char temp[SS_MAXLLEN] = "";
	//printf("entering into function <LBRT_VALIDATE_IMPLEMENT_MCO_WF> ...!");
	TC_write_syslog("libwiprocustom --- Exiting libwiprocustom.dll \n");

	ITK(retcode,EPM_ask_root_task (message.task, &tRootTask));		
	ITK(retcode,LBT_get_MCO_revision(tRootTask, CLASS_MCO_REVISION, EPM_target_attachment, &tMCORevTag));

	if (tMCORevTag == NULLTAG)
	{
		return decision;
	}
	else
	{
		ITK(retcode,LBT_get_related_objects(tMCORevTag,"CMHasSolutionItem", &iSolutionRevsCount, &tsolutionRevTags));
	}
	
	// Check# 1: Validation for atleast one commercial part revision in the solution items folder	
	if (iSolutionRevsCount == 0)
	{
		ITK(retcode,fnDisplayAlertForNoSolutionItems());
		return decision;
	}
	else if (iSolutionRevsCount > 0 && tsolutionRevTags != NULL)
	{
		//Check MCO Revision for Pending status
		vector<string> vReleaseStatusNames;
		ITK(retcode,fnGetItemReleasedStatusNames(tMCORevTag,vReleaseStatusNames));
		if (vReleaseStatusNames.size() == 1)
		{
			if (tc_strcmp(vReleaseStatusNames[0].c_str(),PENDING_STATUS) != 0)
			{
				tc_strcpy(temp,"\nMCO is not in Pending status.So, it cannnot be submitted to Implement MCO Workflow\n");
				//tc_strcat(temp,cpMajorRevList);
				Is_MCO_Validation_Ok = false;
				if (!Is_MCO_Validation_Ok)
				{
					EMH_store_initial_error_s1(EMH_severity_user_error, LBT_VALIDATION_MSG_MCO,temp);
					decision = EPM_nogo;
					return decision;
				}
			}
		}		
		// Check# 2: Check for the Major revisions exists under MCO
		ITK(retcode,fnGetMajorRevTags(tsolutionRevTags,iSolutionRevsCount,&iMajorRevCount,&tMajorRevTags));
		ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iMajorRevCount,tMajorRevTags,&cpMajorRevList));
		
		if (tc_strlen(cpMajorRevList) > 0 && cpMajorRevList != NULL)
		{
			tc_strcpy(temp,"\n--Following solution items are not minor revisions:\n");
			tc_strcat(temp,cpMajorRevList);
			//tc_strcat(temp,"\n");
			Is_MCO_Validation_Ok = false;
		}		
		//Minor Rev's validations
		//Check# 3: Check the status of the solution items is preliminary. System should throw an alert the user if solution items status other than preliminary
		char *cpSolutionItemsNoPreliminaryStatus = NULL;
		int iPreliminaryMinorRevCount = 0;
		tag_t *tPreliminaryMinorRevTags = NULL;
		ITK(retcode,fnGetMinorRevTags(tsolutionRevTags,iSolutionRevsCount,&iMinorRevCount,&tMinorRevTags));
		if (iMinorRevCount > 0 && tMinorRevTags)
		{
			ITK(retcode,fnGetSolutionItemsNoPreliminaryStatus(tMinorRevTags,iMinorRevCount,&iSoultionItemsNoPreliminaryStatusCount,&tSoultionItemsNoPreliminaryStatus));
			if (iSoultionItemsNoPreliminaryStatusCount > 0 && tSoultionItemsNoPreliminaryStatus != NULL)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iSoultionItemsNoPreliminaryStatusCount,tSoultionItemsNoPreliminaryStatus,&cpSolutionItemsNoPreliminaryStatus));
				if (tc_strlen(cpSolutionItemsNoPreliminaryStatus) > 0 && cpSolutionItemsNoPreliminaryStatus != NULL)
				{
					tc_strcat(temp,"\n--Following solution items are not in Preliminary state:\n");
					tc_strcat(temp,cpSolutionItemsNoPreliminaryStatus);
					Is_MCO_Validation_Ok = false;
				}
			}
			if (tSoultionItemsNoPreliminaryStatus != NULL)
				MEM_free(tSoultionItemsNoPreliminaryStatus);
			if (cpSolutionItemsNoPreliminaryStatus != NULL)
				MEM_free(cpSolutionItemsNoPreliminaryStatus);	
			// Get all the valid Minor Rev (Minor revs with only preliminary status)
			ITK(retcode,fnGetAllMinorRevsWithPreliminaryStatus(tMinorRevTags,iMinorRevCount,&iPreliminaryMinorRevCount,&tPreliminaryMinorRevTags));
		}	
		//Check# 4: Check whether its previous revisions exsiting with Preliminary status

		int iPreviousRevInvalidStatusCount = 0;
		tag_t *tPreviousRevInvalidStatusTags = NULL;
		char *cpPreviousRevIds = NULL;			

		if (iPreliminaryMinorRevCount > 0 && tPreliminaryMinorRevTags != NULL)
		{
			ITK(retcode,fnGetSolutionItemsPreviousWithPreliminaryStatus(tPreliminaryMinorRevTags,iPreliminaryMinorRevCount,&iPreviousRevInvalidStatusCount,&tPreviousRevInvalidStatusTags));

			if (iPreviousRevInvalidStatusCount > 0 && tPreviousRevInvalidStatusTags != NULL)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iPreviousRevInvalidStatusCount,tPreviousRevInvalidStatusTags,&cpPreviousRevIds));

				if (tc_strlen(cpPreviousRevIds) > 0 && cpPreviousRevIds != NULL)
				{
					tc_strcat(temp,"\n--Following solution items have previous revisions which are not in Prototype or Obsolete or Inactive or Released:\n");
					tc_strcat(temp,cpPreviousRevIds);
					Is_MCO_Validation_Ok = false;
				}
			}

			if (tPreviousRevInvalidStatusTags != NULL) 				MEM_free(tPreviousRevInvalidStatusTags);
			if (cpPreviousRevIds != NULL) 				MEM_free(cpPreviousRevIds);

			//Check# 5: Check whether target values provided by end user or not

			char *cpNoRelProSolItems = NULL;
			logical SetFlage = false;	

			//ITK(retcode,LBT_ValidateSolutionItemRelationProperties(tMCORevTag,iMinorRevCount,tMinorRevTags,&cpNoRelProSolItems));
			
			ITK(retcode,fnGetAllSolutionItemWithTargetValueEmpty(tMCORevTag,iPreliminaryMinorRevCount,tPreliminaryMinorRevTags,&cpNoRelProSolItems));
			if (tc_strlen(cpNoRelProSolItems) > 0 && cpNoRelProSolItems != NULL)
			{
				if (!SetFlage)
				{					
					tc_strcat(temp,"\n--Following Solution Items do not have a few mandatory values to be set for MCO submission:");
					SetFlage= true;
				}
				
				tc_strcat(temp,cpNoRelProSolItems);
				Is_MCO_Validation_Ok = false;
			}
			if (cpNoRelProSolItems != NULL)			MEM_free(cpNoRelProSolItems);

			//Check# 6: Check effective date set for the solution items is in future

			int iPastEffDateRevCount = 0;
			tag_t *tPastEffDateRevTags = NULL;
			char *cpPastEffDateItemIDs = NULL;
			ITK(retcode,LBT_get_past_effective_solution_items(tMCORevTag,iPreliminaryMinorRevCount,tPreliminaryMinorRevTags,&iPastEffDateRevCount,&tPastEffDateRevTags));

			if (iPastEffDateRevCount > 0 && tPastEffDateRevTags != NULL)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iPastEffDateRevCount,tPastEffDateRevTags,&cpPastEffDateItemIDs));
				if (tc_strlen(cpPastEffDateItemIDs) > 0 && cpPastEffDateItemIDs != NULL)
				{	
					char *cpEffectiveDatePatternMsg = NULL;
					//ITK(retcode,fnGetEffectiveDatepatternMsg(cpPastEffDateItemIDs,&cpEffectiveDatePatternMsg));
					if (!SetFlage)
					{
						tc_strcat(temp,"\n--Following Solution Items do not have a few mandatory values to be set for MCO submission:");
					}					
					tc_strcat(temp,"\n--Solution Item Effective date is past or not set:");
					tc_strcat(temp,cpPastEffDateItemIDs);
					Is_MCO_Validation_Ok = false;

					//if (cpEffectiveDatePatternMsg != NULL)MEM_free(cpEffectiveDatePatternMsg);
				}
			}
			if (tPastEffDateRevTags != NULL) MEM_free(tPastEffDateRevTags);
			if (cpPastEffDateItemIDs != NULL) MEM_free(cpPastEffDateItemIDs);
		}
		if (tPreliminaryMinorRevTags != NULL) MEM_free(tPreliminaryMinorRevTags);
	}
	if (!Is_MCO_Validation_Ok)
	{
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT_VALIDATION_MSG_MCO,temp);
		decision = EPM_nogo;
	}
	else if (Is_MCO_Validation_Ok)
	{
		decision = EPM_go;
	}

	if (tMajorRevTags != NULL)
		MEM_free(tMajorRevTags);
	if (cpMajorRevList != NULL)
		MEM_free(cpMajorRevList);

	return decision;
}
extern EPM_decision_t LBT9_VALIDATE_CANCEL_MCO_WF(EPM_rule_message_t message)
{
	int retcode = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	char temp[SS_MAXLLEN] = "";
	tag_t tRootTask				= NULLTAG;
	tag_t tMCORevTag			= NULLTAG;
	tag_t tOwningUserTag		= NULLTAG;
	tag_t tCurrentGroupmember   = NULLTAG;
	tag_t tCurrentUserTag		= NULLTAG;
	char *cpUserID				= NULL;
	char *cploginUserID			= NULL;
	char *cpObjectType			= NULL;
	logical ValidUser			= false;
	logical InValidStatusFlag	= false;
	logical IsSelectedObjectMCo = false;
	vector<string> vMCORevReleaseNames;

	ITK(retcode,EPM_ask_root_task (message.task, &tRootTask));	
	if (tRootTask != NULLTAG) ITK(retcode,LBT_get_MCO_revision(tRootTask, CLASS_MCO_REVISION, EPM_target_attachment, &tMCORevTag));

	if (tMCORevTag != NULLTAG)
	{	
		ITK(retcode,WSOM_ask_object_type2(tMCORevTag,&cpObjectType));
		if (tc_strlen(cpObjectType) > 0 && tc_strcmp("LBT9_MCORevision",cpObjectType) == 0)
		{
			IsSelectedObjectMCo = true;
		}
		EMR_free(cpObjectType);
	}
	if (IsSelectedObjectMCo)
	{
		ITK(retcode,fnGetItemReleasedStatusNames(tMCORevTag,vMCORevReleaseNames));
		ValidUser = IsInitiatedUserValid(tMCORevTag);
		//Check 1: Checking MCO rev is in Pending status or not
		if (vMCORevReleaseNames.size() == 1)
		{
			if (tc_strcmp(vMCORevReleaseNames[0].c_str(),PENDING_STATUS) == 0)
			{
				decision = EPM_go;
			}
			else
			{			
				tc_strcat(temp,"\nMCO is not in Pending status. So, it cannot be submitted to Cancel MCO Workflow.");			
				InValidStatusFlag = true;			
			}
		}
		else if (!InValidStatusFlag)
		{			
			tc_strcat(temp,"\nMCO is not in Pending status. So, it cannot be submitted to Cancel MCO Workflow.");
			InValidStatusFlag = true;		
		}
		//Check 2: Only originator or change analyst can submit cancel MCO w/f		
		if (ValidUser)
		{
			decision = EPM_go;							
		}
		else
		{
			tc_strcat(temp,"\nChange Analyst or Originator only can initiate Cancel MCO Workflow.");
		}
	
	}
	else
	{
		tc_strcat(temp,"\nSelected object is not a MCORevision. So, it cannot be submitted to Cancel MCO Workflow.");
	}
	
	if (InValidStatusFlag || !ValidUser)
	{
		decision = EPM_nogo;
	}
	if (decision == EPM_nogo)EMH_store_initial_error_s1(EMH_severity_user_error, LBT_VALIDATION_MSG_CANCEL_MCO,temp);

	return decision;
}
logical IsInitiatedUserValid(tag_t ItemRev)
{
	logical bValidUser = false;
	int retcode = ITK_ok;
	char *cpUserID				= NULL;
	char *cploginUserID			= NULL;
	char *cpAnalystId			= NULL;
	tag_t tOwningUserTag		= NULLTAG;
	tag_t tCurrentGroupmember   = NULLTAG;
	tag_t tCurrentUserTag		= NULLTAG;
	ITK(retcode,AOM_ask_value_tag(ItemRev,OWNING_USER,&tOwningUserTag));
	ITK(retcode,AOM_ask_value_string(ItemRev,"lbt9_Change_Analyst",&cpAnalystId));
	if (tOwningUserTag != NULLTAG)
	{
		ITK(retcode,SA_ask_user_identifier2(tOwningUserTag,&cpUserID));		
	}
	ITK(retcode,SA_ask_current_groupmember(&tCurrentGroupmember));
	if (tCurrentGroupmember != NULLTAG)
	{
		ITK(retcode,SA_ask_groupmember_user(tCurrentGroupmember, &tCurrentUserTag));

		if (tCurrentUserTag != NULLTAG)
		{
			ITK(retcode,SA_ask_user_identifier2(tCurrentUserTag,&cploginUserID));
		}
		if (tc_strlen(cploginUserID) > 0 && tc_strlen(cpUserID) > 0)
		{
			if (tc_strcmp(cploginUserID,cpUserID) == 0 || tc_strcmp(cploginUserID,cpAnalystId) == 0)
			{
				bValidUser = true;
			}
		}
	}
	EMR_free(cpAnalystId);
	EMR_free(cploginUserID);
	EMR_free(cpUserID);
	return bValidUser;
}
int fnGetEffectiveDatepatternMsg(char *cpInputString,  /*<I>*/
								 char **cpOutputString /*<OF>*/
								) 
{
	int retcode = ITK_ok;
	logical flage = false;
	*cpOutputString = NULL;
	char Temp[SS_MAXLLEN] = "";
	char **cpParseStringList = NULL;
	int iParseStringCount = 0;

	EPM__parse_string(cpInputString,";",&iParseStringCount,&cpParseStringList);

	if (tc_strlen(cpInputString) > 0 && iParseStringCount == 0)
	{
		iParseStringCount = 1;
	}

	for (int i = 0; i < iParseStringCount; i++)
	{
		if (!flage)
		{
			tc_strcpy(Temp,"Solution Item <");
			flage = true;
		}
		else
		{
			tc_strcat(Temp,"Solution Item <");
		}		
		tc_strcat(Temp,cpParseStringList[i]);
		tc_strcat(Temp,"> Effectivity date is past or not set");
		if (i < iParseStringCount -1)tc_strcat(Temp,"\n");		
	}

	*cpOutputString = (char *) MEM_alloc((tc_strlen(Temp)+1)*sizeof(char));
		tc_strcpy(*cpOutputString,Temp);

	return retcode;
}
int fnGetSolutionItemsPreviousWithPreliminaryStatus(tag_t *tsolutionRevTags,			/*<I>*/
													int iSolutionRevsCount,				/*<I>*/
													int *iInvalidPreviousRevCount,		/*<O>*/
													tag_t **tInvalidPreviousRevTags		/*<OF>*/
													)
{
	int retcode = ITK_ok;
	vector<tag_t> vPreviousRevWrapper;
	vPreviousRevWrapper.clear();
	//Loop for each solution items
	for (int i = 0; i < iSolutionRevsCount; i++)
	{
		int iPreviousRevsWithInvalidStatusCount = 0;
		tag_t *tPrevisousRevsWithInvalidStatusTags = NULL;
		// Get the tags of Previous revision with Preliminary status for each solution item
		//yet to implement this function
		ITK(retcode,fnGetPreviousRevsWithPreliminaryStatus(tsolutionRevTags[i],&iPreviousRevsWithInvalidStatusCount,&tPrevisousRevsWithInvalidStatusTags));

		if (iPreviousRevsWithInvalidStatusCount > 0 && tPrevisousRevsWithInvalidStatusTags != NULL)
		{
			vPreviousRevWrapper.push_back(tsolutionRevTags[i]);
			/*for (int k = 0; k < iPreviousRevsWithInvalidStatusCount; k++)
			{
				vPreviousRevWrapper.push_back(tPrevisousRevsWithInvalidStatusTags[k]);
			}*/
		}
	}

	if (vPreviousRevWrapper.size() > 0)
	{
		//Returing array of tags
		int count = vPreviousRevWrapper.size();
		*tInvalidPreviousRevTags = (tag_t *) MEM_realloc(*tInvalidPreviousRevTags,(count+1)*sizeof(tag_t));
		for (int n = 0; n < count; n++)
		{
			(*tInvalidPreviousRevTags)[n] = vPreviousRevWrapper[n];
			*iInvalidPreviousRevCount = n + 1;
		}
	}
	return retcode;
}
int fnGetAllSolutionItemWithTargetValueEmpty(tag_t rev_tag,                       /* <I> */
											 int n_solution_revs,                 /* <I> */
											 tag_t *solution_rev_tags,			  /* <I> */												
											 char **cpSolItemNoRelProValues		  /* <OF> */
											)
{
	int retcode = ITK_ok;

	*cpSolItemNoRelProValues = NULL;
	int iNOTargetStatusCount = 0;
	char Temp[SS_MAXLLEN] = "";
	tag_t *tNOTargetStatusTags = NULL; 

	//Get all the solution items having Target status value is empty
	ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Target_Status",&iNOTargetStatusCount,&tNOTargetStatusTags));

	if (iNOTargetStatusCount > 0 && tNOTargetStatusTags != NULL)
	{
		char *cpNOTargetStatusList = NULL;
		ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iNOTargetStatusCount,tNOTargetStatusTags,&cpNOTargetStatusList));

		if (tc_strlen(cpNOTargetStatusList) > 0 && cpNOTargetStatusList != NULL)
		{
			tc_strcat(Temp,"\n--Solution Item Target status is not set:");
			tc_strcat(Temp,cpNOTargetStatusList);
		}
		if (cpNOTargetStatusList != NULL) MEM_free(cpNOTargetStatusList);
	}
	if (tNOTargetStatusTags != NULL) MEM_free(tNOTargetStatusTags);

	//Get all the solution items having No Change Function value is empty
	int iNoChangeFunctionCount = 0;
	tag_t *tNoChangeFunctionTags = NULL;
	ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Change_Function",&iNoChangeFunctionCount,&tNoChangeFunctionTags));

	if (iNoChangeFunctionCount > 0 && tNoChangeFunctionTags != NULL)
	{
		char *cpNoChangeFunctionList = NULL;
		ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iNoChangeFunctionCount,tNoChangeFunctionTags,&cpNoChangeFunctionList));

		if (tc_strlen(cpNoChangeFunctionList) > 0 && cpNoChangeFunctionList != NULL)
		{
			tc_strcat(Temp,"\n--Solution Item Change function is not set:");
			tc_strcat(Temp,cpNoChangeFunctionList);
		}
		if (cpNoChangeFunctionList != NULL) MEM_free(cpNoChangeFunctionList);
	}
	if (tNoChangeFunctionTags != NULL) MEM_free(tNoChangeFunctionTags);

	////Get all the solution items having Field Mode value is empty
	//int iFieldModeCount = 0;
	//tag_t *tNoFieldModeTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Field_Mod",&iFieldModeCount,&tNoFieldModeTags));

	//if (iFieldModeCount > 0 && tNoFieldModeTags != NULL)
	//{
	//	char *cpNoFieldModeList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iFieldModeCount,tNoFieldModeTags,&cpNoFieldModeList));

	//	if (tc_strlen(cpNoFieldModeList) > 0 && cpNoFieldModeList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item Field Modification is not set:");
	//		tc_strcat(Temp,cpNoFieldModeList);
	//	}
	//	if (cpNoFieldModeList != NULL) MEM_free(cpNoFieldModeList);
	//}
	//if (tNoFieldModeTags != NULL) MEM_free(tNoFieldModeTags);

	////Get all the solution items having Finished Good value is empty 
	//int iFinishedGoodsCount = 0;
	//tag_t *tFinishedGoodsTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Finished_Goods",&iFinishedGoodsCount,&tFinishedGoodsTags));

	//if (iFinishedGoodsCount > 0 && tFinishedGoodsTags != NULL)
	//{
	//	char *cpNoFineshedGoodsList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iFinishedGoodsCount,tFinishedGoodsTags,&cpNoFineshedGoodsList));

	//	if (tc_strlen(cpNoFineshedGoodsList) > 0 && cpNoFineshedGoodsList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item Finished Goods is not set:");
	//		tc_strcat(Temp,cpNoFineshedGoodsList);
	//	}
	//	if (cpNoFineshedGoodsList != NULL) MEM_free(cpNoFineshedGoodsList);
	//}
	//if (tFinishedGoodsTags != NULL) MEM_free(tFinishedGoodsTags);
	//
	////Get all the solution items having Note value is empty
	//int iNoteCount = 0;
	//tag_t *tNoteTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Note",&iNoteCount,&tNoteTags));

	//if (iNoteCount > 0 && tNoteTags != NULL)
	//{
	//	char *cpNoNoteList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iNoteCount,tNoteTags,&cpNoNoteList));

	//	if (tc_strlen(cpNoNoteList) > 0 && cpNoNoteList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item Note is not set:");
	//		tc_strcat(Temp,cpNoNoteList);
	//	}
	//	if (cpNoNoteList != NULL) MEM_free(cpNoNoteList);
	//}
	//if (tNoteTags != NULL) MEM_free(tNoteTags);

	////Get all the solution items having On Order value is empty
	//int iOnOrderCount = 0;
	//tag_t *tOnOrderTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_On_Order",&iOnOrderCount,&tOnOrderTags));

	//if (iOnOrderCount > 0 && tOnOrderTags != NULL)
	//{
	//	char *cpOnOrderList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iOnOrderCount,tOnOrderTags,&cpOnOrderList));

	//	if (tc_strlen(cpOnOrderList) > 0 && cpOnOrderList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item On Order is not set:");
	//		tc_strcat(Temp,cpOnOrderList);
	//	}
	//	if (cpOnOrderList != NULL) MEM_free(cpOnOrderList);
	//}
	//if (tOnOrderTags != NULL) MEM_free(tOnOrderTags);

	////Get all the solution items having Stock value is empty
	//int iStockCount = 0;
	//tag_t *tStockTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Stock",&iStockCount,&tStockTags));

	//if (iStockCount > 0 && tStockTags != NULL)
	//{
	//	char *cpNoStockList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iStockCount,tStockTags,&cpNoStockList));

	//	if (tc_strlen(cpNoStockList) > 0 && cpNoStockList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item Stock is not set:");
	//		tc_strcat(Temp,cpNoStockList);
	//	}
	//	if (cpNoStockList != NULL) MEM_free(cpNoStockList);
	//}
	//if (tStockTags != NULL) MEM_free(tStockTags);

	////Get all the solution items having WIP value is empty
	//int iWIPCount = 0;
	//tag_t *tWIPTags = NULL;
	//ITK(retcode,LBT_get_solution_items_with_no_target_Attribute_Value(rev_tag,n_solution_revs,solution_rev_tags,"lbt9_Work_In_Progress",&iWIPCount,&tWIPTags));

	//if (iWIPCount > 0 && tWIPTags != NULL)
	//{
	//	char *cpNoWIPList = NULL;
	//	ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(iWIPCount,tWIPTags,&cpNoWIPList));

	//	if (tc_strlen(cpNoWIPList) > 0 && cpNoWIPList != NULL)
	//	{
	//		tc_strcat(Temp,"\n--Solution Item WIP is not set:");
	//		tc_strcat(Temp,cpNoWIPList);
	//	}
	//	if (cpNoWIPList != NULL) MEM_free(cpNoWIPList);
	//}
	//if (tWIPTags != NULL) MEM_free(tWIPTags);

	// Memory allocation and return into a string
	*cpSolItemNoRelProValues = (char *) MEM_alloc((tc_strlen(Temp)+1)*sizeof(char));
	tc_strcpy(*cpSolItemNoRelProValues, Temp);

	return retcode;
}
int LBT_get_solution_items_with_no_target_Attribute_Value(tag_t rev_tag,                  /* <I> */
														  int n_solution_revs,            /* <I> */
														  tag_t *solution_rev_tags,       /* <I> */
														  char *cpAttributeValue,		  /* <I> */
														  int *n_no_target_sol_revs,      /* <O> */
														  tag_t **no_target_sol_rev_tags  /* <OF> */
														)
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	*n_no_target_sol_revs = 0;
	*no_target_sol_rev_tags = NULL;
	if (tc_strlen(cpAttributeValue) > 0 && cpAttributeValue != NULL)
	{
		
	}
	else
	{
		return retcode;
	}
	ITK(retcode,GRM_find_relation_type("CMHasSolutionItem", &relation_type_tag));
	
	if ( relation_type_tag == NULLTAG )
	{
		return retcode;
	}
	
	for (int inx = 0; inx < n_solution_revs; inx++)
	{
		tag_t relation_tag = NULLTAG;
		
		ITK(retcode,GRM_find_relation(rev_tag, solution_rev_tags[inx], relation_type_tag, &relation_tag));
		
		if ( relation_tag != NULLTAG )
		{
			//fnGetItemTagsForRelationalProperties(relation_tag,solution_rev_tags[inx], "lbt9_Target_Status",n_no_target_sol_revs,no_target_sol_rev_tags);
			char *target_status = NULL;
			
			//ITK(retcode,AOM_ask_value_string(relation_tag, "lbt9_Target_Status", &target_status));
			ITK(retcode,AOM_ask_value_string(relation_tag,cpAttributeValue, &target_status));
			//printf("Target Status : %s\n", target_status);
			
			if ( target_status == NULL || tc_strlen(target_status) <= 0 )
			{
				*no_target_sol_rev_tags = (tag_t *) MEM_realloc(*no_target_sol_rev_tags,(*n_no_target_sol_revs+1)*sizeof(tag_t));
				(*no_target_sol_rev_tags)[*n_no_target_sol_revs] = solution_rev_tags[inx];
				*n_no_target_sol_revs = *n_no_target_sol_revs + 1;
			}
			
			MEM_free(target_status);
		}
	}
	
	return retcode;
}
int LBT_ValidateSolutionItemRelationProperties(tag_t rev_tag,                         /* <I> */
                                                 int n_solution_revs,                 /* <I> */
												 tag_t *solution_rev_tags,			  /* <I> */												
												 char **cpSolItemNoRelProValues  /* <OF> */
												)
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	char temp[SS_MAXLLEN] = "";
	*cpSolItemNoRelProValues = NULL;
	logical flage = false;
	//*n_no_target_sol_revs = 0;
	//*no_target_sol_rev_tags = NULL;
	
	ITK(retcode,GRM_find_relation_type("CMHasSolutionItem", &relation_type_tag));
	
	if ( relation_type_tag == NULLTAG )
	{
		return retcode;
	}
	
	for (int inx = 0; inx < n_solution_revs; inx++)
	{
		tag_t relation_tag = NULLTAG;
		
		ITK(retcode,GRM_find_relation(rev_tag, solution_rev_tags[inx], relation_type_tag, &relation_tag));
		
		if ( relation_tag != NULLTAG )
		{
			//fnGetItemTagsForRelationalProperties(relation_tag,solution_rev_tags[inx], "lbt9_Target_Status",n_no_target_sol_revs,no_target_sol_rev_tags);
			char *cpSolItemEmptyRelProNames = NULL;
			char *ItemIdValue = NULL;
			//ITK(retcode,AOM_ask_value_string(relation_tag, "lbt9_Target_Status", &target_status));
			ITK(retcode,fnGetEmptyPropertyValues(relation_tag,&cpSolItemEmptyRelProNames));

			if (tc_strlen(cpSolItemEmptyRelProNames) > 0 && cpSolItemEmptyRelProNames != NULL)
			{				
				LBT_getCommaSeparatedListOfItemRevs(1,&solution_rev_tags[inx],&ItemIdValue);
				if (tc_strlen(ItemIdValue) > 0 && ItemIdValue != NULL)
				{
					if (!flage)
					{
						tc_strcpy(temp,"Solution Item <");
						flage =  true;
					}
					else
					{
						tc_strcat(temp,"Solution Item <");
					}
					tc_strcat(temp,ItemIdValue);
					tc_strcat(temp,"> <");					
					tc_strcat(temp,cpSolItemEmptyRelProNames);
					tc_strcat(temp,"> is/are not set");
					//tc_strcat(temp,": Following Properties are empty i.e ");
					if (inx < n_solution_revs-1) tc_strcat(temp,"\n");					
				}				
			}	
			if (cpSolItemEmptyRelProNames != NULL)
			{
				MEM_free(cpSolItemEmptyRelProNames);
			}
			if (ItemIdValue != NULL)
			{
				MEM_free(ItemIdValue);
			}			
		}
	}
	
	if (tc_strlen(temp) > 0 && temp != NULL)
	{
		*cpSolItemNoRelProValues = (char *) MEM_alloc((tc_strlen(temp)+1)*sizeof(char));
		tc_strcpy(*cpSolItemNoRelProValues, temp);	
	}

	return retcode;
}
int fnGetEmptyPropertyValues(tag_t tRelationTag,	/*<I>*/
						 char **cpProNames		/*<OF>*/
						)
{
	int retcode = ITK_ok;
	char Temp[SS_MAXLLEN] = ""; 
	*cpProNames				  = NULL;
	char *cpTargetStatusValue = NULL;
	char *cpChangeFunValue    = NULL;
	char *cpFieldModValue    = NULL;
	char *cpFineshedGoodValue    = NULL;
	char *cpNoteValue    = NULL;
	char *cpOnOrderValue    = NULL; 
	char *cpStockValue    = NULL; 
	char *cpWIPValue    = NULL;
	logical flage = false;

	AOM_ask_value_string(tRelationTag,Attr_TARGET_STATUS,&cpTargetStatusValue);
	AOM_ask_value_string(tRelationTag,Attr_CHANGE_FUNCTION,&cpChangeFunValue);
	AOM_ask_value_string(tRelationTag,Attr_FIELD_MOD,&cpFieldModValue);
	AOM_ask_value_string(tRelationTag,Attr_FINISHED_GOOD,&cpFineshedGoodValue);
	AOM_ask_value_string(tRelationTag,Attr_NOTE,&cpNoteValue);
	AOM_ask_value_string(tRelationTag,Attr_ON_ORDER,&cpOnOrderValue);
	AOM_ask_value_string(tRelationTag,Attr_STOCK,&cpStockValue);
	AOM_ask_value_string(tRelationTag,Attr_WIP_STATUS,&cpWIPValue);

	if (cpTargetStatusValue == NULL || tc_strcmp(cpTargetStatusValue,"") == 0)
	{
		tc_strcpy(Temp,Attr_TARGET_STATUS);
		flage = true;
	}
	if (cpChangeFunValue == NULL || tc_strcmp(cpChangeFunValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_CHANGE_FUNCTION);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_CHANGE_FUNCTION);
		}			
	}
	if (cpFieldModValue == NULL || tc_strcmp(cpFieldModValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_FIELD_MOD);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_FIELD_MOD);
		}			
	}
	if (cpFineshedGoodValue == NULL || tc_strcmp(cpFineshedGoodValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_FINISHED_GOOD);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_FINISHED_GOOD);
		}			
	}
	if (cpNoteValue == NULL || tc_strcmp(cpNoteValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_NOTE);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_NOTE);
		}			
	}
	if (cpOnOrderValue == NULL || tc_strcmp(cpOnOrderValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_ON_ORDER);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_ON_ORDER);
		}			
	}
	if (cpStockValue == NULL || tc_strcmp(cpStockValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_STOCK);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_STOCK);
		}
	}
	if (cpWIPValue == NULL || tc_strcmp(cpWIPValue,"") == 0)
	{
		if (flage)
		{
			tc_strcat(Temp,",");
			tc_strcat(Temp,Attr_WIP_STATUS);
		}	
		else
		{
			flage = true;
			tc_strcpy(Temp,Attr_WIP_STATUS);
		}
	}

	if (tc_strlen(Temp) > 0 && Temp != NULL)
	{
		*cpProNames = (char *) MEM_alloc((tc_strlen(Temp)+1)*sizeof(char));
		tc_strcpy(*cpProNames, Temp);
	}

	return retcode;
}
int fnGetPreviousRevsWithPreliminaryStatus(tag_t tItemRevTag,								/*<I>*/
										   int *iPreviousRevWithPreliminaryStatusCount,		/*<O>*/
										   tag_t **tPreviousRevWithPreliminaryStatusTags	/*<OF>*/
										  )
{
	int retcode = ITK_ok; 
	int iRevCount = 0;
	char *cpSolutionItemRevID = NULL;
	tag_t ItemTag = NULLTAG;
	tag_t *tRevList = NULL;
	logical IsPreviousRevWithPreliminaryStatus = false;

	vector<tag_t> vPrevisousRevPreliminaryStatusWrapper;
	vPrevisousRevPreliminaryStatusWrapper.clear();

	ITEM_ask_item_of_rev(tItemRevTag,&ItemTag);
	ITEM_ask_rev_id2(tItemRevTag,&cpSolutionItemRevID);

	if (ItemTag != NULLTAG)
	{
		ITEM_list_all_revs(ItemTag,&iRevCount,&tRevList);
		if (iRevCount > 1)
		{
			for (int inx = 0; inx < iRevCount; inx++)
			{
				char *cpItemRevID = NULL;
				ITEM_ask_rev_id2(tRevList[inx],&cpItemRevID);

				if (tc_strlen(cpItemRevID) > 0 && tc_strcmp(cpSolutionItemRevID,cpItemRevID) == 0)
				{
					break;
				}
				else
				{
					IsPreviousRevWithPreliminaryStatus = IsItemRevWithPreliminaryStatus(tRevList[inx]);

					if (IsPreviousRevWithPreliminaryStatus)
					{
						vPrevisousRevPreliminaryStatusWrapper.push_back(tRevList[inx]);
					}
				}
			}
			if (tRevList != NULL)
				MEM_free(tRevList);
		}
		else
		{
			return retcode;
		}
		
	}
	
	if (vPrevisousRevPreliminaryStatusWrapper.size() > 0)
	{
		//Returing of array tags
		//Returing array of tags
		int count = vPrevisousRevPreliminaryStatusWrapper.size();
		*tPreviousRevWithPreliminaryStatusTags = (tag_t *) MEM_realloc(*tPreviousRevWithPreliminaryStatusTags,(count+1)*sizeof(tag_t));
		for (int n = 0; n < count; n++)
		{
			(*tPreviousRevWithPreliminaryStatusTags)[n] = vPrevisousRevPreliminaryStatusWrapper[n];
			*iPreviousRevWithPreliminaryStatusCount = n + 1;
		}		
	}
	return retcode;
}
logical IsItemRevWithPreliminaryStatus(tag_t tItemRevTag  /*<I>*/
									  )
{
	int retcode = ITK_ok; 
	logical IsPreliminaryStatusExist =false;
	vector<string> vItemRevReleaseNames;

	ITK(retcode,fnGetItemReleasedStatusNames(tItemRevTag,vItemRevReleaseNames));

	if (vItemRevReleaseNames.size() > 0)
	{
		int count  = vItemRevReleaseNames.size();
		for (int i = 0; i < count; i++)
		{
			if (tc_strlen(vItemRevReleaseNames[i].c_str()) > 0 && tc_strcmp(vItemRevReleaseNames[i].c_str(),PRELIMINARY) == 0)
			{
				IsPreliminaryStatusExist = true;
				break;
			}
		}
	}

	return IsPreliminaryStatusExist;
}
int fnGetAllMinorRevsWithPreliminaryStatus(tag_t *tMinorRevs,		/*<I>*/
										  int iMinorRevsCount,		/*<I>*/
										  int *iPreliminaryMinorRevCount,  /*<O>*/
										  tag_t **tPreliminaryMinorRevTags		/*<OF>*/
										  )
{
	int retcode = ITK_ok;
	*tPreliminaryMinorRevTags = NULL;
	//logical IsPreliminaryStatusExist = false;
	vector<string> ReleasedStatusNames;
	vector<tag_t> wrapper;
	wrapper.clear();
	//counted_tag_list_t tTagList = NULL_COUNTED_TAG_LIST;
	// Get the item tags which were not having preliminary status
	for (int inx = 0; inx < iMinorRevsCount; inx++)
	{
		int Is_released;
		//logical IsSolutiionItemRevMinor = false;

		ITK(retcode,CR_ask_if_released(tMinorRevs[inx],&Is_released));
		//IsSolutiionItemRevMinor = fnIsSolutionItemMinorRev(tsolutionRevTags[inx]);

		if (Is_released)
		{
			fnGetItemReleasedStatusNames(tMinorRevs[inx],ReleasedStatusNames);

			if (ReleasedStatusNames.size() == 1)
			{
				if (ReleasedStatusNames[0].length() > 0 && tc_strcmp(ReleasedStatusNames[0].c_str(),PRELIMINARY) == 0)
				{
					//IsPreliminaryStatusExist = true;
					wrapper.push_back(tMinorRevs[inx]);
				}
			}			
		}				
	}

	if (wrapper.size() > 0)
	{
		int count = wrapper.size();
		*tPreliminaryMinorRevTags = (tag_t *) MEM_realloc(*tPreliminaryMinorRevTags,(count+1)*sizeof(tag_t));
		for (int n = 0; n < count; n++)
		{
			(*tPreliminaryMinorRevTags)[n] = wrapper[n];
			*iPreliminaryMinorRevCount = n + 1;
		}		
	}

	return retcode;
}
int fnGetSolutionItemsNoPreliminaryStatus(tag_t *tsolutionRevTags,		/*<I>*/
										  int iSolutionRevsCount,		/*<I>*/
										  int *iSolutionItemsNoPreliminaryStatusCount,  /*<O>*/
										  tag_t **tSolutionItemsNoPreliminaryStatus		/*<OF>*/
										  )
{
	int retcode = ITK_ok; 
	logical IsPreliminaryStatusExist = false;
	vector<string> ReleasedStatusNames;
	vector<tag_t> wrapper;
	wrapper.clear();
	//counted_tag_list_t tTagList = NULL_COUNTED_TAG_LIST;
	// Get the item tags which were not having preliminary status
	for (int inx = 0; inx < iSolutionRevsCount; inx++)
	{
		int Is_released;
		logical IsSolutiionItemRevMinor = false;

		ITK(retcode,CR_ask_if_released(tsolutionRevTags[inx],&Is_released));
		IsSolutiionItemRevMinor = fnIsSolutionItemMinorRev(tsolutionRevTags[inx]);

		if (Is_released && !(IsSolutiionItemRevMinor))
		{
			fnGetItemReleasedStatusNames(tsolutionRevTags[inx],ReleasedStatusNames);

			for (int k = 0; k < ReleasedStatusNames.size(); k ++)
			{
			
				if (ReleasedStatusNames[k].length() > 0 && tc_strcmp(ReleasedStatusNames[k].c_str(),PRELIMINARY) == 0)
				{
					IsPreliminaryStatusExist = true;
					break;
				}
				else
				{
					IsPreliminaryStatusExist = false;
				}
			}

			if (!IsPreliminaryStatusExist)
			{
				wrapper.push_back(tsolutionRevTags[inx]);
			}
		}
		else if (IsSolutiionItemRevMinor)
		{
			//EPM__add_to_tag_list(tsolutionRevTags[inx],&tTagList);
			wrapper.push_back(tsolutionRevTags[inx]);			
		}		
	}

	if (wrapper.size() > 0)
	{
		int count = wrapper.size();
		*tSolutionItemsNoPreliminaryStatus = (tag_t *) MEM_realloc(*tSolutionItemsNoPreliminaryStatus,(count+1)*sizeof(tag_t));
		for (int n = 0; n < count; n++)
		{
			(*tSolutionItemsNoPreliminaryStatus)[n] = wrapper[n];
			*iSolutionItemsNoPreliminaryStatusCount = n + 1;
		}		
	}
	return retcode;
}
logical fnIsSolutionItemMinorRev(tag_t ItemRev		/*I*/
								)
{
	int retcode = ITK_ok;
	logical IsMinorRevIDInValid = false;

	char *ItemRevID = NULL;
	char *chMinorRevFinder = NULL;
	int iDelimitorCount = 0;
	char **cpParseStringList = NULL;
	ITK(retcode,ITEM_ask_rev_id2(ItemRev,&ItemRevID));
	ITK(retcode,EPM__parse_string(ItemRevID,".",&iDelimitorCount,&cpParseStringList));
	if (iDelimitorCount == 1)
	{
		IsMinorRevIDInValid = true;
	}

	for (int i = 1; i < iDelimitorCount; i++)
	{
		chMinorRevFinder = (char *)MEM_alloc(tc_strlen(cpParseStringList[i]) + 1);
		tc_strcpy(chMinorRevFinder,"");
		tc_strcpy(chMinorRevFinder,cpParseStringList[i]);
		int iCount = tc_strlen(chMinorRevFinder);
		for (int j = 0; j < iCount; j++)
		{
			if (isalpha(chMinorRevFinder[0]))
			{ 
				char *MatchString = NULL;
				MatchString = STRNG_find_first_char(chMinorRevFinder,'M');				
				if (MatchString == NULL)
				{
					IsMinorRevIDInValid = true;
				}
			}
			else
			{
				IsMinorRevIDInValid = true;
			}			
			if (IsMinorRevIDInValid)
			{
				break;
			}
		}
		if (IsMinorRevIDInValid)
		{
			break;
		}
	}	
	
	if (ItemRevID != NULL)
	MEM_free(ItemRevID);
	if (cpParseStringList != NULL)
	MEM_free(cpParseStringList);
	return IsMinorRevIDInValid;
}
int fnGetItemReleasedStatusNames(tag_t titemRev,
								 std::vector<std::string>& ReleasedStatusNames 
								)
{
	int retcode = ITK_ok; 
	int iStatusCount = 0;
	
	tag_t *tStatusList = NULL;
	ReleasedStatusNames.clear();
	WSOM_ask_release_status_list(titemRev,&iStatusCount,&tStatusList);
	

	for (int i  = 0; i < iStatusCount; i++)
	{
		char *cpReleaseStatusName = NULL;

		AOM_ask_value_string(tStatusList[i],OBJECT_NAME,&cpReleaseStatusName);
		ReleasedStatusNames.push_back(cpReleaseStatusName);

		if (cpReleaseStatusName != NULL)
		MEM_free(cpReleaseStatusName);
	}

	return retcode;
}
int fnGetMajorRevTags(tag_t *tsolutionRevTags,   /*<I>*/
					  int iSolutionRevsCount,    /*<I>*/
					  int *iMajorRevCount,       /*<O>*/
					  tag_t **tMajorRevTags        /*<OF>*/
					 )
{
	int retcode = ITK_ok;
	char *chMinorRevFinder  = NULL;
	for (int inx  = 0; inx < iSolutionRevsCount; inx++)
	{
		char *ItemRevID = NULL;
		logical IsMajorRevIDInValid = false;
		IsMajorRevIDInValid  = ValidateMajorRevID(tsolutionRevTags[inx]);

		if (!IsMajorRevIDInValid)
		{
			*tMajorRevTags = (tag_t *) MEM_realloc(*tMajorRevTags,(*iMajorRevCount+1)*sizeof(tag_t));
			(*tMajorRevTags)[*iMajorRevCount] = tsolutionRevTags[inx];
			*iMajorRevCount = *iMajorRevCount + 1;
		}		

		if (ItemRevID != NULL)
		MEM_free(ItemRevID);
	}

	return retcode;
}
logical ValidateMajorRevID(tag_t majorRevTag)
{
	int retcode = ITK_ok;
	char *ItemRevID = NULL;
	int iDelimitorCount = 0;
	char **cpParseStringList = NULL;
	char *cpStringFinder1 = NULL;
	char *cpStringFinder = NULL;

	logical IsmajorRevIDInValid = false;

	ITK(retcode,ITEM_ask_rev_id2(majorRevTag,&ItemRevID));

	if (tc_strlen(ItemRevID) > 0 && ItemRevID != NULL)
	{
		cpStringFinder = (char *)MEM_alloc(30);		
		cpStringFinder1 = (char *)MEM_alloc(30);
		tc_strcpy(cpStringFinder," ");
		tc_strcpy(cpStringFinder1," ");
		cpStringFinder = tc_strstr(ItemRevID,".M0");
		cpStringFinder1 = tc_strstr(ItemRevID,".M");
		if (tc_strlen(cpStringFinder) > 0 && cpStringFinder != NULL)
		{
			//printf("cpStringFinder = <%s>\n",cpStringFinder);
			//printf("Not a Minor RevID : <%s>\n",cpStringList2[i]);
			IsmajorRevIDInValid = false;	
			return 	IsmajorRevIDInValid;
		}
		else if (tc_strlen(cpStringFinder1) > 0 && cpStringFinder1 != NULL)
		{
			int iCount = 0;
			char **cpStringList = NULL;
			EPM__parse_string(ItemRevID,".M",&iCount,&cpStringList);
			if (iCount == 2 && tc_strlen(cpStringList[1]) > 0)
			{
				//printf("cpStringFinder1 = <%s>\n",cpStringFinder1);
				//printf("Minor RevID : <%s>\n",cpStringList2[i]);
				IsmajorRevIDInValid = true;
				if (cpStringList != NULL) MEM_free(cpStringList);
				return 	IsmajorRevIDInValid;
			}
			else
			{
				//printf("Not a Minor RevID : <%s>\n",cpStringList2[i]);
				IsmajorRevIDInValid = false;
				if (cpStringList != NULL) MEM_free(cpStringList);
				return 	IsmajorRevIDInValid;
			}	
			
		}
		else
		{
			//printf("cpStringFinder = <%s>\n",cpStringFinder);
			//printf("Not a Minor RevID : <%s>\n",cpStringList2[i]);
			IsmajorRevIDInValid = false;
			return 	IsmajorRevIDInValid;
		}
	}
	
	
	/*ITK(retcode,EPM__parse_string(ItemRevID,".",&iDelimitorCount,&cpParseStringList));
	
	for(int i = 1; i < iDelimitorCount; i++)
	{
		char *Temp = NULL;
		int iCount = 0;
		Temp = (char *)MEM_alloc(tc_strlen(cpParseStringList[i]) + 1);
		tc_strcpy(Temp,"");
		tc_strcpy(Temp,cpParseStringList[i]);
		iCount = tc_strlen(Temp);

		for (int k = 0; k < iCount; k++)
		{
			if (isalpha(Temp[k]))
			{ 
				IsmajorRevIDInValid = true;				
			}
		}		
	}*/

	if (ItemRevID != NULL) MEM_free(ItemRevID);
	return 	IsmajorRevIDInValid;
}
int fnGetMinorRevTags(tag_t *tsolutionRevTags,   /*<I>*/
					  int iSolutionRevsCount,    /*<I>*/
					  int *iMinorRevCount,       /*<O>*/
					  tag_t **tMinorRevTags        /*<OF>*/
					 )
{
	int retcode = ITK_ok;
	*tMinorRevTags = NULL;
	char *chMinorRevFinder  = NULL;
	for (int inx  = 0; inx < iSolutionRevsCount; inx++)
	{
		char *ItemRevID = NULL;
		logical IsMinorRevIDValid = false;		
		
		//IsMinorRevIDInValid = fnIsSolutionItemMinorRev(tsolutionRevTags[inx]);
		IsMinorRevIDValid  = ValidateMajorRevID(tsolutionRevTags[inx]);

		if (IsMinorRevIDValid)
		{			
			*tMinorRevTags = (tag_t *) MEM_realloc(*tMinorRevTags,(*iMinorRevCount+1)*sizeof(tag_t));
			(*tMinorRevTags)[*iMinorRevCount] = tsolutionRevTags[inx];
			*iMinorRevCount = *iMinorRevCount + 1;
		}		
	}
	return retcode;
}
int fnDisplayAlertForNoSolutionItems()
{
	int retcode = ITK_ok;
	EMH_clear_errors();
	EMH_store_initial_error_s1(EMH_severity_user_error, LBT_NO_SOLUTION_ITEMS_MCO,"");
	//decision = EPM_nogo;
	//validationFailed = true;
	return retcode;	
}
extern int LBT_get_MCO_revision(tag_t task,           /* <I> */
								char *className,      /* <I> */
								int attachment_type,  /* <I> */
                                tag_t *object         /* <O> */
                               )
{
    int retcode = ITK_ok;
    int count = 0;

    tag_t *attachments = NULL;

	*object = NULLTAG;

    ITK(retcode,EPM_ask_attachments(task, attachment_type, &count, &attachments));

    for(int inx = 0; inx < count; inx++)
    {
        char *classname = NULL;
        tag_t class_id = NULLTAG;
		char  object_type[WSO_name_size_c+1] = "";
		ITK(retcode,WSOM_ask_object_type(attachments[inx],object_type));
        /*ITK(retcode,POM_class_of_instance(attachments[inx],&class_id));

        ITK(retcode,POM_name_of_class(class_id,&classname));*/

		//printf("Target Object's Class Name : %s\n", object_type);

        if( object_type != NULL && tc_strcmp(object_type, className) == 0 )
        {
            *object = attachments[inx];
            break;
        }
        MEM_free( classname );
    }
    MEM_free( attachments );
	
    return retcode;
}

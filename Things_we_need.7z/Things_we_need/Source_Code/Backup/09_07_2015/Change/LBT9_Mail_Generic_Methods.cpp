	
/******************************************************************************************

File			:	LBRT_Mail_Generic_Methods.cpp

Description		:	Functions for Workflow action handlers 

Author			:  Krupakar Reddy G

Date created	:   10/05/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

02/06/2015		Krupkar Reddy G             Added LBT_get_email_id

02/06/2015		Krupkar Reddy G             Added LBT_send_notification_email

03/06/2015		Krupkar Reddy G             Added LBT_get_perform_signoff_task

03/06/2015		Krupkar Reddy G             Added LBT_get_perform_signoff_details

04/06/2015		Krupkar Reddy G 			Added fnToGetActiveUserList

04/06/2015		Krupkar Reddy G				Added fnGetParticipantList

04/06/2015		Krupkar Reddy G				Added hasAllTheSubProcessesCompleted

04/06/2015		Krupkar Reddy G				Added hasAllProcessCompletedforCA

04/06/2015		Krupkar Reddy G				Added fnToGetChangeAnalystComments

04/06/2015		Krupkar Reddy G				Added fnToGetListOfUser

15/07/2015		Krupkar Reddy G				Added fnDelegateMail

15/07/2015		Krupkar Reddy G				Added fnSubjectForDelegateMail

15/07/2015		Krupkar Reddy G				Added fnBodyForDelegateMail

******************************************************************************************/
#include "LBT9_Change_Handler.h"


/**********************************************************************************************************************
*	Handler name	:	LBT_get_email_id

*	Description		:	This is Function is used to get the email id of the user

***********************************************************************************************************************/

extern int LBT_get_email_id(char *user_id,    /* <I> */
							char **email_id   /* <OF> */
						   )
{
	int iFail = ITK_ok;

	tag_t user_tag = NULLTAG;

	*email_id = NULL;

	ITK(iFail,SA_find_user(user_id, &user_tag));

	if ( user_tag != NULLTAG )
	{
		tag_t person_tag = NULLTAG;

		ITK(iFail,SA_ask_user_person(user_tag, &person_tag));

		if ( person_tag != NULLTAG )
		{
			char *emailId = NULL;

			ITK(iFail,SA_ask_person_attr(person_tag, "PA9", &emailId));

			/* Assuming email id always contains .com */
			if ( emailId != NULL && (char *)tc_strstr(emailId, "@") != NULL && tc_strlen(emailId) > 3 )
			{
				*email_id = (char *)MEM_alloc((tc_strlen(emailId)+1)*sizeof(char));
				tc_strcpy(*email_id, emailId);
			}
			EMR_free(emailId);
		}
	}
	return iFail;
}

/**********************************************************************************************************************
*	Handler name	:	LBT_send_notification_email

*	Description		:	This is Function is used to send the email using tc_mail_smtp
***********************************************************************************************************************/

extern int LBT_send_notification_email(char *to_users_list,    /* <I> */
									   char *cc_users_list,    /* <I> */ 	
									   char *subject,          /* <I> */
									   char *bodypath          /* <I> */
									  )
{
	int iFail = ITK_ok;

	int piStringCount = 0;
	char **pppStringList = NULL;
	
	int ccUsersCount = 0;
	char **ccUsersList = NULL;

	char emailRecipients[SS_MAXLLEN] = "";
	char sendMailCmd[SS_MAXLLEN];

	/* Add to list*/
	ITK(iFail,EPM__parse_string(to_users_list,USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));

	for (int inx = 0; inx < piStringCount; inx++)
	{
		char *email_id = NULL;

		ITK(iFail,LBT_get_email_id(pppStringList[inx], &email_id));

		if ( email_id != NULL && tc_strlen(email_id) > 0 )
		{
			if ( tc_strcmp(emailRecipients, "") == 0 || tc_strlen(emailRecipients) == 0 )
			{
				tc_strcpy(emailRecipients," -to=");
                tc_strcat(emailRecipients,email_id);
			}
			else
			{
				tc_strcat(emailRecipients," -to=");
				tc_strcat(emailRecipients,email_id);
			}
		}
		EMR_free(email_id);
	}
	EMR_free(pppStringList);
	
	/* Add CC list*/
	if ( cc_users_list != NULL && tc_strlen(cc_users_list) > 0 )
	{
		printf("CC Users List :  %s\n", cc_users_list);
		ITK(iFail,EPM__parse_string(cc_users_list,USERS_LIST_SEPERATOR, &ccUsersCount, &ccUsersList));
	}

	for (int inx = 0; inx < ccUsersCount; inx++)
	{
		char *email_id = NULL;

		ITK(iFail,LBT_get_email_id(ccUsersList[inx], &email_id));

		if ( email_id != NULL && tc_strlen(email_id) > 0 )
		{
			if ( tc_strcmp(emailRecipients, "") == 0 || tc_strlen(emailRecipients) == 0 )
			{
				tc_strcpy(emailRecipients," -cc=");
                tc_strcat(emailRecipients,email_id);
			}
			else
			{
				tc_strcat(emailRecipients," -cc=");
				tc_strcat(emailRecipients,email_id);
			}
		}
		EMR_free(email_id);
	}
	EMR_free(ccUsersList);

	if ( emailRecipients != NULL && tc_strlen(emailRecipients) > 0 )
	{
		char *so_subject = NULL;

		/* start constructing tc_mail_smtp command*/
		tc_strcpy(sendMailCmd, "tc_mail_smtp ");

        //value in emailRecipients will be something like " -to=username1@emerson.com -to=username2@emerson.com" 
        tc_strcat(sendMailCmd, emailRecipients ); 

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);

		//ITK(EPG2_get_email_subject(subject, subject_props, revTag, &so_subject));

        //Compose the subject of the Email here
        tc_strcat(sendMailCmd, " -subject=\"");
		tc_strcat(sendMailCmd, subject);
        tc_strcat(sendMailCmd, "\"");

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);
		
		tc_strcat(sendMailCmd, " -body=");
        tc_strcat(sendMailCmd, bodypath);

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);

		tc_strcat(sendMailCmd, " -server=");
        tc_strcat(sendMailCmd,"inetmail.emrsn.net");
        tc_strcat(sendMailCmd, " -port=");
        tc_strcat(sendMailCmd,"25");
		printf("\nsendMailCmd : <%s>\n", sendMailCmd);

        //printf("\nsendMailCmd=%s\n",sendMailCmd);
        if( system(sendMailCmd) != 0)
        {
           // TC_write_syslog("libWiproLiebert --- Send Mail Failed. Command -->\n<%s>\n",sendMailCmd);
            return iFail;
        }
	}

	return iFail;
}

/**********************************************************************************************************************
*	Handler name	:	LBT_get_perform_signoff_task

*	Description		:	This is Function is used to get the tag of particular perform signoff task
***********************************************************************************************************************/

extern int LBT_get_perform_signoff_task(tag_t job,                     /* <I> */
								        const char *task_name,         /* <I> */
								        tag_t *perform_signoff_task    /* <O> */
								       )
{
	int iFail = ITK_ok;
	int taskCount = 0;

	tag_t *taskTags = NULL;
	
	*perform_signoff_task = NULLTAG;

	ITK(iFail,EPM_get_type_tasks(job, eEPMPerformSignoffTask, &taskCount, &taskTags));

	for (int inx = 0; inx < taskCount; inx++)
	{
		tag_t parent_task = NULLTAG;

		char parent_task_name[WSO_name_size_c+1];

		ITK(iFail,AOM_ask_value_tag(taskTags[inx], PARENT_TASK, &parent_task));
		
		ITK(iFail,EPM_ask_name(parent_task, parent_task_name));

		if (tc_strcmp(parent_task_name, task_name) == 0)
		{
			*perform_signoff_task = taskTags[inx];
			break;
		}
	}
	
	EMR_free(taskTags);
	return iFail;
}

/**********************************************************************************************************************
*	Handler name	:	LBT_get_perform_signoff_details

*	Description		:	This is Function is used to get the details of the perform sign off task

***********************************************************************************************************************/

extern int LBT_get_perform_signoff_details(tag_t perform_signoff_task,            /* <I> */
										   EPM_signoff_decision_t decision_type,  /* <I> */
								           char **decision_taken_by_user_id,      /* <OF> */
										   char **decision_taken_by_user_name,    /* <OF> */
										   char **decision_comments,              /* <OF> */
										   char **decision_date_string            /* <OF> */
								          )
{
	int iFail = ITK_ok;
	int signoffCount = 0;

	tag_t *signoffObjects = NULL;
	
	ITK(iFail,EPM_ask_attachments(perform_signoff_task, EPM_signoff_attachment, &signoffCount, &signoffObjects));

	printf("Signoff Count : %d\n", signoffCount);
	
	if ( signoffCount == 0 )
	{
		return iFail;
	}

	for (int inx = 0; inx < signoffCount; inx++)
	{
		tag_t memberTag = NULLTAG;
		
		SIGNOFF_TYPE_t memberType;
		
		ITK(iFail,EPM_ask_signoff_member(signoffObjects[inx], &memberTag, &memberType));
		
		if( memberType == SIGNOFF_GROUPMEMBER )
		{
			EPM_signoff_decision_t decision;
		
			char *comments = NULL;
		
			date_t decision_date = NULLDATE;
			
			ITK(iFail,EPM_ask_signoff_decision(signoffObjects[inx], &decision, decision_comments, &decision_date));
			
			if ( decision == decision_type )
			{
				char *group_full_name = NULL;
				char *rolename = NULL;
				
				tag_t userTag = NULLTAG;
				tag_t groupTag = NULLTAG;
				tag_t roleTag = NULLTAG;
				
				ITK(iFail,ITK_date_to_string(decision_date, decision_date_string));

				ITK(iFail,SA_ask_groupmember_user(memberTag, &userTag));
				ITK(iFail,SA_ask_groupmember_group(memberTag, &groupTag));
				ITK(iFail,SA_ask_groupmember_role(memberTag, &roleTag));

				ITK(iFail,AOM_ask_value_string(userTag,USER_ID, decision_taken_by_user_id));
				
				ITK(iFail,SA_ask_user_person_name2(userTag, decision_taken_by_user_name));

				ITK(iFail,SA_ask_group_full_name(groupTag, &group_full_name));

				ITK(iFail,SA_ask_role_name2(roleTag, &rolename)); 

				printf("Signed By Group Member --> User : %s\tGroup : %s\tRole : %s\n", *decision_taken_by_user_id, group_full_name, rolename);
			
				EMR_free(group_full_name);
				EMR_free(rolename);
				
				break;
			}
			
			EMR_free(comments);
		}
	}
	EMR_free(signoffObjects);
	
	return iFail;
}


/**********************************************************************************************************************
*	Function name	:	fnCRToGetActiveUserList
*	DesECNiption	:	This Function is used to get current assigned users list for the mail recipients 
												

***********************************************************************************************************************/

int fnToGetActiveUserList	(tag_t RevisionTag,					/* <I> */
							 int ApproverFormCount,				/* <I> */
							 tag_t *tApproverFormTag,           /* <I> */
							 std::vector<char*> &Vuser			/* <O> */							
							)
{
	int iFail = ITK_ok;
	int iterationValue = 0;
	char *cpApproverStatus = NULL;
	char *cpApproverId	   = NULL;
	char *cpAnalystId = NULL;
	logical allFromsValidated  = false;
	ITK(iFail,AOM_ask_value_string(RevisionTag,"lbt9_Change_Analyst",&cpAnalystId));
	ITK(iFail,AOM_ask_value_int(RevisionTag,"lbt9_Iteration",&iterationValue));
	for(int i = 0; i < ApproverFormCount; i++)
	{
		int FormIterationValue = 0;
		ITK(iFail,AOM_ask_value_int(tApproverFormTag[i],"lbt9_Iteration",&FormIterationValue));
		if(iterationValue == FormIterationValue)
		{
			ITK(iFail,AOM_ask_value_string(tApproverFormTag[i],"lbt9_ApproverStatus",&cpApproverStatus));
			if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Removed") != 0)
			{
				ITK(iFail,AOM_ask_value_string(tApproverFormTag[i],"lbt9_ApproverUserID",&cpApproverId));	
				if(cpApproverId != NULL && tc_strcmp(cpAnalystId,cpApproverId) != 0)
				{
					if(Vuser.size() == 0)
					{
						Vuser.push_back(cpApproverId);
					}
					else
					{
						for(int j = 0; j < Vuser.size() ; j++)
						{
							if(tc_strcmp(Vuser[j],cpApproverId) == 0)
							{
								allFromsValidated = false;
								break;
							}
							else
							{
								allFromsValidated = true;
							}
						}
						if(allFromsValidated)
						{
							Vuser.push_back(cpApproverId);
						}
					}
				}
			}
		}
	}
	
	return iFail;
}



/**********************************************************************************************************************
*	Function name	:	fnGetParticipantList
*	DesECNiption	:	This Function is used to get the Various Participant from different Partcipant type 
												

***********************************************************************************************************************/

int fnGetParticipantList	(tag_t tTargetAttachment,										/* <I> */
							 const char *ParticipantType,									/* <I> */
							 tag_t *tAssgnParticipantTag									/* <O> */
							)
{
	int iFail							=	ITK_ok;
	int iParticipantCount				= 0;
	tag_t tParticipantType				= NULLTAG;
	tag_t tAssignee						= NULLTAG;
	tag_t *participant_list				= NULL;
	char *cpParticipantType				= NULL;
	
	cpParticipantType=(char *) MEM_alloc(tc_strlen(ParticipantType) + 2);
	tc_strcpy(cpParticipantType,"");
	tc_strcpy(cpParticipantType,ParticipantType);
	ITK(iFail,EPM_get_participanttype(cpParticipantType,&tParticipantType));
	if (tParticipantType != NULLTAG)
	{
		ITK(iFail,ITEM_rev_ask_participants(tTargetAttachment,tParticipantType,&iParticipantCount,&participant_list));
	}
	
	if (participant_list != NULL)
	{
		
		ITK(iFail,AOM_ask_value_tag(participant_list[0],ASSIGNEE_USER,&tAssignee));

		if (tAssignee != NULLTAG)
		{
			tag_t tUserTag = NULLTAG;
			ITK(iFail,AOM_ask_value_tag(tAssignee,USER,&tUserTag));
			if(tUserTag != NULLTAG)
			{
				*tAssgnParticipantTag = tUserTag;
			}
		}
		EMR_free(participant_list);
	}

	return ITK_ok;
}

/**********************************************************************************************************************
*	Function name	:	hasAllTheSubProcessesCompleted
*	DesECNiption	:	This Function is used to get the logical value (true/fase) based on whether all the processes 
						are completed or not												

***********************************************************************************************************************/


int hasAllTheSubProcessesCompleted(tag_t rev_tag,                /* <I> */
                                   tag_t current_form,           /* <I> */
                                   logical *allAreCompleted      /* <O> */
                                  )
{
	int iFail = ITK_ok;
	int iFormCount = 0;
	int iterationValue = 0;
	tag_t *tFormTags = NULL;
	tag_t relation_type_tag = NULLTAG;
	
	*allAreCompleted = false;

	ITK(iFail,AOM_ask_value_tags(rev_tag,Attr_ECN_REVIEWERS_LIST,&iFormCount,&tFormTags));
	ITK(iFail,AOM_ask_value_int(rev_tag,"lbt9_Iteration",&iterationValue));
	if(iFormCount > 0 && tFormTags != NULL)
	{
		for (int inx = 0; inx < iFormCount; inx++)
		{
			char *cpApproverStatus = NULL;
			int FromIterationValue = 0;
			ITK(iFail,AOM_ask_value_int(tFormTags[inx],"lbt9_Iteration",&FromIterationValue));
			if(FromIterationValue == iterationValue)
			{
				ITK(iFail,AOM_ask_value_string(tFormTags[inx], APPROVER_STATUS, &cpApproverStatus));
			
				if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Removed") != 0)
				{
					char *cpSignoffStatus = NULL;

					ITK(iFail,AOM_ask_value_string(tFormTags[inx], SIGNOFF_STATUS, &cpSignoffStatus));

					if ( cpSignoffStatus != NULL && tc_strcmp(cpSignoffStatus, "") == 0)
					{
						//printf("%s has been approved or rejected.", form_name);
						*allAreCompleted = false;
						break;
					}
					else
					{
						*allAreCompleted = true;
					}

					EMR_free(cpSignoffStatus);
				}
			}			
			EMR_free(cpApproverStatus);
		}
		
	}
	EMR_free(tFormTags);
	return iFail;
}

/**********************************************************************************************************************
*	Function name	:	hasAllProcessCompletedforCA
*	DesECNiption	:	This Function is used to get the logical value (true/fase) based on whether all the processes 
						are completed or not other than Change Analyst												

***********************************************************************************************************************/

int hasAllProcessCompletedforCA	  (tag_t rev_tag,                /* <I> */
                                   tag_t current_form,           /* <I> */
                                   logical *allAreCompleted      /* <O> */
                                  )
{
	int iFail = ITK_ok;
	int iFormCount = 0;
	int iterationValue = 0;
	tag_t *tFormTags = NULL;
	tag_t relation_type_tag = NULLTAG;
	char *AnalystId = NULL;
	*allAreCompleted = false;

	ITK(iFail,AOM_ask_value_tags(rev_tag,Attr_ECN_REVIEWERS_LIST,&iFormCount,&tFormTags));
	ITK(iFail,AOM_ask_value_int(rev_tag,"lbt9_Iteration",&iterationValue));
	ITK(iFail,AOM_ask_value_string(rev_tag,"lbt9_Change_Analyst",&AnalystId));
	if(iFormCount > 0 && tFormTags != NULL)
	{
		for (int inx = 0; inx < iFormCount; inx++)
		{
			int FromIterationValue = 0;
			ITK(iFail,AOM_ask_value_int(tFormTags[inx],"lbt9_Iteration",&FromIterationValue));
			if(FromIterationValue == iterationValue)
			{
				char *cpApproverId = NULL;
				ITK(iFail,AOM_ask_value_string(tFormTags[inx], "lbt9_ApproverUserID", &cpApproverId));
				if(cpApproverId != NULL && tc_strcmp(cpApproverId,AnalystId) != 0)
				{
					char *cpApproverStatus = NULL;
					ITK(iFail,AOM_ask_value_string(tFormTags[inx], APPROVER_STATUS, &cpApproverStatus));
			
					if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Removed") != 0)
					{
						char *cpSignoffStatus = NULL;

						ITK(iFail,AOM_ask_value_string(tFormTags[inx], SIGNOFF_STATUS, &cpSignoffStatus));

						if ( cpSignoffStatus != NULL && tc_strcmp(cpSignoffStatus, "") == 0)
						{
							//printf("%s has been approved or rejected.", form_name);
							*allAreCompleted = false;
							break;
						}
						else
						{
							*allAreCompleted = true;
						}

						EMR_free(cpSignoffStatus);
						EMR_free(cpApproverStatus);
					}
					EMR_free(cpApproverId);
				}
			}				
		}
		EMR_free(tFormTags);
	}
	EMR_free(AnalystId);
	
	return iFail;
}

/**********************************************************************************************************************
*	Function name	:	fnToGetChangeAnalystComments
*	DesECNiption	:	This Function is used to get the change Analyst Comments when he rejects the task and moves change object												
						from CCB to Pending
***********************************************************************************************************************/


int fnToGetChangeAnalystComments  (tag_t rev_tag,                /* <I> */
                                   char *Analyst,				 /* <I> */
                                   char **decision_comment		 /* <OF> */
                                  )
{
	int iFail = ITK_ok;
	int iFormCount = 0;
	int iterationValue = 0;
	tag_t *tFormTags = NULL;
	tag_t relation_type_tag = NULLTAG;
	*decision_comment = NULL;
	ITK(iFail,AOM_ask_value_tags(rev_tag,Attr_ECN_REVIEWERS_LIST,&iFormCount,&tFormTags));
	ITK(iFail,AOM_ask_value_int(rev_tag,"lbt9_Iteration",&iterationValue));
	if(iFormCount > 0 && tFormTags != NULL)
	{
		for (int inx = 0; inx < iFormCount; inx++)
		{
			int FromIterationValue = 0;
			ITK(iFail,AOM_ask_value_int(tFormTags[inx],"lbt9_Iteration",&FromIterationValue));
			if(FromIterationValue == iterationValue)
			{
				char *cpApproverId = NULL;
				ITK(iFail,AOM_ask_value_string(tFormTags[inx], "lbt9_ApproverUserID", &cpApproverId));
				if(cpApproverId != NULL && tc_strcmp(cpApproverId,Analyst) == 0)
				{
					char *cpApproverStatus = NULL;
					ITK(iFail,AOM_ask_value_string(tFormTags[inx], APPROVER_STATUS, &cpApproverStatus));
			
					if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Completed") == 0)
					{
						char *cpApproverComment = NULL;

						ITK(iFail,AOM_ask_value_string(tFormTags[inx], "lbt9_ApproverComments", &cpApproverComment));

						if ( cpApproverComment != NULL)
						{
							//printf("%s has been approved or rejected.", form_name);
							*decision_comment = (char *)MEM_alloc(tc_strlen(cpApproverComment) + 2);
							tc_strcpy(*decision_comment,cpApproverComment);
							break;
						}
									
						EMR_free(cpApproverStatus);
					}
					EMR_free(cpApproverId);
				}
			}				
		}	
		EMR_free(tFormTags);
	}
	
	return iFail;
}

/**********************************************************************************************************************
*	Function name	:	fnToGetListOfUser
*	DesECNiption	:	This Function is used to get the semi colon seperated list of user from the vector which contain
						list of user
***********************************************************************************************************************/

int	fnToGetListOfUser	(std::vector<char *> Vuser,				/* <I> */
						 char **cpListofUser					/* <OF> */
						) 
{
	int iFail = ITK_ok;
	*cpListofUser = (char *)MEM_alloc(Vuser.size() * 32);
	tc_strcpy(*cpListofUser,"");
	for(int k = 0; k < Vuser.size(); k++)
	{
		if(tc_strcmp(*cpListofUser,"") == 0)
		{
			tc_strcpy(*cpListofUser,Vuser[k]);
		}
		else
		{
			tc_strcat(*cpListofUser,";");
			tc_strcat(*cpListofUser,Vuser[k]);
		}
	}
	return ITK_ok;
}
int fnGetSystemToListusers(tag_t rev_tag,					/*<I>*/
						   const char *cpAddtionaluser,		/*<I>*/ 
						   char **cpToUserList				/*<OF>*/
						   )
{
	int iFail = ITK_ok;
	int iUserCount = 0;
	char **cpSysRecommendeduserList = NULL;
	char UsersToList[SS_MAXLLEN] = "";
	*cpToUserList = NULL;
	ITK(iFail,AOM_ask_value_strings(rev_tag,"lbt9_Proposed_Reviewers",&iUserCount,&cpSysRecommendeduserList));
		
	if (iUserCount > 0 && cpSysRecommendeduserList != NULL)
	{
		for (int inx = 0; inx < iUserCount; inx++)
		{
			tc_strcat(UsersToList,cpSysRecommendeduserList[inx]);
			tc_strcat(UsersToList,";");
		}			
	}	
	tc_strcat(UsersToList,cpAddtionaluser);

	*cpToUserList = (char *) MEM_alloc((tc_strlen(UsersToList)+1)*sizeof(char));
	tc_strcpy(*cpToUserList, UsersToList);
	return ITK_ok;
}

/**********************************************************************************************************************
*	Function name	:	fnDelegateMail
*	DesECNiption	:	This Function is used to get the userids of login user and user to whom task is delegated

***********************************************************************************************************************/
int fnDelegateMail (tag_t tRevisionTag,		/*<I>*/
					char *LoginUserId,		/*<I>*/
					char *AssignedUserId	/*<I>*/
					)
{
	int iFail	=	ITK_ok;

	tag_t tItemTag	= NULLTAG;
		char *cpItemId	= NULL;
		char *cpRevId = NULL;
		char *subject	= NULL;
		char *emailTemplatePath = NULL;
		char *cpItemName  = NULL;
		char *cpType	= NULL;
		ITK(iFail,ITEM_ask_item_of_rev(tRevisionTag, &tItemTag));
		
		ITK(iFail,ITEM_ask_id2(tItemTag, &cpItemId));
		
		ITK(iFail,ITEM_ask_rev_id2(tRevisionTag, &cpRevId));

		ITK(iFail,AOM_ask_value_string(tRevisionTag,"object_name",&cpItemName));

		ITK(iFail,fnToGetShortObjectNameForChangeObject(tRevisionTag,&cpType));

		ITK(iFail,fnSubjectForDelegateMail(cpItemId,cpItemName,cpType,&subject));
		ITK(iFail,fnBodyForDelegateMail (cpItemId,cpRevId,tRevisionTag,LoginUserId,AssignedUserId,cpType,&emailTemplatePath));
					
		ITK(iFail,LBT_send_notification_email(AssignedUserId, LoginUserId, subject, emailTemplatePath));
		EMR_free(emailTemplatePath);
		EMR_free(subject);
		EMR_free(cpItemId);
		EMR_free(cpRevId);
		EMR_free(cpItemName);
		EMR_free(cpType);

	return iFail;
}
/**********************************************************************************************************************
*	Function name	:	fnSubjectForOOFDelegateMail
*	DesECNiption	:	This Function is For subject to Delegation Mail

***********************************************************************************************************************/

int fnSubjectForOOFDelegateMail	(char *ObjectId,			/* <I> */
								 char *ObjectName,			/* <I> */
								 tag_t tChangeRevTag,				/* <I> */
								 char **subject			    /* <OF> */
								)
{
	int iFail = ITK_ok;
	char *cpType = NULL; 
	*subject = NULL;
	*subject = (char *) MEM_alloc((tc_strlen("Task Delegation Notice ")+tc_strlen(ObjectId)+ tc_strlen(" | ") + tc_strlen(ObjectName) + tc_strlen(" | ")+tc_strlen(cpType) + tc_strlen(".")+ 1)*sizeof(char));
	tc_strcpy(*subject, "Task Delegation Notice|");
	//Get the object type that needs to be print in the mail
	//ITK(iFail,fnGetItemTypeforMail(tChangeRevTag,&cpType));
	//tc_strcat(*subject, cpType);	
	//tc_strcat(*subject, "|");
	tc_strcat(*subject, ObjectId);
	tc_strcat(*subject,"|");
	tc_strcat(*subject,ObjectName);
	return ITK_ok;
}
int fnGetItemTypeforMail(tag_t ItemRevtag,		/*<I>*/
						 char **cpItemRevType   /*<OF>*/
						)
{
	int iFail = ITK_ok; 
	char *cpObjectType = NULL;
	*cpItemRevType = NULL;
	ITK(iFail,WSOM_ask_object_type2(ItemRevtag,&cpObjectType));
	if (tc_strlen(cpObjectType) > 0 && cpObjectType != NULL)
	{
		*cpItemRevType = (char *)MEM_alloc(30);
		tc_strcpy(*cpItemRevType, "");
		if (tc_strcmp(cpObjectType,"LBT9_ECNRevision") == 0)	tc_strcat(*cpItemRevType , "Engineering Change Notice");
		if (tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision") == 0)	tc_strcat(*cpItemRevType , "Change Request Notice");
		if (tc_strcmp(cpObjectType,"LBT9_DCNRevision") == 0)	tc_strcat(*cpItemRevType , "Document Change Notice");
		if (tc_strcmp(cpObjectType,"LBT9_MCORevision") == 0)	tc_strcat(*cpItemRevType , "MCO");
		if (tc_strcmp(cpObjectType,"LBT9_StopShipRevision") == 0)	tc_strcat(*cpItemRevType ,"StopShip");
	}
	return ITK_ok;
}

/**********************************************************************************************************************
*	Function name	:	fnSubjectForDelegateMail
*	DesECNiption	:	This Function is For subject to Delegation Mail

***********************************************************************************************************************/

int fnSubjectForDelegateMail	(char *ObjectId,			/* <I> */
								 char *ObjectName,			/* <I> */
								 char *cpType,				/* <I> */
								 char **subject			    /* <OF> */
								)
{
	int iFail = ITK_ok;
	*subject = NULL;
	*subject = (char *) MEM_alloc((tc_strlen("Task Delegation Notice ")+tc_strlen(ObjectId)+ tc_strlen(" | ") + tc_strlen(ObjectName) + tc_strlen(" | ")+tc_strlen(cpType) + tc_strlen(".")+ 1)*sizeof(char));
	tc_strcpy(*subject, "Task Delegation Notice ");
	tc_strcat(*subject, cpType);
	tc_strcat(*subject, "|");
	tc_strcat(*subject, ObjectId);
	tc_strcat(*subject,"|");
	tc_strcat(*subject,ObjectName);
	return ITK_ok;
}


/**********************************************************************************************************************
*	Function name	:	fnBodyForDelegateMail
*	DesECNiption	:	This Function is For Body for Delegation Mail

***********************************************************************************************************************/

int fnBodyForDelegateMail (	char *item_id,              /* <I> */
							char *item_rev_id,			/* <I> */
							tag_t item_rev_tag,			/* <I> */
							char* LoginUserId,			/* <I> */
							char * AssignedUserId,		/* <I> */
							char *cpType,				/* <I> */
							char **emailTemplatePath    /* <OF> */
						  )
{
	int iFail = ITK_ok;
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;	
	char * value  = NULL;
	char * current_date_string	=	NULL;
	char *cpObjectType	=	NULL;
	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;
	
	//ITK(iFail,fnToGetShortObjectNameForChangeObject(item_rev_tag,&cpObjectType));

	ITK(iFail,ITK_ask_default_date_format(&current_date_string));
	email_template_path = (char *) MEM_alloc(tc_strlen(getenv("TEMP")) + tc_strlen("\\LBT_Delegate_Mail_notify_") + tc_strlen(item_id) +tc_strlen(".txt") + 2);
	tc_strcpy(email_template_path,"");
	tc_strcpy(email_template_path,getenv("TEMP"));
	tc_strcat(email_template_path,"\\LBT_Delegate_Mail_notify_");
	tc_strcat(email_template_path,item_id);
	tc_strcat(email_template_path,".txt");
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		char *cpDescChange	=	NULL;
		tc_strcpy(bodypath, email_template_path);
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);
		ITK(iFail,AOM_ask_value_string(item_rev_tag,"lbt9_Description",&cpDescChange));
		if(cpDescChange != NULL)
		{
			fp_email_body = fopen(bodypath, "w+");
			fprintf(fp_email_body,"The below mentioned task is delegated to you by %s. \n\n",LoginUserId);
			fprintf(fp_email_body,"%s %s/%s is Submitted to Change Analyst %s. Please review and complete your task to move the %s to CCB.",cpType,item_id,item_rev_id,AssignedUserId,cpType);
			fprintf(fp_email_body,"\n\nDescription of Change - %s",cpDescChange);
			fprintf(fp_email_body,"\n\n# AUTO-GENERATED MAIL KINDLY DO NOT RESPOND");
			fclose(fp_email_body);
			EMR_free(cpDescChange);

			
		}

		EMR_free(email_template_path);
	}
	return ITK_ok;
}


/**********************************************************************************************************************
*	Function name	:	LBT9_ECN_PreApproval_Originator_Notify
*	Description		:	 This Function is used to get the body of mail when any change object moves from PreApproval to Submitted as part of OOF
												

***********************************************************************************************************************/


int fnOOFBodyForDelegateMailPreApprovalToSubmitted (	char *item_id,              /* <I> */
											char *item_rev_id,			/* <I> */
											char *analyst_name,		    /* <I> */
											tag_t item_rev_tag,			/* <I> */
											char *cpDelegationUserID,    /* <I> */
											char **emailTemplatePath    /* <OF> */
									   )
{
	int iFail = ITK_ok;
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;
	char *cpType = NULL;
	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;
	ITK(iFail,fnGetItemTypeforMail(item_rev_tag,&cpType));
	email_template_path = (char *) MEM_alloc(tc_strlen(getenv("TEMP")) + tc_strlen("\\LBT_Email_notify_PreApproval_to_Submitted_") + tc_strlen(item_id) + tc_strlen(cpType)+ tc_strlen(".txt") + 2);
	tc_strcpy(email_template_path,"");
	tc_strcpy(email_template_path,getenv("TEMP"));
	tc_strcat(email_template_path,"\\LBT_Email_notify_PreApproval_to_Submitted_");
	//tc_strcat(email_template_path,cpType);
	tc_strcat(email_template_path,item_id);
	tc_strcat(email_template_path,".txt");
	
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		char *cpDescChange	=	NULL;
		tc_strcpy(bodypath, email_template_path);
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);
		ITK(iFail,AOM_ask_value_string(item_rev_tag,"lbt9_Description",&cpDescChange));
		if(cpDescChange != NULL && tc_strlen(cpType) > 0 && cpType !=  NULL)
		{
			fp_email_body = fopen(bodypath, "w+");
			fprintf(fp_email_body,"The below mentioned task is delegated to you by %s.\n\n",analyst_name);
			fprintf(fp_email_body,"%s %s/%s - %s is submitted to Change Analyst %s. Please review the %s and provide your approval for moving to CCB.",cpType,item_id,item_rev_id,cpDescChange,cpDelegationUserID,cpType);
			fprintf(fp_email_body,"\n\n# AUTO-GENERATED MAIL KINDLY DO NOT RESPOND");
			fclose(fp_email_body);
			EMR_free(cpDescChange);
		}
		EMR_free(cpType);
		EMR_free(email_template_path);
	}
	return ITK_ok;
}
/**********************************************************************************************************************
*	Function name	:	fnECNBodyForNotifyTaskAssignment
*	Description		:	This Function is used to generated the body of mail to Notify originator about the task been assigned
						when change object moves to Released status aas part of OOF

***********************************************************************************************************************/

int fnOOFBodyForDelegateMailNotifyTaskAssignment(tag_t rev_tag,												/* <I> */
												 char *item_id,												/* <I> */
												 char *rev_id,												/* <I> */
												 char *OwningUserID,											/* <I> */
												 char **emailTemplatePath									/* <OF> */
												)
{
	int iFail = ITK_ok;
	char bodypath[SS_MAXLLEN];	
	char *cpType = NULL;
	char *email_template_path = NULL;

	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;
	ITK(iFail,fnGetItemTypeforMail(rev_tag,&cpType));
	if (tc_strlen(cpType) > 0 && cpType != NULL)
	{
		email_template_path = (char *) MEM_alloc(tc_strlen(getenv("TEMP")) + tc_strlen("\\LBT_Email_notify_Task_Assigned_")+ tc_strlen(cpType) + tc_strlen(item_id) + tc_strlen(".txt") + 2);
		tc_strcpy(email_template_path,"");
		tc_strcpy(email_template_path,getenv("TEMP"));
		tc_strcat(email_template_path,"\\LBT_Email_notify_Task_Assigned_");
		//tc_strcat(email_template_path,cpType);
		tc_strcat(email_template_path,item_id);
		tc_strcat(email_template_path,".txt");
	}	
	
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		char *cpDescChange	=	NULL;
		tc_strcpy(bodypath, email_template_path);
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);
		ITK(iFail,AOM_ask_value_string(rev_tag,"lbt9_Description",&cpDescChange));
		if(cpDescChange != NULL)
		{
			fp_email_body = fopen(bodypath, "w+");
			fprintf(fp_email_body,"The below mentioned task is delegated to you by %s.\n\n",OwningUserID);
			fprintf(fp_email_body,"%s %s/%s - %s has moved to Released status and you have been assigned the task to Complete the workflow/Implement the %s.",cpType,item_id,rev_id,cpDescChange,cpType);
			fprintf(fp_email_body,"\n\n# AUTO-GENERATED MAIL KINDLY DO NOT RESPOND");
			fclose(fp_email_body);
			EMR_free(cpDescChange);
		}
		EMR_free(email_template_path);
	}
	return ITK_ok;

}

int fnDeligateMailBodyForNotifyTaskAssignment(tag_t rev_tag,												/* <I> */
									 char *item_id,												/* <I> */
									 char *rev_id,												/* <I> */
									 char *OwningUserID,										/* <I> */
									 char *cpObjectType,										/* <I> */
									 char **emailTemplatePath									/* <OF> */
									)
{
	int iFail = ITK_ok;
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;
	//char *cpObjectType = NULL;
	FILE *fp_email_body = NULL;
	//ITK(iFail,WSOM_ask_object_type2(rev_tag,&cpObjectType));
	*emailTemplatePath = NULL;
	email_template_path = (char *) MEM_alloc(tc_strlen(getenv("TEMP")) + tc_strlen("\\LBT_Email_Delegate_notify_Task_Assigned_") + tc_strlen(item_id) + tc_strlen(".txt") + 2);
	tc_strcpy(email_template_path,"");
	tc_strcpy(email_template_path,getenv("TEMP"));
	tc_strcat(email_template_path,"\\LBT_Email_Delegate_notify_Task_Assigned_");
	tc_strcat(email_template_path,item_id);
	tc_strcat(email_template_path,".txt");
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		char *cpDescChange	=	NULL;
		tc_strcpy(bodypath, email_template_path);
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);
		ITK(iFail,AOM_ask_value_string(rev_tag,"lbt9_Description",&cpDescChange));
		if(cpDescChange != NULL)
		{
			fp_email_body = fopen(bodypath, "w+");
			fprintf(fp_email_body,"The below mentioned task is delegated to you by %s.\n\n",OwningUserID);
			if (tc_strlen(cpObjectType) > 0 && tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision") == 0)
			{
				fprintf(fp_email_body,"Change Request %s/%s - %s has moved to Released status and you have been assigned the task to close the Change Request, after the ECN associated to the CR is implemented.",item_id,rev_id,cpDescChange);
			}
			else if (tc_strlen(cpObjectType) > 0 && tc_strcmp(cpObjectType,"LBT9_StopShipRevision") == 0)
			{
				fprintf(fp_email_body,"StopShip %s/%s - %s has moved to Released status and you have been assigned the Resume task to Resume the StopShip Request.",item_id,rev_id,cpDescChange);
			}			
			fprintf(fp_email_body,"\n\n# AUTO-GENERATED MAIL KINDLY DO NOT RESPOND");
			fclose(fp_email_body);
			EMR_free(cpDescChange);
		}
		EMR_free(email_template_path);
		//EMR_free(cpObjectType);
	}
	return ITK_ok;
}

int fnForNotifyingOOFAddedApprovers		( tag_t RevisionTag,	 /* <I> */
										  tag_t tUserTag,        /* <I> */										 
										  char *OriginalUserID	  /* <I> */
										)
{
	int iFail = ITK_ok;
	int iApproverFormCount = 0;
	tag_t *tApproverFormTag = NULL;
	char *cpUserToNotify	= NULL;
	char *cpApproverId = NULL;
	char *cpApproverStatus = NULL;
	std::vector<char*> Vuser;
	char *cpListofUser = NULL;
	char *cpAnalystId     = NULL;
	tag_t tAnalystTag				= NULLTAG;
	char *emailTemplatePath = NULL;	
	ITK(iFail,fnGetParticipantList(RevisionTag,CHANGE_ANALYST,&tAnalystTag));
	if(tAnalystTag != NULLTAG)
	{
		ITK(iFail,SA_ask_user_identifier2(tAnalystTag,&cpAnalystId));
	}
	ITK(iFail,fnBodyForOOFNotifyingAddedApprovers(OriginalUserID,&emailTemplatePath));
	ITK(iFail,LBT_send_notification_email(cpAnalystId,OriginalUserID,"CCB Reviewer - Out Of Office Assistant Notice", emailTemplatePath));
	
	EMR_free(emailTemplatePath);
	return ITK_ok;
}

/**********************************************************************************************************************
*	Function name	:	fnECNBodyForNotifyngAddedApprovers
*	Description		:	 This Function is used to get the body of mail for the approvers who are added
												

***********************************************************************************************************************/


int fnBodyForOOFNotifyingAddedApprovers  (	  char *OriginalUserID,											 
											  char **emailTemplatePath    /* <OF> */
										 )
{
	int iFail = ITK_ok;
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;
	char *cpType = NULL;
	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;
	email_template_path = (char *) MEM_alloc(tc_strlen(getenv("TEMP")) + tc_strlen("\\LBT_Email_Delegation_notify_Adding_Approvers_") + tc_strlen(".txt") + 2);
	tc_strcpy(email_template_path,"");
	tc_strcpy(email_template_path,getenv("TEMP"));
	tc_strcat(email_template_path,"\\LBT_Email_Delegation_notify_Adding_Approvers_");	
	tc_strcat(email_template_path,".txt");
	
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		char *cpDescChange	=	NULL;
		tc_strcpy(bodypath, email_template_path);
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);		
		if(OriginalUserID != NULL && tc_strlen(OriginalUserID) > 0)
		{
			fp_email_body = fopen(bodypath, "w+");
			
			fprintf(fp_email_body,"Reviewer %s has assigned an Out Of Office Assistant in this period. So, CCB Review Task cannot be assigned to %s",OriginalUserID,OriginalUserID);
			
			fprintf(fp_email_body,"\n\n# AUTO-GENERATED MAIL KINDLY DO NOT RESPOND");
			fclose(fp_email_body);
			EMR_free(cpDescChange);
		}
		EMR_free(email_template_path);
	}
	return ITK_ok;
}



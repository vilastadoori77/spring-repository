	
/******************************************************************************************

File			:	LBRT_ECN_Workflow.cpp

Description		:	Workflow action handlers for Libert

Author			:	Krupakar Reddy G

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added LBT9_ECN_SET_VALUES_ON_SOLUTION_ITEMS 

01/06/2015		Krupkar Reddy G             Added fnSetEffectivityOnStatusObject

02/06/2015		Krupkar Reddy G             Added LBT9_Proposed_Reviewers
					
******************************************************************************************/
#include "LBT9_Change_Handler.h"




/****************************************************************************************************
*	Handler name	:	LBT9_ECN_SET_VALUES_ON_SOLUTION_ITEMS

*	Description		:	Action Handler - For setting Disposition Code values on Solution Items when Status 
						of Change object is changed to Released
******************************************************************************************************/

extern int LBT9_ECN_SET_VALUES_ON_SOLUTION_ITEMS(EPM_action_message_t msg)
{
	int   retcode  				= 	ITK_ok;
	int   iCount				=	0;
	int   i						=	0;
	int   iTagCount				=	0;
	int   iTrgtAtchmnts         =   0;
	int   value					=	0;
	char * current_date_string  =   0;
	char * cObjectType			=	NULL;
	char * cChangeValue			=	NULL;
	char * cFieldMod			=	NULL;
	char * cGoods				=	NULL;
	char * cNote				=	NULL;
	char * cOrder				=	NULL;
	char * cStock				=	NULL;
	char * cStatus				=	NULL;
	char * cWIP					=	NULL;
	date_t  cDate				=	NULLDATE;
	date_t current_date			=	NULLDATE;
	tag_t *rev_tag   			=	NULL;
	tag_t tPrimaryObject		=	NULLTAG;;
	tag_t tRelationTypeTag		=	NULLTAG;
	tag_t tRelationTag			=	NULLTAG;;
	tag_t * tSolutionItems	    =	NULL;
	tag_t *tStatusTag			=	NULL;
	tag_t root_task				=   NULLTAG;
	tag_t release_status 		= NULLTAG;
	logical status				= true;
	
	ITK(retcode,EPM_ask_root_task(msg.task, &root_task));

	if(root_task != NULL)
	{
		ITK(retcode, EPM_ask_attachments(root_task,EPM_target_attachment, &iTrgtAtchmnts, &rev_tag));
	}
	ITK(retcode,GRM_find_relation_type(SOLUTION_ITEMS_RELATION,&tRelationTypeTag));

	if(tRelationTypeTag!=NULLTAG)
	{
		GRM_list_secondary_objects_only(rev_tag[0],tRelationTypeTag,&iCount,&tSolutionItems);
		{
			if(iCount >0 && tSolutionItems!= NULL)
			{
				 for(i=0;i<iCount;i++)
				 {

					GRM_find_relation(rev_tag[0],tSolutionItems[i],tRelationTypeTag,&tRelationTag);
					if(tRelationTag!=NULLTAG)
					{
						ITK(retcode,AOM_ask_value_string(tRelationTag,"lbt9_Target_Status",&cStatus));
						ITK(retcode,AOM_ask_value_date(tRelationTag,"lbt9_Effective_Date",&cDate));
					
						tag_t *Status = NULL;
						int Count = 0;
						ITK(retcode,AOM_ask_value_tags(tSolutionItems[i],"release_status_list",&Count,&Status));
						ITK(retcode,CR_create_release_status2("EMR_Released",&release_status));
						ITK(retcode,AOM_refresh(tSolutionItems[i],TRUE));		
						ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	                    ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
                        POM_compare_dates(cDate,current_date,&value);
						if(value == 1)
						{
							ITK(retcode,AOM_set_value_date(tSolutionItems[i],"lbt9_Effective_Date",cDate));
						}
						else if (value < 0)						
						{							
							ITK(retcode,AOM_set_value_date(tSolutionItems[i],"lbt9_Effective_Date",current_date));							
						}	
						
						char  release_status_type[WSO_name_size_c+1] = "EMR_Released";
						ITK(retcode,AOM_save(tSolutionItems[i]));
						ITK(retcode,AOM_refresh(tSolutionItems[i],FALSE));


						tag_t tTemplateTag = NULLTAG;
						tag_t NewJobProcess = NULLTAG;
						int *iAttachmentTypes;
						iAttachmentTypes = (int *)MEM_alloc(sizeof(int)*2);
						iAttachmentTypes[0] = EPM_target_attachment;
						tag_t *tProcessAtt					=	NULL;
						tProcessAtt = (tag_t *)MEM_alloc(sizeof(tag_t)*2);
						tProcessAtt[0] = tSolutionItems[i];
						if(cStatus != NULL && tc_strcmp(cStatus,"Released")==0)
						{
							
							EPM_find_process_template("Set Release Status",&tTemplateTag);
							if (tTemplateTag != NULLTAG)
							{
								ITK(retcode,EPM_create_process("Set Release Status","test",tTemplateTag,1,tProcessAtt,iAttachmentTypes,&NewJobProcess));
							}
							tag_t tItemTag	=	NULLTAG;
							ITEM_ask_item_of_rev(tSolutionItems[i],&tItemTag);
							ITK(retcode,AOM_refresh(tItemTag,TRUE));
							ITK(retcode,AOM_refresh(tSolutionItems[i],TRUE));
						    ITK(retcode,fnSetEffectivityOnStatusObject(tSolutionItems[i],rev_tag[0],cDate));
							ITK(retcode,AOM_save(tSolutionItems[i]));
						    ITK(retcode,AOM_refresh(tSolutionItems[i],FALSE));
							ITK(retcode,AOM_save(tItemTag));
						    ITK(retcode,AOM_refresh(tItemTag,FALSE));
							EMR_free(tProcessAtt);
						}
						else if(cStatus != NULL && tc_strcmp(cStatus,"Obsolete")==0)
						{
							
							EPM_find_process_template("Set Obsolete Status",&tTemplateTag);
							if (tTemplateTag != NULLTAG)
							{
								ITK(retcode,EPM_create_process("Set Obsolete Status","test",tTemplateTag,1,tProcessAtt,iAttachmentTypes,&NewJobProcess));
							}
						
							EMR_free(tProcessAtt);
						}
						else if(cStatus != NULL && tc_strcmp(cStatus,"Inactive")==0)
						{
						
							EPM_find_process_template("Set Inactive Status",&tTemplateTag);
							if (tTemplateTag != NULLTAG)
							{
								ITK(retcode,EPM_create_process("Set Inactive Status","test",tTemplateTag,1,tProcessAtt,iAttachmentTypes,&NewJobProcess));
							}
						
							EMR_free(tProcessAtt);
						}
						ITK(retcode,fnGetDatasets(tSolutionItems[i],cStatus));
					}
				 }
			 }
		 }
	}
	return retcode;
}

/****************************************************************************************************
*	Function name	:	fnSetEffectivityOnStatusObject

*	Description		:	Function is used to set Disposition Code values on Solution Items when Status 
						of Change object is changed to Released
******************************************************************************************************/

 int fnSetEffectivityOnStatusObject(tag_t	SolutionItemTag,	/*<I>*/
									tag_t	rev_tag,			/*<I>*/
									date_t	Date				/*<I>*/
									)
 {
	int retcode					=	ITK_ok;
	int status_count			=	0;
	int iDates					=	0;
	tag_t * status_list			=	NULL;
	

	ITK(retcode,WSOM_ask_release_status_list(SolutionItemTag,&status_count,&status_list));
	if (status_count > 0 && status_list != NULL)
	{
		int iEffectivityCount		=	0;
		int value					=	0;
		char * current_date_string  =   0;

		date_t current_date			=	NULLDATE;
		date_t current_date1		=	NULLDATE;
		tag_t tItemTag				=	NULLTAG;
		tag_t tEffectivityTag		=	NULLTAG;

		date_t *start_end_values	=	NULL; 
		WSOM_open_ended_status_t  open_ended_or_stockOut;

		ITK(retcode,ITK_ask_default_date_format(&current_date_string));
		ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
		ITK(retcode,POM_compare_dates(Date,current_date,&value));	
		start_end_values = (date_t *)MEM_alloc(sizeof(date_t)*2);
		if(value == 1)
		{
			start_end_values[0]	=	Date;
		}
		else
		{
			start_end_values[0]	=	current_date;
		}
		
		ITK(retcode,WSOM_effectivity_create_empty(status_list[0],&tEffectivityTag));
		ITK(retcode,AOM_save(status_list[0]));
		
		if(tEffectivityTag != NULLTAG)
		{
			ITK(retcode,WSOM_eff_set_dates(status_list[0],tEffectivityTag,1,start_end_values,EFFECTIVITY_open_ended,FALSE));
			ITK(retcode,AOM_save(status_list[0]));
		}

		ITK(retcode,ITEM_ask_item_of_rev(SolutionItemTag,&tItemTag));
		if(tItemTag != NULLTAG)
		{
			int iRevCount				=	0;
			int iIsReleased				=	0;
			int i						=	0;
			int PRstatus_count			=	0;
			tag_t tPrevReVTag			=	NULLTAG;
			tag_t* tRevTag				=	NULL;
			tag_t* PRstatus_list		=	NULL;

			ITK(retcode,fnToCheckLRRofItem(tItemTag,SolutionItemTag,&tPrevReVTag));
			if(tPrevReVTag != NULLTAG)
			{
				int iStatusCount	=	0;
				char * cpStatusName	=	NULL;
				tag_t * tStatusTags	=	NULL;
				ITK(retcode,WSOM_ask_release_status_list(tPrevReVTag,&PRstatus_count,&PRstatus_list));
				if(PRstatus_count	> 0 && PRstatus_list !=NULL)
				{
					int n_effectivities	=	0;
					tag_t* effectivities	=	NULL;
					int n_dates			=	0;
					date_t *start_values_of_PR	=	NULL;
					date_t *start_end_values_for_PR	=	NULL;
					WSOM_open_ended_status_t  status;
					
					start_values_of_PR = (date_t *)MEM_alloc(sizeof(date_t)*2);
					start_end_values_for_PR = (date_t *)MEM_alloc(sizeof(date_t)*2);

					ITK(retcode,WSOM_status_ask_effectivities(PRstatus_list[0],&n_effectivities,&effectivities));

					if(n_effectivities > 0 && effectivities != NULL)
					{
						ITK(retcode,WSOM_eff_ask_dates(PRstatus_list[0],effectivities[0],&n_dates,&start_values_of_PR,&status));

						start_end_values_for_PR[0]	=	start_values_of_PR[0];
						start_end_values_for_PR[1]	=	start_end_values[0];
						
						ITK(retcode,AOM_refresh(tPrevReVTag,TRUE));
						ITK(retcode,WSOM_eff_set_dates(PRstatus_list[0],effectivities[0],2,start_end_values_for_PR,EFFECTIVITY_closed,FALSE));
						ITK(retcode,AOM_save(PRstatus_list[0]));
						ITK(retcode,AOM_save(tPrevReVTag));
						ITK(retcode,AOM_refresh(tPrevReVTag,FALSE));
						
						
					}

					EMR_free(effectivities);
					EMR_free(start_values_of_PR);
					EMR_free(start_end_values_for_PR);
					EMR_free(PRstatus_list);
				}
			 

			}
		
			
		 }

		EMR_free(current_date_string);
		EMR_free(start_end_values);
		 
	}	
	
	//Memory free
	if(status_list != NULL)
	{
		EMR_free(status_list);
	}
	
	 return ITK_ok;
 }

 /****************************************************************************************************
*	Handler name	:	LBT9_Proposed_Reviewers

*	Description		:	Action Handler - Consolidating Addresslist Users and Responsible persons and 
						For setting  Unique Users values on Proposed Reviewers of  Change Object before 
						Submitted Status
******************************************************************************************************/
extern int LBT9_Proposed_Reviewers(EPM_action_message_t msg)
{
	int retcode =ITK_ok;
    int   iTrgtAtchmnts         =   0;
	int		iAttchItemCount	=	0;
	int iIterationValue	=	0;
  
	tag_t rev_tag	=	NULLTAG;
	tag_t tECNTag	=	NULLTAG;
	tag_t tECNRevTag	=	NULLTAG;
	tag_t tRelationtypeTag	=	NULLTAG;
	tag_t * tAttchItemTag	= NULL;
	tag_t tRootTask	=	NULLTAG;
	tag_t* ptTargetAttmnts=NULL;
	
	ITK(retcode,EPM_ask_root_task(msg.task,&tRootTask));
	ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	
	if(ptTargetAttmnts != NULL)
	{
		char * cpObjectType	=	NULL;
		WSOM_ask_object_type2(ptTargetAttmnts[0],&cpObjectType);
		if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_ECNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_DCNRevision")==0 || tc_strcmp(cpObjectType,"LBT9_MCORevision")==0 ))
		{
			ITK(retcode,GRM_find_relation_type("CMHasSolutionItem",&tRelationtypeTag));
		}
		else if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_DeviationRevision")==0 || tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision")==0 || tc_strcmp(cpObjectType,"LBT9_StopShipRevision")==0 ))
		{
			ITK(retcode,GRM_find_relation_type("CMHasImpactedItem",&tRelationtypeTag));
		}
		ITK(retcode,AOM_ask_value_int(ptTargetAttmnts[0],"lbt9_Iteration",&iIterationValue));
		ITK(retcode,GRM_list_secondary_objects_only(ptTargetAttmnts[0],tRelationtypeTag,&iAttchItemCount,&tAttchItemTag));
		if(iIterationValue==1)
		{
			fnToSetProposedReviwers(ptTargetAttmnts,tAttchItemTag,iAttchItemCount);
		}
		else
		{
			std::vector<tag_t> VFormTags;
			std::vector<char*> VUserId;
			int n = iIterationValue-1;
			int n_forms	=	0;
			tag_t * tFormTags	=	NULL;
			logical Iteration =false;
			VFormTags.clear();
			VUserId.clear();
			ITK(retcode,AOM_ask_value_tags(ptTargetAttmnts[0],"lbt9_Approver_Form",&n_forms,&tFormTags));
			{
				int iFormIterationValue	=	0;
				for(int k=0;k<n_forms;k++)
				{
					ITK(retcode,AOM_ask_value_int(tFormTags[k],"lbt9_Iteration",&iFormIterationValue));
					if(iFormIterationValue==n)
					{
						VFormTags.push_back(tFormTags[k]);
					}
					
				}
			}
			if(VFormTags.size()==0)
			{
				int n_of_reviewers  =  0;
				char ** cReviewers = NULL;
				tag_t class_id	=	NULLTAG;
				tag_t attr_id	=	NULLTAG;
				//tag_t * tSolutionTagArray	=	NULL;
				ITK(retcode,AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&n_of_reviewers,&cReviewers));
				//tSolutionTagArray[0]	=	ptTargetAttmnts[0];
				if(n_of_reviewers > 0 && cReviewers != NULL)
				{
					//ITK(retcode,POM_class_id_of_class ("LBT9_ECNRevision",&class_id));
					ITK(retcode,POM_attr_id_of_attr  ( "lbt9_Proposed_Reviewers",cpObjectType,&attr_id));
					//ITK(retcode,POM_clear_attr(1,ptTargetAttmnts,attr_id));
					ITK(retcode,AOM_refresh(ptTargetAttmnts[0],TRUE));
					//ITK(retcode,POM_set_attr_nulls(1,ptTargetAttmnts,attr_id,0,n_of_reviewers));
					ITK(retcode,POM_clear_attr(1,ptTargetAttmnts,attr_id));
					ITK(retcode,AOM_save(ptTargetAttmnts[0]));
					ITK(retcode,AOM_refresh(ptTargetAttmnts[0],FALSE));
				}
				fnToSetProposedReviwers(ptTargetAttmnts,tAttchItemTag,iAttchItemCount);
				fnAddressList(ptTargetAttmnts,iAttchItemCount ,tAttchItemTag);

				LBT9_MEM_free_Strings(cReviewers,n_of_reviewers);
			}
			else
			{
				char * cUserId	=	NULL;
				char *Analyst = NULL;
				ITK(retcode,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&Analyst));
				for(int y=0;y<VFormTags.size();y++)
				{
					ITK(retcode,AOM_ask_value_string(VFormTags[y],"lbt9_ApproverUserID",&cUserId));
					if(cUserId != NULL && tc_strcmp(cUserId,Analyst) != 0)
					{
						VUserId.push_back(cUserId);
					}
				}
			}
			if(VUserId.size()!=0)
			{
				int n_instances	=	0;
				tag_t attr_id	=	NULLTAG;
				tag_t class_id	=	NULLTAG;
				tag_t * instance_tags	=	NULL;
				
				int n_of_reviewers  =  0;
				char ** cReviewers = NULL;
				char *cpChangeAnalystUserID = NULL;
				logical flag = false;
				ITK(retcode,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpChangeAnalystUserID));
				for(int m=0;m<VUserId.size();m++)
				{
					ITK(retcode,AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&n_of_reviewers,&cReviewers));
					int n=n_of_reviewers;
					for(int l=0;l<n_of_reviewers;l++)
					{
						if(tc_strcmp(VUserId[m],cReviewers[l])==0)				
						{
							flag = true;
							break;
						}
						else
						{
							flag = false;		
						}	
					}
					if(!flag)
					{
						if (tc_strlen(cpChangeAnalystUserID) > 0 && tc_strcmp(VUserId[m],cpChangeAnalystUserID) == 0)
						{
							continue;
						}
						else
						{
							ITK(retcode,AOM_refresh(ptTargetAttmnts[0],TRUE));
							ITK(retcode,AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",n,VUserId[m]));
							ITK(retcode,AOM_save(ptTargetAttmnts[0]));
							ITK(retcode,AOM_refresh(ptTargetAttmnts[0],FALSE));
						}
						
					}
				}
			}
			
		}
	}
	  EMR_free(ptTargetAttmnts);
	  EMR_free(tAttchItemTag);
	
    return retcode;
}


extern int LBT9_val_and_Release_Design(EPM_action_message_t  msg)		/* <I> */
{

	int iFail					=	ITK_ok;
	int iTrgtAtchmnts			=	0;
	EPM_decision_t	decision	=	EPM_go;
	tag_t tRootTask				=	NULLTAG;
	tag_t* ptTargetAttmnts		=	NULL;
	int iProcSubTasks			=	0;
	tag_t* ptProcessSubTasks	=	NULL;
	tag_t tJob					=	NULLTAG;
	tag_t ECORevision			=   NULLTAG;

	TC_write_syslog("\nLBT9Handlers: Entered the function LBT9_val_and_Release_Design.");
	if(msg.task == NULLTAG)
	{
		TC_write_syslog("\nLBT9Handlers: Invalid task as the input.");
		iFail = EPM_invalid_argument;
		//decision		=	EPM_nogo;
		return iFail;
	}
	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	
	/** Check if the Test Report Reviewer belongs to the same groups of the Lab Manager (request reviewer) */
		
	ITK(iFail,EPM_ask_job(tRootTask,&tJob));
	/*if(tJob == NULLTAG)
	{
		TC_write_syslog("\nLBT9Handlers: Unable to get the job for the root task");
		EMH_store_initial_error(EMH_severity_error,WORKLFOW_TASK_PROCESSING_ERROR);
		//return EPM_nogo;
		return iFail;
	}*/
	ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	if(iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		int kNx;
		for( kNx = 0; kNx < iTrgtAtchmnts; kNx++ )
		{
			char *cObjectType           =   NULL;
			ITK(iFail, AOM_ask_value_string(ptTargetAttmnts[kNx],"object_type",&cObjectType));
			if(cObjectType != NULL && tc_strlen(cObjectType) !=0 && tc_strcasecmp((const char*)cObjectType,CLASS_ECN_REVISION) == 0)
			{
				ECORevision = ptTargetAttmnts[kNx];
				break;
			}
		}
		tag_t tCMReferencesRelType = NULLTAG;

		ITK(iFail,GRM_find_relation_type(CM_DESIGN_ITEMS,&tCMReferencesRelType));
		if(tCMReferencesRelType != NULLTAG)
		{
			int iDesignItems = 0;
			tag_t *ptDesisnItems = NULL;
			ITK(iFail,GRM_list_secondary_objects_only(ECORevision,tCMReferencesRelType,&iDesignItems,&ptDesisnItems));
			if(iDesignItems > 0 && ptDesisnItems != NULL)
			{
				int iNx = 0;
				for(iNx = 0; iNx < iDesignItems; iNx++)
				{
					tag_t tProcessTemplateTag = NULLTAG;
					tag_t tProcessTag = NULLTAG;

					ITK(iFail,EPM_find_process_template( "DesignReleaseProcess", &tProcessTemplateTag));
					if(tProcessTemplateTag != NULLTAG)
					{
						int iAttTypes= 0;
						int att_type = 1;
						ITK(iFail,EPM_create_process("Test","Test", tProcessTemplateTag, 1, &ptDesisnItems[iNx], &att_type, &tProcessTag));
						if(tProcessTag != NULLTAG)
						{
							printf("\n Process Created\n");
						}
					}

				}
			}
			EMR_free(ptDesisnItems);
		}

	}
	EMR_free(ptTargetAttmnts);
	return iFail;
}
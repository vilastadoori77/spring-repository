//#ifdef __cplusplus
//extern "C" {
//#endif

#include <string.h>
#include <tc/tc.h>
#include <sa\am.h>
#include <form/form.h>
#include <tccore/custom.h>
#include <pom/pom/pom.h>
#include <tccore/tctype.h>
#include <sa/groupmember.h>
#include <sa/group.h>
#include <sa/user.h>
#include <bom/bom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <tccore/custom.h>
#include <itk/mem.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/signoff.h>
#include <epm/epm_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/uom.h>
#include <fclasses/tc_date.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/iman_util.h>
#include <sa/tcfile.h>
#include <stdlib.h>
#include <tccore\workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <epm\epm_toolkit_tc_utils.h>
#include <tc\aliaslist.h>
#include <time.h>
#include <conio.h>
#include <ae/ae.h>
#include <stdio.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_string.h>
#include <res/res_itk.h>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <fclasses/tc_date.h>
#include <vector>
#include <tc\iman_arguments.h>
#include "LBT9_CR_Handler.h"
#include "LBT9_DCN_Handler.h"
#include "LBT9_ECN_Handler.h"
#include "LBT9_DEV_Handler.h"
#include "LBT9_MCO_Handler.h"
#include "LBT9_StopShip_Handler.h"
using namespace std;


//#ifdef __cplusplus
//}
//#endif

#define ITK(ifail,argument)                                                               \
{                                                                                           \
   if ((ifail) == ITK_ok)                                                                   \
   {                                                                                        \
      if ( ( (ifail) = (argument) ) != ITK_ok )                                             \
      {                                                                                     \
         TC_write_syslog("\nFILE: %s LINE: %d\n", __FILE__, __LINE__);                      \
         printErrorMessage( ifail );                                                        \
	  }                                                                                     \
   }                                                                                        \
}

//changed macro as macro used single arguments
#define ERROR_CHECK( argument )                                     \
{                                                                   \
	if (retcode == ITK_ok)                                                    \
{                                                                        \
	retcode = argument;                                             \
	if ( retcode != ITK_ok )                                            \
{                                                                    \
	char* s;                                                        \
	TC_write_syslog( " "#argument "\n" );                                    \
	TC_write_syslog( "  returns [%d]\n", retcode );                          \
	EMH_ask_error_text (retcode, &s);                               \
	TC_write_syslog( "  Teamcenter Engineering Error: [%s]\n", s);          \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	if (s != 0) EMR_free (s);                                       \
}                                                                   \
}                                                                                          \
}

	
#define	LBT9_user_error_base										(EMH_USER_error_base )
#define	LBRT_STATUS_INVALID											(EMH_USER_error_base + 62 )
#define	LBRT_RELEASE_STATUS_ERROR									(EMH_USER_error_base + 63 )
#define	LBRT_PART_STATUS_ERROR										(EMH_USER_error_base + 64 )
#define LBRT_EFFECTIVITY_DATE_ERROR									(EMH_USER_error_base + 65 )
#define LBT_OBSOLETE_CHILD_ITEMS_FOUND                              (EMH_USER_error_base + 66 )
#define LBT_CHILD_REVS_DOES_NOT_EXIST_IN_SOLUTION_ITEMS             (EMH_USER_error_base + 67 )
#define LBT_RELEASED_SOLUTION_ITEMS_FOUND                           (EMH_USER_error_base + 68 )
#define LBT_PAST_EFFECTIVE_SOLUTION_ITEMS_FOUND			            (EMH_USER_error_base + 69 )
#define LBT_NO_TARGET_STATUS_SOLUTION_ITEMS_FOUND		            (EMH_USER_error_base + 70 )
#define LBT_HIGHER_REVISION_SOLUTION_ITEMS_FOUND		            (EMH_USER_error_base + 71 )
#define LBT_OTHER_ECN_SOLUTION_ITEMS_FOUND				            (EMH_USER_error_base + 72 )
#define LBT_NO_SOLUTION_ITEMS_FOUND									(EMH_USER_error_base + 73 )
#define LBT_NO_CHANGE_FUNCTION_SOLUTION_ITEMS_FOUND					(EMH_USER_error_base + 74 )
#define LBT_NO_FIELD_MODIFICATION_SOLUTION_ITEMS_FOUND				(EMH_USER_error_base + 75 )
#define LBT_NO_FINISHED_GOODS_SOLUTION_ITEMS_FOUND					(EMH_USER_error_base + 76 )
#define LBT_NO_NOTE_SOLUTION_ITEMS_FOUND							(EMH_USER_error_base + 77 )
#define LBT_NO_ON_ORDER_SOLUTION_ITEMS_FOUND						(EMH_USER_error_base + 78 )
#define LBT_NO_STOCK_SOLUTION_ITEMS_FOUND							(EMH_USER_error_base + 79 )
#define LBT_NO_WIP_SOLUTION_ITEMS_FOUND								(EMH_USER_error_base + 80 )
#define LBT_REVISION_SELECTED_IS_NOT_ECN_REVISION					(EMH_USER_error_base + 81 )
#define LBT_NO_SOLUTION_ITEMS										(EMH_USER_error_base + 82 )
#define LBT_CANNOT_COMPLETE_THE_TASK								(EMH_USER_error_base + 83 )
#define LBT_ECN_SELCTED_IS_NOT_IN_PENDING							(EMH_USER_error_base + 95 )
#define LBT9_TASK_DELEGATION_MESSAGE								(EMH_USER_error_base + 127)
#define LBT_ECN_ERP_STATUS_IS_NOT_CORRECT							(EMH_USER_error_base + 251)
#define LBT_ORIGINATOR_SHOULD_INITIATE_PRELIM_WORKFLOW				(EMH_USER_error_base + 252)

// Constansts for LBT9_LES_Integration.cpp flat file
//BOM expot functionlity constants (Header 1)
#define ECN_NUMBER_SPACE_LENGTH  							    	 12
#define CHANGE_ANALYST_SPACE_LENGTH  								 24
#define LES_STATUS_SPACE_LENGTH  								     20
#define ECN_DESCRIPTION_SPACE_LENGTH  								 15

//Affected items header space length (Headder 2)
#define LEVEL_SPACE_LENGTH  										 6
#define PART_NUMBER_SPACE_LENGTH  									 15
#define PCC_SPACE_LENGTH  									         15
#define UoM_SPACE_LENGTH  									         21
#define PLT_SPACE_LENGTH  									         18
#define CREATE_USER_SPACE_LENGTH  									 24
#define DEPT_SPACE_LENGTH  											 12
#define ASP_DATA_SPACE_LENGTH  										 9
#define SIMCST_SPACE_LENGTH  										 11
#define EFF_FM_DT_SPACE_LENGTH  									 10
#define Attachment_Where_SPACE_LENGTH  							     20
#define ROHS_REQ_SPACE_LENGTH  									     8
#define PART_DESCRIPTION_SPACE_LENGTH  								 16

//(Header 3)
#define BOM_PARENT_SPACE_LENGTH										 15
#define PART_NUMBER_SPACE_LENGTH									 15
#define OLD_REV_SPACE_LENGTH									     6
#define NEW_REV_SPACE_LENGTH									     6
#define ITM_SPACE_LENGTH  									         4
#define QTY_PER_SPACE_LENGTH  									     8
#define AC_PER_SPACE_LENGTH  									     2

//(Header 4)
#define MFG_PART_NUMBER_SPACE_LENGTH								 30
#define MFGR_NUMBER_SPACE_LENGTH									 9
#define MFGR_NAME_SPACE_LENGTH  									 40
#define MFGR_STATUS_SPACE_LENGTH								     15
#define AC_PER_SPACE_LENGTH  									     2

//(Header 4)
#define HEADER_VALUE_1												 1
#define HEADER_VALUE_2												 2
#define HEADER_VALUE_3												 3
#define HEADER_VALUE_4												 4

//Defining the constants
#define OBSOLETE_WORKFLOW											 "Obsolete"

#define EPM_REVIEW_TASK												 "EPMReviewTask"
#define EPM_SELECT_SIGNOFF_TASK										 "EPMSelectSignoffTask"
#define EPM_PERFORM_SIGNOFF_TASK									 "EPMPerformSignoffTask"

#define PROD_REL_STATUS												 "Production Released"
#define ASSIGNEE_USER												 "assignee"
#define USER														 "the_user"
#define PRE_APPROVAL_REVIEWERS										 "LBT9_PreApprovalReviewers"
#define ECN_TYPE													 "LBT9_ECNRevision"
#define EMR_DOCUMENT_REVISION										 "EMR_Document Revision"
#define	PRODUCT_SPECS_DOC_REV										 "LBT9_SpecDocRevision"
#define ASSIGNEE_USER												 "assignee"
#define USER														 "the_user"
#define CCB_REVIEWERS												 "Analyst"
#define FLAT_FILE_LOCATION                                           "EXP_BOM_FLAT_FILE_LOCATION"
#define EMAIL_BODY													 "LBRT_EMAIL_BODY_FILE"
#define REPORT_FILE_LOCATION										 "ECN_BOM_REPORT_FILE_LOCATION"
#define FILE_WRITING												 "w"
#define ITEM_ID														 "item_id"
#define ITEM_REVISION_ID											 "item_revision_id"
#define OWNING_USER													 "owning_user"
#define CHANGE_ANALYST												 "Analyst"
#define OBJECT_DESCRIPTION											 "object_desc"
#define ECN_RELEASE_STATUS											 "TCM Released"
#define ATTACHMENT_PRESENT											 "Attached to Document"
#define ATTACHMENT_NOT_PRESENT										 "No Attachment"
#define PCC_ATT_VALUE												 "lbt9_PCC"	
#define DOC_PCC_ATT_VALUE											 "lbt9_Category"
#define UOM_Att_VALUE												 "uom_tag"
#define PCC_SCHEMATIC_AST											 "*SCHEMATIC"		
#define PCC_SCHEMATIC_PLUS											 "SCHEMATIC"
#define PCC_WORK_INST_AST											 "*WORK INSTRUCTN"
#define PCC_WORK_INST_PLUS											 "WORK INSTRUCTIONS"
#define PCC_WORK_INST_AST1											 "*WORK INSTRUCTIONS"
#define OPT_ATT_VALUE												 "lbt9_Is_Option"
#define Y_VALE														 "Y"
#define N_VALE														 "N"
#define YES_VALE													 "YES"
#define NO_VALE													     "NO"
#define PLT_ATT_VALUE												 "lbt9_Plant"
#define SFA_ATT_VALUE												 "lbt9_Is_SFA_Part"
#define DEPT_ATT_VALUE												 "lbt9_Department"
#define ASP_DATA_ATT_VALUE											 "lbt9_Shelf_Life"
#define SMICST_ATT_VALUE											 "lbt9_Estimated_Cost"
#define ROHS_REQ_ATT_VALUE											 "lbt9_IS_RoHS_Reqd"
#define PART_DESC_ATT_VALUE											 "lbt9_Description"
#define UOM_ATT_VALUE												 "uom_tag"
#define ACTION_CODE_CHANGE											 "C"
#define ACTION_CODE_ADD												 "A"
#define ACTION_CODE_DELETE											 "D"
#define each														 "EA - EACH"
#define EA															 "EA - EACH"
#define FT 															 "FT - FEET"
#define LB															 "LB - POUND"
#define RE															 "RE - REFERENCE"
#define IN															 "IN - INCH"
#define RL															 "RL - ROLL"
#define SF															 "SF - SQUARE FEET"
#define ME															 "ME - METERS"
#define PR															 "PR - PAIR"
#define GA															 "GA - GALLON"
#define SE															 "SE - SET"
#define KG															 "KG - KILOGRAM"
#define PK															 "PK - PACKAGE"
#define IN2															 "SI - SQUARE INCH"
#define OZ															 "OZ - OUNCE"
#define ST															 "ST - SHEET"
#define BX															 "BX - BOX"
#define KT															 "KT - KIT"
#define DZN															 "DZ - DOZEN"
#define CA															 "CA - CAN"
#define GM															 "GM - GRAM"
#define TU															 "TB - TUBE"
#define DR															 "DR - DRUM"
#define CS															 "CS - CASE"
#define BO															 "BO - BOTTLE"
#define BG															 "BG - BAG"
#define T3															 "T3 - PER 1000"
#define HC															 "HC - PER 100"
#define PT															 "PT - PINTS"
#define ML															 "ML - MILLILETER"
#define CY															 "CY - CYLINDER"
#define L															 "L - LITER"
#define BE															 "BE - BUNDLE"
#define CC															 "CC - CUBIC CENTIMETER"
#define QT															 "QT - QUART"
#define M2															 "M2 - SQUARE METER"
#define LT															 "LT - LOT"
#define CF															 "CF - CUBICFEET"
#define APZ															 "TO - TROY OUNCE"
#define RM															 "RM - REAM"
#define DELIMITED													 "~"
#define USERS_LIST_SEPERATOR										 ";"
#define COMMERCIAL_VENDORPART_PROP									 "vendorparts"
#define VENDORPART_VENDORER_RELATION								 "TC_vendor_part_rel"
#define CURRENT_NAME												 "current_name"
//venu code
#define CM_ROUTING_DO_TASK_NAME 									 "Routing"
#define CM_RESUME_ROUTING_DO_TASK_NAME								 "Routing for Resume"
#define CM_FORM_TYPE 												 "LBT9_Approver_Form"
#define CM_SIGNOFF_FORM_TYPE 										 "LBT9_Signoff_Form"
#define CM_OBSERVER_FORM_TYPE										 "LBT9_Observer_Form"
#define CM_FORM_ATTACH_RELATION_TYPE								 "IMAN_specification"
#define CM_SUB_PROCESS_NAME     									 "Approval Sub Process"
#define CM_SUBPROCESS_DEPENDENT_TASK								 "Complete"
#define CM_SUBPROCESS_DEPENDENT_REVIEW_TASK							 "Sub Process Review"
#define CLASS_ECN_APPROVER_FORM										 "Form"
#define Attr_APPROVER_COMMENTS										 "lbt9_ApproverComments"
#define Attr_ECN_REVIEWERS_LIST										 "lbt9_Approver_Form"
#define Attr_SIGNOFF_HISTORY										 "lbt9_Signoff_History"
#define	Attr_Note_Form												 "lbt9_Note_Forms"			
#define Attr_ECN_OBSERVER_LIST  									 "lbt9_transfer_form"

#define RESPONSIBLE_PERSON											 "lbt9_Responsible_Person"
#define CCB_REVIEWERS_LIST											 "LBT9_CCB_Reviewers"
#define PROCESS_OWNER												 "$PROCESS_OWNER"
#define ORIGINATOR													 "Requestor"
#define CLASS_ECN_REVISION											 "LBT9_ECNRevision"
#define CLASS_DCN_REVISION											 "LBT9_DCNRevision"
#define STATUS_LIST													 "release_status_list"
#define OBJECT_NAME													 "object_name"
#define ATTACH_TYPE													 "attach_type"
#define REVIEW_TASK_NAME											 "review_task_name"
#define STATUS														 "status"

// Sign OFF form Properties
#define SIGNOFF_USER												 "lbt9_history_user"
//#define SIGNOFF_STATUS											 "lbt9_history_status"
#define SIGNOFF_DATE												 "lbt9_history_date"
#define SIGNOFF_TYPE												 "lbt9_history_type"
#define SIGNOFF_COMMENT												 "lbt9_history_comments"
//Task definition
#define PRE_APPROVAL_REVIEW_TASK									 "PreApproval Review"
#define SUB_PROCESS_USER_DO_TASK									 "User Do Task"
#define COMPLETED													 "Completed"
#define RESPONSIBLE_PARTY											 "resp_party"
#define COMMENTS													 "comments"
#define PARENT_TASK													 "parent_task"
#define USER_ID														 "user_id"
#define OBJECT_TYPE													 "object_type"
#define CA_PERFORM_SIGNOFF											 "perform-signoffs"
#define CCB_REVIEW_SIGNOFF											 "EPMPerformSignoffTask"
#define PA9															 "PA9"
#define ASSIGNED_BY													 "lbt9_AssignedBy"
#define APPROVER_COMMENTS											 "lbt9_ApproverComments"
#define APPROVER_STATUS												 "lbt9_ApproverStatus"
#define APPROVER_STATUS_ACTIVE										 "Active"
#define SIGNOFF_STATUS												 "lbt9_SignoffStatus"
#define SIGNOFF_STATUS_INPROCESS									 "In Process"
#define STATUS_CCB													 "LBT9_CCB_Review"
#define PROCESS_NAME												 "process_name"
//ECN Validation
#define SOLUTION_ITEMS_RELATION										 "CMHasSolutionItem"
#define IMPACTED_ITEMS_RELATION										 "CMHasImpactedItem"
#define CM_DESIGN_ITEMS												 "LBT9CMHasDesignItems"
#define OBSOLETE_STATUS												 "Obsolete"
#define INACTIVE_STATUS												 "LBT9_Inactive"
#define RELEASE_STATUS												 "EMR_Released"
#define PENDING_STATUS												 "Pending"
#define PRELIMINARY													 "LBT9_Preliminary"
#define PROTOTYPE													 "LBT9_Prototype"
#define IMAN_MASTER_FORM_RELATION									 "IMAN_master_form"
#define ECN_ERP_STATUS												 "lbt9_ERP_Status"

#define ECN_PLANTS_AFFECTED											 "lbt9_Plants_Affected"
#define ECN_PRODUCT_LINES											 "lbt9_Product_Lines"
#define COMMERCIAL_PART_PLANTS										 "lbt9_Plant"
#define COMMERCIAL_PRODUCT_LINES									 "lbt9_Product_Lines"

#define ADDRESS_LIST												 "addresslist"

//MPN MFGR_status
#define MFGR_STATUS_ACTIVE											 "Preferred"
#define MFGR_STATUS_NOT_PREFERRED									 "Not Preferred"

//Prelimnary Process sign off form attributes
#define SIGN_OFF_PRLEMIN_USER										 "lbt9_signoff_Prelimn_user"
#define SIGN_OFF_PRELIMN_START_DATE									 "lbt9_signoff_start_date"
#define SIGN_OFF_PRELIMN_COMPLETE_DATE								 "lbt9_signoff_end_date"
#define SIGN_OFF_PRELIMN_STATUS										 "lbt9_signoff_Prelimn_status"

//Preliminary ECN Task Name
#define PRELIMINARY_CONDITION_TASK_NAME								 "Data Base Change Analyst"

//LES Change Analyst
#define Attr_ECN_change_analyst										 "lbt9_Change_Analyst"
#define PRELIMINARY_ECN_WORKFLOW									 "Preliminary ECN workflow"
#define ECN_WORKFLOW												 "Implement ECN Workflow"
#define MCO_WORKFLOW												 "Implement MCO Workflow"

//Send Notes
#define CM_NOTES_FORM_ATTACH_RELATION_TYPE							 "LBT9_ECN_Notes_Rel"
#define PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH						 "Wipro_LBT_Approver_Email_Template_Location"
#define CM_NOTE_FORM_TYPE                   						 "LBT9_Note_Form"

//Modify solution Item Properties

#define TARGET_STATUS 	       										 "lbt9_Target_Status"
#define CHANGE_FUNCTION												 "lbt9_Change_Function"
#define FIELD_MODIFICATION  										 "lbt9_Field_Mod"
#define ON_ORDER		 											 "lbt9_On_Order"
#define STOCK			 											 "lbt9_Stock"
#define NOTE			 											 "lbt9_Note"
#define WORK_IN_PROGRESS											 "lbt9_Work_In_Progress"
#define FINISHED_GOODS												 "lbt9_Finished_Goods"

#define PREF_MAIL_SERVER_NAME										 "Mail_server_name"
#define PREF_MAIL_SERVER_PORT										 "Mail_server_port"

#ifdef __cplusplus
extern "C" {
#endif


//Functions defined in LBT9_Change_Register_Handlers.cpp
extern DLLAPI int libLBT9_Change_register_callbacks();
extern DLLAPI int libLBT9_Change_register_handlers(int *decision, va_list args);
extern DLLAPI int wiprocustom_userservice_register_methods(int *decision, va_list args);
extern int LBRT_register_action_handlers();
extern int LBRT_register_rule_handlers();


//Functions defined in LBT9_Generic_Handlers.cpp
extern int LBT9_SET_VALUES_ON_CHANGE_OBJECT(EPM_action_message_t msg);
extern int LBT9_ASSIGN_TASK_TO_CA(EPM_action_message_t msg);
extern int LBT9_ASSIGN_ROUTING_TASK_TO_CA(EPM_action_message_t msg);
extern int LBT9_CHANGE_HISTORY(EPM_action_message_t message);
extern int LBT9_CREATE_CCB_SUBPROCESS(EPM_action_message_t message);
extern int LBT9_Proposed_Reviewers(EPM_action_message_t msg);
extern int LBT9_Set_Iteration_Property(EPM_action_message_t message);
extern int LBT9_COMPLETE_ROUTING_TASK(EPM_action_message_t message);
extern EPM_decision_t LBT9_Change_Analyst_validation(EPM_rule_message_t message);
extern int LBT9_COMPLETE_CONDITION_TASK(EPM_action_message_t message);
extern int LBT9_Set_Approval_Comments(EPM_action_message_t message);
extern int LBT9_ASSIGN_PARTCIPANT(EPM_action_message_t msg);
extern int LBT9_LES_FILE_IMPLEMENTED(EPM_action_message_t message);
extern int LBT9_APPEND_COMPLETED_TO_APPROVER_FORM(EPM_action_message_t message);
extern int LBT9_DATABASE_CA_TASK_ASSIGN(EPM_action_message_t message);
extern int LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM(EPM_action_message_t msg);


//Functions defined in LBT9_Generic_Methods.cpp
void printErrorMessage								(int ifail													/* <I> */ 
													);	
int LBT9_MEM_free_Strings							(char ** PropertyName,										/* <I> */
													 int PropertyCount 											/* <I> */
													);
void EMR_free										(void* ptr													/* <I> */
													);
int fnSetFormValuesForTransfer						(tag_t FormTag,												/* <I> */
													 tag_t UserTag,												/* <I> */
													 char *Status,												/* <I> */
													 const char *Comments										/* <I> */
													);
extern int createOrRemoveSubProcess					(void *returnValueType										/* <I> */
													);
extern int findForm									(tag_t revTag,												/* <I> */
													 char *formName,											/* <I> */
													 tag_t *formTag												/* <O> */
													);
extern int LBT_getActiveApprovalForms				(tag_t ecn_rev_tag,											/* <I> */
													 int *n_active_forms,										/* <O> */
													 tag_t **active_form_tags									/* <OF> */
													);
extern int LBT_get_single_preference_value			(char *preference_name,										/* <I> */
													 char **preference_value									/* <OF> */
													);
extern int get_ecn_rev_master_form					(tag_t rev_tag,												/* <I> */
													 tag_t *rev_master_form_tag									/* <I> */
													);
extern int clearProcess								(tag_t objectTag,											/* <I> */
													 tag_t parent_process_tag									/* <I> */
													);
int deleteApproverSubprocesses						(tag_t revTag,												/* <I> */
													 int n_removed_groupmembers,								/* <I> */
													 tag_t *removed_group_member_tags,							/* <I> */
													 char *logged_in_user										/* <I> */
													);
int LBT_getUniqueObjects							(int n_objects,												/* <I> */
													 tag_t *object_tags,										/* <I> */
													 int *n_unique_obects,										/* <O> */
													 tag_t **unique_object_tags									/* <OF> */
													);
int addAttachment									(tag_t rootTask,											/* <I> */		
													 tag_t objectTag,											/* <I> */
													 int attachment_type										/* <I> */
													);
int attachFormToRevision							(tag_t formTag,												/* <I> */
													 tag_t revTag,												/* <I> */
													 const char *cpECNPropertyName								/* <I> */
													);
int initiateSubProcess								(char *processName,											/* <I> */
													 tag_t targetObject,										/* <I> */
													 tag_t referenceObject,										/* <I> */
													 tag_t *subProcessTag										/* <O> */
													);
int getSubProcessDependencyTask1					(tag_t job_tag,												/* <I> */
													 char *task_name,											/* <I> */
													 tag_t *task_tag											/* <I> */
													);
int getPerformSignoffTaskOfReview					(tag_t job_tag,												/* <I> */
													 char *review_task_name,									/* <I> */
													 tag_t *task_tag											/* <O> */
													);
int createAddApproverSubProcesses					(tag_t revTag,												/* <I> */
													 int n_added_groupmembers,									/* <I> */
													 tag_t *added_group_member_tags,							/* <I> */
													 char *logged_in_user,										/* <I> */
													 const char *cpAction
													);
int createAddApproverSubProcessesStopShip			(tag_t revTag,												/* <I> */
													 int n_added_groupmembers,									/* <I> */
													 tag_t *added_group_member_tags,							/* <I> */
													 char *logged_in_user,										/* <I> */
													 const char *cpAction
													);
int getRoutingDoTaskOfJob							(tag_t job_tag,												/* <I> */
													 char *taskName,											/* <I> */
													 tag_t *task_tag											/* <O> */
													);
int fnSetFormValues									(tag_t FormTag,												/* <I> */
													 tag_t UserTag,												/* <I> */
													 char* status												/* <O> */
													);
int fnGetParticipantUsersList1						(tag_t tTargetAttachment,									/* <I> */
													 const char *ParticipantType,								/* <I> */
													 int *iReviewersCount,										/* <O> */
													 tag_t **tReviewersTags										/* <OF> */
													);
int addObservers									(tag_t revTag,												/* <I> */
													 int n_added_observers,										/* <I> */
													 tag_t *added_observer_tags,								/* <I> */
													 char *logged_in_user										/* <I> */
													);
int attachObserverFormToRevision					(tag_t formTag,												/* <I> */
													 tag_t revTag												/* <I> */
													);
int getConsolidatedObservers						(int n_existing_observers,									/* <I> */
													 char **existing_observers_list,							/* <I> */
													 int n_added_observers,										/* <I> */
													 char **added_observers_list,								/* <I> */
													 int *n_con_observers,										/* <O> */
													 char ***con_observers_list									/* <OF> */
													);
int getNewlyAddedObservers							(int n_existing_observers,									/* <I> */
													 char **existing_observers_list,							/* <I> */
													 int n_added_observers,										/* <I> */
													 char **added_observers_list,								/* <I> */
													 int *n_new_observers,										/* <O> */
													 char ***new_observers_list									/* <OF> */
													);
int CreateObserverForms								(tag_t revTag,												/* <I> */
													 int n_new_observers,										/* <I> */
													 char **new_observers_list,									/* <I> */
													 char *logged_in_user										/* <I> */
													);
int removeObservers									(tag_t revTag,												/* <I> */
													 int n_removed_observers,									/* <I> */
													 tag_t *removed_observer_tags,								/* <I> */
													 char *logged_in_user										/* <I> */
													);
int getLeftOverObservers							(int n_existing_observers,									/* <I> */
													 char **existing_observers_list,							/* <I> */
													 int n_removed_observers,									/* <I> */
													 char **removed_observers_list,								/* <I> */
													 int *n_leftover_observers,									/* <O> */
													 char ***leftover_observers_list							/* <OF> */
													);
extern int LBT_removeValueFromMultiListString		(tag_t object,												/* <I> */
													 char *multi_string_propertyname,							/* <I> */
													 int n_values_to_be_removed,								/* <I> */
													 char **valueToBeRemoved,									/* <I> */
													 logical *flag												/* <O> */
													);
int findObserverForm								(tag_t revTag,												/* <I> */
													 char *formName,											/* <I> */
													 tag_t *formTag												/* <O> */
													);
int  fnsubString									(char*  String,												/* <I> */ 
													 int endvalue,												/* <I> */
													 char ** subString											/* <OF> */
													);
int fnAddressList									(tag_t* ptTargetAttmnts ,									/* <I> */
													 int iAttchItemCount,										/* <I> */
													 tag_t* tAttchItemTag										/* <I> */
													);
int fnToSetProposedReviwers							(tag_t* TargtAttcmnt,										/* <I> */
													 tag_t* SecondryItemTag,									/* <I> */
													 int SecondryItemCount										/* <I> */
													);
int fnGetCommaSeperatedList							(int UserCount,												/* <I> */
													 char **UserList,											/* <I> */
													 char **Temp												/* <OF> */
													);
int fnGetUserListforNotCompletedTask				(char *AnalystId,											/* <I> */
													 int FormCount,												/* <I> */
													 tag_t* FormTags,											/* <I> */
													 int *UserCount,											/* <O> */
													 char ***UserList											/* <OF> */
													);
int fnToGetTheLatestChangeAnalystResult				(int FormCount,												/* <I> */
													 tag_t *FormTags,											/* <I> */
													 tag_t ECNRevisionTag,										/* <I> */
													 char *AnalystId,											/* <I> */
													 char **Result												/* <OF> */
													);
int fnGetParticipantUsersList						(tag_t tTargetAttachment,									/* <I> */
													const char *ParticipantType,								/* <I> */
													std::vector<tag_t> &Vuser									/* <O> */
													);
int LBT_get_unreleased_impacted_items				(int n_imp_revs,											/* <I> */
													 tag_t *imp_rev_tags,										/* <I> */
													 int *n_unreleased_revs,									/* <O> */ 
													 tag_t **unreleased_rev_tags								/* <OF> */ 
													);
int fnToGetShortObjectNameForChangeObject			(tag_t ObjectTag,											/* <I> */
													 char **Object_Name											/* <OF> */
													);
int fnToGetDatabaseChangeAnalystUser				(char **DBAUser												/* <OF> */
													);
int fnToValidateChangeObjectStatus					(tag_t ChangeObjectTag,										/* <I> */
													 const char *StatusName,									/* <I> */
													 logical *ValidationStatus									/* <O> */
													);

int LBT_get_notALatestRev_impacted_items			(int n_imp_revs,											/* <I> */
													 tag_t *imp_rev_tags,										/* <I> */
													 int *n_notLatestRev_revs,									/* <O> */ 
													 tag_t **notLatest_rev_tags									/* <OF> */ 
													);
int fnUpdateChangeHistoryForm						(tag_t change_rev_tag,      								/* <I> */
													 int n_solution_items,      								/* <I> */
													 tag_t *solution_rev_tags   								/* <I> */
													);
 int fnToGetCurrentUserId							(char **CurrentUserId										/* <OF> */
													);
  int fnToCheckCurrentUserIsOriginator				(tag_t RevisionTag,											/* <I> */
													 logical *UserIsOriginator									/* <O> */
													);
//Declaration of methods used in LBT9_Mail_Generic_Methods.cpp 

extern int LBT_get_email_id							(char *user_id,												/* <I> */
													 char **email_id											/* <OF> */
													);
extern int LBT_send_notification_email				(char *to_users_list,										/* <I> */
									                 char *cc_users_list,										/* <I> */ 	
													 char *subject,												/* <I> */
													 char *bodypath												/* <I> */
													);
extern int LBT_get_perform_signoff_task				(tag_t job,													/* <I> */
													 const char *task_name,										/* <I> */
													 tag_t *perform_signoff_task								/* <O> */
													);
extern int LBT_get_perform_signoff_details			(tag_t perform_signoff_task,								/* <I> */
										             EPM_signoff_decision_t decision_type,						/* <I> */
								                     char **decision_taken_by_user_id,							/* <OF> */
										             char **decision_taken_by_user_name,						/* <OF> */
													 char **decision_comments,									/* <OF> */
													 char **decision_date_string								/* <OF> */
													);
int fnGetParticipantList							(tag_t tTargetAttachment,									/* <I> */
													 const char *ParticipantType,								/* <I> */
													 tag_t *tAssgnParticipantTag								/* <O> */
													);
int fnToGetActiveUserList							(tag_t RevisionTag,											/* <I> */
													 int ApproverFormCount,										/* <I> */
													 tag_t *tApproverFormTag,									/* <I> */
													 std::vector<char*> &Vuser									/* <O> */							
													);
int hasAllTheSubProcessesCompleted					(tag_t rev_tag,												/* <I> */
													 tag_t current_form,										/* <I> */
													 logical *allAreCompleted									/* <O> */
													);
int hasAllProcessCompletedforCA						(tag_t rev_tag,												/* <I> */
													 tag_t current_form,										/* <I> */
													 logical *allAreCompleted									/* <O> */
													);
int fnToGetChangeAnalystComments					(tag_t rev_tag,												/* <I> */
													 char *Analyst,												/* <I> */
													 char **decision_comment									/* <OF> */
													);
int	fnToGetListOfUser								(std::vector<char *> Vuser,									/* <I> */
													 char **cpListofUser										/* <OF> */
													);
int fnGetSystemToListusers							(tag_t rev_tag,												/* <I> */
													 const char *cpAddtionaluser,								/* <I> */ 
													 char **cpToUserList										/* <OF> */
													);
int fnDelegateMail									(tag_t tRevisionTag,										/*<I>*/
													 char * LoginUserId,										/*<O>*/
													 char * AssignedUserId										/*<O>*/
													);
int fnSubjectForDelegateMail						(char *ObjectId,			/* <I> */
													 char *ObjectName,			/* <I> */
													 char *cpType,				/* <I> */
													 char **subject			    /* <OF> */
													);
													
int fnBodyForDelegateMail							(char *item_id,												/* <I> */
													 char *item_rev_id,											/* <I> */
													 tag_t item_rev_tag,										/* <I> */
													 char* LoginUserId,											/* <I> */
													 char * AssignedUserId,										/* <I> */
													 char *cpType,												/* <I> */
													 char **emailTemplatePath									/* <OF> */
													);
													
//Added by Rahul
int fnSubjectForOOFDelegateMail	(char *ObjectId,			/* <I> */
								 char *ObjectName,			/* <I> */
								 tag_t tChangeRevTag,				/* <I> */
								 char **subject			    /* <OF> */
								);

int fnOOFBodyForDelegateMailPreApprovalToSubmitted (	char *item_id,              /* <I> */
											char *item_rev_id,			/* <I> */
											char *analyst_name,		    /* <I> */
											tag_t item_rev_tag,			/* <I> */
											char *cpDelegationUserID,    /* <I> */
											char **emailTemplatePath    /* <OF> */
									   );

int fnOOFBodyForDelegateMailNotifyTaskAssignment(tag_t rev_tag,												/* <I> */
												 char *item_id,												/* <I> */
												 char *rev_id,												/* <I> */
												 char *OwningUserID,											/* <I> */
												 char **emailTemplatePath									/* <OF> */
												);
int fnDeligateMailBodyForNotifyTaskAssignment(tag_t rev_tag,												/* <I> */
									 char *item_id,												/* <I> */
									 char *rev_id,												/* <I> */
									 char *OwningUserID,										/* <I> */
									 char *cpObjectType,										/* <I> */
									 char **emailTemplatePath									/* <OF> */
									);
int fnGetDeligationUser(tag_t tuserTag,	/*<I>*/
						char **DelegationUserID /*<OF>*/
					   );
int fnGetItemTypeforMail(tag_t ItemRevtag, /*<I>*/
						 char **cpItemRevType /*<OF>*/
						);
int fnForNotifyingOOFAddedApprovers		( tag_t RevisionTag,	 /* <I> */
										  tag_t tUserTag,        /* <I> */										  
										  char *OriginalUserID	  /* <I> */
										);
int fnBodyForOOFNotifyingAddedApprovers  (	  char *OriginalUserID,											 
											  char **emailTemplatePath    /* <OF> */
										 );
	

//Declaration of handlers and methods used in LBT9_Mail_Generic_Handler.cpp

extern int LBT9_PreApproval_Originator_Notify(EPM_action_message_t message);
extern int LBT9_Originator_Pending_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_Submitted_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_CCB_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_CCB_Resume_Notify(EPM_action_message_t message);
extern int LBT9_Analyst_Submitted_to_Pending_Notify(EPM_action_message_t message);
int fnForNotifyingRemoveApprovers				(tag_t RevisionTag,											/* <I> */
													 tag_t tUserTag,											/* <I> */
													 char *UserId												/* <I> */
													);
int fnForNotifyingAddedApprovers					(tag_t RevisionTag,											/* <I> */
													 tag_t tUserTag,											/* <I> */
													 char *UserId												/* <I> */
													);
int fnNotifyApproveDecision							(char *originator_id,										/* <I> */
													 char *assigned_by,											/* <I> */
													 tag_t rev_tag,												/* <I> */
													 char *user_id,												/* <I> */
													 char *user_comment											/* <I> */
													);
extern int LBT9_Notify_Approval(EPM_action_message_t message);
int fnNotifyRejectionDecision						(char *originator_id,										/* <I> */
													 char *assigned_by,											/* <I> */
													 tag_t rev_tag,												/* <I> */
													 char *user_id,												/* <I> */
													 char *user_comment											/* <I> */
													);
extern int LBT9_Notify_Rejection(EPM_action_message_t message);
int fnNotifyWhenAllUserCompleted					(tag_t RevisionTag,											/* <I> */
													 char *AnalystId,											/* <I> */
													 char *OridinatorId											/* <I> */
													);
extern int LBT9_Notify_Change_Analyst_After_All_Signoffs(EPM_action_message_t message);
extern int LBT9_Originator_CCB_To_Pending_Notify(EPM_action_message_t msg);
extern int LBT9_Originator_CCB_To_Resumed_Rejection_Notify(EPM_action_message_t msg);
extern int LBT9_Originator_Released_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_Task_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_Implemented_Notify(EPM_action_message_t msg);
extern int LBT9_Originator_Or_Analyst_Canceled_Notify(EPM_action_message_t msg);
extern int LBT9_Analyst_Resumed_to_Released_Notify(EPM_action_message_t message);
extern int LBT9_Originator_Task_Notify(EPM_action_message_t msg);

//Delegation relation Handlers
extern int LBT9_DELEGATE_MAIL(EPM_action_message_t message);
extern EPM_decision_t LBT9_DELEGATE_VALIDATION(EPM_rule_message_t message);

//Functions defined in LBT9_Mass_Change.cpp
extern int performMassChange						(void *returnValueType
													);
int fnToCheckLRRofItemMassChange					(tag_t tPartTag,							/* <I> */
													tag_t *PartLRRTag							/* <O> */
													);
int processPartNumber(char* strAssemblyPartNo, char* strPartNumber, tag_t ecn_rev_tag, char* strMode, char* strReplacingPartNumber);
int processBOMForAssemblyRev(tag_t assembly_new_rev_tag, tag_t assembly_item_tag, char* strPartNumber, char* strMode, char* strReplacingPartNumber);
//Functions defined in LBT9_Send_Note.cpp
extern int sendNote									(void *returnValueType										/* <I> */					
													);
extern int LBT_send_note_email						(char *to_users_list,										/* <I> */
													 char *email_id_list,										/* <I> */ 	
													 char *subject,												/* <I> */
													 char *bodypath												/* <I> */
													);
int createNoteForm									(tag_t rev_tag,												/* <I> */              
													 tag_t logged_in_group_member_tag,							/* <I> */
													 char *to_users_list,										/* <I> */
													 char *to_email_id,											/* <I> */
													 char *comments												/* <I> */
													);
int makePartcipantsList								(char *users_list,											/* <I> */
													 char *email_id_list,										/* <I> */
													 int *n_participants,										/* <O> */
													 char ***participants_list									/* <OF> */
													);
int attachNotesFormToRevision						(tag_t formTag,												/* <I> */
													 tag_t revTag												/* <I> */
													);
int generateNoteBodyAttachment						(char *commment,											/* <I> */
													 char **emailTemplatePath									/* <OF> */
													);
int generateDefaultBodyAttachment					(tag_t rev_tag,												/* <I> */
													 char *item_id,												/* <I> */
													 char *rev_id,												/* <I> */
													 char *process_owner_name,									/* <I> */
													 char **emailTemplatePath									/* <OF> */
													);
int getParticipantsUserIds							(char *recipient,											/* <I> */
													 tag_t rev_tag,												/* <I> */   
													 tag_t root_task,											/* <I> */						   
													 char **to_users_list										/* <OF> */
													);
int fnToGetTheSubjectForNote						(const char * ObjectType,									/* <I> */
													 char *item_id,												/* <I> */
													 char *rev_id,												/* <I> */
													 char **email_subject										/* <OF> */
													);
extern int deriveChange									(void *returnValueType										/* <I> */					
													);
int fnCreateChgRequestFromChgNotice					(tag_t  tChgNoticeRevTag,									/*< I >*/
													 char * cptargetType,										/*< I >*/
													 char * isDatasetsSelected,									/*< I >*/
													 char ** cpNewObjectId										/*< O >*/
													);
int fnCreateChgNoticeFromChgRequest					(tag_t tChgRequestTag,										/*< I >*/
													 char * cptargetType,										/*< I >*/
													 char * isDatasetsSelected,									/*< I >*/
													 char ** cpNewObjectId										/*< O >*/
													);
int fnCreateChgRequestFromChgRequest				(tag_t tChgRequestTag,										/*< I >*/
													 char * cptargetType,										/*< I >*/
													 char * isDatasetsSelected,									/*< I >*/
													 char ** cpNewObjectId										/*< O >*/
													);
int fnCreateChgNoticeFromChgNotice					(tag_t tChgNoticeTag,										/*< I >*/
													char * cptargetType,										/*< I >*/
													char * isDatasetsSelected,									/*< I >*/
													char ** cpNewObjectId										/*< O >*/
													);
int fnGetTargetTypeRealName							(char * cptargetType,										/*< I >*/
													 char **cpRealname											/*< O >*/
													);

int fnCreatingNewItem								(tag_t ChangeObjectTag,										/* <I> */
													 char * cpCreateType,										/* <I> */
													 tag_t * tNewItemRevTag										/* <O> */
													);
int fnAttachDatasets								(tag_t tChgObjectTag,										/* <I> */
													 tag_t tNewChgObjectTag										/* <I> */
													);
int commonForDatasets								(tag_t chgObjectRevTag,										/* <I> */
													 tag_t NewchgObjectRevTag,									/* <I> */
													 tag_t tTypeTag												/* <I> */
													);
int fnGetNewRevisionValue							(char * revid,												/* <I> */
												     tag_t tItemTag,											/* <I> */
													 char** NewRevisionId										/* <O> */
													);
int fnToCheckRevDoesNotExists						(char * revid,												/* <I> */
				 									 tag_t tItemTag,											/* <I> */
				 									 logical* booleancheck										/* <O> */
				 									);
int fnToIncrementRevisionId							(char * revid,												/* <I> */
				 									 tag_t tItemTag,											/* <I> */
				 									 char ** NewRevid											/* <O> */
				 									);
int  fnsubStringForMinorRev							(char*  String,												/* <I> */ 
													 int endvalue,												/* <I> */
													 char ** subString											/* <OF> */
													);


//Functions defined in LBT9_ECN_Generic_Methods.cpp // it is Common for all

extern int LBT_get_ecn_revision						(tag_t task,												/* <I> */
													 char *className,											/* <I> */
													 int attachment_type,										/* <I> */
													 tag_t *object												/* <O> */
													);
int LBT_get_related_objects							(tag_t rev_tag,												/* <I> */
													 char *relation,											/* <I> */
													 int *n_solution_revs,										/* <O> */
													 tag_t **solution_rev_tags									/* <OF> */
													);
int hasStatusReleased								(tag_t objectTag,											/* <I> */
													 char *statusName,											/* <I> */
													 logical *flag												/* <O> */
													);
int hasStatusInactive								(tag_t objectTag,											/* <I> */
													 char *statusName,											/* <I> */
													 logical *flag												/* <O> */
													);
int hasStatus										(tag_t objectTag,											/* <I> */
													 char *statusName,											/* <I> */
													 logical *flag												/* <O> */
													);
extern int LBT_get_latest_released_revision			(tag_t item_tag,											/* <I> */
													 tag_t *rev_tag												/* <O> */
													);
int LBT_get_obsolete_children						(tag_t revTag,												/* <I> */
													 tag_t bvrTag,												/* <I> */
													 int *n_obsolete_child,										/* <O> */
													 tag_t **obsolete_childrens									/* <OF> */
													);
int LBT_get_inactive_children						(tag_t revTag,												/* <I> */
													 tag_t bvrTag,												/* <I> */
													 int *n_inactive_child,										/* <O> */
													 tag_t **inactive_childrens									/* <OF> */
													);
int LBT_getCommaSeparatedListOfItemRevs				(int revCount,												/* <I> */
													 tag_t *revTags,											/* <I> */
													 char **revs_list											/* <OF> */
													);
int LBT_getCommaSeparatedListOfItemRevsObsolete		(tag_t revTag,												/* <I> */
													 char **revs_list											/* <OF> */
													);
int LBT_get_unreleased_children						(tag_t revTag,												/* <I> */
													 tag_t bvrTag,												/* <I> */
													 int *n_unreleased_child,									/* <O> */
													 tag_t **unrelased_child_tags								/* <OF> */
													);
int LBT_checkif_unreleased_revs_exist_in_solutions	(int n_solution_revs,										/* <I> */ 
                                                    tag_t *solution_rev_tags,									/* <I> */
												    int n_unreleased_child,										/* <I> */
												    tag_t *unreleased_child_tags,								/* <I> */
												    int *n_child_not_in_solutions,								/* <O> */
												    tag_t **child_not_in_solutions								/* <OF> */
													);
int LBT_Is_Solution_Items_Status_Preliminary_or_Prototype(int n_sol_revs,										/* <I> */
														  tag_t *sol_rev_tags,									/* <I> */
														  int *n_released_revs,									/* <I> */ 
														  tag_t **released_rev_tags,							/* <I> */ 
														  logical *SolutionItemStatus							/* <O> */
														 );
int Check_status_for_each_solution_object			(tag_t tSolutiontag,										/* <I> */
													 logical *EachSolutionItemStatus							/* <O> */
													);
int LBT_get_released_solution_items					(int n_sol_revs,											/* <I> */
													 tag_t *sol_rev_tags,										/* <I> */
													 int *n_released_revs,										/* <I> */ 
													 tag_t **released_rev_tags									/* <I> */ 
													);
int LBT_has_release_status							(tag_t object,												/* <I> */
													 logical *statusFlag										/* <O> */
													);
int LBT_get_released_solution_items					(int n_sol_revs,											/* <I> */
													 tag_t *sol_rev_tags,										/* <I> */
													 int *n_released_revs,										/* <I> */ 
													 tag_t **released_rev_tags									/* <I> */ 
													);

int LBT_get_lower_rev_solution_items				(int n_solution_revs,										/* <I> */
													 tag_t *solution_rev_tags,									/* <I> */
													 int *n_hi_sol_revs,										/* <O> */
													 tag_t **hi_sol_rev_tags									/* <OF> */
													);
int fnGetDatasets									(tag_t tSolutionItemTag,									/*< I >*/
													 char * cpStatus											/*< I >*/
													);
int fnSetStatusOnDatasets							(tag_t tSolutionItemTag,									/*< I >*/
													 tag_t tRelTypeTag,											/*< I >*/
													 char * cpStatus											/*< I >*/
													);
// Functions defined in LBT9_LES_Integration.cpp
extern int LBT9_BOM_EXP(EPM_action_message_t msg);
int fnPrintingPartMPNInfo							(tag_t tPartObjectTag,  									/* <I> */
													 char *ECNItemId,											/* <I> */
													 FILE *fp													/* <I> */
													);
int fnMPNPrinting									(tag_t CommrclPartRevisionTag,								/* <I> */
													 tag_t tVendorPartTag,										/* <I> */
													 char *VendorPartID,										/* <I> */	
													 char *Action,												/* <I> */
													 FILE *fp													/* <I> */
													);
int fnPrintingPartBOMInfo							(tag_t tPartObjectTag,										/* <I> */
													 char *ECNItemId,											/* <I> */
													 FILE *fp													/* <I> */
													);
int fnWriteCRBOMInfo								(tag_t BVRParent,											/* <I> */
													 char *ECNItemID,											/* <I> */
													 char *CRId,												/* <I> */
													 FILE *fp													/* <I> */
													);	
int fnBomlinePrinting							    (tag_t tParenttag,											/* <I> */
													 tag_t tchildtag,											/* <I> */
													 char *ECNItemId,											/* <I> */
													 char *NewRevID,											/* <I> */
													 char *OldRevID,											/* <I> */
													 char *Action,												/* <I> */
													 FILE *fp													/* <I> */
													);	
int fnPrintingPartInfo								(tag_t tPartObjectTag,										/* <I> */
													 tag_t tECNObjecttag,										/* <I> */
													 char *ECNItemId,											/* <I> */
													 map<std::string,std::string> mUOMAllValue,					/* <I> */
													 FILE *fp													/* <I> */
													);
int fnPrintingDocInfo								(tag_t tDocumentRevTag,										/* <I> */
													 tag_t tECNObjecttag,										/* <I> */
													 char *ECNItemId,											/* <I> */
													 FILE *fp													/* <I> */
													);		
int fnEFF_FM_DATE									(tag_t tPartObjectTag,										/* <I> */
													 FILE *fp													/* <I> */
													);
int IsDocumentExist									(tag_t tPartRevObject										/* <I> */
													);	
int fnWrite_YorN_Value								(char *cpAttrValue,											/* <I> */
													 FILE *fp													/* <I> */
													);	
int fnPrintECNInfo									(tag_t tECNObjecttag,										/* <I> */
													 char *cpProcessName,										/* <I> */
													 FILE *fp													/* <I> */
													);			
int fnWriteChangeAnalystValue						(tag_t tChangeObject,										/* <I> */
													 FILE *fp													/* <I> */
													);	
int fnToTrimtheExceedLength							(int iPropertyLength,										/* <I> */
													 int iPropertySpecifiedLength,								/* <I> */
													 char *cpPropertyValue,										/* <I> */
													 FILE *fp													/* <I> */
													);	
int fnToPrintTheRevisionId							(char *cpPartRevID,											/* <I> */
													 FILE *fp													/* <I> */
													);													
int fnPrintSpaceValues								(int spaceValue,											/* <I> */
													 FILE *fp													/* <I> */
													);
int fnPrintECNheader								(FILE *fp,													/* <I> */
													int headervalue												/* <I> */
												    );	
int fnUpdateFormProperties							(tag_t tRevTag,												/* <I> */
													 tag_t tUserTag,											/* <I> */
													 char *cpStatus,											/* <I> */
													 char * wfuser												/* <I> */
													);												
int fnToCheckLRRofItem								(tag_t tPartTag,											/* <I> */
													 tag_t tCurrentPartRevTag,									/* <I> */
													 tag_t *PartLRRTag											/* <O> */
													);
int fnWriteLRRBOMInfo								(tag_t BVRParent,											/* <I> */				
													 char *ECNItemID,											/* <I> */
													 char *LRRId,												/* <I> */
													 FILE *fp													/* <I> */
													);
													
int LBT_get_notALatestRev_impacted_items	(int n_imp_revs,				/* <I> */
										    tag_t *imp_rev_tags,			/* <I> */
										    int *n_notLatestRev_revs,       /* <O> */ 
										    tag_t **notLatest_rev_tags      /* <OF> */ 
										    );
extern int LBT9_Custom_Handler(EPM_action_message_t msg);

int createNoteFormOptional(tag_t rev_tag,                           /* <I> */              
				   tag_t logged_in_group_member_tag,        /* <I> */
                   char *to_users_list,                     /* <I> */
				   char *to_email_id,                       /* <I> */
				   char *comments,  
				   tag_t *tForm/* <O> */
				  );
int attachFormToRevision2(tag_t formTag,          /* <I> */
						 tag_t revTag            /* <I> */
					    );
int deleteFormFromItem(tag_t item_tag,					/* <I> */
					   char *form_name					/* <I> */
			          );

int removeForm(tag_t object,							/* <I> */
               char *form_name,							/* <I> */
			   tag_t *form_object						/* <O> */
			   );

int deleteFormProperties(tag_t change_form);	         /* <I> */
extern int LBT9_Custom_Handler_Update_History(EPM_action_message_t msg);
int fnUpdateChangeFormInRevision(tag_t tRevTag);
int fnUpdateChangeHistoryForm2(tag_t change_rev_tag,      /* <I> */
							  int n_impacted_items,      /* <I> */
							  tag_t *impacted_rev_tags   /* <I> */
                             );


													
#ifdef __cplusplus
}
#endif
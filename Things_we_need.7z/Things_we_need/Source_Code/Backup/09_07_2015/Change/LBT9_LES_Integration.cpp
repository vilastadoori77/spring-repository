
/******************************************************************************************

File			:	LBT9_LES_Integration.cpp

Description		:	Functions for Workflow action handlers 

Author			:   Tanay Gupta

Date created	:   10/04/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

10/04/2015		Tanay Gupta		 		Inital version

10/04/2015		Tanay Gupta             Added LBT9_BOM_EXP

13/07/2015		Tanay Gupta				Added fnToCheckLRRofItem

10/04/2015		Tanay Gupta             Added fnPrintingPartMPNInfo

10/04/2015		Tanay Gupta             Added fnMPNPrinting

12/04/2015		Tanay Gupta             Added fnPrintingPartBOMInfo

13/07/2015		Tanay Gupta				Added fnWriteLRRBOMInfo

12/04/2015		Tanay Gupta             Added fnWriteCRBOMInfo

12/04/2015		Tanay Gupta             Added fnBomlinePrinting

12/04/2015		Tanay Gupta 			Added fnPrintingPartInfo

14/04/2015		Tanay Gupta				Added fnPrintingDocInfo

14/04/2015		Tanay Gupta				Added fnEFF_FM_DATE

14/04/2015		Tanay Gupta 			Added IsDocumentExist

14/04/2015		Tanay Gupta				Added fnPrintECNInfo

14/04/2015		Tanay Gupta				Added fnWriteChangeAnalystValue

14/04/2015		Tanay Gupta				Added fnToTrimtheExceedLength

14/04/2015		Tanay Gupta				Added fnToPrintTheRevisionId

14/04/2015		Tanay Gupta				Added fnPrintSpaceValues

14/04/2015		Tanay Gupta				Added fnPrintECNheader

14/04/2015		Tanay Gupta				Added fnUpdateFormProperties
			
******************************************************************************************/
#include "LBT9_Change_Handler.h"


//using namespace std;

/*******************************************************************************************
*	Handler Name	:	 LBRT_BOM_EXP

*	Description		:	 This Handler is used for Exporting the BOM Information of SolutionItems
												
********************************************************************************************/

extern int LBT9_BOM_EXP(EPM_action_message_t msg)	
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=	0;
	int iParentJobcount					=	0;
	int iArgumentsCount					=	0;
	char *cpItemType					=	NULL;
	char *ECNItemID						=	NULL;
	char *cpObjectType					=	NULL;
	char *ItemId						=	NULL;
	char *ItemRevID						=	NULL;
	char *current_date_string			=	NULL;
	char *cpCurrentDate					=	NULL;
	char *wfuser						=	NULL;
	date_t currentDate					=	NULLDATE;
	tag_t  tRootTask					=	NULLTAG;
	tag_t* ptTargetAttmnts				=	NULL;
	tag_t* tParentJobTags				=	NULL;
	tag_t tUserTag						=	NULLTAG;
	FILE *fp;
	//using namespace std;
	//Declaration of UOM swaping values and reuse
	std::map<std::string,std::string> mUOMAllValue;
	mUOMAllValue[""]="EA - EACH";
	mUOMAllValue["each"]="EA - EACH";
	mUOMAllValue["EA"]="EA - EACH";
	mUOMAllValue["FT"]="FT - FEET";
	mUOMAllValue["LB"]="LB - POUND";
	mUOMAllValue["RE"]="RE - REFERENCE";
	mUOMAllValue["IN"]="IN - INCH";
	mUOMAllValue["RL"]="RL - ROLL";
	mUOMAllValue["SF"]="SF - SQUARE FEET";
	mUOMAllValue["ME"]="ME - METERS";
	mUOMAllValue["PR"]="PR - PAIR";
	mUOMAllValue["GA"]="GA - GALLON";
	mUOMAllValue["SE"]="SE - SET";
	mUOMAllValue["KG"]="KG - KILOGRAM";
	mUOMAllValue["PK"]="PK - PACKAGE";
	mUOMAllValue["IN2"]= "SI - SQUARE INCH";
	mUOMAllValue["OZ"]=	"OZ - OUNCE";
	mUOMAllValue["ST"]=	"ST - SHEET";
	mUOMAllValue["BX"]=	"BX - BOX";
	mUOMAllValue["KT"]=	"KT - KIT";
	mUOMAllValue["DZN"]= "DZ - DOZEN";
	mUOMAllValue["CA"]=	"CA - CAN";
	mUOMAllValue["GM"]=	"GM - GRAM";
	mUOMAllValue["TU"]=	"TB - TUBE";
	mUOMAllValue["DR"]=	"DR - DRUM";
	mUOMAllValue["CS"]=	"CS - CASE";
	mUOMAllValue["BO"]=	"BO - BOTTLE";
	mUOMAllValue["BG"]=	"BG - BAG";
	mUOMAllValue["T3"]=	"T3 - PER 1000";
	mUOMAllValue["HC"]=	"HC - PER 100";
	mUOMAllValue["PT"]=	"PT - PINTS";
	mUOMAllValue["ML"]=	"ML - MILLILETER";
	mUOMAllValue["CY"]=	"CY - CYLINDER";
	mUOMAllValue["L"]=	"L - LITER";
	mUOMAllValue["BE"]=	"BE - BUNDLE";
	mUOMAllValue["CC"]=	"CC - CUBIC CENTIMETER";
	mUOMAllValue["QT"]=	"QT - QUART";
	mUOMAllValue["M2"]=	"M2 - SQUARE METER";
	mUOMAllValue["LT"]=	"LT - LOT";
	mUOMAllValue["CF"]=	"CF - CUBICFEET";
	mUOMAllValue["APZ"]="TO - TROY OUNCE";
	mUOMAllValue["RM"]=	"RM - REAM";

	printf("\nEntering into <LBRT_BOM_EXP> function...!\n");


	
	ITK(iFail,EPM_substitute_task_keyword(msg.task, PROCESS_OWNER, &wfuser));
	printf("Process Owner : %s\n", wfuser);
	if(wfuser != NULL)
	{
		ITK(iFail,SA_find_user2(wfuser,&tUserTag));
	}
	ITK(iFail,ITK_ask_default_date_format(&current_date_string));
	if(current_date_string != NULL)
	{
		STRNG_replace_str(current_date_string,":","-",&cpCurrentDate);
	}
	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	char * cpProcessName	=	NULL;
	iArgumentsCount = IMAN_number_of_arguments(msg.arguments);
	
    if ( iArgumentsCount == 0 && iFail == ITK_ok )
    {
        iFail = EPM_successful_with_warnings ;
        EMH_store_error_s1( EMH_severity_warning,iFail,"Wrong no of arguments"); 
        return iFail;
    }
    for ( int indx = 0; (indx < iArgumentsCount && iFail == ITK_ok); indx++ )
    {
        char *flag = NULL;
        char *value = NULL;

        ITK(iFail,ITK_ask_argument_named_value( IMAN_next_argument(msg.arguments), &flag, &value )); 

        if ( iFail == ITK_ok ) 
        {
           	if ( tc_strcasecmp(flag, PROCESS_NAME) == 0 )
			{
				if ( value != NULL )
                {
                    cpProcessName = (char*) MEM_alloc(( tc_strlen(value) + 1)* sizeof(char));
                    tc_strcpy(cpProcessName, value);
                }
			}
            else
            {
                iFail = EPM_invalid_argument;
                EMH_store_error( EMH_severity_warning, iFail );
				return iFail;
            }
        }
        if( flag != NULL )
            EMR_free( flag );
        if( value != NULL )
            EMR_free( value );
    }

	if (tRootTask != NULLTAG)
	{
		// get all target objects from the workflow
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
		
		if (iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
		{
			int i = 1;
			int k = 1;
			int j = 1;
			char *FilePath	=	NULL;
			char *cpFileLocation = NULL;
			char *cpECNId = NULL;
			char *cpWorkflowName = NULL;
			ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],ITEM_ID,&cpECNId));
			//Read flat file location using preference value			 
			ITK(iFail,PREF_ask_char_value(FLAT_FILE_LOCATION,0,&FilePath));
			if(FilePath != NULL && cpCurrentDate != NULL)
			{
				cpFileLocation = (char*) MEM_alloc(tc_strlen(FilePath) + tc_strlen("\\") + tc_strlen(cpECNId) + tc_strlen("_") + tc_strlen(cpCurrentDate) + tc_strlen(".txt")+ 2);
				tc_strcpy(cpFileLocation,"");
				tc_strcpy(cpFileLocation,FilePath);
				tc_strcat(cpFileLocation,"\\");
				tc_strcat(cpFileLocation,cpECNId);
				tc_strcat(cpFileLocation,"_");
				tc_strcat(cpFileLocation,cpCurrentDate);
				tc_strcat(cpFileLocation,".txt");

				fp = fopen(cpFileLocation, FILE_WRITING);
			
				//printing header values in the file
				ITK(iFail,fnPrintECNheader(fp,HEADER_VALUE_1));
				//printf("cpFileLocation : <%s>\n",cpFileLocation);	
				ITK(iFail,WSOM_ask_object_type2(ptTargetAttmnts[0],&cpItemType));
				//printf("%s",cpItemType);
				ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],ITEM_ID,&ECNItemID));
				if (tc_strlen(cpItemType) > 0 )
				{
					if (tc_strcmp(cpItemType,ECN_TYPE) == 0 || tc_strcmp(cpItemType,CLASS_MCO_REVISION) == 0)
					{
						ITK(iFail,fnPrintECNInfo(ptTargetAttmnts[0],cpProcessName,fp));				
						EMR_free(cpItemType);
					}					
				}			
				//printing header2 in the output file
				fnPrintECNheader(fp,HEADER_VALUE_2);
				//Getting the solution item
				int iSolutionItemCount = 0;
				tag_t *tSolutionItemTag = NULL;
				ITK(iFail,LBT_get_related_objects(ptTargetAttmnts[0],SOLUTION_ITEMS_RELATION, &iSolutionItemCount, &tSolutionItemTag));
				// looping for each Solution Item
				if(iSolutionItemCount > 0 && tSolutionItemTag != NULL)
				{
					if (tc_strlen(ECNItemID) > 0 && ECNItemID != NULL)
					{
						//looping to print part info
						for (i = 0; i < iSolutionItemCount; i++)
						{					
							ITK(iFail,WSOM_ask_object_type2(tSolutionItemTag[i],&cpObjectType));
							// Printing Document info
							if(cpObjectType != NULL && (tc_strcmp(cpObjectType,EMR_DOCUMENT_REVISION) == 0 || tc_strcmp(cpObjectType,PRODUCT_SPECS_DOC_REV) == 0))
							{
								ITK(iFail,fnPrintingDocInfo(tSolutionItemTag[i],ptTargetAttmnts[0],ECNItemID,fp));
							}
							// Printing Part info
							else	
							{	
								ITK(iFail,fnPrintingPartInfo(tSolutionItemTag[i],ptTargetAttmnts[0],ECNItemID,mUOMAllValue,fp));
							}
						}
					}
					//Printing header 3 in the output file
					ITK(iFail,fnPrintECNheader(fp,HEADER_VALUE_3));
					if (tc_strlen(ECNItemID) > 0 && ECNItemID != NULL)
					{
						//looping to print Part BOM info
						for (k = 0; k < iSolutionItemCount; k++)
						{					
							ITK(iFail,fnPrintingPartBOMInfo(tSolutionItemTag[k],ECNItemID,fp));
						}
					}
						//Printing header 4 in the output file
					ITK(iFail,fnPrintECNheader(fp,HEADER_VALUE_4));
					if (tc_strlen(ECNItemID) > 0 && ECNItemID != NULL)
					{	
						//looping to print Part MPN info
						for(j = 0; j < iSolutionItemCount; j++)
						{
							ITK(iFail,WSOM_ask_object_type2(tSolutionItemTag[j],&cpObjectType));
							if(cpObjectType != NULL && tc_strcmp(cpObjectType,"EMR_CommrclPart Revision") == 0)
							{
								ITK(iFail,fnPrintingPartMPNInfo(tSolutionItemTag[j],ECNItemID,fp));
							}
						}
					}
				}
				EMR_free(tSolutionItemTag);
				EMR_free(cpECNId);
			}
			else
			{
				printf("Preference is not provided in TC\n");
				return ITK_ok;
			}
			
		}
		if(iFail == 0 && tUserTag != NULLTAG)
		{
			ITK(iFail,fnUpdateFormProperties(ptTargetAttmnts[0],tUserTag,"Transferred",wfuser));
		}
		else
		{
			ITK(iFail,fnUpdateFormProperties(ptTargetAttmnts[0],tUserTag,"Failed",wfuser));
		}
	}    
	fclose(fp);
	EMR_free(current_date_string);
	EMR_free(wfuser);
	EMR_free(ptTargetAttmnts);
	EMR_free(ECNItemID);
	EMR_free(cpObjectType);
	return ITK_ok;
	
}


/*******************************************************************************************
*	Function Name	:	 fnToCheckLRRofItem

*	Description		:	 This Function is for checking whether the revision tag is latest released or not
												
********************************************************************************************/

int fnToCheckLRRofItem	(tag_t tPartTag,							/* <I> */
						 tag_t tCurrentPartRevTag,					/* <I> */
						 tag_t *PartLRRTag							/* <O> */
						)
{
	int iFail = ITK_ok;
	int iStatusCount = 0;
	int iAllRevisionCount = 0;
	int iRevStatusCount = 0;
	tag_t *tRevStatusTags = NULL;
	tag_t *tStatusTags = NULL;
	tag_t *AllRevisionTags = NULL;
	logical LRRItemFound = false;
	logical DateValidation = false;
	int iPreviousDateCount = 0;
	*PartLRRTag = NULLTAG;
	std::vector<date_t> AllPreviousRevisionDate; 
	date_t LRRRevisonDate;
	ITK(iFail,ITEM_list_all_revs(tPartTag,&iAllRevisionCount,&AllRevisionTags));
	if(AllRevisionTags != NULL && iAllRevisionCount > 1)
	{
		//getting the date of LRR and validating it with the previous released revisions 
		for(int i = iAllRevisionCount-2; i >= 0; i--)
		{
			if(tCurrentPartRevTag != AllRevisionTags[i])
			{
				ITK(iFail,AOM_ask_value_tags(AllRevisionTags[i],"release_status_list",&iStatusCount,&tStatusTags));
				if(tStatusTags != NULL && iStatusCount > 0)
				{
					char *cpStatusName = NULL;
					ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));
					if(cpStatusName != NULL && tc_strcmp(cpStatusName,RELEASE_STATUS) == 0)
					{
						LRRItemFound = true;
						ITK(iFail,AOM_ask_value_date(tStatusTags[0],"date_released",&LRRRevisonDate));
						EMR_free(cpStatusName);
					}
				}
			}
			if(LRRItemFound)
			{
				DateValidation = false;
				logical NoMoreRevisionExist = true;
				for(int j = i-1; j >= 0; j--)
				{
					NoMoreRevisionExist = false;
					ITK(iFail,AOM_ask_value_tags(AllRevisionTags[j],"release_status_list",&iRevStatusCount,&tRevStatusTags));
					if(tRevStatusTags != NULL && iRevStatusCount > 0)
					{
						char *cpRevStatusName = NULL;
						ITK(iFail,AOM_ask_value_string(tRevStatusTags[0],OBJECT_NAME,&cpRevStatusName));
						if(cpRevStatusName != NULL && tc_strcmp(cpRevStatusName,RELEASE_STATUS) == 0)
						{
							date_t PreviousRevisionDate;
							int answer = 0;
							ITK(iFail,AOM_ask_value_date(tRevStatusTags[0],"date_released",&PreviousRevisionDate));
							ITK(iFail,POM_compare_dates(LRRRevisonDate,PreviousRevisionDate,&answer));
							if(answer == 1 || answer > 1)
							{
								DateValidation = true;
							}
							EMR_free(cpRevStatusName);
						}
						else
						{
							DateValidation = true;
						}
					}
				}
				if(DateValidation || NoMoreRevisionExist)
				{
					*PartLRRTag = (tag_t) MEM_alloc(AllRevisionTags[i]*sizeof(tag_t));
					*PartLRRTag = AllRevisionTags[i];
					break;
				}
			}
		}
		EMR_free(tStatusTags);
		EMR_free(tRevStatusTags);
	}
	return ITK_ok;
}


/*******************************************************************************************
*	Function Name	:	 fnPrintingPartMPNInfo

*	Description		:	 This Function is for getting Action Code of Manufacture part 
												
********************************************************************************************/



int fnPrintingPartMPNInfo(tag_t tPartObjectTag,char *ECNItemId,FILE *fp)
{
	
	int	iFail	=	ITK_ok; 
	int iVendorCurrentItemCount = 0;
	int iVendorLRRItemCount		= 0;
	int iVendorCount = 0;
	int iVendorLRRCount = 0;
	int iVendorCRCount = 0;
	int count		= 0;
	/*int i = 0;
	int j = 0;
	int n = 0;
	int k = 0;
	int l = 0;*/
	int inx = 0;
	tag_t tItemTag = NULLTAG;
	int ireleased_status	= 0;
	tag_t *tVendorCurrentItemTags = NULL;
	tag_t *tVendorLRRItemTags	 = NULL;
	char *cpVendorLRRPartId = NULL;
	char *cpVendorCurrentPartId = NULL;
	tag_t tPartTag				= NULLTAG;
	tag_t tPartObjectLatestReleased		= NULL;
	logical vendorPartExistsCheckLRR = false;
	logical vendorPartExistsCheckCR = false;
	printf("Code Execution Start\n");

	ITK(iFail,ITEM_ask_item_of_rev(tPartObjectTag,&tPartTag));
	if(tPartTag != NULLTAG)
	{
		ITK(iFail,fnToCheckLRRofItem(tPartTag,tPartObjectTag,&tPartObjectLatestReleased));
		ITK(iFail,AOM_ask_value_tags(tPartObjectTag,COMMERCIAL_VENDORPART_PROP,&iVendorCurrentItemCount,&tVendorCurrentItemTags));
		if(tPartObjectLatestReleased != NULL)
		{
			ITK(iFail,AOM_ask_value_tags(tPartObjectLatestReleased,COMMERCIAL_VENDORPART_PROP,&iVendorLRRItemCount,&tVendorLRRItemTags));
		}
		for(int i = 0;  i < iVendorLRRItemCount; i++)
		{
			vendorPartExistsCheckLRR = false;
			// lodic for Action code "D"
			//Getting the current revision and latest released revision manufacture part id and the associated manufacturer
			for(int j = 0;  j < iVendorCurrentItemCount; j++)
			{	
				if(tVendorLRRItemTags[i] == tVendorCurrentItemTags[j])
				{
					vendorPartExistsCheckLRR = true;
					break;
				}
			}

			if(vendorPartExistsCheckLRR)
			{
				// Do nothing
			}
			else 
			{
				ITK(iFail,AOM_ask_value_string(tVendorLRRItemTags[i],ITEM_ID,&cpVendorLRRPartId));
				fnMPNPrinting(tPartObjectLatestReleased,tVendorLRRItemTags[i],cpVendorLRRPartId,"D",fp);
				fprintf(fp,"\n");
			}
		}
		for(int k = 0;  k < iVendorCurrentItemCount; k++)
		{
			vendorPartExistsCheckCR = false;
			for(int l = 0;  l < iVendorLRRItemCount; l++)
			{
				if(tVendorCurrentItemTags[k] == tVendorLRRItemTags[l]) 
				{
					vendorPartExistsCheckCR = true;
					break;
				}
								
			}
			if(vendorPartExistsCheckCR)
			{
				// No Change 
			}
			else
			{
				ITK(iFail,AOM_ask_value_string(tVendorCurrentItemTags[k],ITEM_ID,&cpVendorCurrentPartId));
				fnMPNPrinting(tPartObjectTag,tVendorCurrentItemTags[k],cpVendorCurrentPartId,"A",fp);
				fprintf(fp,"\n");
			}
		}
	}
	EMR_free(tVendorCurrentItemTags);
	EMR_free(tVendorLRRItemTags);
	EMR_free(cpVendorLRRPartId);
	EMR_free(cpVendorCurrentPartId);
	return iFail;
}


/*******************************************************************************************
*	Function Name	:	 fnMPNPrinting

*	Description		:	 This Function is for prnting Manufacture Part Data
												
********************************************************************************************/


int fnMPNPrinting(tag_t CommrclPartRevisionTag,tag_t tVendorPartTag,char *VendorPartID,char *Action,FILE *fp)
{
	int	iFail									= ITK_ok; 
	int PART_NUMBER_EMPTY_SPACE_LENGTH			= 0;
	int MFG_PART_NUMBER_EMPTY_SPACE_LENGTH		= 0;							 
	int MFGR_NUMBER_EMPTY_SPACE_LENGTH			= 0;						 
	int MFGR_NAME_EMPTY_SPACE_LENGTH  			= 0;						 
	int MFGR_STATUS_EMPTY_SPACE_LENGTH			= 0;	
	int iVendorCount							= 0;
	int iTagCount								= 0;
	tag_t *tMPNStatusTag						= NULL;
	char *cpMPNStatusName						= NULL;
	char *cpVendorId							= NULL;
	char *cpVendorName							= NULL;
	tag_t tVendorRelationType = NULLTAG;
	tag_t *tVendorSecondaryObjects				= NULL;

	printf("Printing MPN DATA");
	//printing part number
	char *cpPartRevisionId = NULL;
	ITK(iFail,AOM_ask_value_string(CommrclPartRevisionTag,"item_id",&cpPartRevisionId));
	fprintf(fp, cpPartRevisionId);
	PART_NUMBER_EMPTY_SPACE_LENGTH = PART_NUMBER_SPACE_LENGTH - tc_strlen(cpPartRevisionId);
	ITK(iFail,fnPrintSpaceValues(PART_NUMBER_EMPTY_SPACE_LENGTH,fp));

	//printing MFG-PART-NUMBER
	fprintf(fp, VendorPartID);
	MFG_PART_NUMBER_EMPTY_SPACE_LENGTH = MFG_PART_NUMBER_SPACE_LENGTH - tc_strlen(VendorPartID);
	ITK(iFail,fnPrintSpaceValues(MFG_PART_NUMBER_EMPTY_SPACE_LENGTH,fp));
	
	//Printing Manufacturer id
	ITK(iFail,GRM_find_relation_type(VENDORPART_VENDORER_RELATION,&tVendorRelationType));
	ITK(iFail,GRM_list_secondary_objects_only(tVendorPartTag,tVendorRelationType,&iVendorCount,&tVendorSecondaryObjects));
	if(tVendorSecondaryObjects != NULL && iVendorCount > 0)
	{
		ITK(iFail,AOM_ask_value_string(tVendorSecondaryObjects[0],ITEM_ID,&cpVendorId));
		if (tc_strlen(cpVendorId) > 0 && cpVendorId != NULL)
		{
			fprintf(fp, cpVendorId);
			MFGR_NUMBER_EMPTY_SPACE_LENGTH = MFGR_NUMBER_SPACE_LENGTH - tc_strlen(cpVendorId);
			ITK(iFail,fnPrintSpaceValues(MFGR_NUMBER_EMPTY_SPACE_LENGTH,fp));
		}
		else
		{
			ITK(iFail,fnPrintSpaceValues(MFGR_NUMBER_SPACE_LENGTH,fp));
		}
	}
	//Printing Manufacturer Name
	if(tVendorSecondaryObjects != NULL && iVendorCount > 0)
	{
		ITK(iFail,AOM_ask_value_string(tVendorSecondaryObjects[0],CURRENT_NAME,&cpVendorName));
		if (tc_strlen(cpVendorName) > 0 && cpVendorName != NULL)
		{
			fprintf(fp, cpVendorName);
			MFGR_NAME_EMPTY_SPACE_LENGTH = MFGR_NAME_SPACE_LENGTH - tc_strlen(cpVendorName);
			ITK(iFail,fnPrintSpaceValues(MFGR_NAME_EMPTY_SPACE_LENGTH,fp));
		}
		else
		{
			ITK(iFail,fnPrintSpaceValues(MFGR_NAME_SPACE_LENGTH,fp));
		}
	}
	//Printing Manufacturer status 

	if(tc_strcmp(Action,"A") == 0)
	{
		fprintf(fp, MFGR_STATUS_ACTIVE);
		MFGR_STATUS_EMPTY_SPACE_LENGTH =  MFGR_STATUS_SPACE_LENGTH - tc_strlen(MFGR_STATUS_ACTIVE);
		ITK(iFail,fnPrintSpaceValues(MFGR_STATUS_EMPTY_SPACE_LENGTH,fp));
	}
	else if(tc_strcmp(Action,"D") == 0)
	{
		fprintf(fp, MFGR_STATUS_NOT_PREFERRED);
		MFGR_STATUS_EMPTY_SPACE_LENGTH =  MFGR_STATUS_SPACE_LENGTH - tc_strlen(MFGR_STATUS_NOT_PREFERRED);
		ITK(iFail,fnPrintSpaceValues(MFGR_STATUS_EMPTY_SPACE_LENGTH,fp));	
	}
	else
	{
		ITK(iFail,fnPrintSpaceValues(MFGR_STATUS_SPACE_LENGTH,fp));
	}
	//printing Action value in the output file	
	fprintf(fp, Action);
	EMR_free(cpVendorId);
	EMR_free(cpPartRevisionId);
	EMR_free(cpVendorName);
	EMR_free(tVendorSecondaryObjects);
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnPrintingPartBOMInfo

*	Description		:	 This Function is for printing Commercial Part BOM Data
												
********************************************************************************************/
int fnPrintingPartBOMInfo(tag_t tPartObjectTag,char *ECNItemId,FILE *fp)
{
	int	iFail									= ITK_ok; 
	int iCurrentItemBVRCount					= 0;
	int iItemLatestReleasedRVRCount				= 0;
	int count									= 0;
	int ireleased_status						= 0;
	int iCurrentItemBVRChildCount				= 0;
	int iLatestReleasedItemBVRChildCount		= 0;
	int iRevCount								= 0;
	int BOMQuantyID								= 0;
	int item_Id_attribute						= 0;
	int item_rev_id_attribute					= 0;
	int find_No_attribute						= 0;
	int iIsLRRReleased							= 0;
	char *cpPartObjectRevId						= NULL;
	char *cpPartObjectLRRRevId					= NULL;
	char *cpPartObjectLatestReleasedRevId		= NULL;
	char *cpCurrentChildItemQty					= NULL;
	char *cpLatestReleasedChildItemQty			= NULL;
	char *cpCurrentChildItemId					= NULL;
	char *cpLatestReleasedChildItemId			= NULL;
	char *cpCurrentChildItemRevId				= NULL;
	char *cpLatestReleasedChildItemRevId		= NULL;
	char *cpCurrentChildFindNo					= NULL;
	char *cpLatestReleasedChildFindNo			= NULL;
	char *cpCurrentRevID						= NULL;
	char *cpLRRID								= NULL;
	char *ParentItemID							= NULL;
	tag_t tWindowCurrent						= NULLTAG;
	tag_t tPartTag								= NULLTAG;
	tag_t tWindowLatestReleased					= NULLTAG;
	tag_t tCurrentItemBVRTopLine				= NULLTAG;
	tag_t tLatestReleasedItemBVRTopLine			= NULLTAG;
	tag_t *tCurrentItemBVRChildrenTags			= NULL;
	tag_t *tLatestReleasedItemBVRChildrenTags	= NULL;
	//int iposition=0;
	tag_t tPartObjectLatestReleased				= NULLTAG;
	tag_t *tCurrentItemBVRTags					= NULL;
	tag_t *tItemLatestReleasedBVRTags			= NULL;

	//logical values declaration
	logical FindNoLRRValidation = false;
	logical FindNoCRValidation = false;
	//tag_t *tItemRevlist=NULL;
	//finding the item tag from item revison tag
	ITK(iFail,ITEM_ask_item_of_rev  (tPartObjectTag ,&tPartTag)); 
	if(tPartTag != NULLTAG)
	{
		//finding the latest released item revision from all the revision
		ITK(iFail,fnToCheckLRRofItem(tPartTag,tPartObjectTag,&tPartObjectLatestReleased));
	}

	ITK(iFail,ITEM_ask_rev_id2(tPartObjectTag,&cpPartObjectRevId));

	//BOM attributes API
	ITK(iFail,BOM_create_window(&tWindowCurrent));
	ITK(iFail,BOM_create_window(&tWindowLatestReleased));
	ITK(iFail,BOM_line_look_up_attribute("bl_sequence_no", &find_No_attribute));
	ITK(iFail,BOM_line_look_up_attribute (bomAttr_itemId, &item_Id_attribute));
	ITK(iFail,BOM_line_look_up_attribute( bomAttr_itemRevId, &item_rev_id_attribute));
	ITK(iFail,BOM_line_look_up_attribute(bomAttr_occQty,&BOMQuantyID));
	//Get current Item BVR object
	ITK(iFail,ITEM_rev_list_bom_view_revs(tPartObjectTag,&iCurrentItemBVRCount,&tCurrentItemBVRTags));
	if(iCurrentItemBVRCount > 0 && tCurrentItemBVRTags != NULL)
	{
		ITK(iFail,BOM_set_window_top_line_bvr(tWindowCurrent,tCurrentItemBVRTags[0],&tCurrentItemBVRTopLine));
	}
	//Getting the latest released BVR tags
	if (tPartObjectLatestReleased != NULLTAG)
	{
		ITK(iFail,ITEM_rev_list_bom_view_revs(tPartObjectLatestReleased,&iItemLatestReleasedRVRCount,&tItemLatestReleasedBVRTags));
		ITK(iFail,ITEM_ask_rev_id2(tPartObjectLatestReleased,&cpPartObjectLatestReleasedRevId));
		//when there is no current revision BVR tags and latest released revision BVR tag is present then print Action code "D" for all the latest released child items
		if(tItemLatestReleasedBVRTags != NULL && iItemLatestReleasedRVRCount > 0 && iCurrentItemBVRCount == 0 &&  tCurrentItemBVRTags == NULL)
		{
			ITK(iFail,fnWriteLRRBOMInfo(tItemLatestReleasedBVRTags[0],ECNItemId,cpPartObjectLatestReleasedRevId,fp));
		}		
	}
	//When there is no latest released and current revision is having bom it should print Action code as "A" for all the child items 
	if(iCurrentItemBVRCount > 0 && tCurrentItemBVRTags != NULLTAG && (tPartObjectLatestReleased == NULLTAG || iItemLatestReleasedRVRCount == 0))
	{
		ITK(iFail,fnWriteCRBOMInfo(tCurrentItemBVRTags[0],ECNItemId,cpPartObjectRevId,fp));
	}
	if (iItemLatestReleasedRVRCount > 0  && tItemLatestReleasedBVRTags != NULL)
	{			
		ITK(iFail,BOM_set_window_top_line_bvr(tWindowLatestReleased,tItemLatestReleasedBVRTags[0],&tLatestReleasedItemBVRTopLine));
	}
	if (tCurrentItemBVRTopLine != NULLTAG && tLatestReleasedItemBVRTopLine != NULLTAG)
	{
		ITK(iFail,BOM_line_ask_all_child_lines(tCurrentItemBVRTopLine,&iCurrentItemBVRChildCount,&tCurrentItemBVRChildrenTags));
		ITK(iFail,BOM_line_ask_all_child_lines(tLatestReleasedItemBVRTopLine,&iLatestReleasedItemBVRChildCount,&tLatestReleasedItemBVRChildrenTags));
		//looping to find action add and change
		for (int i = 0; i < iLatestReleasedItemBVRChildCount; i++)
		{
			ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[i],find_No_attribute,&cpLatestReleasedChildFindNo));
			ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[i],item_Id_attribute,&cpLatestReleasedChildItemId));
			ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[i],item_rev_id_attribute,&cpLatestReleasedChildItemRevId));
			ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[i],BOMQuantyID,&cpLatestReleasedChildItemQty));
			int k = 0;
			int a = 0;
			FindNoLRRValidation = false;
			for (k = 0; k < iCurrentItemBVRChildCount ; k++)
			{
				// getting find no for latest release and current revision						
				ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[k],find_No_attribute,&cpCurrentChildFindNo));						
				
				// getting Item id for latest release and current revision
				ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[k],item_Id_attribute,&cpCurrentChildItemId));
										
				// getting Item Revision id for latest release and current revision
				ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[k],item_rev_id_attribute,&cpCurrentChildItemRevId));
				
				// getting Item Quantity for latest release and current revision
				ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[k],BOMQuantyID,&cpCurrentChildItemQty));

				// condition for same find no CHANGE and ADD action code
				if(tc_strcmp(cpLatestReleasedChildFindNo,cpCurrentChildFindNo) == 0)
				{
					a = k;
					FindNoLRRValidation = true;
					break;
				}
			}
			if(FindNoLRRValidation)
			{
				if (tc_strcmp(cpCurrentChildItemId,cpLatestReleasedChildItemId) == 0 && tc_strcmp(cpLatestReleasedChildItemRevId,cpCurrentChildItemRevId) == 0)
				{
					//action type change											
					if (tc_strlen(cpCurrentChildItemQty) > 0 && tc_strlen(cpLatestReleasedChildItemQty) > 0 &&tc_strcmp(cpLatestReleasedChildItemQty,cpCurrentChildItemQty) != 0)
					{
							
						fnBomlinePrinting(tCurrentItemBVRTopLine,tCurrentItemBVRChildrenTags[a],ECNItemId,cpPartObjectRevId,cpPartObjectLatestReleasedRevId,ACTION_CODE_CHANGE,fp);
						fprintf(fp,"\n");
					}
					else
					{
						//for no change in quantity
					}
				}			
				else
				{
					//Find no CHANGE action code for based on item
					fnBomlinePrinting(tLatestReleasedItemBVRTopLine,tLatestReleasedItemBVRChildrenTags[i],ECNItemId,cpPartObjectRevId,cpPartObjectLatestReleasedRevId,ACTION_CODE_CHANGE,fp);
					fprintf(fp,"\n");
					//Find no ADD action code for current item
					fnBomlinePrinting(tCurrentItemBVRTopLine,tCurrentItemBVRChildrenTags[a],ECNItemId,cpPartObjectRevId,cpPartObjectLatestReleasedRevId,ACTION_CODE_ADD,fp);
					fprintf(fp,"\n");
				}
			}
			else if(!FindNoLRRValidation)
			{
				fnBomlinePrinting(tLatestReleasedItemBVRTopLine,tLatestReleasedItemBVRChildrenTags[i],ECNItemId,cpPartObjectRevId,cpPartObjectLatestReleasedRevId,ACTION_CODE_DELETE,fp);
				fprintf(fp,"\n");
			}
		}
		//condition for applying CHANGE action code
		//looping to find action ADD
		for (int m = 0; m < iCurrentItemBVRChildCount; m++)
		{
			FindNoCRValidation = false;
			ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[m],item_Id_attribute,&cpCurrentChildItemId));
			ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[m],item_rev_id_attribute,&cpCurrentChildItemRevId));
			ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[m],find_No_attribute,&cpCurrentChildFindNo));
			ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[m],BOMQuantyID,&cpCurrentChildItemQty));
			int n = 0;
			int b = 0;
			for (n = 0; n < iLatestReleasedItemBVRChildCount; n++)
			{
										
				ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[n],item_Id_attribute,&cpLatestReleasedChildItemId));
				
				ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[n],item_rev_id_attribute,&cpLatestReleasedChildItemRevId));
				
				ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[n],find_No_attribute,&cpLatestReleasedChildFindNo));
				
				ITK(iFail,BOM_line_ask_attribute_string(tLatestReleasedItemBVRChildrenTags[n],BOMQuantyID,&cpLatestReleasedChildItemQty));
				
				if(tc_strcmp(cpCurrentChildFindNo,cpLatestReleasedChildFindNo) == 0)
				{
					b = n;
					FindNoCRValidation = true;
					break;
				}
			}
			if(FindNoCRValidation)
			{
				//No change 
			}
			else
			{
				fnBomlinePrinting(tCurrentItemBVRTopLine,tCurrentItemBVRChildrenTags[m],ECNItemId,cpPartObjectRevId,cpPartObjectLatestReleasedRevId,ACTION_CODE_ADD,fp);
				fprintf(fp,"\n");
			}
		}
	}

	//Memory free
	EMR_free(cpPartObjectRevId);
	EMR_free(cpLRRID);
	EMR_free(tCurrentItemBVRTags);
	EMR_free(tItemLatestReleasedBVRTags);
	EMR_free(cpPartObjectLatestReleasedRevId);
	EMR_free(tCurrentItemBVRChildrenTags);
	EMR_free(tLatestReleasedItemBVRChildrenTags);
	EMR_free(cpLatestReleasedChildFindNo);
	EMR_free(cpCurrentChildFindNo);
	EMR_free(cpLatestReleasedChildItemId);
	EMR_free(cpCurrentChildItemId);
	EMR_free(cpLatestReleasedChildItemRevId);
	EMR_free(cpCurrentChildItemRevId);
	EMR_free(cpLatestReleasedChildItemQty);
	EMR_free(cpCurrentChildItemQty);
	return iFail;
}


/*******************************************************************************************
*	Function Name	:	 fnWriteLRRBOMInfo

*	Description		:	 This Function is for writing  Current Commercial Part Revision  BOM Data
												
********************************************************************************************/


int fnWriteLRRBOMInfo	(tag_t BVRParent,							/* <I> */				
						 char *ECNItemID,							/* <I> */
						 char *LRRId,								/* <I> */
						 FILE *fp									/* <I> */
						)
{
	int	iFail							= ITK_ok;
	int iLRRBVRChildCount		= 0;
	int inx								= 0;
	tag_t tBOMWindow					= NULLTAG;
	tag_t tLRRBVRTopLine		= NULLTAG;
	tag_t *tLRRBVRChildrenTags  = NULL;
	ITK(iFail,BOM_create_window(&tBOMWindow));
	ITK(iFail,BOM_set_window_top_line_bvr(tBOMWindow,BVRParent,&tLRRBVRTopLine));
	if (tLRRBVRTopLine != NULLTAG)
	{
		ITK(iFail,BOM_line_ask_all_child_lines(tLRRBVRTopLine,&iLRRBVRChildCount,&tLRRBVRChildrenTags));
		for(inx; inx < iLRRBVRChildCount; inx++)
		{
			if(tLRRBVRChildrenTags != NULL)
			{
				//ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[inx],item_rev_id_attribute,&cpCurrentChildItemRevId));
				fnBomlinePrinting(tLRRBVRTopLine,tLRRBVRChildrenTags[inx],ECNItemID,LRRId,"",ACTION_CODE_DELETE,fp);
				fprintf(fp,"\n");
				
			}
		}
	}
	EMR_free(tLRRBVRChildrenTags);
	return iFail;
}


/*******************************************************************************************
*	Function Name	:	 fnWriteCRBOMInfo

*	Description		:	 This Function is for writing  Current Commercial Part Revision  BOM Data
												
********************************************************************************************/


int fnWriteCRBOMInfo(tag_t BVRParent,char *ECNItemID,char *CRId,FILE *fp)
{
	int	iFail							= ITK_ok;
	int iCurrentItemBVRChildCount		= 0;
	int inx								= 0;
	tag_t tBOMWindow					= NULLTAG;
	tag_t tCurrentItemBVRTopLine		= NULLTAG;
	tag_t *tCurrentItemBVRChildrenTags  = NULL;
	ITK(iFail,BOM_create_window(&tBOMWindow));
	ITK(iFail,BOM_set_window_top_line_bvr(tBOMWindow,BVRParent,&tCurrentItemBVRTopLine));
	if (tCurrentItemBVRTopLine != NULLTAG)
	{
		ITK(iFail,BOM_line_ask_all_child_lines(tCurrentItemBVRTopLine,&iCurrentItemBVRChildCount,&tCurrentItemBVRChildrenTags));
		for(inx; inx < iCurrentItemBVRChildCount; inx++)
		{
			if(tCurrentItemBVRChildrenTags != NULL)
			{
				//ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[inx],item_rev_id_attribute,&cpCurrentChildItemRevId));
				fnBomlinePrinting(tCurrentItemBVRTopLine,tCurrentItemBVRChildrenTags[inx],ECNItemID,CRId,"",ACTION_CODE_ADD,fp);
				fprintf(fp,"\n");	
			}
		}
	}
	EMR_free(tCurrentItemBVRChildrenTags);
	
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnBomlinePrinting

*	Description		:	 This Function is for Printing Commercial Part BOM line data
										
********************************************************************************************/
int fnBomlinePrinting(tag_t tParenttag,tag_t tchildtag,char *ECNItemId,char *NewRevID,char *OldRevID,char *Action,FILE *fp)
{
	int	iFail							= ITK_ok;
	int ECN_EMPTY_Space_Length			= 0;
	int BOMQuantyID						= 0;
	int BOM_PARENT_EMPTY_Space_Length   = 0;
	int PART_NUMBER_EMPTY_Space_Length  = 0;
	int OLD_REV_EMPTY_Space_Length      = 0;
	int NEW_REV_EMPTY_Space_Length      = 0;
	int QTY_PER_EMPTY_Space_Length      = 0;
	int ITM_PER_EMPTY_Space_Length      = 0;
	int item_Id_attribute				= 0;
	int item_rev_id_attribute			= 0;
	int find_No_attribute				= 0;
	char *ParentItemID					= NULL;
	char *ChildItemID					= NULL;
	char *ChildItemQty					= NULL;
	char *ChildFindNo					= NULL;
	char *ChildRevItemID				= NULL;
	tag_t tPartObjectTag				= NULLTAG;
	tag_t tCurrentRevtag				= NULLTAG;
	//printing ECN NUMBER in the output file 
	fprintf(fp, ECNItemId);
	ECN_EMPTY_Space_Length = ECN_NUMBER_SPACE_LENGTH - tc_strlen(ECNItemId);
	fnPrintSpaceValues(ECN_EMPTY_Space_Length,fp);

	//printing BOM-PARENT value in the output file
	//AOM_ask_value_string(tParenttag,"item_id",&ParentItemID);
	// ITEM_ask_id2  (tParenttag,&ParentItemID); 
	BOM_line_look_up_attribute (bomAttr_itemId, &item_Id_attribute);
	BOM_line_ask_attribute_string(tParenttag,item_Id_attribute,&ParentItemID);
	
	if (tc_strlen(ParentItemID) > 0 && ParentItemID != NULL)
	{
		fprintf(fp, ParentItemID);
		BOM_PARENT_EMPTY_Space_Length = BOM_PARENT_SPACE_LENGTH - tc_strlen(ParentItemID);
		fnPrintSpaceValues(BOM_PARENT_EMPTY_Space_Length,fp);
	}
	else
	{
		fnPrintSpaceValues(BOM_PARENT_SPACE_LENGTH,fp);
	}

	//printing PART-NUMBER value in the output file
	//AOM_ask_value_string(tchildtag,"item_id",&ChildItemID);
	//ITEM_ask_id2  (tchildtag,&ChildItemID); 
	BOM_line_look_up_attribute (bomAttr_itemId, &item_Id_attribute);
	BOM_line_ask_attribute_string(tchildtag,item_Id_attribute,&ChildItemID);
	ITK(iFail,BOM_line_look_up_attribute( bomAttr_itemRevId, &item_rev_id_attribute));
	BOM_line_ask_attribute_string(tchildtag,item_rev_id_attribute,&ChildRevItemID);
	
	if (tc_strlen(ChildItemID) > 0 && ChildItemID != NULL)
	{
		fprintf(fp, ChildItemID);
		PART_NUMBER_EMPTY_Space_Length = PART_NUMBER_SPACE_LENGTH - tc_strlen(ChildItemID);
		fnPrintSpaceValues(PART_NUMBER_EMPTY_Space_Length,fp);
	}
	else
	{
		fnPrintSpaceValues(PART_NUMBER_SPACE_LENGTH,fp);
	}

	//printing OLD-REV value in the output file 
	if (tc_strlen(OldRevID) > 0 && OldRevID != NULL)
	{
		fnToPrintTheRevisionId(OldRevID,fp);
		/*fprintf(fp, OldRevID);
		OLD_REV_EMPTY_Space_Length = OLD_REV_SPACE_LENGTH - tc_strlen(OldRevID);
		fnPrintSpaceValues(OLD_REV_EMPTY_Space_Length,fp);*/
	}
	else
	{
		fnPrintSpaceValues(OLD_REV_SPACE_LENGTH,fp);
	}

	//printing NEW-REV value in the output file 
	if (tc_strlen(NewRevID) > 0 && NewRevID != NULL)
	{
		fnToPrintTheRevisionId(NewRevID,fp);
		/*fprintf(fp, NewRevID);
		NEW_REV_EMPTY_Space_Length = NEW_REV_SPACE_LENGTH - tc_strlen(NewRevID);
		fnPrintSpaceValues(NEW_REV_EMPTY_Space_Length,fp);*/
	}
	else
	{
		fnPrintSpaceValues(NEW_REV_SPACE_LENGTH,fp);
	}
	 
	//printing EFF-FM-DT value in the output file
	//yet to confirm by Aravinth, Need to add code once it is done
	//ITEM_find_item(ParentItemID,&tPartObjectTag);
	if (tc_strlen(NewRevID)> 0 && tc_strlen(ParentItemID)> 0)
	{
		ITEM_find_rev(ParentItemID,NewRevID,&tCurrentRevtag);
		if (tCurrentRevtag != NULL)
		{
			fnEFF_FM_DATE(tCurrentRevtag,fp);
		}
		else
		{
			fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);
		}
	}
	else
	{
		fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);
	}
	//printing ITM value in the output file
	//yet to confirm by Aravinth, Need to add code once it is done
	//recently added
	BOM_line_look_up_attribute("bl_sequence_no", &find_No_attribute);
	BOM_line_ask_attribute_string(tchildtag,find_No_attribute,&ChildFindNo);
	if(tc_strlen(ChildFindNo)>0 && ChildFindNo!=NULL)
	{
		fprintf(fp, ChildFindNo);
		ITM_PER_EMPTY_Space_Length = ITM_SPACE_LENGTH - tc_strlen(ChildFindNo);
		fnPrintSpaceValues(ITM_PER_EMPTY_Space_Length,fp);
	}
	
	//printing quanty value in the output file	
	
	BOM_line_look_up_attribute(bomAttr_occQty,&BOMQuantyID);
	BOM_line_ask_attribute_string(tchildtag,BOMQuantyID,&ChildItemQty);
	if (tc_strlen(ChildItemQty) > 0 && ChildItemQty != NULL)
	{
		fprintf(fp, ChildItemQty);
		QTY_PER_EMPTY_Space_Length = QTY_PER_SPACE_LENGTH - tc_strlen(ChildItemQty);
		fnPrintSpaceValues(QTY_PER_EMPTY_Space_Length,fp);
	}
	else
	{
		fnPrintSpaceValues(QTY_PER_SPACE_LENGTH,fp);
	}
	//printing Action value in the output file	
	fprintf(fp, Action);
	//Memory free
	EMR_free(ParentItemID);
	EMR_free(ChildItemID);
	EMR_free(ChildFindNo);
	EMR_free(ChildItemQty);
	return iFail;
}


/*******************************************************************************************
*	Function Name	:	 fnPrintingPartInfo

*	Description		:	 This Function is for Printing Commercial Part Information
										
********************************************************************************************/


int fnPrintingPartInfo(tag_t tPartObjectTag,tag_t tECNObjecttag,char *ECNItemId,map<std::string,std::string> mUOMAllValue,FILE *fp)
{
	int	iFail									= ITK_ok;	
	int DocumentItemExist						= 0;
	int ECN_EMPTY_Space_Length					= 0;
	int PCC_EMPTY_SPACE_LENGTH					= 0;
	int PCC_STRING_LENGTH						= 0;
	int PLT_EMPTY_SPACE_LENGTH					= 0;
	int PLT_STRING_LENGTH						= 0;
	int DEPT_EMPTY_SPACE_LENGTH					= 0;
	int ASP_DATA_EMPTY_SPACE_LENGTH				= 0;
	int SIMCST_EMPTY_SPACE_LENGTH				= 0;
	int LEVEL_EMPTY_Space_Length				= 0;
	int Attachment_Where_EMPTY_SPACE_LENGTH		= 0;
	int iSecondaryObjectCount					= 0;
	int DEPT_STRING_LENGTH						= 0;
	int ASP_DATA_STRING_LENGTH					= 0;
	int SIMCST_STRING_LENGTH					= 0;
	int k										= 0;
	int j										= 0;
	int m										= 0;
	int n										= 0;
	int count									= 0;
	int UoM_EMPTY_SPACE_LENGTH					= 0;
	int inx										= 0;
	char *cpPartObjectId						= NULL;
	char *cpPartRevID							= NULL;
	char *cpPCCValue							= NULL;
	char *cpPartObjectDescValue					= NULL;
	char *cpOptionValue							= NULL;
	char *cpPlantValue							= NULL;
	char *cpSFAPartValue						= NULL;
	char *cpDEPTValue							= NULL;
	char *cpShelfLifeValue						= NULL;
	char *cpSIMCSTValue							= NULL;
	char *cpROHSReqValue						= NULL;
	char *cpASPTrimValue						= NULL;
	char *cpPartDescValue						= NULL;
	char *cpUOMValue							= NULL;
	char cpType1[WSO_name_size_c+1]				= "";
	char *cpNewUOMValue							= NULL;
	tag_t tOwningUserTag						= NULLTAG;
	tag_t tPartTag								= NULLTAG;
	tag_t ItemTag								= NULLTAG;
	tag_t tUOMTAG								= NULLTAG;
	tag_t tCommrclPartRevisionMaster			= NULLTAG;
	tag_t tCostDataForm							= NULLTAG;
	tag_t tItemmasterFormRelationTag			= NULLTAG;
	tag_t *SecondaryObjectTags					= NULL;
	tag_t *tSecondaryObjects					= NULL; 
	
	logical UOMstatus = false;
	
	string UOMValue;
	
	std::map<std::string,std::string>::iterator UOMiterator;

	
	
		

	//Master form variable declaration
	

	//printing ECN NUMBER in the output file
	fprintf(fp, ECNItemId);
	ECN_EMPTY_Space_Length = ECN_NUMBER_SPACE_LENGTH - tc_strlen(ECNItemId);
	fnPrintSpaceValues(ECN_EMPTY_Space_Length,fp);

	//printing LEVEL(Part Rev ID) in the output file
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,ITEM_REVISION_ID,&cpPartRevID));
	if (tc_strlen(cpPartRevID) > 0 && cpPartRevID != NULL)
	{ 
		fnToPrintTheRevisionId(cpPartRevID,fp);
	}
	else
	{
		fnPrintSpaceValues(LEVEL_SPACE_LENGTH,fp);
	}
	//printing PART-NUMBER in the output file
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,ITEM_ID,&cpPartObjectId));
	if (tc_strlen(cpPartObjectId) > 0 && cpPartObjectId != NULL)
	{
		int PART_NUMBER_EMPTY_Space_Length = 0;
		fprintf(fp, cpPartObjectId);	
		PART_NUMBER_EMPTY_Space_Length = PART_NUMBER_SPACE_LENGTH - tc_strlen(cpPartObjectId);
		fnPrintSpaceValues(PART_NUMBER_EMPTY_Space_Length,fp);
	}
	else
	{
		fnPrintSpaceValues(PART_NUMBER_SPACE_LENGTH,fp);
	}


	// writing pcc values into output file
	
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,PCC_ATT_VALUE,&cpPCCValue));
	if (tc_strlen(cpPCCValue) > 0 && cpPCCValue != NULL)
	{
		if (tc_strcmp(PCC_SCHEMATIC_PLUS,cpPCCValue) == 0)
		{
			fprintf(fp, PCC_SCHEMATIC_AST);
			PCC_STRING_LENGTH = tc_strlen(PCC_SCHEMATIC_AST);
		}
		else if (tc_strcmp(PCC_WORK_INST_AST1,cpPCCValue) == 0 || tc_strcmp(PCC_WORK_INST_PLUS,cpPCCValue) == 0)
		{
			fprintf(fp, PCC_WORK_INST_AST);
			PCC_STRING_LENGTH = tc_strlen(PCC_WORK_INST_AST);
		}
		else
		{
			fprintf(fp, cpPCCValue);
			PCC_STRING_LENGTH = tc_strlen(cpPCCValue);
		}	
		PCC_EMPTY_SPACE_LENGTH = PCC_SPACE_LENGTH - PCC_STRING_LENGTH;
		fnPrintSpaceValues(PCC_EMPTY_SPACE_LENGTH,fp);
	}
	else
	{
		fnPrintSpaceValues(PCC_SPACE_LENGTH,fp);
	}

	//writing optional value into output file
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,OPT_ATT_VALUE,&cpOptionValue));
	if(cpOptionValue != NULL)
	{
		fnWrite_YorN_Value(cpOptionValue,fp);				
	}
	else
	{
		fprintf(fp, N_VALE);
	}

	//writing UOM value into output file
	
	ITK(iFail,ITEM_ask_item_of_rev(tPartObjectTag,&ItemTag));
	if (ItemTag != NULLTAG)
	{
		ITK(iFail,ITEM_ask_unit_of_measure(ItemTag,&tUOMTAG));
		if (tUOMTAG != NULLTAG)
		{
			ITK(iFail,UOM_ask_symbol(tUOMTAG,&cpUOMValue));
			if (tc_strlen(cpUOMValue) > 0 && cpUOMValue != NULL)
			{
				UOMiterator = mUOMAllValue.find(cpUOMValue);
				if (UOMiterator != mUOMAllValue.end())
				{	
					//UOMValue = UOMiterator->second.c_str();						
					cpNewUOMValue = (char *) malloc(UOMiterator->second.length() + 1);
					tc_strcpy(cpNewUOMValue,"");
					tc_strcpy(cpNewUOMValue,UOMiterator->second.c_str());
					fprintf(fp,cpNewUOMValue);
					UoM_EMPTY_SPACE_LENGTH = UoM_SPACE_LENGTH - tc_strlen(cpNewUOMValue);
					fnPrintSpaceValues(UoM_EMPTY_SPACE_LENGTH,fp);
				}
				else
				{
					UOMstatus = true;
				}
			}
			else
			{
				UOMstatus = true;
			}
			
		}
		else
		{			
			UOMiterator = mUOMAllValue.find("each");
			if (UOMiterator != mUOMAllValue.end())
			{	
				//UOMValue = UOMiterator->second;						
				cpNewUOMValue = (char *) MEM_alloc(UOMiterator->second.length() + 2);
				tc_strcpy(cpNewUOMValue,"");
				tc_strcpy(cpNewUOMValue,UOMiterator->second.c_str());
				fprintf(fp,cpNewUOMValue);
				UoM_EMPTY_SPACE_LENGTH = UoM_SPACE_LENGTH - tc_strlen(cpNewUOMValue);
				fnPrintSpaceValues(UoM_EMPTY_SPACE_LENGTH,fp);
			}
		}
		tc_strcpy(cpNewUOMValue,"");
	}	
	else
	{
		UOMstatus = true;		
	}	
	if (UOMstatus)
	{
		fnPrintSpaceValues(UoM_SPACE_LENGTH,fp);
	}

	
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,PLT_ATT_VALUE,&cpPlantValue));	
	if (tc_strlen(cpPlantValue) > 0 && cpPlantValue != NULL)
	{
		PLT_STRING_LENGTH = tc_strlen(cpPlantValue);
		if( PLT_STRING_LENGTH > PLT_SPACE_LENGTH)
		{
			fnToTrimtheExceedLength(PLT_STRING_LENGTH,PLT_SPACE_LENGTH,cpPlantValue,fp);
		}
		else
		{
			fprintf(fp,cpPlantValue);
			PLT_EMPTY_SPACE_LENGTH = PLT_SPACE_LENGTH - PLT_STRING_LENGTH;
			fnPrintSpaceValues(PLT_EMPTY_SPACE_LENGTH,fp);
		}
	}
	else
	{
		fnPrintSpaceValues(PLT_SPACE_LENGTH,fp);
	}
	

	//writing the Create User (Need to print change analyst of ECN/ MCO) into output file
	fnWriteChangeAnalystValue(tECNObjecttag,fp);

	//writing SFA value into output file
	
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,SFA_ATT_VALUE,&cpSFAPartValue));	
	if(cpSFAPartValue != NULL)
	{
		fnWrite_YorN_Value(cpSFAPartValue,fp);				
	}
	else
	{
		fprintf(fp,N_VALE);
	}

	//writing dept value into output file
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,DEPT_ATT_VALUE,&cpDEPTValue));
	if (tc_strlen(cpDEPTValue) > 0 && cpDEPTValue != NULL)
	{
		fprintf(fp,cpDEPTValue);
		DEPT_STRING_LENGTH = tc_strlen(cpDEPTValue);
		DEPT_EMPTY_SPACE_LENGTH = DEPT_SPACE_LENGTH - DEPT_STRING_LENGTH;
		fnPrintSpaceValues(DEPT_EMPTY_SPACE_LENGTH,fp);
	}
	else
	{
		fnPrintSpaceValues(DEPT_SPACE_LENGTH,fp);
	}

	//writing ASP data in the output file

	ITK(iFail,AOM_ask_value_string(tPartObjectTag,ASP_DATA_ATT_VALUE,&cpShelfLifeValue));

	if (tc_strlen(cpShelfLifeValue) > 0 && cpShelfLifeValue != NULL)
	{
		STRNG_replace_str(cpShelfLifeValue," - "," ",&cpASPTrimValue);
		if (tc_strlen(cpASPTrimValue) > 0)
		{
			fprintf(fp,cpASPTrimValue);
			ASP_DATA_STRING_LENGTH = tc_strlen(cpASPTrimValue);
			ASP_DATA_EMPTY_SPACE_LENGTH = ASP_DATA_SPACE_LENGTH - ASP_DATA_STRING_LENGTH;
			fnPrintSpaceValues(ASP_DATA_EMPTY_SPACE_LENGTH,fp);
		}
		else
		{
			fnPrintSpaceValues(ASP_DATA_SPACE_LENGTH,fp);
		}
	}
	else
	{
		fnPrintSpaceValues(ASP_DATA_SPACE_LENGTH,fp);
	}


	//writing SIMCST value in the output file
	
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,SMICST_ATT_VALUE,&cpSIMCSTValue));
	if (tc_strlen(cpSIMCSTValue) > 0 && cpSIMCSTValue != NULL)
	{
		fprintf(fp,cpSIMCSTValue);
		SIMCST_STRING_LENGTH = tc_strlen(cpSIMCSTValue);
		SIMCST_EMPTY_SPACE_LENGTH = SIMCST_SPACE_LENGTH - SIMCST_STRING_LENGTH;
		fnPrintSpaceValues(SIMCST_EMPTY_SPACE_LENGTH,fp);
	}	
	else
	{
		fnPrintSpaceValues(SIMCST_SPACE_LENGTH,fp);
	}
	

	//writing DAC value in the output file
	DocumentItemExist  = IsDocumentExist(tPartObjectTag); 
	if (DocumentItemExist == 1)
	{
		fprintf(fp,Y_VALE);
	}
	else
	{
		fprintf(fp,N_VALE);
	}

	//writing EFF-FM-DT value in the output file
	fnEFF_FM_DATE(tPartObjectTag,fp);
	//fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);

	//writing Attachment where ? value in the output file
	if (DocumentItemExist == 1)
	{
		fprintf(fp,ATTACHMENT_PRESENT);
	}
	else
	{
		fprintf(fp,ATTACHMENT_NOT_PRESENT);
		Attachment_Where_EMPTY_SPACE_LENGTH = Attachment_Where_SPACE_LENGTH - tc_strlen(ATTACHMENT_NOT_PRESENT);
		fnPrintSpaceValues(Attachment_Where_EMPTY_SPACE_LENGTH,fp);
	}

	//writing ROHS-REQ value in the output file
	if (tCommrclPartRevisionMaster != NULLTAG)
	{
		ITK(iFail,AOM_ask_value_string(tPartObjectTag,ROHS_REQ_ATT_VALUE,&cpROHSReqValue));	
		fnWrite_YorN_Value(cpROHSReqValue,fp);				
	}
	else
	{
		fprintf(fp,N_VALE);
	}

	// writing Part Des value in the output file
	
	ITK(iFail,AOM_ask_value_string(tPartObjectTag,OBJECT_DESCRIPTION,&cpPartDescValue));
	if (tc_strlen(cpPartDescValue) > 0 && cpPartDescValue != NULL)
	{
		fprintf(fp,cpPartDescValue);
	}
	fprintf(fp,"\n");
	
	//Memory free
	EMR_free(cpPartRevID);
	EMR_free(cpPartObjectId);
	EMR_free(tSecondaryObjects);
	EMR_free(cpPCCValue);
	EMR_free(cpOptionValue);
	EMR_free(cpUOMValue);
	EMR_free(cpPlantValue);
	EMR_free(cpSFAPartValue);
	EMR_free(cpDEPTValue);
	EMR_free(cpShelfLifeValue);
	EMR_free(cpSIMCSTValue);
	EMR_free(cpROHSReqValue);
	EMR_free(cpPartDescValue);
	
	
	return iFail;
}
/*******************************************************************************************
*	Function Name	:	 fnPrintingDocInfo

*	Description		:	 This Function is for Printing Document Information
										
********************************************************************************************/
int fnPrintingDocInfo(tag_t tDocumentRevTag,tag_t tECNObjecttag,char *ECNItemId,FILE *fp)
{
	int	iFail									= ITK_ok;	
	int DocumentItemExist						= 0;
	int ECN_EMPTY_Space_Length					= 0;
	int PCC_EMPTY_SPACE_LENGTH					= 0;
	int PCC_STRING_LENGTH						= 0;
	int PLT_EMPTY_SPACE_LENGTH					= 0;
	int PLT_STRING_LENGTH						= 0;
	int LEVEL_EMPTY_Space_Length				= 0;
	int iSecondaryObjectCount					= 0;
	int k										= 0;
	int i										= 0;
	int count									= 0;
	int iDocCount								= 0;

	char *cpDocumentId							= NULL;
	char *cpDocRevID							= NULL;
	char *cpPCCValue							= NULL;
	char cpDocType[WSO_name_size_c+1]			= "";
	char *cpPlantValue							= NULL;
	char *cpDocDescValue						= NULL;
	char cpType1[WSO_name_size_c+1]				= "";
	
	
	tag_t tDocumentRevisionMaster				= NULLTAG;
	tag_t tDocumentMaster						= NULLTAG;
	tag_t tItemmasterFormRelationTag			= NULLTAG;
	tag_t *SecondaryObjectTags					= NULL;
	tag_t *tSecondaryDocObjects					= NULL;
	tag_t *tSecondaryObjects					= NULL; 
	tag_t tDocumentTag							= NULLTAG;
	//Master form variable declaration
	

	//printing ECN NUMBER in the output file
	fprintf(fp, ECNItemId);
	ECN_EMPTY_Space_Length = ECN_NUMBER_SPACE_LENGTH - tc_strlen(ECNItemId);
	fnPrintSpaceValues(ECN_EMPTY_Space_Length,fp);

	//printing LEVEL(Part Rev ID) in the output file
	ITK(iFail,AOM_ask_value_string(tDocumentRevTag,ITEM_REVISION_ID,&cpDocRevID));
	if (tc_strlen(cpDocRevID) > 0 && cpDocRevID != NULL)
	{ 
		
		fnToPrintTheRevisionId(cpDocRevID,fp);
		/*fprintf(fp, cpDocRevID);	
		LEVEL_EMPTY_Space_Length = LEVEL_SPACE_LENGTH - tc_strlen(cpDocRevID);
		fnPrintSpaceValues(LEVEL_EMPTY_Space_Length,fp);*/
	}
	else
	{
		fnPrintSpaceValues(LEVEL_SPACE_LENGTH,fp);
	}
	//printing PART-NUMBER in the output file
	ITK(iFail,AOM_ask_value_string(tDocumentRevTag,ITEM_ID,&cpDocumentId));
	if (tc_strlen(cpDocumentId) > 0 && cpDocumentId != NULL)
	{
		int PART_NUMBER_EMPTY_Space_Length = 0;
		fprintf(fp, cpDocumentId);	
		PART_NUMBER_EMPTY_Space_Length = PART_NUMBER_SPACE_LENGTH - tc_strlen(cpDocumentId);
		fnPrintSpaceValues(PART_NUMBER_EMPTY_Space_Length,fp);
	}
	else
	{
		fnPrintSpaceValues(PART_NUMBER_SPACE_LENGTH,fp);
	}
	//Get EMR_Document Revision Master


	// writing pcc values into output file

	ITK(iFail,ITEM_ask_item_of_rev(tDocumentRevTag, &tDocumentTag))
	ITK(iFail,AOM_ask_value_string(tDocumentTag,DOC_PCC_ATT_VALUE,&cpPCCValue));
	if (tc_strlen(cpPCCValue) > 0 && cpPCCValue != NULL)
	{
		if (tc_strcmp(PCC_SCHEMATIC_PLUS,cpPCCValue) == 0)
		{
			fprintf(fp, PCC_SCHEMATIC_AST);
			PCC_STRING_LENGTH = tc_strlen(PCC_SCHEMATIC_AST);
		}
		else if (tc_strcmp(PCC_WORK_INST_AST1,cpPCCValue) == 0 || tc_strcmp(PCC_WORK_INST_PLUS,cpPCCValue) == 0)
		{
			fprintf(fp, PCC_WORK_INST_AST);
			PCC_STRING_LENGTH = tc_strlen(PCC_WORK_INST_AST);
		}
		else
		{
			fprintf(fp, cpPCCValue);
			PCC_STRING_LENGTH = tc_strlen(cpPCCValue);
		}	
		PCC_EMPTY_SPACE_LENGTH = PCC_SPACE_LENGTH - PCC_STRING_LENGTH;
		fnPrintSpaceValues(PCC_EMPTY_SPACE_LENGTH,fp);
	}
	else
	{
		fnPrintSpaceValues(PCC_SPACE_LENGTH,fp);
	}



	//writing UOM space in the output file
	fnPrintSpaceValues(UoM_SPACE_LENGTH+1,fp);
		
	//writing PLT value into output file

	ITK(iFail,AOM_ask_value_string(tDocumentRevTag,PLT_ATT_VALUE,&cpPlantValue));	
	if (tc_strlen(cpPlantValue) > 0 && cpPlantValue != NULL)
	{
		PLT_STRING_LENGTH = tc_strlen(cpPlantValue);
		if( PLT_STRING_LENGTH > PLT_SPACE_LENGTH)
		{
			fnToTrimtheExceedLength(PLT_STRING_LENGTH,PLT_SPACE_LENGTH,cpPlantValue,fp);
			/*string test = cpPlantValue;
			test.erase(PLT_SPACE_LENGTH,PLT_STRING_LENGTH);
			char *cpPlantTrimValue = "";
			cpPlantTrimValue = (char *)alloca(test.size() + 1);
			memcpy(cpPlantTrimValue, test.c_str(), test.size() + 1);
			fprintf(fp,cpPlantTrimValue);*/
		}
		else
		{
			fprintf(fp,cpPlantValue);
			PLT_EMPTY_SPACE_LENGTH = PLT_SPACE_LENGTH - PLT_STRING_LENGTH;
			fnPrintSpaceValues(PLT_EMPTY_SPACE_LENGTH,fp);
		}
	}
	else
	{
		fnPrintSpaceValues(PLT_SPACE_LENGTH,fp);
	}
		
	
	
	//writing create user space in the output file
	//fnPrintSpaceValues(CREATE_USER_SPACE_LENGTH,fp);
	fnWriteChangeAnalystValue(tECNObjecttag,fp);			//added by tanay on 30-06-2015

	//writing SFA-DEPT space in the output file
	fnPrintSpaceValues(DEPT_SPACE_LENGTH + 1,fp);

	//writing ASP-DATA space in the output file
	fnPrintSpaceValues(ASP_DATA_SPACE_LENGTH,fp);
	
	//writing SIMCST space in the output file
	fnPrintSpaceValues(SIMCST_SPACE_LENGTH + 1,fp);

	//writing EFF-FM-DT value in the output file
	fnEFF_FM_DATE(tDocumentRevTag,fp);
	//fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);

	//writing Attachment where in the output file
	fnPrintSpaceValues(Attachment_Where_SPACE_LENGTH + 1,fp);
	
	//writnig ROHS-Req space in the output file
	//fnPrintSpaceValues(ROHS_REQ_SPACE_LENGTH,fp);
	
	
	// writing Part Des value in the output file
	
	ITK(iFail,AOM_ask_value_string(tDocumentRevTag,OBJECT_DESCRIPTION,&cpDocDescValue));
	if (tc_strlen(cpDocDescValue) > 0 && cpDocDescValue != NULL)
	{
		fprintf(fp,cpDocDescValue);
	}
	fprintf(fp,"\n");

	//Memory free
	EMR_free(cpDocRevID);
	EMR_free(cpDocumentId);
	EMR_free(cpPCCValue);
	EMR_free(cpPlantValue);
	EMR_free(cpDocDescValue);

	
	return iFail;
}
/*******************************************************************************************
*	Function Name	:	 fnEFF_FM_DATE

*	Description		:	 This Function is for getting Effective From Date of Part
										
********************************************************************************************/
int fnEFF_FM_DATE(tag_t tPartObjectTag,FILE *fp)
{
	int	iFail							= ITK_ok;
	int status_count					= 0;
	int imonth							= 0; 
	int iday							= 0;  
	int iyear							= 0;
	int ihour							= 0;
	int iminute							= 0; 
	int isecond							= 0;
	int i								= 0;
	int iEffectivityCount				= 0;
	int iDates							= 0;
	int inx								= 0;
	int EFF_FM_DT_EMPTY_SPACE_LENGTH	= 0;
	char *EffectStartDate				= NULL;	
	char *cpValue						= NULL;
	char *Dateformat					= NULL;
	char NewDateStr[11]					= "";
	tag_t * status_list					= NULL;
	tag_t *tEffectivityTags				= NULL;
	date_t *start_end_values; 
	WSOM_open_ended_status_t  open_ended_or_stockOut;
	date_t   value;

	WSOM_ask_release_status_list  (tPartObjectTag,&status_count,&status_list);
	if (status_count > 0 && status_list != NULL)
	{
		//AOM_ask_value_tag(status_list[status_count - 1],"effectivities",&tEffectivityTag);
		WSOM_status_ask_effectivities(status_list[0],&iEffectivityCount,&tEffectivityTags);
		if (tEffectivityTags != NULL)
		{
			WSOM_effectivity_ask_dates(tEffectivityTags[0],&iDates,&start_end_values,&open_ended_or_stockOut);
		}
		else
		{
			fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);
		}		

		if (iDates > 0)
		{
			ITK_date_to_string(start_end_values[0],&EffectStartDate);
			
			if (EffectStartDate != NULL && tc_strlen(EffectStartDate) > 0)
			{
				DATE_get_internal_date_string_format(&Dateformat);
				if (tc_strlen(Dateformat) > 0)
				printf("Dateformat : %s",Dateformat);
				DATE_string_to_date(EffectStartDate,Dateformat,&imonth,&iday,&iyear,&ihour,&iminute,&isecond);
				if (imonth <= 9)
				{
					//tc_strcpy(NewDateStr,)
					sprintf(NewDateStr,"0%d/%d/%d",imonth,iday,iyear);
				}
				else
				{
					sprintf(NewDateStr,"%d/%d/%d",imonth,iday,iyear);
				}
				if (tc_strlen(NewDateStr) > 0)
				{
					fprintf(fp,NewDateStr);
				}
				else
				{
					fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);
				}					
				/*EFF_FM_DT_EMPTY_SPACE_LENGTH = EFF_FM_DT_SPACE_LENGTH - tc_strlen(EffectStartDate);
				fnPrintSpaceValues(EFF_FM_DT_EMPTY_SPACE_LENGTH,fp);*/
			}
			else
			{
				fnPrintSpaceValues(EFF_FM_DT_SPACE_LENGTH,fp);		
			}
			/*for (inx; inx < iDates; inx++)
			{
				
			}*/
			printf("tEffectivityTag found ..!\n");
		}
	}	
	//Memory free
	EMR_free(status_list);
	EMR_free(tEffectivityTags);
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 IsDocumentExist

*	Description		:	 This Function is for checking the Document Presence in BOM
										
********************************************************************************************/
int IsDocumentExist(tag_t tPartRevObject)
{
	int	iFail							= ITK_ok;
	int FindNoExist						= 0;
	int n								= 0;
	int iCurrentItemBVRCount			= 0;
	int iCurrentItemBVRChildCount		= 0; 
	int find_No_attribute				= 0;
	char *cpPartObjectRevId				= NULL;
	char *cpCurrentChildFindNo			= NULL;
	
	tag_t tWindowCurrent				= NULLTAG;
	tag_t tCurrentItemBVRTopLine		= NULLTAG;
	tag_t *tCurrentItemBVRChildrenTags	= NULL;
	tag_t *tCurrentItemBVRTags			= NULL;
	
	ITK(iFail,ITEM_rev_list_bom_view_revs(tPartRevObject,&iCurrentItemBVRCount,&tCurrentItemBVRTags));
	//AOM_ask_value_string(tPartObjectTag,ITEM_REVISION_ID,&cpPartObjectRevId);
	ITK(iFail,BOM_create_window(&tWindowCurrent));
	if (iCurrentItemBVRCount > 0 && tCurrentItemBVRTags != NULL)
	{			
		ITK(iFail,BOM_set_window_top_line_bvr(tWindowCurrent,tCurrentItemBVRTags[0],&tCurrentItemBVRTopLine));
		if (tCurrentItemBVRTopLine != NULLTAG)
		{
			ITK(iFail,BOM_line_ask_all_child_lines(tCurrentItemBVRTopLine,&iCurrentItemBVRChildCount,&tCurrentItemBVRChildrenTags));
			for (n=0; n < iCurrentItemBVRChildCount; n++)
			{
				ITK(iFail,BOM_line_look_up_attribute("bl_sequence_no", &find_No_attribute));
				ITK(iFail,BOM_line_ask_attribute_string(tCurrentItemBVRChildrenTags[n],find_No_attribute,&cpCurrentChildFindNo));
				if(strlen(cpCurrentChildFindNo)> 0 && cpCurrentChildFindNo!=NULL)
				{
					if(strcmp(cpCurrentChildFindNo,"0")==0)
					{
						FindNoExist=1;
						break;
					}		
						
				}
				
			}
				
		}
	}
	//Memory free
	EMR_free(tCurrentItemBVRTags);
	EMR_free(tCurrentItemBVRChildrenTags);
	EMR_free(cpCurrentChildFindNo);
	
	return FindNoExist;
}
int fnWrite_YorN_Value(char *cpAttrValue,FILE *fp)
{
	int	iFail	=	ITK_ok;

	if (tc_strlen(cpAttrValue) > 0 && cpAttrValue != NULL)
	{
		if (tc_strcmp(YES_VALE,cpAttrValue) == 0)
		{
			fprintf(fp, Y_VALE);
		}
		else
		{
			fprintf(fp, N_VALE);
		}
	}
	else
	{
		fprintf(fp, N_VALE);
	}
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnPrintECNInfo

*	Description		:	 This Function is for Pinting ECN Information
										
********************************************************************************************/
int fnPrintECNInfo(tag_t tECNObjecttag,char *cpProcessName,FILE *fp)
{
	int	iFail							= ITK_ok; 
	int ENCItemIDLength					= 0;
	int ENCNumberSpaceLength			= 0;
	int iSecondaryObjectCount			= 0;
	int LES_STATUS_EMPTY_SPACE_LENGTH	= 0;
	int iParticipantCount				= 0;
	char *cpECNItemID					= NULL;
	char *cpECNDescValue				= NULL;
	char *cpChangeAnalystName			= NULL;
	char *cpLatestReleaseStatusName		= NULL;
	//char cpType1[WSO_name_size_c+1]	=  "";
	char *UserID						= NULL;
	char *cpAnalystTagType				= NULL;
	char *cpLatestStatus				= NULL;
	char *cpECNERPStatus				= NULL;
	tag_t *participant_list				= NULL;
	tag_t tAssignee						= NULLTAG;
	tag_t tAnalystTag					= NULLTAG;
	tag_t Parttype						= NULLTAG;
	tag_t tUsertag						= NULLTAG;
	tag_t tItemmasterFormRelationTag	= NULLTAG;
	tag_t *SecondaryObjectTags			= NULL;	

	
	
	ITK(iFail,AOM_ask_value_string(tECNObjecttag,ITEM_ID,&cpECNItemID));
	ENCItemIDLength = tc_strlen(cpECNItemID);
	ENCNumberSpaceLength = ECN_NUMBER_SPACE_LENGTH - ENCItemIDLength;
	// printing ECN-NUMBER in the output file
	if (tc_strlen(cpECNItemID) > 0 && cpECNItemID != NULL)
	{
		fprintf(fp, cpECNItemID);
	}	
	fnPrintSpaceValues(ENCNumberSpaceLength,fp);

	
	//printing 	CHANGE-ANALYST value in the output file
	fnWriteChangeAnalystValue(tECNObjecttag,fp);		

	//printing LES-STATUS value in the output file
	
	//fnGetLatestReleaseStatus(tECNObjecttag,&cpLatestStatus);
	//AOM_ask_value_string(tECNObjecttag,"last_release_status",&cpLatestReleaseStatusName);
	//
	//ITK(iFail,AOM_ask_value_string(tECNObjecttag,ECN_ERP_STATUS,&cpECNERPStatus));
	//printf("\n Master Form Type: %s\n",cpECNERPStatus);
	
	if(tc_strcmp(cpProcessName,PRELIMINARY_ECN_WORKFLOW) == 0)
	{
		fprintf(fp,"PRELIM LOAD TO LES");
		LES_STATUS_EMPTY_SPACE_LENGTH=LES_STATUS_SPACE_LENGTH-strlen("PRELIM LOAD TO LES");
		fnPrintSpaceValues(LES_STATUS_EMPTY_SPACE_LENGTH,fp);
		//AOM_ask_value_string();
		//printf("iSecondaryObjectCount : %d \n",iSecondaryObjectCount);
	}
	else if(tc_strcmp(cpProcessName,ECN_WORKFLOW) == 0 || tc_strcmp(cpProcessName,MCO_WORKFLOW) == 0)
	{
		fprintf(fp,"PROD RELEASE TO LES");
		LES_STATUS_EMPTY_SPACE_LENGTH=LES_STATUS_SPACE_LENGTH-strlen("PROD RELEASE TO LES");
		fnPrintSpaceValues(LES_STATUS_EMPTY_SPACE_LENGTH,fp);	
	}
	else
	{
		fnPrintSpaceValues(LES_STATUS_SPACE_LENGTH,fp);
	}

	//Yet to confirm this value hence leving blank now. Once confirm need to modify below code accordingly
	

	//printing ECN-DESCRIPTION value in the output file
	ITK(iFail,AOM_ask_value_string(tECNObjecttag,OBJECT_NAME,&cpECNDescValue));
	if (tc_strlen(cpECNDescValue) > 0 &&  cpECNDescValue != NULL)
	{
		fprintf(fp, cpECNDescValue);
	}
	fprintf(fp, "\n");
	//printing Report values
	//Memory free
	EMR_free(cpECNItemID);
	EMR_free(SecondaryObjectTags);
	EMR_free(cpECNERPStatus);
	EMR_free(cpECNDescValue);
	
	return iFail;
}
/*******************************************************************************************
*	Function Name	:	 fnWriteChangeAnalystValue

*	Description		:	 This Function is for Writing ChangeAnalyst value in Flat File
										
********************************************************************************************/
int fnWriteChangeAnalystValue(tag_t tChangeObject,FILE *fp)
{

	int	iFail						=	ITK_ok;
	int cpAnalystValueLength		=	0;
	int cpAnalystValueSpaceLength	=	0;
	char *cpAnalystValue			=	NULL;

	ITK(iFail, AOM_ask_value_string(tChangeObject,Attr_ECN_change_analyst,&cpAnalystValue));
	if (tc_strlen(cpAnalystValue) > 0 && cpAnalystValue != NULL)
	{
		
		cpAnalystValueLength = tc_strlen(cpAnalystValue);
		if( cpAnalystValueLength > CHANGE_ANALYST_SPACE_LENGTH)
		{
			fnToTrimtheExceedLength(cpAnalystValueLength,CHANGE_ANALYST_SPACE_LENGTH,cpAnalystValue,fp);
		}
		else
		{
			fprintf(fp, cpAnalystValue);
			cpAnalystValueSpaceLength  = CHANGE_ANALYST_SPACE_LENGTH - cpAnalystValueLength;
			fnPrintSpaceValues(cpAnalystValueSpaceLength,fp);
		}
	}
	else
	{
		fnPrintSpaceValues(CHANGE_ANALYST_SPACE_LENGTH,fp);
	}
	EMR_free(cpAnalystValue);
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnToTrimtheExceedLength

*	Description		:	 This Function is for Trimmming the length of Property value
										
********************************************************************************************/

int fnToTrimtheExceedLength(int iPropertyLength,int iPropertySpecifiedLength, char *cpPropertyValue,FILE *fp)
{
	int	iFail	=	ITK_ok;
	string test = cpPropertyValue;
	test.erase(iPropertySpecifiedLength,iPropertyLength);
	char *cpTrimValue = "";
	cpTrimValue = (char *)alloca(test.size() + 1);
	memcpy(cpTrimValue, test.c_str(), test.size() + 1);
	fprintf(fp,cpTrimValue);
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnToPrintTheRevisionId

*	Description		:	 This Function is for Printing the Revision ID of Item
										
********************************************************************************************/

int fnToPrintTheRevisionId(char *cpPartRevID, FILE *fp)
{
		int LEVEL_EMPTY_Space_Length				= 0;
		int iFail = ITK_ok;
		char *cpPointerValue = NULL;
		cpPointerValue = (char *)MEM_alloc(tc_strlen(strchr(cpPartRevID,'.')) + 1);
		cpPointerValue = strchr(cpPartRevID,'.');
		if(cpPointerValue != NULL)
		{
			string stRevId = cpPartRevID;
			int length = tc_strlen(cpPartRevID) - tc_strlen(cpPointerValue);
			stRevId.erase(length,tc_strlen(cpPartRevID));
			char *cpRevID	=	NULL;
			cpRevID = (char *)alloca(stRevId.size() + 1);
			memcpy(cpRevID, stRevId.c_str(), stRevId.size() + 1);
			fprintf(fp, cpRevID);
			LEVEL_EMPTY_Space_Length = LEVEL_SPACE_LENGTH - tc_strlen(cpRevID);
			fnPrintSpaceValues(LEVEL_EMPTY_Space_Length,fp);
		}
		else
		{
			fprintf(fp, cpPartRevID);	
			LEVEL_EMPTY_Space_Length = LEVEL_SPACE_LENGTH - tc_strlen(cpPartRevID);
			fnPrintSpaceValues(LEVEL_EMPTY_Space_Length,fp);
		}
		return ITK_ok;
}

/*******************************************************************************************
*	Function Name	:	 fnPrintSpaceValues

*	Description		:	 This Function is for Printing Spcae Values
										
********************************************************************************************/
int fnPrintSpaceValues(int spaceValue,FILE *fp)
{
	int	iFail	=	ITK_ok;
	int i = 0;
	for (i; i < spaceValue; i++)
	{
		fprintf(fp, " ");
	}
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnPrintECNheader

*	Description		:	 This function will print all the header for the different section of the file 
										
********************************************************************************************/
int fnPrintECNheader(FILE *fp,int headervalue)
{
	int	iFail	=	ITK_ok;
	if (headervalue == 1)
	{
		fprintf(fp, "# ECN-MASTER Data\n");
		fprintf(fp, "ECN-NUMBER  CHANGE-ANALYST          LES-STATUS          ECN-DESCRIPTION\n");
	}
	else if (headervalue == 2)
	{
		fprintf(fp, "\n");
		fprintf(fp, "# NEW PART Data\n");
		fprintf(fp, "ECN-NUMBER  LEVEL PART-NUMBER    PCC            OUoM                  PLT               CREATE-USER             SFADEPT      ASP-DATA SIMCST     DACEFF-FM-DT Attachment Where?   ROHS-REQPART-DESCRIPTION\n");		
	}
	else if (headervalue == 3)
	{
		fprintf(fp, "\n");
		fprintf(fp, "# BOM Data\n");
		fprintf(fp, "ECN-NUMBER  BOM-PARENT     PART-NUMBER    OLD-REVNEW-REVEFF-FM-DT ITM QTY-PER AC\n");
	}
	else if (headervalue == 4)
	{
		fprintf(fp, "\n");
		fprintf(fp, "# MPN Data\n");
		fprintf(fp, "PART-NUMBER    MFG-PART-NUMBER               MFGR-No  MANUFACTURER-NAME                       MFGR-Status    AC\n");	
	}
	return iFail;
}

/*******************************************************************************************
*	Function Name	:	 fnUpdateFormProperties

*	Description		:	 This function is used for Updating the Form Properties
										
********************************************************************************************/
int fnUpdateFormProperties(tag_t tRevTag, tag_t tUserTag, char *cpStatus, char * wfuser)
{

	int iFail = ITK_ok;	
	tag_t tGroupMemberTag =	NULLTAG;
	tag_t tGrouptag		  = NULLTAG;
	tag_t tRoleTag		  = NULLTAG;
	char *cpGroupName = NULL;
	char *cpRoleName  = NULL;
	char *Temp = NULL;
	tag_t tFormTag = NULLTAG;
	ITK(iFail, SA_ask_current_groupmember(&tGroupMemberTag));
	if(tGroupMemberTag != NULLTAG)
	{
		ITK(iFail, SA_ask_groupmember_group(tGroupMemberTag,&tGrouptag));
		if(tGrouptag != NULLTAG)
		{
			ITK(iFail, SA_ask_group_name2(tGrouptag,&cpGroupName));
		}
		ITK(iFail, SA_ask_groupmember_role(tGroupMemberTag,&tRoleTag));
		if(tRoleTag != NULLTAG)
		{
			ITK(iFail, SA_ask_role_name2(tRoleTag,&cpRoleName));
		}
		if(cpRoleName != NULL && cpGroupName != NULL)
		{
			Temp = (char *)MEM_alloc(tc_strlen(cpGroupName) + tc_strlen("/") + tc_strlen(cpRoleName)  + tc_strlen("/") + tc_strlen(wfuser) + 2);
			tc_strcpy(Temp,"");
			tc_strcpy(Temp,cpGroupName);
			tc_strcat(Temp,"/");
			tc_strcat(Temp,cpRoleName);
			tc_strcat(Temp,"/");
			tc_strcat(Temp,wfuser);
			
		}
	}
	if(Temp != NULL)
	{
		ITK(iFail, FORM_create(Temp,"",CM_SIGNOFF_FORM_TYPE,&tFormTag));
	}
	if( tFormTag != NULLTAG)
	{			
		if(tc_strcmp(cpStatus,"Transferred") == 0)
		{
			ITK(iFail,fnSetFormValuesForTransfer(tFormTag,tUserTag,cpStatus,"LES file is generated"));
		}
		else if(tc_strcmp(cpStatus,"Failed") == 0)
		{
			ITK(iFail,fnSetFormValuesForTransfer(tFormTag,tUserTag,cpStatus,"LES file is not generated"));
		}
	}

	if(tRevTag != NULLTAG)
	{
		ITK(iFail,attachFormToRevision(tFormTag,tRevTag,Attr_SIGNOFF_HISTORY));
	}
	EMR_free(cpGroupName);
	EMR_free(cpRoleName);
	return ITK_ok;
}
	
/******************************************************************************************

File			:	LBT9_DCN_Validation.cpp

Description		:	Workflow action handlers for Libert

Author			:	Krupakar Reddy G

Date created	:   14/06/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

14/06/2015		Krupkar Reddy G		 		Inital version

14/06/2015		Krupkar Reddy G             Added LBT9_DCN_Validation

04/07/2015		Krupkar Reddy G             Added LBT9_VALIDATE_CANCEL_DCN_WF
******************************************************************************************/
#include "LBT9_Change_Handler.h"

/**********************************************************************************************************************
*	Handler Name	:	LBT9_DCN_Validation

*	Description		:	This Function is used to Validate the DCN When Implement ECN workflow is initiated
																	
***********************************************************************************************************************/

extern EPM_decision_t LBT9_DCN_Validation(EPM_rule_message_t message)
{
	int retcode	= ITK_ok;
	EPM_decision_t decision		=	EPM_nogo;
	logical validationFailed = false;
	logical all_ok = true;
	int iTargetAttchmnt			=	0;
	int iSolutionItemCount		=	0;
	int i = 0;
	int j = 0;
	int m = 0;
	char *past_solution_revs = NULL;
	char *no_target_solution_revs = NULL;
	char *no_change_function_solution_revs = NULL;
	char *child_not_in_solution_list = NULL;
	char *obsolete_child_list = NULL;
	char *inactive_child_list = NULL;

	tag_t tRootTask				=	NULLTAG;
	tag_t* tAttchItemTag		=	NULL;
	tag_t* tSoluitionItemTag	=	NULL;
	tag_t *tObsoleteParenttags					=	NULL;
	tag_t *tInactiveParenttags					=	NULL;
	tag_t *tUnreleasedParenttags				=	NULL;

	logical ValidationObsoleteChild = false;
	logical ValidationInactiveChild = false;
	logical ValidationUnreleasedChild = false;

	ITK(retcode,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		ITK(retcode,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp("LBT9_DCNRevision",cpObjectType) == 0)
		{
			int iStatusCount	=	0;
			tag_t * tStatusTags	=	NULL;
			ITK(retcode,WSOM_ask_release_status_list(tAttchItemTag[0],&iStatusCount,&tStatusTags));
			if(iStatusCount > 0 && tStatusTags != NULL)
			{
				char * cpStatusName	=	NULL;
				ITK(retcode,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));
				if(cpStatusName != NULL && tc_strcmp(cpStatusName,"Pending")==0)
				{
					ITK(retcode,LBT_get_related_objects(tAttchItemTag[0],"CMHasSolutionItem",&iSolutionItemCount,&tSoluitionItemTag));
				}
				else
				{
					EMH_clear_errors();
					EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_DCN_REVISION_IS_NOT_IN_PENDING_STATUS,"");
					decision = EPM_nogo;
					validationFailed = true;
					return decision;
				}
				EMR_free(cpStatusName);
			}
			EMR_free(tStatusTags);
			EMR_free(cpObjectType);
		}
		else
		{
			EMH_clear_errors();
			EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_REVISION_SELECTED_IS_NOT_DCN_REVISION,"");
			decision = EPM_nogo;
			validationFailed = true;
			return decision;
			EMR_free(cpObjectType);
		}
	 if(tSoluitionItemTag == NULL && iSolutionItemCount == 0)
	 {
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_NO_SOLUTION_ITEMS,"");
		decision = EPM_nogo;
		validationFailed = true;
		return decision;
	 }
	  else if(iSolutionItemCount > 0 && tSoluitionItemTag != NULL)
		{
			int valid_sol_item_count	=	0;
			int invalid_sol_item_count	=	0;
			char *Temp = NULL;
			char * cObjecttype	=	NULL;
			char *released_solution_revs = NULL;
			char *prelimn_sol_prev_revs	=	NULL;
			char *invalid_solution_revs = NULL;
			tag_t * tvalidObjecttags	=	NULL;
			tag_t * tinvalidObjecttags	=	NULL;
			for(int j=0; j < iSolutionItemCount; j++)
			{
				WSOM_ask_object_type2(tSoluitionItemTag[j],&cObjecttype);
				if(cObjecttype != NULL && tc_strcmp("LBT9_BusDocRevision",cObjecttype)==0)
				{
					tvalidObjecttags = (tag_t *)MEM_realloc(tvalidObjecttags,sizeof(tag_t)*(valid_sol_item_count+1));
					tvalidObjecttags[valid_sol_item_count] = tSoluitionItemTag[j];
					valid_sol_item_count++;
				}
				else
				{
					tinvalidObjecttags = (tag_t *)MEM_realloc(tinvalidObjecttags,sizeof(tag_t)*(invalid_sol_item_count+1));
					tinvalidObjecttags[invalid_sol_item_count] = tSoluitionItemTag[j];
					invalid_sol_item_count++;
				}
			}
			
			for (int inx = 0; inx < valid_sol_item_count; inx++)
			{
				logical IsSolutionItemStausNotPreliminary = false;
				int n_rel_sol_revs = 0;
				tag_t *rel_sol_rev_tags = NULL;
				tag_t *prelimn_sol_prev_revs_tags	=	NULL;
				tag_t *past_sol_rev_tags = NULL;
				tag_t *no_target_sol_rev_tags = NULL;
				tag_t *no_change_function_sol_rev_tags = NULL;
				
				// checking the Status of the Solution Item
				ITK(retcode,LBT_Is_Solution_Items_Status_Preliminary_or_Prototype(valid_sol_item_count,tvalidObjecttags,&n_rel_sol_revs, &rel_sol_rev_tags,&IsSolutionItemStausNotPreliminary));
				if (IsSolutionItemStausNotPreliminary)
				{	

					ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_rel_sol_revs, rel_sol_rev_tags, &released_solution_revs));
					decision = EPM_nogo;
					all_ok = false;
				}
				// checking for previous revisions status of Solution Item
				int n_prelimn_sol_prev_revs	=	0;
				ITK(retcode,LBT_get_lower_rev_solution_items(valid_sol_item_count,tvalidObjecttags,&n_prelimn_sol_prev_revs,&prelimn_sol_prev_revs_tags));
				if(n_prelimn_sol_prev_revs > 0 && prelimn_sol_prev_revs_tags != NULL)
				{
					ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_prelimn_sol_prev_revs,prelimn_sol_prev_revs_tags,&prelimn_sol_prev_revs));
					all_ok = false;
				}
				int bvrCount = 0;
				tag_t *bvrTags = NULL;
				//checking the BOM view revision of the Soluiton item having Obsolete status or not
				ITK(retcode,ITEM_rev_list_bom_view_revs(tvalidObjecttags[inx], &bvrCount, &bvrTags));
				for (int jnx = 0; jnx < bvrCount; jnx++)
				{
					int n_unreleased_child = 0;
					int n_child_not_in_solutions = 0;
					int n_obsolete_child = 0;
					int n_inactive_child = 0;
					tag_t *unreleased_child_tags = NULL;
					tag_t *child_not_in_solution = NULL;
					tag_t *obsolete_children = NULL;
					tag_t *inactive_children = NULL;

					ITK(retcode,LBT_get_obsolete_children(tvalidObjecttags[inx], bvrTags[jnx], &n_obsolete_child, &obsolete_children));
					if(obsolete_children != NULL && n_obsolete_child > 0)
					{
						tObsoleteParenttags = (tag_t *)MEM_realloc(tObsoleteParenttags,sizeof(tag_t)*(i+1));
						tObsoleteParenttags[i] = tvalidObjecttags[inx];
						i++;
						ValidationObsoleteChild = true;
					}
					if(ValidationObsoleteChild)
					{
						all_ok = false;
					}
					if(obsolete_children != NULL)
					{
						EMR_free(obsolete_children);
					}
					ITK(retcode,LBT_get_inactive_children(tvalidObjecttags[inx], bvrTags[jnx], &n_inactive_child, &inactive_children));
					if(inactive_children != NULL && n_inactive_child > 0)
					{
						tInactiveParenttags = (tag_t *)MEM_realloc(tInactiveParenttags,sizeof(tag_t)*(m+1));
						tInactiveParenttags[m] = tvalidObjecttags[inx];
						m++;
						ValidationInactiveChild = true;
					}
					if(ValidationInactiveChild)
					{
						all_ok = false;
					}
					if(inactive_children != NULL)
					{
						EMR_free(inactive_children);
					}
					ITK(retcode,LBT_get_unreleased_children(tvalidObjecttags[inx], bvrTags[jnx], &n_unreleased_child, &unreleased_child_tags));
				
					ITK(retcode,LBT_checkif_unreleased_revs_exist_in_solutions(valid_sol_item_count, tvalidObjecttags, n_unreleased_child, unreleased_child_tags, &n_child_not_in_solutions, &child_not_in_solution));
				
					if ( n_child_not_in_solutions > 0 )
					{
						tUnreleasedParenttags = (tag_t *)MEM_realloc(tUnreleasedParenttags,sizeof(tag_t)*(j+1));
						tUnreleasedParenttags[j] = tvalidObjecttags[inx];
						j++;
						ValidationUnreleasedChild = true;
						EMR_free(unreleased_child_tags);
						EMR_free(child_not_in_solution);
					}
					if(ValidationUnreleasedChild)
					{
						all_ok = false;
					}
				}
				// checking for past effective solution items
				int n_past_sol_revs = 0;
				ITK(retcode,LBT_get_past_effective_solution_items(tAttchItemTag[0], valid_sol_item_count, tvalidObjecttags, &n_past_sol_revs, &past_sol_rev_tags));
				if ( n_past_sol_revs > 0 )
				{
					ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_past_sol_revs, past_sol_rev_tags, &past_solution_revs));
					decision = EPM_nogo;
					all_ok = false;
				}
				int n_no_target_sol_revs = 0;
				ITK(retcode,LBT9_get_solution_items_with_no_disposition_values(tAttchItemTag[0], valid_sol_item_count, tvalidObjecttags,TARGET_STATUS, &n_no_target_sol_revs, &no_target_sol_rev_tags));
				if ( n_no_target_sol_revs > 0 )
				{
					ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_no_target_sol_revs, no_target_sol_rev_tags, &no_target_solution_revs));
					decision = EPM_nogo;
					all_ok = false;
					EMR_free(no_target_sol_rev_tags);
				}
				int n_no_change_function_sol_revs = 0;
				ITK(retcode,LBT9_get_solution_items_with_no_disposition_values(tAttchItemTag[0], valid_sol_item_count, tvalidObjecttags,CHANGE_FUNCTION, &n_no_change_function_sol_revs, &no_change_function_sol_rev_tags));
				if ( n_no_change_function_sol_revs > 0 )
				{
					ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_no_change_function_sol_revs, no_change_function_sol_rev_tags, &no_change_function_solution_revs));
					decision = EPM_nogo;
					all_ok = false;
					EMR_free(no_change_function_sol_rev_tags);
				}
			}
			if(invalid_sol_item_count > 0)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(invalid_sol_item_count, tinvalidObjecttags, &invalid_solution_revs));
				decision = EPM_nogo;
				all_ok = false;
			}
			if(ValidationObsoleteChild)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(i, tObsoleteParenttags, &obsolete_child_list));
				decision = EPM_nogo;
			}
			if(ValidationInactiveChild)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(m, tInactiveParenttags, &inactive_child_list));
				decision = EPM_nogo;
			}
			if(ValidationUnreleasedChild)
			{
				ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(j, tUnreleasedParenttags, &child_not_in_solution_list));
				decision = EPM_nogo;
			}
			Temp = (char *)MEM_alloc(tc_strlen("1. Following Solution Items are not in Preliminary State:") + tc_strlen("2. Following Solution Items are not Office Business Documents") + tc_strlen("3.  Following Solution Items have previous revisions which are not in  Obsolete or Inactive or Released:") +  tc_strlen("4. Following Solution Items have Obsolete children") + tc_strlen("5. Following Solution Items have Inactive children:\n") + tc_strlen("6. Following Solution Items have Unreleased children which have not been added to the same DCN") + tc_strlen(obsolete_child_list) + tc_strlen(child_not_in_solution_list) + tc_strlen(released_solution_revs) + 1700 * iSolutionItemCount + 1);
			tc_strcpy(Temp,"\n");
			if(invalid_solution_revs != NULL)
			{
				tc_strcat(Temp,"--  Following Solution Items are not Office Business Documents :\n");
				tc_strcat(Temp,invalid_solution_revs);
			}
			if(released_solution_revs != NULL)
			{
				tc_strcat(Temp,"\n--  Following Solution Items are not in Preliminary State:\n");
				tc_strcat(Temp,released_solution_revs);
			}
			if(prelimn_sol_prev_revs != NULL)
			{
				tc_strcat(Temp,"\n-- Following Solution Items have previous revisions which are not in  Obsolete or Inactive or Released:\n");
				tc_strcat(Temp,prelimn_sol_prev_revs);
			}
			if(obsolete_child_list != NULL)
			{
				tc_strcat(Temp,"\n--  Following Solution Items have Obsolete children:\n");
				tc_strcat(Temp,obsolete_child_list);
			}
			if(inactive_child_list != NULL)
			{
				tc_strcat(Temp,"\n-- Following Solution Items have Inactive children:\n");
				tc_strcat(Temp,inactive_child_list);	
			}
			if(child_not_in_solution_list != NULL)
			{
				tc_strcat(Temp,"\n-- Following Solution Items have Unreleased children which have not been added to the same DCN:\n");
				tc_strcat(Temp,child_not_in_solution_list);
			}
			if(past_solution_revs != NULL || no_target_solution_revs != NULL || no_change_function_solution_revs != NULL )
			{
				tc_strcat(Temp,"\n--  Following Solution Items do not have a few mandatory values to be set for DCN submission:");
				if(past_solution_revs != NULL)
				{
					tc_strcat(Temp,"\n--  Solution Item Effective date is Past or not set: ");
					tc_strcat(Temp,past_solution_revs);
				}
				if(no_target_solution_revs != NULL)
				{
					tc_strcat(Temp,"\n--  Solution Item Target status is not set: ");
					tc_strcat(Temp,no_target_solution_revs);
				}
				if(no_change_function_solution_revs != NULL)
				{
					tc_strcat(Temp,"\n--  Solution Item Change function is not set: ");
					tc_strcat(Temp,no_change_function_solution_revs);
				}
			}
			if(!all_ok)
			{
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_VALIDATION_SOLUTION_ITEMS, Temp);
				decision = EPM_nogo;
			}

			else if(all_ok)
			{
				decision = EPM_go;
			}
			
			
		}
	
	}
	return decision;
}

/**********************************************************************************************************************
*	Handler Name	:	LBT9_VALIDATE_CANCEL_DCN_WF

*	Description		:	This Function is used to Validate the DCN When Cancel DCN Workflow is initiated
																	
***********************************************************************************************************************/

extern EPM_decision_t LBT9_VALIDATE_CANCEL_DCN_WF(EPM_rule_message_t message)
{
	int retcode = ITK_ok;
	int iTargetAttchmnt			=	0;
	int iStatusCount			=	0;
	EPM_decision_t decision		=	EPM_nogo;
	char temp[SS_MAXLLEN]		=	"";
	tag_t tRootTask				=	NULLTAG;
	tag_t tMCORevTag			=	NULLTAG;
	tag_t tOwningUserTag		=	NULLTAG;
	tag_t tCurrentGroupmember   =	NULLTAG;
	tag_t tCurrentUserTag		=	NULLTAG;
	tag_t * tAttchItemTag		=	NULL;
	tag_t * tStatusTags			=	NULL;
	char *cpUserID				=	NULL;
	char *cploginUserID			=	NULL;
	logical ValidStatus			=	false;
	logical ValidUser			=	false;
	

	ITK(retcode,EPM_ask_root_task (message.task, &tRootTask));	
	if (tRootTask != NULLTAG) 
	{
		ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	char *cpObjectType = NULL;
	ITK(retcode,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
	if(cpObjectType != NULL && tc_strcmp("LBT9_DCNRevision",cpObjectType) == 0)
	{
		if (iTargetAttchmnt > 0 && tAttchItemTag != NULL)
		{		
			ITK(retcode,WSOM_ask_release_status_list(tAttchItemTag[0],&iStatusCount,&tStatusTags));

			if(iStatusCount > 0 && tStatusTags != NULL)
			{
				char * cpStatusName	=	NULL;
				ITK(retcode,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));

				if(cpStatusName	!= NULL && tc_strcmp(cpStatusName,"Pending")==0)
				{
					//Getting Originator and Change Analyst Values and Checking with Current login User
					char * cpLoginUserId			= NULL;
					char * cpOriginatorId			= NULL;
					char * cpAnalystId				= NULL;
					tag_t tOriginatorTag			= NULLTAG;
					tag_t tAnalystTag				= NULLTAG;
					tag_t tCurrentGrpMemberTag		= NULLTAG;
					tag_t tUserTag					= NULLTAG;

					ValidStatus	=	true;
					ITK(retcode,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
					if(tOriginatorTag != NULLTAG)
					{
						ITK(retcode,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
					}
					ITK(retcode,fnGetParticipantList(tAttchItemTag[0],CHANGE_ANALYST,&tAnalystTag));
					if(tAnalystTag != NULLTAG)
					{
						ITK(retcode,SA_ask_user_identifier2(tAnalystTag,&cpAnalystId));
					}

					ITK(retcode,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
					ITK(retcode,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
					ITK(retcode,SA_ask_user_identifier2(tUserTag,&cpLoginUserId));
					if(cpLoginUserId != NULL && (tc_strcmp(cpLoginUserId,cpOriginatorId)==0 || tc_strcmp(cpLoginUserId,cpAnalystId)==0 ))
					{
						ValidUser = true;
						decision = EPM_go;
					}
					else
					{
						ValidUser	=	false;
					}
				    EMR_free(cpOriginatorId);
					EMR_free(cpAnalystId);
					EMR_free(cpLoginUserId);
				}
				else
				{
					ValidStatus	=	false;
				}
				EMR_free(cpStatusName);
			}
		
			if(!ValidStatus)
			{
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_DCN_WORKFLOW_STATUS,"");
				decision = EPM_nogo;
			}
			else if(!ValidUser)
			{
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_DCN_WORKFLOW_USER_VALIDATION,"");
				decision = EPM_nogo;
			}
		 EMR_free(tStatusTags);
		}
	}
	else
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_DCN_WORKFLOW_OBJECT_VALIDATION,"");
		decision = EPM_nogo;
	}
	EMR_free(cpObjectType);
	EMR_free(tAttchItemTag);

	return decision;
}
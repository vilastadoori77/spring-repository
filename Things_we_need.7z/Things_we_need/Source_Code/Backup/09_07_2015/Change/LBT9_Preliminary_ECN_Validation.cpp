	
/******************************************************************************************

File			:	LBRT_Preliminary_ECN_Validation.cpp

Description		:	Workflow action handlers for Libert

Author			:	Krupakar Reddy G

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added LBT9_VALIDATE_ECN
					
******************************************************************************************/
#include "LBT9_Change_Handler.h"




/****************************************************************************************************
*	Handler name	:	LBT9_VALIDATE_ECN

*	Description		:	Rule Handler - For the validation of Preliminary ECN workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_VALIDATE_ECN(EPM_rule_message_t message)
{
	int retcode = ITK_ok;
	tag_t root_task = NULLTAG;
	tag_t rev_tag = NULLTAG;
	EPM_decision_t decision = EPM_nogo;
	char *child_not_in_solution_list = NULL;
	char *obsolete_child_list = NULL;
	char *inactive_child_list = NULL;
	char *released_solution_revs =NULL;
	logical validationFailed = false;
	logical all_ok = true;
	int j = 0;
	int i = 0;
	int m = 0;
	tag_t *tObsoleteParenttags					=	NULL;
	tag_t *tInactiveParenttags					=	NULL;
	tag_t *tUnreleasedParenttags				=	NULL;
	logical ValidationObsoleteChild = false;
	logical ValidationInactiveChild = false;
	logical ValidationUnreleasedChild = false;
	ITK(retcode,EPM_ask_root_task (message.task, &root_task));

	ITK(retcode,LBT_get_ecn_revision(root_task, CLASS_ECN_REVISION, EPM_target_attachment, &rev_tag));

	if(rev_tag != NULLTAG)
	{
		int n_solution_revs = 0;
		
		tag_t *solution_rev_tags = NULL;
		logical validationForStatus = false;
		ITK(retcode, fnToValidateChangeObjectStatus(rev_tag,PENDING_STATUS,&validationForStatus));
		if(validationForStatus)
		{
			char *cpERPStatus = NULL;
			ITK(retcode, AOM_ask_value_string(rev_tag,"lbt9_ERP_Status",&cpERPStatus));
			if(tc_strcmp(cpERPStatus,"Transfer To ERP") == 0)
			{
				logical UserIsOriginator = false;
				ITK(retcode,fnToCheckCurrentUserIsOriginator(rev_tag,&UserIsOriginator));
				if(UserIsOriginator)
				{
					ITK(retcode,LBT_get_related_objects(rev_tag, "CMHasSolutionItem", &n_solution_revs, &solution_rev_tags));
					if ( n_solution_revs == 0 )
					{
						EMH_clear_errors();
						EMH_store_initial_error_s1(EMH_severity_user_error, LBT_NO_SOLUTION_ITEMS,"");
						decision = EPM_nogo;
						validationFailed = true;
						EMR_free(cpERPStatus);
						EMR_free(solution_rev_tags);
						return decision;
					}
					else if(n_solution_revs > 0 && solution_rev_tags != NULLTAG)
					{
						char *Temp = NULL;
		
						for (int inx = 0; inx < n_solution_revs; inx++)
						{
							logical IsSolutionItemStausNotPreliminary = false;
							int n_rel_sol_revs = 0;
							tag_t *rel_sol_rev_tags = NULL;
							// checking the Status of the Solution Item
							ITK(retcode,LBT_Is_Solution_Items_Status_Preliminary_or_Prototype(n_solution_revs,solution_rev_tags,&n_rel_sol_revs, &rel_sol_rev_tags,&IsSolutionItemStausNotPreliminary));
							if (IsSolutionItemStausNotPreliminary)
							{	

								ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_rel_sol_revs, rel_sol_rev_tags, &released_solution_revs));
								decision = EPM_nogo;
								all_ok = false;
								EMR_free(rel_sol_rev_tags);
							}
							int bvrCount = 0;
							tag_t *bvrTags = NULL;
							//checking the BOM view revision of the Soluiton item having Obsolete status or not
							ITK(retcode,ITEM_rev_list_bom_view_revs(solution_rev_tags[inx], &bvrCount, &bvrTags));
							for (int jnx = 0; jnx < bvrCount; jnx++)
							{
								int n_unreleased_child = 0;
								int n_child_not_in_solutions = 0;
								int n_obsolete_child = 0;
								int n_inactive_child = 0;
								tag_t *unreleased_child_tags = NULL;
								tag_t *child_not_in_solution = NULL;
								tag_t *obsolete_children = NULL;
								tag_t *inactive_children = NULL;

								ITK(retcode,LBT_get_obsolete_children(solution_rev_tags[inx], bvrTags[jnx], &n_obsolete_child, &obsolete_children));
								if(obsolete_children != NULL && n_obsolete_child > 0)
								{
									tObsoleteParenttags = (tag_t *)MEM_realloc(tObsoleteParenttags,sizeof(tag_t)*(i+1));
									tObsoleteParenttags[i] = solution_rev_tags[inx];
									i++;
									ValidationObsoleteChild = true;
								}
								if(ValidationObsoleteChild)
								{
									all_ok = false;
								}
								if(obsolete_children != NULL)
								{
									EMR_free(obsolete_children);
								}
								ITK(retcode,LBT_get_inactive_children(solution_rev_tags[inx], bvrTags[jnx], &n_inactive_child, &inactive_children));
								if(inactive_children != NULL && n_inactive_child > 0)
								{
									tInactiveParenttags = (tag_t *)MEM_realloc(tInactiveParenttags,sizeof(tag_t)*(m+1));
									tInactiveParenttags[m] = solution_rev_tags[inx];
									m++;
									ValidationInactiveChild = true;
								}
								if(ValidationInactiveChild)
								{
									all_ok = false;
								}
								if(inactive_children != NULL)
								{
									EMR_free(inactive_children);
								}
								ITK(retcode,LBT_get_unreleased_children(solution_rev_tags[inx], bvrTags[jnx], &n_unreleased_child, &unreleased_child_tags));
				
								ITK(retcode,LBT_checkif_unreleased_revs_exist_in_solutions(n_solution_revs, solution_rev_tags, n_unreleased_child, unreleased_child_tags, &n_child_not_in_solutions, &child_not_in_solution));
				
								if ( n_child_not_in_solutions > 0 )
								{
									tUnreleasedParenttags = (tag_t *)MEM_realloc(tUnreleasedParenttags,sizeof(tag_t)*(j+1));
									tUnreleasedParenttags[j] = solution_rev_tags[inx];
									j++;
									ValidationUnreleasedChild = true;
									EMR_free(unreleased_child_tags);
									EMR_free(child_not_in_solution);
								}
								if(ValidationUnreleasedChild)
								{
									all_ok = false;
								}
							}
							EMR_free(bvrTags);
						}
						if(ValidationObsoleteChild)
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(i, tObsoleteParenttags, &obsolete_child_list));
							decision = EPM_nogo;
						}
						if(ValidationInactiveChild)
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(m, tInactiveParenttags, &inactive_child_list));
							decision = EPM_nogo;
						}
						if(ValidationUnreleasedChild)
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(j, tUnreleasedParenttags, &child_not_in_solution_list));
							decision = EPM_nogo;
						}
			
						Temp = (char *)MEM_alloc(tc_strlen("-- Following Solution Items are not in Preliminary or Prototype State:") + tc_strlen("2. Following Solution Items have Obsolete children") + tc_strlen("3. Following Solution Items have Unreleased children which have not been added to the same ECN") + tc_strlen("\n-- Following Solution Items have Inactive children:\n") + tc_strlen(obsolete_child_list) + tc_strlen(child_not_in_solution_list) + tc_strlen(released_solution_revs) + tc_strlen(inactive_child_list) + 1000 * n_solution_revs + 1);
						tc_strcpy(Temp,"\n");
						if(released_solution_revs != NULL)
						{
							tc_strcat(Temp,"-- Following Solution Items are not in Preliminary or Prototype State:\n");
							tc_strcat(Temp,released_solution_revs);
						}
						if(obsolete_child_list != NULL)
						{
							tc_strcat(Temp,"\n-- Following Solution Items have Obsolete children:\n");
							tc_strcat(Temp,obsolete_child_list);
						}
						if(inactive_child_list != NULL)
						{
							tc_strcat(Temp,"\n-- Following Solution Items have Inactive children:\n");
							tc_strcat(Temp,inactive_child_list);	
						}
						if(child_not_in_solution_list != NULL)
						{
							tc_strcat(Temp,"\n-- Following Solution Items have Unreleased children which have not been added to the same ECN:\n");
							tc_strcat(Temp,child_not_in_solution_list);
						}
						if(!all_ok)
						{
							EMH_store_initial_error_s1(EMH_severity_user_error, LBT_NO_SOLUTION_ITEMS_FOUND, Temp);
							EMR_free(Temp);
							decision = EPM_nogo;
						}

						else if(all_ok)
						{
							decision = EPM_go;
						}	
					}
					EMR_free(child_not_in_solution_list);
					EMR_free(inactive_child_list);
					EMR_free(obsolete_child_list);
					EMR_free(released_solution_revs);
					EMR_free(solution_rev_tags);
				}
				else
				{
					EMH_store_initial_error_s1(EMH_severity_user_error,LBT_ORIGINATOR_SHOULD_INITIATE_PRELIM_WORKFLOW, "");
					decision = EPM_nogo;
					EMR_free(cpERPStatus);
					return decision;
				}
			}
			else if(tc_strcmp(cpERPStatus,"Teamcenter Only") == 0)
			{
				EMH_store_initial_error_s1(EMH_severity_user_error,LBT_ECN_ERP_STATUS_IS_NOT_CORRECT, "");
				decision = EPM_nogo;
				return decision;
			}
			EMR_free(cpERPStatus);
		}
		else if(!validationForStatus)
		{
			EMH_store_initial_error_s1(EMH_severity_user_error,LBT_ECN_SELCTED_IS_NOT_IN_PENDING, "");
			decision = EPM_nogo;
			return decision;
		}
	}
	else
	{
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT_REVISION_SELECTED_IS_NOT_ECN_REVISION, "");
		decision = EPM_nogo;
	}
	return decision;
}

/******************************************************************************************

File			:	LBRT_Send_Note.cpp

Description		:	Functions for Workflow action handlers 

Author			:  Krupakar Reddy G

Date created	:   10/05/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added sendNote

01/06/2015		Krupkar Reddy G             Added LBT_send_note_email

02/06/2015		Krupkar Reddy G             Added createNoteForm

02/06/2015		Krupkar Reddy G             Added makePartcipantsList

03/06/2015		Krupkar Reddy G             Added attachNotesFormToRevision

03/06/2015		Krupkar Reddy G             Added generateNoteBodyAttachment

04/06/2015		Krupkar Reddy G 			Added generateDefaultBodyAttachment

04/06/2015		Krupkar Reddy G				Added getParticipantsUserIds

04/06/2015      Tanay Gupta					Added fnToGetTheSubjectForNote
		
******************************************************************************************/


#include "LBT9_Change_Handler.h"

/**************************************************************************************
*	Function name	:	sendNote

*	Description		:	This Function is used for the send Note application in TC 

***************************************************************************************/

extern int sendNote	(void *returnValueType				/* <I> */
					)
{
	int retcode = ITK_ok;
	
	tag_t revTag = NULLTAG;
	tag_t logged_in_group_member_tag = NULLTAG;
	
	char *to_email_id = NULL;
	char *comments = NULL;
	char *isOriginatorSelected = NULL;
	char *isCCBSelected = NULL;
	char *isAnalystSelected = NULL;
	char recipient[64] = "";
	
	/* Get the revision tag */
	ITK(retcode,USERARG_get_tag_argument(&revTag));
	
	/* Get the group member tag of logged in user tag */
	ITK(retcode,USERARG_get_tag_argument(&logged_in_group_member_tag));
	
	/* Get the ; separated email id's */
	ITK(retcode,USERARG_get_string_argument(&to_email_id));
	
	/* Get the comments */
	ITK(retcode,USERARG_get_string_argument(&comments));
	
	/* Get if isOriginatorSelected or not*/
	ITK(retcode,USERARG_get_string_argument(&isOriginatorSelected));
	
	/* Get if isCCBSelected or not */
	ITK(retcode,USERARG_get_string_argument(&isCCBSelected));
	
	/* Get if isAnalystSelected or nor */
	ITK(retcode,USERARG_get_string_argument(&isAnalystSelected));
	
	if ( tc_strcmp(isOriginatorSelected, "Yes") == 0 )
	{
		if ( tc_strcmp(recipient,"") == 0 || recipient == NULL || tc_strlen(recipient) <= 0 )
		{
			tc_strcpy(recipient, "$PROCESS_OWNER");
		}
		else
		{
			tc_strcat(recipient, USERS_LIST_SEPERATOR);
			tc_strcat(recipient, "$PROCESS_OWNER");
		}
	}
	
	if ( tc_strcmp(isCCBSelected, "Yes") == 0 )
	{
		if ( tc_strcmp(recipient,"") == 0 || recipient == NULL || tc_strlen(recipient) <= 0 )
		{
			tc_strcpy(recipient, "$APPROVERS");
		}
		else
		{
			tc_strcat(recipient, USERS_LIST_SEPERATOR);
			tc_strcat(recipient, "$APPROVERS");
		}
	}
	
	if ( tc_strcmp(isAnalystSelected, "Yes") == 0 )
	{
		if ( tc_strcmp(recipient,"") == 0 || recipient == NULL || tc_strlen(recipient) <= 0 )
		{
			tc_strcpy(recipient, "$ANALYST");
		}
		else
		{
			tc_strcat(recipient, USERS_LIST_SEPERATOR);
			tc_strcat(recipient, "$ANALYST");
		}
	}
	printf("Recipient : %s\n", recipient);
	
	if ( revTag != NULLTAG )
	{
		tag_t itemTag = NULLTAG;
		//Get the Basic Info of Revision
		char *item_id = NULL;
		char *rev_id = NULL;
		char *object_type = NULL;
		ITK(retcode,ITEM_ask_item_of_rev(revTag, &itemTag));
		
		ITK(retcode,ITEM_ask_id2(itemTag, &item_id));
		
		ITK(retcode,ITEM_ask_rev_id2(revTag, &rev_id));

		ITK(retcode,WSOM_ask_object_type2(revTag,&object_type));
		
		TC_write_syslog("libWiproLiebert --- Change Item Revision : %s/%s\n", item_id, rev_id);
		
		int n_jobs = 0;
	
		tag_t *job_tags = NULL;
		char *email_subject = NULL;
		char *body_path = NULL;
	
		ITK(retcode,EPM_ask_active_job_for_target(revTag, &n_jobs, &job_tags));
	
		if ( n_jobs > 0 )
		{
			tag_t parent_root_task_tag = NULLTAG;
			
			
			char *to_users_list = NULL;
			
			ITK(retcode,EPM_ask_root_task(job_tags[0], &parent_root_task_tag));
			
			ITK(retcode,getParticipantsUserIds(recipient, revTag, parent_root_task_tag, &to_users_list));
			if(tc_strcmp(object_type,"LBT9_ECNRevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Engineering Change Noice",item_id,rev_id,&email_subject));
			}
			else if(tc_strcmp(object_type,"LBT9_DCNRevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Document Change Notice",item_id,rev_id,&email_subject));
			}
			else if(tc_strcmp(object_type,"LBT9_MCORevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Manufacturing Change Object",item_id,rev_id,&email_subject));
			}
			else if(tc_strcmp(object_type,"LBT9_ChgRequestRevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Change Request Revision",item_id,rev_id,&email_subject));
			}
			else if(tc_strcmp(object_type,"LBT9_DeviationRevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Deviation",item_id,rev_id,&email_subject));
			}
			else if(tc_strcmp(object_type,"LBT9_StopShipRevision") == 0)
			{
				ITK(retcode,fnToGetTheSubjectForNote("Stop Ship",item_id,rev_id,&email_subject));
			}
			EMR_free(object_type);
			ITK(retcode,generateNoteBodyAttachment(comments, &body_path));
			
			if ( to_users_list != NULL || to_email_id != NULL )
			{
				char *current_date_string = NULL;
				
				date_t current_date = NULLDATE;
				/* Send Note via Email*/
				ITK(retcode,LBT_send_note_email(to_email_id, NULL, email_subject, body_path));
				
				/* Create Notes Form and attach it to ECN Revision*/

				logical lPriv = false;
				ITK(retcode,AM_check_privilege(revTag, "WRITE", &lPriv));
				if(lPriv)
				{
					ITK(retcode,createNoteForm(revTag, logged_in_group_member_tag, to_users_list, to_email_id, comments));
				}
				else
				{
					//char * cItemId = NULL;
					//char * cRevId = NULL;
					//tag_t userTag= NULLTAG;
					//char * cUserId = NULL;
					//char * command = NULL;

					//char*cInString = NULL;
					//command =(char*) MEM_alloc(2048);
					//cInString =(char*) MEM_alloc(1024);
					//AOM_ask_value_string(revTag, "item_id", &cItemId);
					//AOM_ask_value_string(revTag, "item_revision_id", &cRevId);
					//
					//SA_ask_groupmember_user(logged_in_group_member_tag, &userTag);
					//SA_ask_user_identifier2(userTag, &cUserId);
					//if(cItemId != NULL && cRevId != NULL)
					//{
					//	tc_strcpy(cInString ,cItemId);
					//	tc_strcat(cInString , "|");
					//	tc_strcat(cInString ,cRevId);
					//	tc_strcat(cInString , "|");
					//	if(cUserId != NULL)
					//	tc_strcat(cInString , cUserId);
					//	tc_strcat(cInString , "|");
					//	if(to_users_list != NULL)
					//	tc_strcat(cInString , to_users_list);
					//	tc_strcat(cInString , "|");
					//	if(to_email_id != NULL)
					//	tc_strcat(cInString , to_email_id);
					//	tc_strcat(cInString , "|");
					//	if(comments != NULL)
					//	tc_strcat(cInString , comments);
			
					//}
					//char * cPrefVal = NULL;
					//PREF_set_search_scope(TC_preference_site);
					//PREF_ask_char_value("LBT_BUS_EXE_LOC",0,&cPrefVal );
					//printf("Prefernece value is %s \n",cPrefVal);

					//tc_strcpy(command ,cPrefVal);
					//tc_strcat(command , " sendNote");
					//tc_strcat(command , " ");
					//tc_strcat(command , "\"");
					//tc_strcat(command , cInString);
					//tc_strcat(command , "\"");

					//printf("command is %s \n", command);
					//if (system(command) != 0 )
					//{
					//	printf("System command Operation failed..!\n");
					//}
					//else
					//{
					//	printf("System command Operation Success..!\n");
					//}
					//EMR_free(command);
					//EMR_free(cInString);

					//sendNote using workflow handler

					int * Type= NULL;
					tag_t *tComp = NULL;
					tag_t userTag = NULLTAG;
					tag_t tForm = NULLTAG;

					char * cUserId = NULL;
					tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*2);
					Type = (int*) MEM_alloc(sizeof(int)*2);
					tComp[0] = revTag;
					SA_ask_groupmember_user(logged_in_group_member_tag, &userTag);
					SA_ask_user_identifier2(userTag, &cUserId);

					ITK(retcode,createNoteFormOptional(revTag, logged_in_group_member_tag, to_users_list, to_email_id, comments, &tForm));
					Type[0] =  EPM_target_attachment;
					Type[1] =  EPM_reference_attachment;
					tComp[1] = tForm;
		
		
					tag_t tProctemplate = NULLTAG;
					tag_t tProcess = NULLTAG;
					EPM_find_process_template("QuickReleaseNoStatus",&tProctemplate);

					char * temp = NULL;
					temp = (char*) MEM_alloc(240);

					tc_strcpy(temp , cUserId);
					tc_strcat(temp , "|");
					if(to_users_list != NULL)
					tc_strcat(temp , to_users_list);
					tc_strcat(temp , "|");
					if(to_email_id != NULL)
					tc_strcat(temp , to_email_id);
					tc_strcat(temp , "|");
					if(comments != NULL)
					tc_strcat(temp , comments);

					EPM_create_process("Test",temp,tProctemplate,2, tComp,Type,&tProcess);
				}
				
				EMR_free(current_date_string);
 		    }
			else
			{
				printf(" No Users are selected for ToList or No Email ID's are entered while sending note.\n");
			}
			
			EMR_free(email_subject);
			EMR_free(body_path);	
			EMR_free(to_users_list);
		}
		EMR_free(job_tags);
		EMR_free(item_id);
		EMR_free(rev_id);
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_send_note_email

*	Description		:	This Function is used to send the mail through send note

***************************************************************************************/

extern int LBT_send_note_email(char *to_users_list,    /* <I> */
							   char *email_id_list,    /* <I> */ 	
							   char *subject,          /* <I> */
							   char *bodypath          /* <I> */
							  )
{
	int retcode = ITK_ok;

	int piStringCount = 0;
	char **pppStringList = NULL;
	
	int ccUsersCount = 0;
	char **ccUsersList = NULL;

	char emailRecipients[SS_MAXLLEN] = "";
	char sendMailCmd[SS_MAXLLEN];

	/* Add to list*/
	ITK(retcode,EPM__parse_string(to_users_list,USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));

	for (int inx = 0; inx < piStringCount; inx++)
	{
		char *email_id = NULL;

		ITK(retcode,LBT_get_email_id(pppStringList[inx], &email_id));

		if ( email_id != NULL && tc_strlen(email_id) > 0 )
		{
			if ( tc_strcmp(emailRecipients, "") == 0 || tc_strlen(emailRecipients) == 0 )
			{
				tc_strcpy(emailRecipients," -to=");
                tc_strcat(emailRecipients,email_id);
			}
			else
			{
				tc_strcat(emailRecipients," -to=");
				tc_strcat(emailRecipients,email_id);
			}
		}
		EMR_free(email_id);
	}
	EMR_free(pppStringList);
	
	/* Add Email ID's list*/
	if ( email_id_list != NULL && tc_strlen(email_id_list) > 0 )
	{
		int n_emails = 0;
		
		char **email_values = NULL;
		
		printf("Email ID List :  %s\n", email_id_list);
		
		ITK(retcode,EPM__parse_string(email_id_list, USERS_LIST_SEPERATOR, &n_emails, &email_values));
		
		for (int inx = 0; inx < n_emails; inx++)
		{
			if ( email_values[inx] != NULL && tc_strlen(email_values[inx]) > 0 )
			{
				if ( tc_strcmp(emailRecipients, "") == 0 || tc_strlen(emailRecipients) == 0 )
				{
					tc_strcpy(emailRecipients," -to=");
					tc_strcat(emailRecipients, email_values[inx]);
				}
				else
				{
					tc_strcat(emailRecipients," -to=");
					tc_strcat(emailRecipients, email_values[inx]);
				}
			}
		}
		
		EMR_free(email_values);
	}

	if ( emailRecipients != NULL && tc_strlen(emailRecipients) > 0 )
	{
		char *so_subject = NULL;

		/* start constructing tc_mail_smtp command*/
		tc_strcpy(sendMailCmd, "tc_mail_smtp ");

        //value in emailRecipients will be something like " -to=username1@emerson.com -to=username2@emerson.com" 
        tc_strcat(sendMailCmd, emailRecipients ); 

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);

		//ITK(EPG2_get_email_subject(subject, subject_props, revTag, &so_subject));

        //Compose the subject of the Email here
        tc_strcat(sendMailCmd, " -subject=\"");
		tc_strcat(sendMailCmd, subject);
        tc_strcat(sendMailCmd, "\"");

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);
		
		tc_strcat(sendMailCmd, " -body=");
        tc_strcat(sendMailCmd, bodypath);

		printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);

		char *mail_server_name = NULL;
		char *mail_server_port = NULL;
		//Read the mail server details from the preferences.
		ITK(retcode,LBT_get_single_preference_value(PREF_MAIL_SERVER_NAME, &mail_server_name));

		ITK(retcode,LBT_get_single_preference_value(PREF_MAIL_SERVER_PORT, &mail_server_port));
        
        tc_strcat(sendMailCmd, " -server=");
        tc_strcat(sendMailCmd, mail_server_name);
        tc_strcat(sendMailCmd, " -port=");
        tc_strcat(sendMailCmd, mail_server_port);

        printf("sendMailCmd : <%s>\n", sendMailCmd);
		TC_write_syslog("libWiproLiebert --- sendMailCmd : <%s>\n", sendMailCmd);

		EMR_free(mail_server_name);
		EMR_free(mail_server_port);

        //printf("\nsendMailCmd=%s\n",sendMailCmd);
        if( system(sendMailCmd) != 0)
        {
            TC_write_syslog("libWiproLiebert --- Send Mail Failed. Command -->\n<%s>\n",sendMailCmd);
            return retcode;
        }
	}

	return retcode;
}



/**************************************************************************************
*	Function name	:	createNoteForm

*	Description		:	This Function is used to create note form 

***************************************************************************************/

int createNoteForm(tag_t rev_tag,                           /* <I> */              
				   tag_t logged_in_group_member_tag,        /* <I> */
                   char *to_users_list,                     /* <I> */
				   char *to_email_id,                       /* <I> */
				   char *comments                           /* <I> */
				  )
{
	int retcode = ITK_ok;
	
	char *current_date_string = NULL;
	
	date_t current_date = NULLDATE;
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	
	ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
	
	if ( logged_in_group_member_tag != NULLTAG )
	{
		int n_participants = 0;
	
		tag_t user_tag = NULLTAG;
		
		char * cStatusName	=	NULL;
		char * cECNId		=	NULL;
		char *assigned_by = NULL;
		char **participants_list = NULL;
		char *form_name = NULL;
		
		AOM_ask_value_string(rev_tag,"current_id",&cECNId);
		ITK(retcode,SA_ask_groupmember_user(logged_in_group_member_tag, &user_tag));
		
		ITK(retcode,SA_ask_user_identifier2(user_tag, &assigned_by));
		
		printf("To Users List : %s\n", to_users_list);
		printf("To Email ID List : %s\n", to_email_id);
		ITK(retcode,makePartcipantsList(to_users_list, to_email_id, &n_participants, &participants_list));
		
		/*form_name = (char *) MEM_alloc((tc_strlen("Notes_By_")+tc_strlen(assigned_by)+1)*sizeof(char));
		tc_strcpy(form_name, "Notes_By_");
		tc_strcat(form_name, assigned_by);*/
		
		form_name = (char *) MEM_alloc((tc_strlen(cECNId)+1)*sizeof(char));
		tc_strcpy(form_name,cECNId );
		/*  Create Form*/
		int istatusCount	=	0;
		char *cpTrimValue = "";
		tag_t formTag = NULLTAG;
		tag_t form_type_tag = NULLTAG;
		tag_t form_create_input_tag = NULLTAG;
		tag_t * tStatusTag		=		NULL;
		tag_t type_tag	=	NULL;
		ITK(retcode,FORM_create(form_name, "", CM_NOTE_FORM_TYPE, &formTag));
		ITK(retcode,TCTYPE_find_type(CM_NOTE_FORM_TYPE, NULL, &form_type_tag));
		
		ITK(retcode,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));
		
		AOM_ask_value_tags(rev_tag,"release_status_list",&istatusCount,&tStatusTag);
		AOM_ask_value_string(tStatusTag[0],"object_name",&cStatusName);
		
		if(tc_strstr(cStatusName,"LBT9_") != NULL)
		{
			string test = cStatusName;
			test.erase(0,5);
			
			cpTrimValue = (char *)alloca(test.size() + 1);
			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
			if(tc_strcmp(cpTrimValue,"CCB_For_Resume")==0)
			{
					cpTrimValue="CCB For Resume";
			}
			
				ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
		
		}
		else if(tc_strstr(cStatusName,"EMR_") != NULL)
		{
			string test = cStatusName;
			test.erase(0,4);
			cpTrimValue = (char *)alloca(test.size() + 1);
			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
			ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
		}
		else
		{
			ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status",cStatusName));
		}

		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", form_name));			
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_NoteInitiator", assigned_by));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Notes", comments));
		//ERROR_CHECK(AOM_set_value_strings(form_create_input_tag, "lbt9_NotifiedParticipants", n_participants, participants_list));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_NotifiedParticipants",to_email_id));
		ERROR_CHECK(AOM_set_value_date(form_create_input_tag, "lbt9_NoteCreatedDate", current_date));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Subject", cECNId));
		
		
		printf("Form Name    : %s\n", form_name);
		printf("Assigned By  : %s\n", assigned_by);
		
		ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
		
		ERROR_CHECK(AOM_save(formTag));
		
		ERROR_CHECK(AOM_save_with_extensions(formTag));
		
		/* Attach the form to the Revision with LBT9_ECN_Observers_Rel relation*/
		ITK(retcode,attachNotesFormToRevision(formTag, rev_tag));
		
		EMR_free(participants_list);
		EMR_free(assigned_by);
		EMR_free(cStatusName);
		
	}
	
	EMR_free(current_date_string);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	makePartcipantsList

*	Description		:	This Function consolidate list of User in one semi colon seperated list 

***************************************************************************************/


int makePartcipantsList(char *users_list,              /* <I> */
                        char *email_id_list,           /* <I> */
                        int *n_participants,           /* <O> */
                        char ***participants_list      /* <OF> */
                       )
{
	int retcode = ITK_ok;
	
	*n_participants = 0;
	*participants_list = NULL;
	
	if ( users_list != NULL && tc_strlen(users_list) > 0 )
	{
		int piStringCount = 0;
		char **pppStringList = NULL;

		/* Add to list*/
		ITK(retcode,EPM__parse_string(users_list, USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));
		
		for (int inx = 0; inx < piStringCount; inx++)
		{
			*participants_list = (char **) MEM_realloc(*participants_list, (*n_participants+1)*sizeof(char *));
			(*participants_list)[*n_participants] = pppStringList[inx];
			*n_participants = *n_participants + 1;
		}
		
		EMR_free(pppStringList);
	}
	
	if ( email_id_list != NULL && tc_strlen(email_id_list) > 0 )
	{
		int piStringCount = 0;
		char **pppStringList = NULL;

		/* Add to list*/
		ITK(retcode,EPM__parse_string(email_id_list, USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));
		
		for (int inx = 0; inx < piStringCount; inx++)
		{
			*participants_list = (char **) MEM_realloc(*participants_list, (*n_participants+1)*sizeof(char *));
			(*participants_list)[*n_participants] = pppStringList[inx];
			*n_participants = *n_participants + 1;
		}
		
		EMR_free(pppStringList);
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	attachNotesFormToRevision

*	Description		:	This Function is used to attach the note form to change object

***************************************************************************************/
int attachNotesFormToRevision(tag_t formTag,       /* <I> */
						      tag_t revTag         /* <I> */
						     )
{
	int retcode = ITK_ok;
	tag_t referenceRelation = NULLTAG;

	int iFail = ITK_ok;
	int iExistingFormCount = 0;
	tag_t *tAllFormTags = NULL;
	ITK(iFail,AOM_ask_value_tags(revTag,Attr_Note_Form,&iExistingFormCount,&tAllFormTags));
	ITK(iFail,AOM_refresh(revTag,TRUE));
	ITK(iFail,AOM_set_value_tag_at(revTag,Attr_Note_Form,iExistingFormCount,formTag));
	ITK(iFail,AOM_save(revTag));
	ITK(iFail,AOM_refresh(revTag,FALSE));
	
	EMR_free(tAllFormTags);
	return retcode;
}

/**************************************************************************************
*	Function name	:	attachNotesFormToRevision

*	Description		:	This Function is used to generate body for the mail sent through
						send note
			
***************************************************************************************/

int generateNoteBodyAttachment(char *commment,              /* <I> */
                               char **emailTemplatePath     /* <OF> */
						      )
{
	int retcode = ITK_ok;
	
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;
	
	tag_t ecn_rev_master_form = NULLTAG;
	
	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;

	ITK(retcode,LBT_get_single_preference_value(PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH, &email_template_path));

	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		tc_strcpy(bodypath, email_template_path);
		tc_strcat(bodypath,"\\LBT_note_notify_template.txt");
		
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);

		fp_email_body = fopen(bodypath, "w+");
		
		fprintf(fp_email_body,"%s\n\n", commment);
		
		fclose(fp_email_body);
	}
	else
	{
		printf("Preference %s is not defined. Please specify the Preference value\n", PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH);
		TC_write_syslog("libWiproLiebert --- Preference %s is not defined. Please specify the Preference value\n", PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH);
	}
	EMR_free(email_template_path);

	return retcode;
}

/**************************************************************************************
*	Function name	:	generateDefaultBodyAttachment

*	Description		:	This Function is used to generate default body for the mail in case 
						no body is provided
			
***************************************************************************************/

int generateDefaultBodyAttachment(tag_t rev_tag,               /* <I> */
                                  char *item_id,               /* <I> */
						          char *rev_id,                /* <I> */
						          char *process_owner_name,    /* <I> */
                                  char **emailTemplatePath     /* <OF> */
						         )
{
	int retcode = ITK_ok;
	
	char bodypath[SS_MAXLLEN];	
	char *email_template_path = NULL;
	
	tag_t ecn_rev_master_form = NULLTAG;
	
	FILE *fp_email_body = NULL;
	
	*emailTemplatePath = NULL;

	ITK(retcode,LBT_get_single_preference_value(PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH, &email_template_path));

	ITK(retcode,get_ecn_rev_master_form(rev_tag, &ecn_rev_master_form));
	
	if ( email_template_path != NULL || tc_strlen(email_template_path) > 0 )
	{
		tc_strcpy(bodypath, email_template_path);
		tc_strcat(bodypath,"\\LBT_Approver_Email_notify_template.txt");
		
		*emailTemplatePath = (char *) MEM_alloc((tc_strlen(bodypath)+1)*sizeof(char));
		tc_strcpy(*emailTemplatePath, bodypath);

		fp_email_body = fopen(bodypath, "w+");
		
		fprintf(fp_email_body,"ECN (Eng Chng Notice) %s has been submitted by %s for your review and routing.\n\n", item_id, process_owner_name);
		
		if ( ecn_rev_master_form != NULLTAG )
		{
			char *change_description = NULL;
			char *reason_for_change = NULL;
			
			ITK(retcode,AOM_ask_value_string(ecn_rev_master_form, "lbt9_Description", &change_description));
			ITK(retcode,AOM_ask_value_string(ecn_rev_master_form, "lbt9_Change_Reason", &reason_for_change));
			
			fprintf(fp_email_body,"Description of Change:\n");
			fprintf(fp_email_body, change_description);
			fprintf(fp_email_body, "\n\n");
			fprintf(fp_email_body,"Reason for Change:\n");
			fprintf(fp_email_body, reason_for_change);
			fprintf(fp_email_body, "\n\n");
			fprintf(fp_email_body, "Submitted by:%s\n", process_owner_name);
			
			EMR_free(change_description);
			EMR_free(reason_for_change);
		}
		
		fclose(fp_email_body);
		
	}
	else
	{
		printf("Preference %s is not defined. Please specify the Preference value\n", PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH);
		TC_write_syslog("libWiproLiebert --- Preference %s is not defined. Please specify the Preference value\n", PREF_LBT_APPROVER_EMAIL_TEMPLATE_PATH);
	}
	EMR_free(email_template_path);
	return retcode;
}


/**************************************************************************************
*	Function name	:	getParticipantsUserIds

*	Description		:	This Function is used to get the users from the Participant
			
***************************************************************************************/

int getParticipantsUserIds(char *recipient,       /* <I> */
						   tag_t rev_tag,         /* <I> */   
                           tag_t root_task,       /* <I> */						   
                           char **to_users_list   /* <OF> */
						  )
{
	int retcode = ITK_ok;
	
	*to_users_list = NULL;
	
	if ( tc_strcmp(recipient, "") == 0 || recipient == NULL || tc_strlen(recipient) <= 0)
	{
		tag_t group_member_tag = NULLTAG;
		tag_t rp_tag = NULLTAG;
		
		logical is_rp = false;
		
		ITK(retcode,EPM_get_participant("$PROCESS_OWNER", root_task, &group_member_tag, &rp_tag, &is_rp));
		
		if ( group_member_tag != NULLTAG )
		{
			tag_t user_tag = NULLTAG;
			
			char *user_id = NULL;
			
			ITK(retcode,SA_ask_groupmember_user(group_member_tag, &user_tag));
			
			ITK(retcode,SA_ask_user_identifier2(user_tag, &user_id));
			
			*to_users_list = (char *) MEM_alloc((tc_strlen(user_id)+1)*sizeof(char));
			tc_strcpy(*to_users_list, user_id);
			
			EMR_free(user_id);
		}
	}
	else
	{
		int recipientCount = 0;
		
		char **recipientsList = NULL;		
		char users_list[2048] = "";

		ITK(retcode,EPM__parse_string(recipient, USERS_LIST_SEPERATOR, &recipientCount, &recipientsList));
		
		for (int inx = 0; inx < recipientCount; inx++)
		{
			if ( tc_strcmp(recipientsList[inx], "$PROCESS_OWNER") == 0 || 
			     tc_strcmp(recipientsList[inx], "$ANALYST") == 0 || 
				 tc_strcmp(recipientsList[inx], "$PROPOSED_RESPONSIBLE_PARTY") == 0 )
			{
				tag_t group_member_tag = NULLTAG;
				tag_t rp_tag = NULLTAG;
				
				logical is_rp = false;
				
				std::vector<tag_t> Vuser;
				if ( tc_strcmp(recipientsList[inx], "$PROCESS_OWNER") == 0 )
				{
					tag_t  tOriginatorTag	= NULLTAG;
					tag_t * Originator		= NULL;
					char * cOriginatorName	=	NULL;
					int iOriginatorcount	=	0;
					fnGetParticipantUsersList(rev_tag,"Requestor",Vuser);
					if(Vuser[0] != NULLTAG)
					{
					/*ITK(retcode,EPM_get_participanttype("Requestor",&tOriginatorTag));
					ITK(retcode,ITEM_rev_ask_participants(rev_tag,tOriginatorTag,&iOriginatorcount,&Originator));
					ITK(retcode,SA_ask_user_person_name2(Originator[0], &cOriginatorName));*/
					SA_ask_user_identifier2(Vuser[0],&cOriginatorName);
					tc_strcpy(users_list, cOriginatorName);
					tc_strcat(users_list, USERS_LIST_SEPERATOR);
					}
							
				}
				if ( tc_strcmp(recipientsList[inx], "$ANALYST") == 0 )
				{
				    tag_t tChangeAnalystTag = NULLTAG;
				    tag_t * Analyst			= NULL;
					char * cAnalystName		=	NULL;
					int  iAnalystcount		=	0;
					fnGetParticipantUsersList(rev_tag,"LBT9_ChangeAnalyst",Vuser);
					if(Vuser[0] != NULLTAG)
					{
					SA_ask_user_identifier2(Vuser[0],&cAnalystName);
					tc_strcpy(users_list, cAnalystName);
					tc_strcat(users_list, USERS_LIST_SEPERATOR);
					}
				}
				//ITK(retcode,EPM_get_participant(recipientsList[inx], root_task, &group_member_tag, &rp_tag, &is_rp));
				
				/*if ( group_member_tag != NULLTAG )
				{
					tag_t user_tag = NULLTAG;
					
					char *user_id = NULL;
					
					ITK(retcode,SA_ask_groupmember_user(group_member_tag, &user_tag));
					
					ITK(retcode,SA_ask_user_identifier2(user_tag, &user_id));
					
					if ( tc_strcmp(users_list, "") == 0 || users_list == NULL || tc_strlen(users_list) <= 0 )
					{
						tc_strcpy(users_list, user_id);
					}
					else
					{
						if ( tc_strstr(users_list, user_id) == NULL )
						{
							tc_strcat(users_list, USERS_LIST_SEPERATOR);
							tc_strcat(users_list, user_id);
						}
					}
					
					EMR_free(user_id);
				}*/
			}
			else if ( tc_strcmp(recipientsList[inx], "$APPROVERS") == 0 )
			{
				int n_approval_forms = 0;
				tag_t *approval_form_tags = NULL;
				
				ITK(retcode,LBT_getActiveApprovalForms(rev_tag, &n_approval_forms, &approval_form_tags));
				
				for (int jnx = 0; jnx < n_approval_forms; jnx++)
				{
					char *user_id = NULL;
					
					ITK(retcode,AOM_ask_value_string(approval_form_tags[jnx], "lbt9_ApproverUserID", &user_id));
					
					if ( tc_strcmp(users_list, "") == 0 || users_list == NULL || tc_strlen(users_list) <= 0)
					{
						tc_strcpy(users_list, user_id);
					}
					else
					{
						if ( tc_strstr(users_list, user_id) == NULL )
						{
							tc_strcat(users_list, USERS_LIST_SEPERATOR);
							tc_strcat(users_list, user_id);
						}
					}
					EMR_free(user_id);
				}
				EMR_free(approval_form_tags);
			}
			else if ( tc_strcmp(recipientsList[inx], "$OBSERVERS") == 0 )
			{
				int n_observers = 0;
				char **observers_list = NULL;
				
				ITK(retcode,AOM_ask_value_strings(rev_tag, "lbt9_Observers", &n_observers, &observers_list));
				
				for (int knx = 0; knx < n_observers; knx++)
				{
					int valueCount = 0;
					char **valueList = NULL;
					
					ITK(retcode,EPM__parse_string(observers_list[knx], "/", &valueCount, &valueList));
					
					if ( valueCount > 0 )
					{
						if ( tc_strcmp(users_list, "") == 0 || users_list == NULL || tc_strlen(users_list) <= 0)
						{
							tc_strcpy(users_list, valueList[2]);
						}
						else
						{
							if ( tc_strstr(users_list, valueList[2]) == NULL )
							{
								tc_strcat(users_list, USERS_LIST_SEPERATOR);
								tc_strcat(users_list, valueList[2]);
							}
						}
					}
					EMR_free(valueList);
				}
				EMR_free(observers_list);
			}
		}
		EMR_free(recipientsList);
		
		if ( users_list != NULL && tc_strlen(users_list) > 0 )
		{
			*to_users_list = (char *) MEM_alloc((tc_strlen(users_list)+1)*sizeof(char));
			tc_strcpy(*to_users_list, users_list);
		}
	}
	
	return retcode;
}


/**************************************************************************************
*	Function name	:	fnToGetTheSubjectForNote

*	Description		:	This function will provide generic subject for the send note for all 
						the workflows
			
***************************************************************************************/

int fnToGetTheSubjectForNote(const char * ObjectType,		/* <I> */
							 char *item_id,					/* <I> */
							 char *rev_id,					/* <I> */
							 char **email_subject			/* <OF> */
							)
{
	int iFail = ITK_ok;
	*email_subject = NULL;
	*email_subject = (char *) MEM_alloc((tc_strlen("A Note has been posted for ")+ tc_strlen(ObjectType) + tc_strlen(item_id) + tc_strlen(rev_id)+3)*sizeof(char));
	tc_strcpy(*email_subject, "A Note has been posted for ");
	tc_strcat(*email_subject,ObjectType);
	tc_strcat(*email_subject," ");
	tc_strcat(*email_subject, item_id);
	tc_strcat(*email_subject, "/");
	tc_strcat(*email_subject, rev_id);
	return ITK_ok;
}
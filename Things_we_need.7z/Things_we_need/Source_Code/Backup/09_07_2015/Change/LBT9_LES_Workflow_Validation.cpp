	
/******************************************************************************************

File			:	LBRT_LES_Workflow_Validation.cpp

Description		:	Workflow action handlers for Libert

Author			:	Tanay Gupta

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Tanay Gupta				 		Inital version

01/06/2015		Tanay Gupta			            Added LBT9_VALIDATE_ECN
					
******************************************************************************************/
#include "LBT9_Change_Handler.h"




/****************************************************************************************************
*	Handler name	:	LBT9_VALIDATE_LES_WORKFLOW

*	Description		:	Rule Handler - For the validation of Preliminary ECN workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_VALIDATE_LES_WORKFLOW(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	int iTargetAttchmnts = 0;
	tag_t tCurrentGrpMembrTag = NULLTAG;
	tag_t tRootTask = NULLTAG;
	tag_t *pTargetAttchmnts = NULL;
	tag_t tUserTag = NULLTAG;
	char *UserId = NULL;
	char *RoleName = NULL;
	char *cpAnalystId = NULL;
	char *ObjectShortName =  NULL;
	EPM_decision_t decision = EPM_nogo;
	logical validation = false;
	logical allValidationCompleted = false;
	logical valid_object = false;
	//Getting current user and role of the login user
	ITK(iFail,SA_ask_current_groupmember(&tCurrentGrpMembrTag));
	if(tCurrentGrpMembrTag != NULLTAG)
	{
		tag_t tRoleTag = NULLTAG;
		ITK(iFail,SA_ask_groupmember_user(tCurrentGrpMembrTag,&tUserTag));
		if(tUserTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tUserTag,&UserId));
		}
		ITK(iFail,SA_ask_groupmember_role(tCurrentGrpMembrTag,&tRoleTag));
		if(tRoleTag != NULLTAG)
		{
			ITK(iFail,SA_ask_role_name2(tRoleTag,&RoleName));
		}
	}
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTargetAttchmnts,&pTargetAttchmnts));
	}
	if(pTargetAttchmnts != NULL && iTargetAttchmnts > 0)
	{
		char *cpObjectType				= NULL;
		//Validation for the Selected object either it should be ECN (having ERP Status as "Transger to ERP")or MCO for rest it should throw error message 
		ITK(iFail,fnToGetShortObjectNameForChangeObject(pTargetAttchmnts[0],&ObjectShortName));
		ITK(iFail,AOM_ask_value_string(pTargetAttchmnts[0],"lbt9_Change_Analyst",&cpAnalystId));
		ITK(iFail,WSOM_ask_object_type2(pTargetAttchmnts[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_ECNRevision") == 0)
		{
			char *cpERPStatus =NULL;
			ITK(iFail,AOM_ask_value_string(pTargetAttchmnts[0],"lbt9_ERP_Status",&cpERPStatus));
			if(cpERPStatus != NULL && tc_strcmp(cpERPStatus,"Transfer To ERP") == 0)
			{
				valid_object = true;
				EMR_free(cpERPStatus);
			}
		}
		else if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_MCORevision") == 0)
		{
			valid_object = true;
		}
		EMR_free(cpObjectType);
	}
	if(valid_object)
	{
		if(cpAnalystId != NULL)
		{
			//Only assigned Change Analyst and Database Change Analyst can perform the workflow validation
			if(RoleName != NULL && tc_strcmp(RoleName,"Database Change Analyst") == 0)
			{
				validation = true;
				EMR_free(RoleName);
			}
			if(UserId != NULL && tc_strcmp(UserId,cpAnalystId) == 0)
			{
				validation = true;
				EMR_free(UserId);
			}
			EMR_free(cpAnalystId);
		}
	}
	else if(!valid_object)
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT_INVALID_OBJECT_TYPE,"");
		decision = EPM_nogo;
		return decision;
	}	
	if(validation)
	{	//Only for Released status of ECN you can apply the LES flat file geneation workflow
		if(pTargetAttchmnts != NULL)
		{
			int iStatusCount = 0;
			tag_t *tStatusTags = NULL;
			ITK(iFail,AOM_ask_value_tags(pTargetAttchmnts[0],"release_status_list",&iStatusCount,&tStatusTags));
			if(tStatusTags != NULL && iStatusCount > 0)
			{
				char *cpStatusName = NULL;
				ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));
				if(cpStatusName != NULL && tc_strcmp(cpStatusName,RELEASE_STATUS) == 0)
				{
					allValidationCompleted =	true;
				}
				else
				{
					allValidationCompleted = false;
				}
				EMR_free(cpStatusName);
				EMR_free(tStatusTags);
			}
			EMR_free(pTargetAttchmnts);
		}
		if(allValidationCompleted)
		{
			decision = EPM_go;
		}
		else if(!allValidationCompleted)
		{
			EMH_clear_errors();
			EMH_store_initial_error_s1(EMH_severity_user_error, LBT_ECN_IS_NOT_RELEASED,ObjectShortName);
			decision = EPM_nogo;
			return decision;
		}
	}
	else if(!validation)
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT_USER_IS_NOT_AUTHORIZED,ObjectShortName);
		decision = EPM_nogo;
	}
	EMR_free(ObjectShortName);
	return decision;
}

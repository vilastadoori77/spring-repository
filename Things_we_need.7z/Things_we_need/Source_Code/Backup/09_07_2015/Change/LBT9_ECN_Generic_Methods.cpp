/******************************************************************************************

File			:	LBRT_ECN_Generic_Methods.cpp

Description		:	Functions for Workflow action handlers 

Author			:  Krupakar Reddy G

Date created	:   10/05/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added LBT_get_ecn_revision

01/06/2015		Krupkar Reddy G             Added LBT_get_related_objects

02/06/2015		Krupkar Reddy G             Added hasStatusReleased

02/06/2015		Krupkar Reddy G             Added hasStatusInactive

03/06/2015		Krupkar Reddy G             Added hasStatus

03/06/2015		Krupkar Reddy G             Added LBT_get_latest_released_revision

04/06/2015		Krupkar Reddy G 			Added LBT_get_obsolete_children

04/06/2015		Krupkar Reddy G				Added LBT_get_inactive_children

04/06/2015		Krupkar Reddy G 			Added LBT_getCommaSeparatedListOfItemRevs

04/06/2015		Krupkar Reddy G				Added LBT_getCommaSeparatedListOfItemRevsObsolete

04/06/2015		Krupkar Reddy G 			Added LBT_get_unreleased_children

04/06/2015		Krupkar Reddy G				Added LBT_checkif_unreleased_revs_exist_in_solutions

04/06/2015		Krupkar Reddy G 			Added LBT_Is_Solution_Items_Status_Preliminary_or_Prototype

04/06/2015		Krupkar Reddy G				Added Check_status_for_each_solution_object

04/06/2015		Krupkar Reddy G 			Added LBT_get_released_solution_items

04/06/2015		Krupkar Reddy G				Added LBT_get_lower_rev_solution_items

04/06/2015		Krupkar Reddy G				Added LBT_has_release_status

04/06/2015		Krupkar Reddy G				Added LBT_get_other_ecn_related_solution_items

04/06/2015		Krupkar Reddy G				Added fnGetDatasets

04/06/2015		Krupkar Reddy G				Added fnSetStatusOnDatasets

******************************************************************************************/
#include "LBT9_Change_Handler.h"

/**************************************************************************************
*	Function name	:	LBT_get_ecn_revision

*	Description		:	This Function is used to get the revision of the change object

***************************************************************************************/

extern int LBT_get_ecn_revision(tag_t task,           /* <I> */
								char *className,      /* <I> */
								int attachment_type,  /* <I> */
                                tag_t *object         /* <O> */
                               )
{
    int retcode = ITK_ok;
    int count = 0;

    tag_t *attachments = NULL;

	*object = NULLTAG;

    ITK(retcode,EPM_ask_attachments(task, attachment_type, &count, &attachments));

    for(int inx = 0; inx < count; inx++)
    {
        char *classname = NULL;
        tag_t class_id = NULLTAG;

        ITK(retcode,POM_class_of_instance(attachments[inx],&class_id));

        ITK(retcode,POM_name_of_class(class_id,&classname));

		printf("Target Object's Class Name : %s\n", classname);

        if( classname != NULL && tc_strcmp(classname, className) == 0 )
        {
            *object = attachments[inx];
            break;
        }
        EMR_free( classname );
    }
    EMR_free( attachments );
	
    return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_related_objects

*	Description		:	This Function is used to get all related object attached to the change object

***************************************************************************************/

int LBT_get_related_objects(tag_t rev_tag,               /* <I> */
                            char *relation,              /* <I> */
                            int *n_solution_revs,        /* <O> */
						    tag_t **solution_rev_tags    /* <OF> */
						   )
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	*n_solution_revs = 0;
	*solution_rev_tags = NULL;
	
	ITK(retcode,GRM_find_relation_type(relation, &relation_type_tag));
	
	if ( relation_type_tag != NULLTAG )
	{
		int secCount = 0;
		tag_t *secObjects = NULL;
		
		ITK(retcode,GRM_list_secondary_objects_only(rev_tag, relation_type_tag, &secCount, &secObjects));
		
		for (int inx = 0; inx < secCount; inx++)
		{
			*solution_rev_tags = (tag_t *) MEM_realloc(*solution_rev_tags,(*n_solution_revs+1)*sizeof(tag_t));
            (*solution_rev_tags)[*n_solution_revs] = secObjects[inx];
            *n_solution_revs = *n_solution_revs + 1;
		}
		
		EMR_free(secObjects);
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	hasStatusReleased

*	Description		:	This Function is used to know whether the object is released or not

***************************************************************************************/


int hasStatusReleased(	tag_t objectTag,       /* <I> */
						char *statusName,      /* <I> */
						logical *flag          /* <O> */
					 )
{
	int retcode = ITK_ok;
	int statusCount = 0;
	
	tag_t *statusObjects = NULL;
	
	*flag = false;
		
	ITK(retcode,AOM_ask_value_tags(objectTag, "release_status_list", &statusCount, &statusObjects));
	
	if ( statusCount == 0 )
	{
		return retcode;
	}
	
	for (int inx = 0; inx < statusCount; inx++)
	{
		char *name = NULL;
		
		ITK(retcode,AOM_ask_value_string(statusObjects[inx], "name", &name));
		
		printf("has Status? child status %s, required status %s\n", name, statusName);
		
		if (tc_strcmp(name,"LBT9_Inactive") == 0 || tc_strcmp(name,OBSOLETE_STATUS) == 0 || tc_strcmp(name,RELEASE_STATUS) == 0)
		{
			*flag = true;
			break;
		}
		
		EMR_free(name);
	}
	
	EMR_free(statusObjects);
	
	return retcode;
}	


/**************************************************************************************
*	Function name	:	hasStatusInactive

*	Description		:	This Function is used to know whether the object is Inactive or not

***************************************************************************************/


int hasStatusInactive(	tag_t objectTag,       /* <I> */
						char *statusName,      /* <I> */
						logical *flag          /* <O> */
					 )
{
	int retcode = ITK_ok;
	int statusCount = 0;
	
	tag_t *statusObjects = NULL;
	
	*flag = false;
		
	ITK(retcode,AOM_ask_value_tags(objectTag, "release_status_list", &statusCount, &statusObjects));
	
	if ( statusCount == 0 )
	{
		return retcode;
	}
	
	for (int inx = 0; inx < statusCount; inx++)
	{
		char *name = NULL;
		
		ITK(retcode,AOM_ask_value_string(statusObjects[inx], "name", &name));
		
		printf("has Status? child status %s, required status %s\n", name, statusName);
		
		if (tc_strcmp(name,"LBT9_Inactive") == 0)
		{
			*flag = true;
			break;
		}
		
		EMR_free(name);
	}
	
	EMR_free(statusObjects);
	
	return retcode;
}	


/**************************************************************************************
*	Function name	:	hasStatus

*	Description		:	This Function is used to know whether the object is Obsolete or not

***************************************************************************************/

int hasStatus(tag_t objectTag,       /* <I> */
              char *statusName,      /* <I> */
              logical *flag          /* <O> */
             )
{
	int retcode = ITK_ok;
	int statusCount = 0;
	
	tag_t *statusObjects = NULL;
	
	*flag = false;
		
	ITK(retcode,AOM_ask_value_tags(objectTag, "release_status_list", &statusCount, &statusObjects));
	
	if ( statusCount == 0 )
	{
		return retcode;
	}
	
	for (int inx = 0; inx < statusCount; inx++)
	{
		char *name = NULL;
		
		ITK(retcode,AOM_ask_value_string(statusObjects[inx], "name", &name));
		
		printf("has Status? child status %s, required status %s\n", name, statusName);
		
		if ( tc_strcmp(name,"Obsolete") == 0)
		{
			*flag = true;
			break;
		}
		
		EMR_free(name);
	}
	
	EMR_free(statusObjects);
	
	return retcode;
}			 


/**************************************************************************************
*	Function name	:	LBT_get_latest_released_revision

*	Description		:	This Function is used to get the latest released revision of the item

***************************************************************************************/


extern int LBT_get_latest_released_revision(tag_t item_tag,   /* <I> */
											tag_t *rev_tag    /* <O> */
										   )
{
	int retcode = ITK_ok;
	int rev_count = 0;
	int n_released_revs = 0;

	tag_t latest_released_revision = NULLTAG;
	tag_t *revisions = NULL;
	*rev_tag = NULLTAG;

	ERROR_CHECK(ITEM_list_all_revs(item_tag, &rev_count, &revisions));

    for (int inx = 0; inx < rev_count; inx++)
    {
		int is_released = 0;

        ERROR_CHECK(CR_ask_if_released(revisions[inx], &is_released));

        if (is_released)
        {
            n_released_revs++;
            if ( n_released_revs == 1 )
            {
                latest_released_revision = revisions[inx];
            }
            else
            {
				int answer = 0;
				date_t latest_date = NULLDATE;
				date_t compare_date = NULLDATE;

				ERROR_CHECK(AOM_ask_value_date(latest_released_revision, "date_released", &latest_date));

                ERROR_CHECK(AOM_ask_value_date(revisions[inx], "date_released", &compare_date));

                ERROR_CHECK(POM_compare_dates(latest_date, compare_date, &answer));

                if ( answer == -1 )
				{
					latest_released_revision = revisions[inx];
				}
            }
        }
    }
	if ( n_released_revs > 0 )
    {
        *rev_tag = latest_released_revision;
    }
	EMR_free(revisions);

	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_obsolete_children

*	Description		:	This Function is used to get the obsolete children in BOM of the Item

***************************************************************************************/

int LBT_get_obsolete_children(tag_t revTag,                 /* <I> */
                              tag_t bvrTag,                 /* <I> */
							  int *n_obsolete_child,        /* <O> */
                              tag_t **obsolete_childrens    /* <OF> */
                             )
{
	int retcode = ITK_ok;
	int n_child_lines = 0;
	
	tag_t bom_window = NULLTAG;
	tag_t top_bom_line = NULLTAG;
	tag_t *child_line_tags = NULL;
	
	*n_obsolete_child = 0;
	*obsolete_childrens = NULL;
	
	ITK(retcode,BOM_create_window(&bom_window));
	
	ITK(retcode,BOM_set_window_top_line_bvr(bom_window, bvrTag, &top_bom_line));
	
	ITK(retcode,BOM_line_ask_child_lines(top_bom_line, &n_child_lines, &child_line_tags));
	
	if ( n_child_lines > 0 )
	{
		int rev_tag_attr;
		int item_id_attr;
		int item_rev_id_attr;
		int item_tag_attr;
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemRevTag, &rev_tag_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemId, &item_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemRevId, &item_rev_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemTag, &item_tag_attr));
		
		for (int inx = 0; inx < n_child_lines; inx++)
		{
			tag_t child_rev_tag = NULLTAG;
			
			logical isObsolete = false;
			
			ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], rev_tag_attr, &child_rev_tag));
			
			if ( child_rev_tag != NULLTAG )
			{
				ITK(retcode,hasStatus(child_rev_tag, OBSOLETE_STATUS, &isObsolete));
			
				if ( isObsolete )
				{
					*obsolete_childrens = (tag_t *) MEM_realloc(*obsolete_childrens,(*n_obsolete_child+1)*sizeof(tag_t));
					(*obsolete_childrens)[*n_obsolete_child] = child_rev_tag;
					*n_obsolete_child = *n_obsolete_child + 1;
				}
			}
			else
			{
				tag_t child_item_tag = NULLTAG;
				
				char *child_item_id = NULL;
				
				printf("Found Item in BOM Line\n");
				
				ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], item_tag_attr, &child_item_tag));
				
				ITK(retcode,BOM_line_ask_attribute_string(child_line_tags[inx], item_id_attr, &child_item_id));
				
				printf("Found Child Item ID : %s", child_item_id);
				
				if ( child_item_tag != NULLTAG )
				{
					tag_t latest_rev_of_child_item = NULLTAG;
					
					ITK(retcode,LBT_get_latest_released_revision(child_item_tag, &latest_rev_of_child_item));
					
					if ( latest_rev_of_child_item == NULLTAG )
					{
						ITK(retcode,ITEM_ask_latest_rev(child_item_tag, &latest_rev_of_child_item));
						
						if ( latest_rev_of_child_item != NULLTAG )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Child Item has no released status:  %s/%s\n", child_item_id, child_item_rev_id);
							
							EMR_free(child_item_rev_id);
						}
					}
					else
					{
						/* Check if it is released to Production */						
						ITK(retcode,hasStatus(latest_rev_of_child_item, OBSOLETE_STATUS, &isObsolete));
						
						if ( isObsolete )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Obsolete Child Item :  %s/%s\n", child_item_id, child_item_rev_id);
							
							*obsolete_childrens = (tag_t *) MEM_realloc(*obsolete_childrens,(*n_obsolete_child+1)*sizeof(tag_t));
							(*obsolete_childrens)[*n_obsolete_child] = latest_rev_of_child_item;
							*n_obsolete_child = *n_obsolete_child + 1;
							
							EMR_free(child_item_rev_id);
						}
					}
				}
				
				EMR_free(child_item_id);
			}
		}
		
	}
	ITK(retcode,BOM_close_window(bom_window));
	
	EMR_free(child_line_tags);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_inactive_children

*	Description		:	This Function is used to get the inactive children in BOM of the Item

***************************************************************************************/


int LBT_get_inactive_children(tag_t revTag,                 /* <I> */
                              tag_t bvrTag,                 /* <I> */
							  int *n_inactive_child,        /* <O> */
                              tag_t **inactive_childrens    /* <OF> */
                             )
{
	int retcode = ITK_ok;
	int n_child_lines = 0;
	
	tag_t bom_window = NULLTAG;
	tag_t top_bom_line = NULLTAG;
	tag_t *child_line_tags = NULL;
	
	*n_inactive_child = 0;
	*inactive_childrens = NULL;
	
	ITK(retcode,BOM_create_window(&bom_window));
	
	ITK(retcode,BOM_set_window_top_line_bvr(bom_window, bvrTag, &top_bom_line));
	
	ITK(retcode,BOM_line_ask_child_lines(top_bom_line, &n_child_lines, &child_line_tags));
	
	if ( n_child_lines > 0 )
	{
		int rev_tag_attr;
		int item_id_attr;
		int item_rev_id_attr;
		int item_tag_attr;
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemRevTag, &rev_tag_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemId, &item_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemRevId, &item_rev_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemTag, &item_tag_attr));
		
		for (int inx = 0; inx < n_child_lines; inx++)
		{
			tag_t child_rev_tag = NULLTAG;
			
			logical isInactive = false;
			
			ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], rev_tag_attr, &child_rev_tag));
			
			if ( child_rev_tag != NULLTAG )
			{
				ITK(retcode,hasStatusInactive(child_rev_tag, INACTIVE_STATUS, &isInactive));
			
				if ( isInactive )
				{
					*inactive_childrens = (tag_t *) MEM_realloc(*inactive_childrens,(*n_inactive_child+1)*sizeof(tag_t));
					(*inactive_childrens)[*n_inactive_child] = child_rev_tag;
					*n_inactive_child = *n_inactive_child + 1;
				}
			}
			else
			{
				tag_t child_item_tag = NULLTAG;
				
				char *child_item_id = NULL;
				
				printf("Found Item in BOM Line\n");
				
				ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], item_tag_attr, &child_item_tag));
				
				ITK(retcode,BOM_line_ask_attribute_string(child_line_tags[inx], item_id_attr, &child_item_id));
				
				printf("Found Child Item ID : %s", child_item_id);
				
				if ( child_item_tag != NULLTAG )
				{
					tag_t latest_rev_of_child_item = NULLTAG;
					
					ITK(retcode,LBT_get_latest_released_revision(child_item_tag, &latest_rev_of_child_item));
					
					if ( latest_rev_of_child_item == NULLTAG )
					{
						ITK(retcode,ITEM_ask_latest_rev(child_item_tag, &latest_rev_of_child_item));
						
						if ( latest_rev_of_child_item != NULLTAG )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Child Item has no released status:  %s/%s\n", child_item_id, child_item_rev_id);
							
							EMR_free(child_item_rev_id);
						}
					}
					else
					{
						/* Check if it is released to Production */						
						ITK(retcode,hasStatusInactive(child_rev_tag, INACTIVE_STATUS, &isInactive));
			
						if ( isInactive )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Inactive Child Item :  %s/%s\n", child_item_id, child_item_rev_id);
							
							*inactive_childrens = (tag_t *) MEM_realloc(*inactive_childrens,(*n_inactive_child+1)*sizeof(tag_t));
							(*inactive_childrens)[*n_inactive_child] = latest_rev_of_child_item;
							*n_inactive_child = *n_inactive_child + 1;
							
							EMR_free(child_item_rev_id);
						}
					}
				}
				
				EMR_free(child_item_id);
			}
		}
		
	}
	ITK(retcode,BOM_close_window(bom_window));
	
	EMR_free(child_line_tags);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_getCommaSeparatedListOfItemRevs

*	Description		:	This Function is used to get the comma seperated list of item revision

***************************************************************************************/

int LBT_getCommaSeparatedListOfItemRevs(int revCount,      /* <I> */
                                        tag_t *revTags,    /* <I> */
										char **revs_list   /* <OF> */
									   )
{
	int retcode = ITK_ok;
	
	*revs_list = NULL;
	
	char temp[SS_MAXLLEN] = "";
	
	if ( revCount > 5 )
	{
		for (int inx = 0; inx < revCount; inx++)
		{
			char *ecn_number = NULL;
			char *ecn_rev = NULL;
			
			tag_t itemTag = NULLTAG; 
			
			ITK(retcode,ITEM_ask_item_of_rev(revTags[inx], &itemTag));
			
			ITK(retcode,ITEM_ask_id2(itemTag, &ecn_number));
			
			ITK(retcode,ITEM_ask_rev_id2(revTags[inx], &ecn_rev));
			
			if (tc_strcmp(temp,"") <= 0 )
			{
				tc_strcpy(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			else
			{
				tc_strcat(temp, ",");
				tc_strcat(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			EMR_free(ecn_number);
			EMR_free(ecn_rev);
		}
	}
	else
	{
		for (int inx = 0; inx < revCount; inx++)
		{
			char *ecn_number = NULL;
			char *ecn_rev = NULL;
			
			tag_t itemTag = NULLTAG; 
			
			ITK(retcode,ITEM_ask_item_of_rev(revTags[inx], &itemTag));
			
			ITK(retcode,ITEM_ask_id2(itemTag, &ecn_number));
			
			ITK(retcode,ITEM_ask_rev_id2(revTags[inx], &ecn_rev));
			
			if (tc_strcmp(temp,"") <= 0 )
			{
				tc_strcpy(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			else
			{
				tc_strcat(temp, ",");
				tc_strcat(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			
			EMR_free(ecn_number);
			EMR_free(ecn_rev);
		}
	}
	*revs_list = (char *) MEM_alloc((tc_strlen(temp)+1)*sizeof(char));
	tc_strcpy(*revs_list, temp);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_getCommaSeparatedListOfItemRevsObsolete

*	Description		:	This Function is used to get the comma seperated list of item revision 
						for obsolete part

***************************************************************************************/

int LBT_getCommaSeparatedListOfItemRevsObsolete(tag_t revTag,    /* <I> */
										char **revs_list   /* <OF> */
									   )
{
	int retcode = ITK_ok;
	
	*revs_list = NULL;
	
	char temp[SS_MAXLLEN] = "";
	

			char *ecn_number = NULL;
			char *ecn_rev = NULL;
			
			tag_t itemTag = NULLTAG; 
			
			ITK(retcode,ITEM_ask_item_of_rev(revTag, &itemTag));
			
			ITK(retcode,ITEM_ask_id2(itemTag, &ecn_number));
			
			ITK(retcode,ITEM_ask_rev_id2(revTag, &ecn_rev));
			
			if (tc_strcmp(temp,"") <= 0 )
			{
				tc_strcpy(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			else
			{
				tc_strcat(temp, ";");
				tc_strcat(temp, ecn_number);
				tc_strcat(temp, "/");
				tc_strcat(temp, ecn_rev);
			}
			
			EMR_free(ecn_number);
			EMR_free(ecn_rev);
		
	
	*revs_list = (char *) MEM_alloc((tc_strlen(temp)+1)*sizeof(char));
	tc_strcpy(*revs_list, temp);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_unreleased_children

*	Description		:	This Function is used to get the unrelesed children from the parent item

***************************************************************************************/

int LBT_get_unreleased_children(tag_t revTag,                 /* <I> */
                                tag_t bvrTag,                 /* <I> */
								int *n_unreleased_child,      /* <O> */
                                tag_t **unrelased_child_tags  /* <OF> */
                               )
{
	int retcode = ITK_ok;
	int n_child_lines = 0;
	
	tag_t bom_window = NULLTAG;
	tag_t top_bom_line = NULLTAG;
	tag_t *child_line_tags = NULL;
	
	*n_unreleased_child = 0;
	*unrelased_child_tags = NULL;
	
	ITK(retcode,BOM_create_window(&bom_window));
	
	ITK(retcode,BOM_set_window_top_line_bvr(bom_window, bvrTag, &top_bom_line));
	
	ITK(retcode,BOM_line_ask_child_lines(top_bom_line, &n_child_lines, &child_line_tags));
	
	if ( n_child_lines > 0 )
	{
		int rev_tag_attr;
		int item_id_attr;
		int item_rev_id_attr;
		int item_tag_attr;
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemRevTag, &rev_tag_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemId, &item_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_itemRevId, &item_rev_id_attr));
		
		ITK(retcode,BOM_line_look_up_attribute(bomAttr_lineItemTag, &item_tag_attr));
		
		for (int inx = 0; inx < n_child_lines; inx++)
		{
			tag_t child_rev_tag = NULLTAG;
			
			logical isReleased = false;
			
			ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], rev_tag_attr, &child_rev_tag));
			
			if( child_rev_tag != NULLTAG )
			{
				ITK(retcode,hasStatusReleased(child_rev_tag, RELEASE_STATUS, &isReleased));
			
				if ( !isReleased )
				{
					tag_t item_tag = NULLTAG;
					
					char *item_id = NULL;
					char *rev_id = NULL;
					
					ITK(retcode,ITEM_ask_item_of_rev(child_rev_tag, &item_tag));
					
					ITK(retcode,ITEM_ask_id2(item_tag, &item_id));
					
					ITK(retcode,ITEM_ask_rev_id2(child_rev_tag, &rev_id));
					
					printf("Unrelased Child Item :  %s/%s\n", item_id, rev_id);
					
					*unrelased_child_tags = (tag_t *) MEM_realloc(*unrelased_child_tags,(*n_unreleased_child+1)*sizeof(tag_t));
					(*unrelased_child_tags)[*n_unreleased_child] = child_rev_tag;
					*n_unreleased_child = *n_unreleased_child + 1;
					
					EMR_free(item_id);
					EMR_free(rev_id);
				}
			}
			else
			{
				tag_t child_item_tag = NULLTAG;
				
				char *child_item_id = NULL;
				
				printf("Found Item in BOM Line\n");
				
				ITK(retcode,BOM_line_ask_attribute_tag(child_line_tags[inx], item_tag_attr, &child_item_tag));
				
				ITK(retcode,BOM_line_ask_attribute_string(child_line_tags[inx], item_id_attr, &child_item_id));
				
				printf("Found Child Item ID : %s", child_item_id);
				
				if ( child_item_tag != NULLTAG )
				{
					tag_t latest_rev_of_child_item = NULLTAG;
					
					ITK(retcode,LBT_get_latest_released_revision(child_item_tag, &latest_rev_of_child_item));
					
					if ( latest_rev_of_child_item == NULLTAG )
					{
						ITK(retcode,ITEM_ask_latest_rev(child_item_tag, &latest_rev_of_child_item));
						
						if ( latest_rev_of_child_item != NULLTAG )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Unrelased Child Item :  %s/%s\n", child_item_id, child_item_rev_id);
							
							*unrelased_child_tags = (tag_t *) MEM_realloc(*unrelased_child_tags,(*n_unreleased_child+1)*sizeof(tag_t));
							(*unrelased_child_tags)[*n_unreleased_child] = latest_rev_of_child_item;
							*n_unreleased_child = *n_unreleased_child + 1;
							
							EMR_free(child_item_rev_id);
						}
					}
					else
					{
						/* Check if it is released to Production */						
						ITK(retcode,hasStatusReleased(latest_rev_of_child_item, RELEASE_STATUS, &isReleased));
						
						if ( !isReleased )
						{
							char *child_item_rev_id = NULL;
						
							ITK(retcode,ITEM_ask_rev_id2(latest_rev_of_child_item, &child_item_rev_id));
							
							printf("Unrelased Child Item :  %s/%s\n", child_item_id, child_item_rev_id);
							
							*unrelased_child_tags = (tag_t *) MEM_realloc(*unrelased_child_tags,(*n_unreleased_child+1)*sizeof(tag_t));
							(*unrelased_child_tags)[*n_unreleased_child] = latest_rev_of_child_item;
							*n_unreleased_child = *n_unreleased_child + 1;
							
							EMR_free(child_item_rev_id);
						}
					}
				}
				
				EMR_free(child_item_id);
			}
		}
		
	}
	ITK(retcode,BOM_close_window(bom_window));
	
	EMR_free(child_line_tags);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_checkif_unreleased_revs_exist_in_solutions

*	Description		:	This Function is used to get the unrelesed revision exist in the solution item

***************************************************************************************/

int LBT_checkif_unreleased_revs_exist_in_solutions(int n_solution_revs,                           /* <I> */ 
                                                   tag_t *solution_rev_tags,                      /* <I> */
												   int n_unreleased_child,                        /* <I> */
												   tag_t *unreleased_child_tags,                  /* <I> */
												   int *n_child_not_in_solutions,                 /* <O> */
												   tag_t **child_not_in_solutions                 /* <OF> */
												  )
{
	int retcode = ITK_ok;
	
	for (int inx = 0; inx < n_unreleased_child; inx++)
	{
		logical flag = false;
		
		for (int jnx  = 0; jnx < n_solution_revs; jnx++)
		{
			if ( unreleased_child_tags[inx] == solution_rev_tags[jnx] )
			{
				flag = true;
				break;
			}
		}
		
		if ( !flag )
		{
			*child_not_in_solutions = (tag_t *) MEM_realloc(*child_not_in_solutions,(*n_child_not_in_solutions+1)*sizeof(tag_t));
			(*child_not_in_solutions)[*n_child_not_in_solutions] = unreleased_child_tags[inx];
			*n_child_not_in_solutions = *n_child_not_in_solutions + 1;
		}
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_Is_Solution_Items_Status_Preliminary_or_Prototype

*	Description		:	This Function is used to check the status of related object is preliminary or not

***************************************************************************************/

int LBT_Is_Solution_Items_Status_Preliminary_or_Prototype(int n_sol_revs,			   /* <I> */
														  tag_t *sol_rev_tags,         /* <I> */
														  int *n_released_revs,        /* <I> */ 
														  tag_t **released_rev_tags,    /* <I> */ 
														  logical *SolutionItemStatus  /*<O>*/
														 )
{
	int retcode = ITK_ok; 
	*n_released_revs = 0;
	*released_rev_tags = NULL;

	for (int i = 0; i < n_sol_revs; i++)
	{
		
		logical EachSolutionItemStatus = false;
		Check_status_for_each_solution_object(sol_rev_tags[i],&EachSolutionItemStatus);
		if (EachSolutionItemStatus)
		{
			*SolutionItemStatus = true;
			*released_rev_tags = (tag_t *) MEM_realloc(*released_rev_tags,(*n_released_revs+1)*sizeof(tag_t));
			(*released_rev_tags)[*n_released_revs] = sol_rev_tags[i];
			*n_released_revs = *n_released_revs + 1;
			//break;
		}
	}

	return retcode;
}

/**************************************************************************************
*	Function name	:	Check_status_for_each_solution_object

*	Description		:	This Function is used to check the status of related object 

***************************************************************************************/

int Check_status_for_each_solution_object(tag_t tSolutiontag,				/* <I> */
										  logical *EachSolutionItemStatus	/*<O>*/
										  )
{
	int retcode = ITK_ok;
	int istatusCount = 0;
	tag_t *tstatusTags = NULL;
	ITK(retcode,AOM_ask_value_tags(tSolutiontag, STATUS_LIST, &istatusCount, &tstatusTags));
	for (int inx = 0; inx < istatusCount; inx++)
	{
		char *cpStatusName = NULL;
		ITK(retcode,AOM_ask_value_string(tstatusTags[inx],OBJECT_NAME,&cpStatusName));

		if (tc_strlen(cpStatusName) > 0 && cpStatusName != NULL)
		{
			if (tc_strcmp(cpStatusName,PRELIMINARY) == 0 || tc_strcmp(cpStatusName,PROTOTYPE) == 0)
			{
				*EachSolutionItemStatus = false;
			}
			else
			{
				*EachSolutionItemStatus = true;
				break;
			}
		}
	}

	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_released_solution_items

*	Description		:	This Function is used to get released solution item

***************************************************************************************/

int LBT_get_released_solution_items(int n_sol_revs,              /* <I> */
                                    tag_t *sol_rev_tags,         /* <I> */
									int *n_released_revs,        /* <I> */ 
									tag_t **released_rev_tags    /* <I> */ 
                                   )
{
	int retcode = ITK_ok;
	
	*n_released_revs = 0;
	*released_rev_tags = NULL;
	
	for (int inx = 0; inx < n_sol_revs; inx++)
	{
		int statusCount = 0;
		
		tag_t *statusTags = NULL;
		
		ITK(retcode,AOM_ask_value_tags(sol_rev_tags[inx], "release_status_list", &statusCount, &statusTags));
		
		if ( statusCount > 0 )
		{
			*released_rev_tags = (tag_t *) MEM_realloc(*released_rev_tags,(*n_released_revs+1)*sizeof(tag_t));
			(*released_rev_tags)[*n_released_revs] = sol_rev_tags[inx];
			*n_released_revs = *n_released_revs + 1;
		}
		
		EMR_free(statusTags);
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_has_release_status

*	Description		:	This Function is check the status of the object whether it is released or not

***************************************************************************************/

int LBT_has_release_status(tag_t object,              /* <I> */
                           logical *statusFlag        /* <O> */
                          )
{
    int retcode = ITK_ok;
	int statusCount = 0;

    tag_t *statusList = NULL;

    *statusFlag = false;
	
	ITK(retcode,WSOM_ask_release_status_list(object,&statusCount,&statusList));

	if (statusCount > 0)
	{
		*statusFlag = true;
	}

	EMR_free( statusList );
    return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_get_lower_rev_solution_items

*	Description		:	This Function is check whether the solution item is having
						lower revisions  in preliminary status or not

***************************************************************************************/


int LBT_get_lower_rev_solution_items	(int n_solution_revs,             /* <I> */
										 tag_t *solution_rev_tags,        /* <I> */
										 int *n_hi_sol_revs,              /* <O> */
										 tag_t **hi_sol_rev_tags          /* <OF> */
										)
{
	int retcode = ITK_ok;
	
	*n_hi_sol_revs = 0;
	*hi_sol_rev_tags = NULL;
	logical PRisHavingPrelimnStatus = false;
	for (int inx = 0; inx < n_solution_revs; inx++)
	{
		tag_t item_tag = NULLTAG;
		tag_t latest_rev_tag = NULLTAG;
		PRisHavingPrelimnStatus = false;
		ITK(retcode,ITEM_ask_item_of_rev(solution_rev_tags[inx], &item_tag));
		
		ITK(retcode,ITEM_ask_latest_rev(item_tag, &latest_rev_tag));
		
		if ( solution_rev_tags[inx] == latest_rev_tag )
		{
			int revCount = 0;
			
			tag_t *revTags = NULL;
			
			ITK(retcode,ITEM_list_all_revs(item_tag, &revCount, &revTags));
			
			for (int jnx = 0; jnx < revCount; jnx++)
			{
				if ( revTags[jnx] != latest_rev_tag )
				{
					logical hasStatus = false;
					
					ITK(retcode,LBT_has_release_status(revTags[jnx], &hasStatus));
					
					if ( !hasStatus )
					{
						*hi_sol_rev_tags = (tag_t *) MEM_realloc(*hi_sol_rev_tags,(*n_hi_sol_revs+1)*sizeof(tag_t));
						(*hi_sol_rev_tags)[*n_hi_sol_revs] = solution_rev_tags[inx];
						*n_hi_sol_revs = *n_hi_sol_revs + 1;
					}
					else if ( hasStatus )
					{
						int statusCount = 0;
						
						tag_t *statusObjects = NULL;
						
						ITK(retcode,AOM_ask_value_tags(revTags[jnx], "release_status_list", &statusCount, &statusObjects));
						
						if(PRisHavingPrelimnStatus)
						{
							break;
						}
						for (int znx = 0; znx < statusCount; znx++)
						{
							char *release_status_name = NULL;
							
							ITK(retcode,AOM_ask_value_string(statusObjects[znx], "name", &release_status_name));
							
							if ( tc_strcmp(PRELIMINARY, release_status_name) == 0 )
							{
								*hi_sol_rev_tags = (tag_t *) MEM_realloc(*hi_sol_rev_tags,(*n_hi_sol_revs+1)*sizeof(tag_t));
								(*hi_sol_rev_tags)[*n_hi_sol_revs] = solution_rev_tags[inx];
								*n_hi_sol_revs = *n_hi_sol_revs + 1;
								PRisHavingPrelimnStatus = true;
							}
							
							MEM_free(release_status_name);
						}
						
						MEM_free(statusObjects);
					}
				}
			}
			MEM_free(revTags);
		}
	}
	return retcode;
}

/**************************************************************************************
*	Function name	:	fnGetDatasets

*	Description		:	This Function is used to get datasets of solution item

***************************************************************************************/

int fnGetDatasets(tag_t tSolutionItemTag,    /*< I >*/
				  char * cpStatus			/*< I >*/
				 )
{
	int iFail		=	ITK_ok;
	int iAttchCount	=	0;
	tag_t tAttchRelTypeTag	=	NULLTAG;
	tag_t tSpecRelTypeTag	=	NULLTAG;
	tag_t tRefRelTypeTag	=	NULLTAG;
	tag_t * tAttachObjects	=	NULL;
	ITK(iFail,GRM_find_relation_type("TC_Attaches",&tAttchRelTypeTag));
	if(tAttchRelTypeTag != NULLTAG)
	{
		ITK(iFail,fnSetStatusOnDatasets(tSolutionItemTag,tAttchRelTypeTag,cpStatus));
	}

	ITK(iFail,GRM_find_relation_type("IMAN_specification",&tSpecRelTypeTag));
	if(tSpecRelTypeTag != NULLTAG)
	{
		ITK(iFail,fnSetStatusOnDatasets(tSolutionItemTag,tSpecRelTypeTag,cpStatus));
	}

	ITK(iFail,GRM_find_relation_type("IMAN_reference",&tRefRelTypeTag));
	if(tRefRelTypeTag != NULLTAG)
	{
		ITK(iFail,fnSetStatusOnDatasets(tSolutionItemTag,tRefRelTypeTag,cpStatus));
	}
	return iFail;
}

/**************************************************************************************
*	Function name	:	fnSetStatusOnDatasets

*	Description		:	This Function is used to set status on datasets of solution item

***************************************************************************************/

int fnSetStatusOnDatasets(tag_t tSolutionItemTag,    /*< I >*/
						  tag_t tRelTypeTag,		/*< I >*/
						  char * cpStatus			/*< I >*/
						 )
{
	int iFail			=	ITK_ok;
	int iDatasetCount	=	0;	
	tag_t *tDatasetObjTags	=	NULL;

	ITK(iFail,GRM_list_secondary_objects_only(tSolutionItemTag,tRelTypeTag,&iDatasetCount,&tDatasetObjTags));
		if(iDatasetCount>0 && tDatasetObjTags != NULL)
		{
			
			if(cpStatus != NULL && tc_strcmp(cpStatus,"Released")==0)
			{
				tag_t tReleaseTag	=	NULLTAG;
				ITK(iFail,RELSTAT_create_release_status("EMR_Released",&tReleaseTag));
				if(tReleaseTag != NULLTAG)
				{
					ITK(iFail,RELSTAT_add_release_status(tReleaseTag,iDatasetCount,tDatasetObjTags,TRUE));
				}
				
			}
			else if(cpStatus != NULL && tc_strcmp(cpStatus,"Obsolete")==0)
			{
				tag_t tObsoleteTag	=	NULLTAG;
				ITK(iFail,RELSTAT_create_release_status("Obsolete",&tObsoleteTag));
				if(tObsoleteTag != NULLTAG)
				{
					ITK(iFail,RELSTAT_add_release_status(tObsoleteTag,iDatasetCount,tDatasetObjTags,TRUE));
				}
				
			}
			else if(cpStatus != NULL && tc_strcmp(cpStatus,"Inactive")==0)
			{
				tag_t tInactiveTag	=	NULLTAG;
				ITK(iFail,RELSTAT_create_release_status("LBT9_Inactive",&tInactiveTag));
				if(tInactiveTag != NULLTAG)
				{
					ITK(iFail,RELSTAT_add_release_status(tInactiveTag,iDatasetCount,tDatasetObjTags,TRUE));
				}
				
			}

			EMR_free(tDatasetObjTags);
		}

	return iFail;
}
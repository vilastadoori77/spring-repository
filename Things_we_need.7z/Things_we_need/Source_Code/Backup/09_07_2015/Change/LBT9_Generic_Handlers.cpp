	
/******************************************************************************************

File			:	LBT9_Generic_Handlers.cpp

Description		:	Workflow action handlers for Libert

Author			:	Krupakar Reddy G

Date created	:   10/05/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added LBT9_SET_VALUES_ON_CHANGE_OBJECT

02/06/2015		Krupkar Reddy G             Added LBT9_ASSIGN_TASK_TO_CA

02/06/2015		Krupkar Reddy G             Added LBT9_ASSIGN_ROUTING_TASK_TO_CA

03/06/2015		Krupkar Reddy G             Added LBT9_CREATE_CCB_SUBPROCESS

03/06/2015		Krupkar Reddy G             Added LBT9_Proposed_Reviewers

03/06/2015		Krupkar Reddy G             Added LBT9_Set_Iteration_Property

03/06/2015		Krupkar Reddy G             Added LBT9_COMPLETE_ROUTING_TASK

03/06/2015		Krupkar Reddy G             Added LBT9_Change_Analyst_validation

03/06/2015		Krupkar Reddy G             Added LBT9_COMPLETE_CONDITION_TASK

03/06/2015		Krupkar Reddy G             Added LBT9_Set_Approval_Comments

03/06/2015		Krupkar Reddy G             Added LBT9_ASSIGN_PARTCIPANT

03/06/2015		Tanay Gupta					Added LBT9_LES_FILE_IMPLEMENTED

06/07/2015		Tanay Gupta					Added LBT9_DATABASE_CA_TASK_ASSIGN

28/07/2015		VenuBabu Avala				Added LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM

******************************************************************************************/
#include "LBT9_Change_Handler.h"


using namespace std;

/**********************************************************************************************************************
*	Handler name	:	LBT9_SET_VALUES_ON_CHANGE_OBJECT

*	Description		:	Action Handler - For Cosolidating the Product lines and Plants Values of Solution Items of ECN
                        and Setting on the ECN When the ECN status is changed to Submitted  
												

***********************************************************************************************************************/


extern int LBT9_SET_VALUES_ON_CHANGE_OBJECT(EPM_action_message_t msg)	
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=	0;
	int i								=	0;
	int j								=	0;
	int m								=	0;
	int k								=	0;
	int n								=	0;
	int x								=	0;
	int y								=	0;
	int inx								=	0;
	int iFormCount						=	0;
	int flag							=	0;
	int iTagCount						=	0;
	int iECNPlantCount					=	0;
	int iECNProductLineCount			=	0;
	tag_t *tStatusTags					=	0;
	tag_t  tRootTask					=	NULLTAG;
	tag_t* ptTargetAttmnts				=	NULL;
	tag_t tRelationTag					=	NULLTAG;
	tag_t *tFormTag						=	NULL;
	char *cpType1						=	NULL;
	char *cpPlantValue					=	NULL;
	char **cpECNPlantValue				=	NULL;
	char **cpProductLineValue			=	NULL;
	char **cpECNProductLineValue		=	NULL;
	int iCommclPartProductLineCount		=	0;
	std::vector<char*> VPlant;
	std::vector<char*> VProductLine;

	VPlant.clear();
	VProductLine.clear();
	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	if(iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
	
		ITK(iFail,AOM_ask_value_strings(ptTargetAttmnts[0],ECN_PLANTS_AFFECTED,&iECNPlantCount,&cpECNPlantValue));
		ITK(iFail,AOM_ask_value_strings(ptTargetAttmnts[0],ECN_PRODUCT_LINES,&iECNProductLineCount,&cpECNProductLineValue));
			
		if(iECNPlantCount > 0 && cpECNPlantValue != NULL) 
		{
			for(m; m < iECNPlantCount; m++)
			{
				VPlant.push_back(cpECNPlantValue[m]);
			}
		}
		if(iECNProductLineCount > 0 && cpECNProductLineValue != NULL)
		{
			for(n; n < iECNProductLineCount; n++)
			{
				VProductLine.push_back(cpECNProductLineValue[n]);
			}
		}
		int iAttchItemCount = 0;
		tag_t *tAttchItemTag = NULL;
		char *cpObjectType = NULL;
		ITK(iFail, WSOM_ask_object_type2(ptTargetAttmnts[0],&cpObjectType));
		if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_ECNRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_DCNRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_MCORevision") == 0))
		{
			ITK(iFail, LBT_get_related_objects(ptTargetAttmnts[0],SOLUTION_ITEMS_RELATION, &iAttchItemCount, &tAttchItemTag));
			EMR_free(cpObjectType);
		}
		if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_DeviationRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_StopShipRevision") == 0))
		{
			ITK(iFail,LBT_get_related_objects(ptTargetAttmnts[0],IMPACTED_ITEMS_RELATION, &iAttchItemCount, &tAttchItemTag));
			EMR_free(cpObjectType);
		}
		if(iAttchItemCount > 0 && tAttchItemTag != NULL)
		{
			for(int i = 0; i < iAttchItemCount; i++)
			{
				flag = 0;
			
				ITK(iFail,AOM_ask_value_string(tAttchItemTag[i],COMMERCIAL_PART_PLANTS,&cpPlantValue));
				ITK(iFail,AOM_ask_value_strings(tAttchItemTag[i],COMMERCIAL_PRODUCT_LINES,&iCommclPartProductLineCount,&cpProductLineValue));
					
				printf("Vplant size <%d> && VproductLine size <%d>\n",VPlant.size(),VProductLine.size());
				if( VPlant.size() == 0)
				{
					VPlant.push_back(cpPlantValue);
				}
				if(VProductLine.size() == 0)
				{
					for(int jnx = 0; jnx < iCommclPartProductLineCount;jnx++)
					{
						VProductLine.push_back(cpProductLineValue[jnx]);
					}
				}
				if(cpProductLineValue != NULL && cpPlantValue != NULL && VPlant.size() > 0 && VProductLine.size() > 0)
				{
					for(int j = 0; j < VPlant.size(); j++)
					{
						if(tc_strcmp(cpPlantValue,VPlant[j]) == 0)
						{
							flag = 1;
							break;
						}
					}
					if( flag != 1)
					{
						VPlant.push_back(cpPlantValue);
						printf("we are inside VPlant if loop\n");
						printf("VPlant size <%d>\n",VPlant.size());

					}
					flag = 0;
					for(inx = 0; inx < iCommclPartProductLineCount ; inx++)
					{
						for(int k = 0; k < VProductLine.size(); k++)
						{
						
							if(tc_strcmp(cpProductLineValue[inx],VProductLine[k]) == 0)
							{
								flag = 1;
								break;
							}
						}
						if( flag != 1)
						{
							VProductLine.push_back(cpProductLineValue[inx]);
							printf("we are inside VProductLine if loop\n");
							printf("VProductLine size <%d>\n",VProductLine.size());
						}
					}
				}
			}	
		}
		if(VPlant.size() > 0 && VProductLine.size() > 0)
		{
			ITK(iFail,AOM_refresh(ptTargetAttmnts[0],TRUE));
			for(x = 0; x < VPlant.size(); x++)
			{
				ITK(iFail,AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Plants_Affected",x,VPlant[x]));
			}
			for(y = 0; y < VProductLine.size(); y++)
			{
				ITK(iFail,AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Product_Lines",y,VProductLine[y]));
			}
			ITK(iFail,AOM_save(ptTargetAttmnts[0]));
			ITK(iFail,AOM_refresh(ptTargetAttmnts[0],FALSE));
		}
		
		EMR_free(cpPlantValue);	
		ITK(iFail,LBT9_MEM_free_Strings(cpProductLineValue,iCommclPartProductLineCount));
		ITK(iFail,LBT9_MEM_free_Strings(cpECNPlantValue,iECNPlantCount));
		ITK(iFail,LBT9_MEM_free_Strings(cpECNProductLineValue,iECNProductLineCount));
		EMR_free(ptTargetAttmnts);
	}
	return ITK_ok;
}


/*******************************************************************************************
*	Handler name	:	LBT9_ASSIGN_TASK_TO_CA

*	Description		:	Action Handler - For Assigning	Review task to Change Analyst

*******************************************************************************************/

 extern int LBT9_ASSIGN_TASK_TO_CA(EPM_action_message_t msg)
{
	int iFail							=	ITK_ok;

	int iTrgtAtchmnts					=	0;
	int iMembers						=	0;
	tag_t tRootTask						=	NULLTAG;
	tag_t* trevs						=   NULL;
	char *cpTaskName					=	NULL;
	char *cpChangeAnalyst				=	NULL;
	tag_t tUserTag						=	NULLTAG;
	tag_t* ptTargetAttmnts				=	NULL;
	tag_t UserDefaultGroup				=	NULLTAG;
	tag_t *tMembers						=	NULLTAG;
	int iCount							=	0;
	int irev							=	0;
	tag_t *tSignoffs					=	NULLTAG;
//	int iParentJobcount					=	0;
//	tag_t *tParentJobTags				=	NULL;


	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	}
	if(ptTargetAttmnts != NULL)
	{
		ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpChangeAnalyst));
		if(cpChangeAnalyst != NULL)
		{
			ITK(iFail, SA_find_user2(cpChangeAnalyst,&tUserTag));
		}
		
	}
	SA_ask_user_login_group(tUserTag,&UserDefaultGroup);
	

	ITK(iFail,EPM_ask_reviewers(msg.task,&irev,&trevs));
		

	if(tUserTag != NULLTAG && UserDefaultGroup != NULLTAG)
	{
		ITK(iFail, SA_find_groupmembers(tUserTag,UserDefaultGroup,&iMembers,&tMembers));
		if(iMembers > 0)
		{
			logical is_duplicate = false;
			for( int i=0; i<irev; i++)
			{

				if(trevs[i] == tMembers[0])
				{
					is_duplicate = true;
				}

			}
			if(!is_duplicate)
			{
				ITK(iFail, EPM_create_adhoc_signoff (msg.task,tMembers[0],&iCount,&tSignoffs));
				ITK(iFail, EPM_set_adhoc_signoff_selection_done(msg.task,true));
			}
		}
		
		//}
		
	
	}

	EMR_free(cpChangeAnalyst);
	EMR_free(ptTargetAttmnts);
	EMR_free(tMembers);
	EMR_free(tSignoffs);

	return iFail;
}

 
/*******************************************************************************************
*	Handler name	:	LBT9_ASSIGN_ROUTING_TASK_TO_CA

*	Description		:	Action Handler - For Assigning	Routing  Task to Change Analyst

*******************************************************************************************/

 extern int LBT9_ASSIGN_ROUTING_TASK_TO_CA(EPM_action_message_t msg)
{
	int iFail							=	ITK_ok;

	int iTrgtAtchmnts					=	0;
	int iMembers						=	0;
	tag_t tRootTask						=	NULLTAG;
	char *cpTaskName					=	NULL;
	char *cpChangeAnalyst				=	NULL;
	tag_t tUserTag						=	NULLTAG;
	tag_t* ptTargetAttmnts				=	NULL;
	tag_t UserDefaultGroup				=	NULLTAG;
	tag_t *tMembers						=	NULLTAG;
	int iCount							=	0;
	tag_t *tSignoffs					=	NULLTAG;
//	int iParentJobcount					=	0;
//	tag_t *tParentJobTags				=	NULL;


	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	}
	if(ptTargetAttmnts != NULL)
	{
		ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpChangeAnalyst));
		if(cpChangeAnalyst != NULL)
		{
			ITK(iFail, SA_find_user2(cpChangeAnalyst,&tUserTag));
		}
	}
	if(tUserTag != NULLTAG)
	{
		EPM_assign_responsible_party(msg.task,tUserTag);
	}

	EMR_free(ptTargetAttmnts);
	EMR_free(cpChangeAnalyst);
	
	return iFail;
}

 
/****************************************************************************************************
*	Handler name	:	LBT9_CHANGE_HISTORY

*	Description		:	Action Handler - For Creating  a Form on Change Object When Status is changed

******************************************************************************************************/

extern int LBT9_CHANGE_HISTORY(EPM_action_message_t message)
{
	int retcode		   =	ITK_ok;
	int number_of_args =	0;
	int iTrgtAtchmnts  =	0;

	char *subject = NULL;
	char *subject_props = NULL;
	char *review_task_name = NULL;
	char *attach_type = NULL;
	char *cpFormName = NULL;
	char *wfuser = NULL;
	char *process_owner_name = NULL;
	//char *task_type = NULL;
	
	tag_t root_task = NULLTAG;
	tag_t rev_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t job_tag = NULLTAG;
	tag_t tFormTag = NULLTAG;

	tag_t* ptTargetAttmnts				=	NULL;
	
	
	ITK(retcode,EPM_ask_root_task(message.task, &root_task));

	ITK(retcode,EPM_ask_job(root_task, &job_tag))
	tag_t tGrpMemberTag = NULLTAG;
	ITK(retcode,SA_ask_current_groupmember(&tGrpMemberTag));
	if(tGrpMemberTag != NULLTAG)
	{
		ITK(retcode,SA_ask_groupmember_user(tGrpMemberTag,&user_tag));
		if(user_tag != NULLTAG)
		{
			char *cpUserId = NULL;
			ITK(retcode,SA_ask_user_identifier2(user_tag,&cpUserId));
			EMR_free(cpUserId);
		}
	}	
	number_of_args = IMAN_number_of_arguments(message.arguments);

    if ( number_of_args == 0 && retcode == ITK_ok )
    {
        retcode = EPM_successful_with_warnings ;
        EMH_store_error_s1( EMH_severity_warning,retcode,"Wrong no of arguments"); 
        return retcode;
    }
    for ( int indx = 0; (indx < number_of_args && retcode == ITK_ok); indx++ )
    {
        char *flag = NULL;
        char *value = NULL;

        ITK(retcode,ITK_ask_argument_named_value( IMAN_next_argument(message.arguments), &flag, &value )); 

        if ( retcode == ITK_ok ) 
        {
           	
			if (tc_strcasecmp(flag, "attach_type") == 0)
			{
				if ( value != NULL )
                {
                    attach_type = (char*) MEM_alloc(( tc_strlen(value) + 1)* sizeof(char));
                    tc_strcpy(attach_type, value);
                }
			}
			else if (tc_strcasecmp(flag, "status") == 0)
			{
				if ( value != NULL )
                {
                    cpFormName = (char*) MEM_alloc(( tc_strlen(value) + 1)* sizeof(char));
                    tc_strcpy(cpFormName, value);
                }
			}
            else
            {
                retcode = EPM_invalid_argument;
                EMH_store_error( EMH_severity_warning, retcode );
				return retcode;
            }
        }
        if( flag != NULL )
            EMR_free( flag );
        if( value != NULL )
            EMR_free( value );
    }

	if( tc_strlen(cpFormName) > 0 && cpFormName != NULL)
	{
		ITK(retcode, FORM_create(cpFormName,"",CM_SIGNOFF_FORM_TYPE,&tFormTag));
	}
	if( tc_strlen(attach_type) > 0 && tc_strcmp(attach_type,"TARGET") == 0)
	{
		if( tFormTag != NULLTAG )
		{			
			ITK(retcode,fnSetFormValues(tFormTag,user_tag,cpFormName));
		}

		//ITK(retcode,LBT_get_ecn_revision(root_task, CLASS_ECN_REVISION, EPM_target_attachment, &rev_tag));
		ITK(retcode,EPM_ask_attachments(root_task,EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
		if(ptTargetAttmnts != NULL)
		{
			ITK(retcode, attachFormToRevision(tFormTag,ptTargetAttmnts[0],Attr_SIGNOFF_HISTORY));
		}
	}

	EMR_free(wfuser);
	EMR_free(cpFormName);
	EMR_free(ptTargetAttmnts);
	
	return ITK_ok;
}


/****************************************************************************************************
*	Handler name	:	LBT9_CREATE_CCB_SUBPROCESS

*	Description		:	Action Handler - For initiating a subprocess for Reviewers when the Status of 
						change object is CCB
************************************************************** ****************************************/

extern int LBT9_CREATE_CCB_SUBPROCESS(EPM_action_message_t message)
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=   0;
	int iParentJobcount					=   0;
	int iArgumentsCount					=	0;
	tag_t tRootTask						= NULLTAG;	
	tag_t *ptTargetAttmnts				= NULL;
	tag_t *tParentJobTags				= NULL;
	char *cpAddressList					= NULL;
	int iAddressListUserCount           = 0;
	tag_t *tAddressListUserTags			= NULL;
	int iECNPlantsCount					= 0;
	char **cpECNPlantsValue				= NULL;
	/*std::vector<tag_t> Vuser;
	Vuser.clear();*/
	int iCCBReviewersCount = 0;
	tag_t *tCCBUsers = NULL;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if (tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	}

	if (iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		ITK(iFail,EPM_ask_active_job_for_target( ptTargetAttmnts[0],&iParentJobcount,&tParentJobTags));
	}
	
	//Get current user tag
	tag_t tCurrentGroupmember = NULLTAG;
	tag_t tCurrentUserTag = NULLTAG;
	char *cploginUserID = NULL;
	SA_ask_current_groupmember(&tCurrentGroupmember);
	if (tCurrentGroupmember != NULLTAG)
	{
		ITK(iFail,SA_ask_groupmember_user(tCurrentGroupmember, &tCurrentUserTag));

		if (tCurrentUserTag != NULLTAG)
		{
			SA_ask_user_identifier2(tCurrentUserTag,&cploginUserID);
		}
	}
	
	//Get Change Analyst usertag
	int iChangeAnalystUserCount = 0;
	tag_t *tChangeAnalystUserTags = NULL;
	ITK(iFail,fnGetParticipantUsersList1(ptTargetAttmnts[0],CHANGE_ANALYST,&iChangeAnalystUserCount,&tChangeAnalystUserTags));

	//Initiate sub workflow for change analyst
	if (iChangeAnalystUserCount > 0 && tChangeAnalystUserTags != NULL && tc_strlen(cploginUserID) > 0 && cploginUserID != NULL)
	{		
		ITK(iFail,createAddApproverSubProcesses(ptTargetAttmnts[0],iChangeAnalystUserCount,tChangeAnalystUserTags,cploginUserID,"ServerTrigger"));
	}
	if (tChangeAnalystUserTags != NULL)
	EMR_free(tChangeAnalystUserTags);

	//Get Proposed Reviewers of ECN
	int iProposedUserCount = 0;
	char **cpProposedUser = NULL;
	tag_t * tProposedUserTags = NULL;
	ITK(iFail,AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&iProposedUserCount,&cpProposedUser));
	

	tag_t *tProposedMembrTags = NULL;
	if(iProposedUserCount > 0)
	{
		
		for(int knx = 0; knx < iProposedUserCount; knx++)
		{
	//Initiate subworkflow for Proposed Reviewers
			tag_t tAddressUserTag = NULLTAG;
			int icount = 0;
			ITK(iFail,SA_find_user2(cpProposedUser[knx],&tAddressUserTag));
			if(tAddressUserTag != NULLTAG)
			{
				ITK(iFail,SA_find_groupmember_by_user(tAddressUserTag,&icount,&tProposedMembrTags));
				tProposedUserTags = (tag_t *)MEM_realloc(tProposedUserTags,sizeof(tag_t)*(1+1));
				tProposedUserTags[0] = tProposedMembrTags[0];
				if (tProposedUserTags != NULL && tc_strlen(cploginUserID) > 0 && cploginUserID != NULL)
				{		
					ITK(iFail,createAddApproverSubProcesses(ptTargetAttmnts[0],1,tProposedUserTags,cploginUserID,"ServerTrigger"));
				}
			}
		}
	}
	EMR_free(tProposedMembrTags);
	EMR_free(tProposedUserTags);
	EMR_free(ptTargetAttmnts);
	EMR_free(tParentJobTags);
	EMR_free(cploginUserID);
	return ITK_ok;
}




/****************************************************************************************************
*	Handler name	:	LBT9_Set_Iteration_Property

*	Description		:	Action Handler - To set the Iteration value for ECN to know how many times it went to ECN workflow

******************************************************************************************************/

extern int LBT9_Set_Iteration_Property(EPM_action_message_t message)
{
	int iFail							= ITK_ok;
	int iTrgtAtchmnts					= 0;
	tag_t tRootTask						= NULLTAG;
	tag_t *ptTargetAttmnts				= NULL;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTrgtAtchmnts,&ptTargetAttmnts));
	}
	if(iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		int iIterationValue = 0;
		ITK(iFail,AOM_ask_value_int(ptTargetAttmnts[0],"lbt9_Iteration",&iIterationValue));
		ITK(iFail,AOM_lock(ptTargetAttmnts[0]));
		ITK(iFail,AOM_set_value_int(ptTargetAttmnts[0], "lbt9_Iteration", iIterationValue + 1));
		ITK(iFail,AOM_save(ptTargetAttmnts[0]));
		ITK(iFail,AOM_unlock(ptTargetAttmnts[0]));
		EMR_free(ptTargetAttmnts);
	}
	return ITK_ok;
}

/****************************************************************************************************
*	Handler name	:	LBT9_COMPLETE_ROUTING_TASK

*	Description		:	Action Handler - To complete the Routing task as soon as CA complete his Review Task

******************************************************************************************************/


extern int LBT9_COMPLETE_ROUTING_TASK(EPM_action_message_t message)
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=   0;
	int iArgumentsCount					=	0;
	int iTaskCount						=	0;
	tag_t tRootTask						= NULLTAG;
	tag_t *tTaskTags					= NULL;
	tag_t *ptTargetAttmnts				= NULL;
	logical allAreCompleted				= false;
	tag_t approver_form_tag				= NULLTAG;
	tag_t tUserTag = NULLTAG;
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_reference_attachment,&iTrgtAtchmnts,&ptTargetAttmnts));
		ITK(iFail,LBT_get_ecn_revision(tRootTask, CLASS_ECN_APPROVER_FORM, EPM_target_attachment, &approver_form_tag));
	}
	if(ptTargetAttmnts != NULL)
	{
		int iParentJobcount					=   0;
		tag_t *tParentJobTags				= NULL;
		ITK(iFail,EPM_ask_active_job_for_target(ptTargetAttmnts[0],&iParentJobcount,&tParentJobTags));
		if(tParentJobTags != NULL && iParentJobcount > 0)
		{
			ITK(iFail,EPM_get_type_tasks(tParentJobTags[0], eEPMDoTask , &iTaskCount, &tTaskTags));
			EMR_free(tParentJobTags);
		}
	}
	if(iTaskCount > 0 && tTaskTags != NULL && approver_form_tag != NULLTAG)
	{
		//function to get the result whether all reviewers has completed their task
		ITK(iFail,hasAllTheSubProcessesCompleted(ptTargetAttmnts[0],approver_form_tag,&allAreCompleted))
		if(allAreCompleted)
		{
			char *cpApproverId = NULL;
			ITK(iFail,AOM_ask_value_string(approver_form_tag,"lbt9_ApproverUserID",&cpApproverId));
			if(cpApproverId != NULL)
			{
				ITK(iFail,SA_find_user2(cpApproverId,&tUserTag));
				if(tUserTag != NULLTAG)
				{
					for(int i = 0; i < iTaskCount; i++)
					{
						char *cpTaskName = NULL;
						ITK(iFail,EPM_ask_name2(tTaskTags[i],&cpTaskName));
						if(cpTaskName != NULL && tc_strcmp(cpTaskName,CM_ROUTING_DO_TASK_NAME) == 0 || tc_strcmp(cpTaskName,CM_RESUME_ROUTING_DO_TASK_NAME) == 0)
						{
							char *cpTaskResult = NULL;
							ITK(iFail,EPM_get_task_result(tTaskTags[i],&cpTaskResult));
							if(cpTaskResult != NULL && tc_strcmp(cpTaskResult,EPM_RESULT_Completed) != 0)
							{
								ITK(iFail,AOM_refresh(tTaskTags[i],TRUE));
								ITK(iFail,EPM_set_task_result(tTaskTags[i],EPM_RESULT_Completed));
								ITK(iFail,EPM_remove_task_hold(tTaskTags[i]));
								//AOM_set_value_string(tSubTaskAttchmnts[0],"task_state","Completed");
								ITK(iFail,AOM_save(tTaskTags[i]));
								ITK(iFail,AOM_refresh(tTaskTags[i],FALSE));
								ITK(iFail,EPM_trigger_action(tTaskTags[i],EPM_complete_action,"Auto complete by the System"));
								EMR_free(cpTaskResult);
							}
							EMR_free(cpTaskName);
						}
					}
				}
				EMR_free(cpApproverId);
			}
		}

	}
	EMR_free(ptTargetAttmnts);
	return ITK_ok;
}


/****************************************************************************************************
*	Handler name	:	LBT9_Change_Analyst_validation

*	Description		:	Rule Handler - for Change Analyst Review Task, he or she cannot complete the 
						task unless CCB reviewers complete their task

******************************************************************************************************/



extern EPM_decision_t LBT9_Change_Analyst_validation(EPM_rule_message_t message)
{
	int iFail =ITK_ok;
	int iTargetAttchmnts = 0;
	int iReferenceAttchmnts = 0;
	int iFormCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *pTargetAttchmnts = NULL;
	tag_t *pReferenceAttchmnts = NULL;
	tag_t *tFormTags = NULL;
	char *ApproverId = NULL;
	char *Analyst =  NULL;
	char *cpErrorList = NULL;
	char *ObjectName = NULL;
	logical allAreCompleted = false;
	EPM_decision_t decision = EPM_go;
	
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTargetAttchmnts,&pTargetAttchmnts))
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_reference_attachment,&iReferenceAttchmnts,&pReferenceAttchmnts))
	}
	if(iTargetAttchmnts > 0 && pTargetAttchmnts != NULL)
	{
		ITK(iFail,AOM_ask_value_string(pTargetAttchmnts[0],"lbt9_ApproverUserID",&ApproverId));
	}
	if(iReferenceAttchmnts > 0 && pReferenceAttchmnts != NULL)
	{
		int iIterationValue = 0;
		ITK(iFail,fnToGetShortObjectNameForChangeObject(pReferenceAttchmnts[0],&ObjectName));
		ITK(iFail,AOM_ask_value_int(pReferenceAttchmnts[0],"lbt9_Iteration",&iIterationValue));
		ITK(iFail,AOM_ask_value_string(pReferenceAttchmnts[0],"lbt9_Change_Analyst",&Analyst));
		if(Analyst != NULL && ApproverId != NULL && tc_strcmp(ApproverId,Analyst) == 0)
		{
			ITK(iFail,AOM_ask_value_tags(pReferenceAttchmnts[0],Attr_ECN_REVIEWERS_LIST,&iFormCount,&tFormTags))
			if(iFormCount > 1 && tFormTags != NULL)
			{
				for(int i = 0; i < iFormCount; i++)
				{
					int iFormIterationValue = 0;
					ITK(iFail,AOM_ask_value_int(tFormTags[i],"lbt9_Iteration",&iFormIterationValue));
					if(iFormIterationValue == iIterationValue)
					{
						char *cpApproverId = NULL;
						ITK(iFail,AOM_ask_value_string(tFormTags[i],"lbt9_ApproverUserID",&cpApproverId));
						if(cpApproverId != NULL && tc_strcmp(cpApproverId,Analyst) != 0)
						{
							char *cpApproverStatus = NULL; 
							ITK(iFail,AOM_ask_value_string(tFormTags[i],"lbt9_ApproverStatus",&cpApproverStatus));
							if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Assigned") != 0)
							{
								allAreCompleted = true;	
							}
							else
							{
								allAreCompleted = false;
								break;
							}
							EMR_free(cpApproverStatus);
							EMR_free(cpApproverId);
						}
					}
				}
			}
			else if(iFormCount == 1)
			{
				allAreCompleted = true;
				decision = EPM_go;
			}
			EMR_free(ApproverId);
		}
		else
		{
			allAreCompleted = true;
			decision = EPM_go;
		}
	}
	if(allAreCompleted)
	{
		decision = EPM_go;
	}
	else if(!allAreCompleted)
	{
		char **cpUserList = NULL;
		int iUserCount = 0;
		if(tFormTags != NULL && iFormCount > 0 && Analyst != NULL)
		{
		// function to get the user list who have not completed their review task
			ITK(iFail,fnGetUserListforNotCompletedTask(Analyst,iFormCount,tFormTags,&iUserCount,&cpUserList));
			if(iUserCount > 0 && cpUserList != NULL)
			{
				//function to get the semicolon separated list of users
				ITK(iFail,fnGetCommaSeperatedList(iUserCount,cpUserList,&cpErrorList));											
			}
		}
		if(cpErrorList != NULL)
		{
			char *Temp = NULL;
			Temp = (char *)MEM_alloc(tc_strlen(cpErrorList) + tc_strlen("\n ") + 10);
			tc_strcpy(Temp,"");
			tc_strcpy(Temp,"\n ");
			tc_strcat(Temp,cpErrorList);
			EMH_store_initial_error_s2(EMH_severity_user_error, LBT_CANNOT_COMPLETE_THE_TASK,ObjectName,Temp);
			decision = EPM_nogo;
			EMR_free(cpErrorList);
			EMR_free(Temp);
		}
	}
	EMR_free(Analyst);
	EMR_free(tFormTags);
	EMR_free(pTargetAttchmnts);
	EMR_free(pReferenceAttchmnts);
	return decision;
}

/****************************************************************************************************
*	Handler name	:	LBT9_COMPLETE_CONDITION_TASK

*	Description		:	Action Handler - To complete the Condition task and direct the path of the
						workflow based on the Change Analyst decision

******************************************************************************************************/


extern int LBT9_COMPLETE_CONDITION_TASK(EPM_action_message_t message)
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=   0;
	int iArgumentsCount					=	0;
	int iTaskCount						=	0;
	tag_t tRootTask						= NULLTAG;
	tag_t *tTaskTags					= NULL;
	tag_t *ptTargetAttmnts				= NULL;
	
	ITK(iFail,EPM_ask_root_task(message.task, &tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTrgtAtchmnts,&ptTargetAttmnts));
	}
	if(ptTargetAttmnts != NULL && iTrgtAtchmnts > 0)
	{
		int iFormCount = 0;
		tag_t *tFormTags = NULL;
		ITK(iFail, AOM_ask_value_tags(ptTargetAttmnts[0],"lbt9_Approver_Form",&iFormCount,&tFormTags));
		if(iFormCount > 0 && tFormTags != NULL)
		{
			char *cpAnalystId = NULL;
			ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpAnalystId));
			if(cpAnalystId != NULL)
			{
				char *Result = NULL;
				char *TaskName = NULL;
				ITK(iFail,EPM_ask_name2(message.task,&TaskName));
				// function to get the Change Analyst current decision
				ITK(iFail,fnToGetTheLatestChangeAnalystResult(iFormCount,tFormTags,ptTargetAttmnts[0],cpAnalystId,&Result));
				if(TaskName != NULL && tc_strcmp(TaskName,"System Complete Condition Task") == 0)
				{
					if(Result != NULL && tc_strcmp(Result,"Approved") == 0)
					{
						ITK(iFail,AOM_refresh(message.task,TRUE));
						ITK(iFail, EPM_set_task_result(message.task,Result));
						ITK(iFail,AOM_save(message.task));
						ITK(iFail,AOM_refresh(message.task,FALSE));						
						EMR_free(Result);
					}
					else if(Result != NULL && tc_strcmp(Result,"Rejected") == 0)
					{					
						ITK(iFail,AOM_refresh(message.task,TRUE));
						ITK(iFail, EPM_set_task_result(message.task,Result));
						ITK(iFail,AOM_save(message.task));
						ITK(iFail,AOM_refresh(message.task,FALSE));
						EMR_free(Result);
					}
					EMR_free(TaskName);
				}
				EMR_free(cpAnalystId);
			}
			EMR_free(tFormTags);
		}
	}
	EMR_free(ptTargetAttmnts);
	return ITK_ok;
}

/****************************************************************************************************
*	Handler name	:	LBT9_Set_Approval_Comments

*	Description		:	Action Handler - For setting the comments to the form from the review task
******************************************************************************************************/


extern int LBT9_Set_Approval_Comments(EPM_action_message_t message)
{
	int iFail = ITK_ok;
	
	int number_of_args = 0;

	char *review_task_name = NULL;
	
	tag_t root_task = NULLTAG;
	tag_t rev_tag = NULLTAG;
	tag_t job_tag = NULLTAG;
	
	
	ITK(iFail,EPM_ask_root_task(message.task, &root_task));
	
	ITK(iFail,EPM_ask_job(root_task, &job_tag));
	
	number_of_args = IMAN_number_of_arguments(message.arguments);

    if ( number_of_args == 0 && iFail == ITK_ok )
    {
        iFail = EPM_successful_with_warnings ;
        EMH_store_error_s1( EMH_severity_warning,iFail,"Wrong no of arguments"); 
        return iFail;
    }
	
    for ( int indx = 0; (indx < number_of_args && iFail == ITK_ok); indx++ )
    {
        char *flag = NULL;
        char *value = NULL;

        ITK(iFail,ITK_ask_argument_named_value( IMAN_next_argument(message.arguments), &flag, &value )); 

        if ( iFail == ITK_ok ) 
        {
			if ( tc_strcasecmp(flag, "review_task_name") == 0 )
			{
				if ( value != NULL )
                {
                    review_task_name = (char*) MEM_alloc(( tc_strlen(value) + 1)* sizeof(char));
                    tc_strcpy(review_task_name, value);
                }
			}
            else
            {
                iFail = EPM_invalid_argument;
                EMH_store_error( EMH_severity_warning, iFail );
				return iFail;
            }
        }
        if( flag != NULL )
            EMR_free( flag );
        if( value != NULL )
            EMR_free( value );
    }

	if ( iFail != ITK_ok || review_task_name == NULL )
	{
		 iFail = EPM_invalid_argument;
         EMH_store_error( EMH_severity_warning, iFail );
		 return iFail;
	}
	
	if ( review_task_name != NULL )
	{
		tag_t perform_signoff_task = NULLTAG;
		
		ITK(iFail,LBT_get_perform_signoff_task(job_tag, review_task_name, &perform_signoff_task));
		
		if ( perform_signoff_task != NULLTAG )
		{
			char *decision_taken_by_user_id = NULL;
			char *decision_taken_by_user_name = NULL;
			char *decision_comments = NULL;
			char *decision_date = NULL;
			
			ITK(iFail,LBT_get_perform_signoff_details(perform_signoff_task, EPM_approve_decision, &decision_taken_by_user_id, &decision_taken_by_user_name, &decision_comments, &decision_date));

			printf("Approved By :  %s\n", decision_taken_by_user_name);
			printf("Approval Comments :  %s\n", decision_comments);
			printf("Approved Date :  %s\n", decision_date);
		
			if ( decision_comments != NULL && tc_strlen(decision_comments) > 0 )
			{
				tag_t approver_form_tag = NULLTAG;
				
				ITK(iFail,LBT_get_ecn_revision(root_task, CLASS_ECN_APPROVER_FORM, EPM_target_attachment, &approver_form_tag));
				
				if(tc_strlen(decision_comments) > 64)
				{
					char *cpTrimDecisionComments = NULL;
					fnsubString(decision_comments,60,&cpTrimDecisionComments);
					/*int	iFail	=	ITK_ok;
					string test = decision_comments;
					test.erase(0,60);
			
					cpTrimDecisionComments = (char *)alloca(test.size() + 1);
					memcpy(cpTrimDecisionComments, test.c_str(), test.size() + 1);*/
					printf("\n\n cpTrimDecisionComments Length : <%d>\n\n",tc_strlen(cpTrimDecisionComments));
					ITK(iFail,AOM_lock(approver_form_tag));
					
					ITK(iFail,AOM_set_value_string(approver_form_tag,Attr_APPROVER_COMMENTS, cpTrimDecisionComments));
					
					ITK(iFail,AOM_save(approver_form_tag));
					
					ITK(iFail,AOM_unlock(approver_form_tag));
					
				}
				else if ( approver_form_tag != NULLTAG )
				{
					ITK(iFail,AOM_lock(approver_form_tag));
					
					ITK(iFail,AOM_set_value_string(approver_form_tag,Attr_APPROVER_COMMENTS, decision_comments));
					
					ITK(iFail,AOM_save(approver_form_tag));
					
					ITK(iFail,AOM_unlock(approver_form_tag));
				}
			}
			
			EMR_free(decision_taken_by_user_id);
			EMR_free(decision_taken_by_user_name);
			EMR_free(decision_comments);
			EMR_free(decision_date);
		}
		else
		{
			printf("No review task found with name %s. please check your handler argument.\n", review_task_name);
		}
	}
	return iFail;
}


/****************************************************************************************************
*	Handler name	:	LBT9_ASSIGN_PARTCIPANT

*	Description		:	Action Handler - For setting  Analyst and Change Analyst values on Participant
						Window of Change Object
						
******************************************************************************************************/

 extern int LBT9_ASSIGN_PARTCIPANT(EPM_action_message_t msg)
 {
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=	0;
	tag_t tRootTask						=	NULLTAG;
	char *cpTaskName					=	NULL;
	char *cpChangeAnalyst				=	NULL;
	tag_t tUserTag						=	NULLTAG;
	tag_t* ptTargetAttmnts				=	NULL;
	int iCount							=	0;
	tag_t *tGroupMemTag					=	NULL;
	tag_t tChangeAnalystAssigneeTag		=	NULLTAG;
	tag_t tAnalystAssigneeTag			=	NULLTAG;
	tag_t tChgSplAssigneeTag			=	NULLTAG;
	tag_t rev_tag						=	NULLTAG;
	ITK(iFail,EPM_ask_root_task(msg.task,&tRootTask));
	std::vector<tag_t> Vuser;
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	}
	tag_t tChangeAnalystParticipantTag	= NULLTAG;
	tag_t tAnalystParticipantTag	= NULLTAG;
	tag_t tChgSplParticipantTag	= NULLTAG;
	ITK(iFail,EPM_get_participanttype("LBT9_ChangeAnalyst",&tChangeAnalystParticipantTag));
	ITK(iFail,EPM_get_participanttype("Analyst",&tAnalystParticipantTag));
	if(ptTargetAttmnts != NULL)
	{
		ITK(iFail,fnGetParticipantUsersList(ptTargetAttmnts[0],"LBT9_ChangeAnalyst",Vuser));
		ITK(iFail,fnGetParticipantUsersList(ptTargetAttmnts[0],"Analyst",Vuser));
	}
	if(Vuser.size() > 0)
	{
		int iCACount = 0;
		int iAnalystCount = 0;
		tag_t *tCATags = NULL;
		tag_t *tAnalystTags = NULL;
		ITK(iFail,ITEM_rev_ask_participants(ptTargetAttmnts[0],tChangeAnalystParticipantTag,&iCACount,&tCATags));
		ITK(iFail,ITEM_rev_ask_participants(ptTargetAttmnts[0],tAnalystParticipantTag,&iAnalystCount,&tAnalystTags));
		ITK(iFail,AOM_refresh(ptTargetAttmnts[0],TRUE));
		for(int i = 0; i < iCACount; i++)
		{
			ITK(iFail,ITEM_rev_remove_participant(ptTargetAttmnts[0],tCATags[i]));
		}
		for(int j = 0; j < iAnalystCount; j++)
		{
			ITK(iFail,ITEM_rev_remove_participant(ptTargetAttmnts[0],tAnalystTags[j]));
		}
		ITK(iFail,AOM_save(ptTargetAttmnts[0]));
		ITK(iFail,AOM_refresh(ptTargetAttmnts[0],FALSE));
		if(iFail == 0)
		{
			Vuser.clear();
		}
		EMR_free(tCATags);
		EMR_free(tAnalystTags);
	}
	if(ptTargetAttmnts != NULL && Vuser.size() == 0)
	{
		//ITK(iFail,LBT_get_ecn_revision(tRootTask, CLASS_ECN_REVISION, EPM_target_attachment, &rev_tag));
		ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpChangeAnalyst));
		if(cpChangeAnalyst != NULL)
		{
			ITK(iFail,SA_find_groupmember_by_rolename("Change Analyst","Change Management.United_States.Liebert.ENP",cpChangeAnalyst,&iCount,&tGroupMemTag)); 
			if(tGroupMemTag != NULL && tChangeAnalystParticipantTag != NULLTAG && tAnalystParticipantTag != NULLTAG)
			{
				ITK(iFail,EPM_create_participant(tGroupMemTag[0],tChangeAnalystParticipantTag,&tChangeAnalystAssigneeTag));
				ITK(iFail,EPM_create_participant(tGroupMemTag[0],tAnalystParticipantTag,&tAnalystAssigneeTag));
				ITK(iFail,AOM_refresh(ptTargetAttmnts[0],TRUE));
				ITK(iFail,ITEM_rev_add_participant(ptTargetAttmnts[0],tChangeAnalystAssigneeTag));
				ITK(iFail,ITEM_rev_add_participant(ptTargetAttmnts[0],tAnalystAssigneeTag));
				ITK(iFail,AOM_save(ptTargetAttmnts[0]));
				ITK(iFail,AOM_refresh(ptTargetAttmnts[0],FALSE));		
			}
		}
		EMR_free(cpChangeAnalyst);
		EMR_free(tGroupMemTag);
	}
	return iFail;
 }

 /****************************************************************************************************
*	Handler name	:	LBT9_LES_FILE_IMPLEMENTED

*	Description		:	Action Handler - For setting  the values after Implemented status
						in Transfer/Signoff Tab for the ECN and MCO
						
******************************************************************************************************/

 extern int LBT9_LES_FILE_IMPLEMENTED(EPM_action_message_t message)
 {
	int iFail = ITK_ok;
	tag_t tRootTask = NULLTAG;
	int iTargetCount = 0;
	tag_t *ptTargetAttchmnts = NULL;
	int NumberOfArguments = 0;
	char *cpStatus		  = NULL;
	NumberOfArguments = IMAN_number_of_arguments(message.arguments);
    if ( NumberOfArguments == 0 && iFail == ITK_ok )
    {
        iFail = EPM_successful_with_warnings ;
        EMH_store_error_s1( EMH_severity_warning,iFail,"Wrong no of arguments"); 
        return iFail;
    }
    for ( int indx = 0; (indx < NumberOfArguments && iFail == ITK_ok); indx++ )
    {
        char *flag = NULL;
        char *value = NULL;

        ITK(iFail,ITK_ask_argument_named_value( IMAN_next_argument(message.arguments), &flag, &value )); 

        if ( iFail == ITK_ok ) 
        { 	
			if (tc_strcasecmp(flag, "status") == 0)
			{
				if ( value != NULL )
                {
                    cpStatus= (char*) MEM_alloc(( tc_strlen(value) + 1)* sizeof(char));
                    tc_strcpy(cpStatus, value);
                }
			}
			else
            {
                iFail = EPM_invalid_argument;
                EMH_store_error( EMH_severity_warning, iFail );
				return iFail;
            }
        }
        if( flag != NULL )
            EMR_free( flag );
        if( value != NULL )
            EMR_free( value );
    }
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTargetCount,&ptTargetAttchmnts));
	}
	if(iTargetCount > 0 && ptTargetAttchmnts != NULL && cpStatus != NULL)
	{
		tag_t tGroupMemberTag =	NULLTAG;
		tag_t tGrouptag		  = NULLTAG;
		tag_t tRoleTag		  = NULLTAG;
		tag_t tUserTag		  = NULLTAG;
		char *cpGroupName	  = NULL;
		char *cpRoleName	  = NULL;
		char *cpCurrentUser	  = NULL;
		char *Temp			  = NULL;
		tag_t tFormTag = NULLTAG;
		char *cpObjectType	  = NULL;
		//This Handler has to work for ECN and MCO 
		//For MCO it should not check for the ERP Status 
		//For ECN it should work only when property "ERP status" value is "Transfer to ERP"
		ITK(iFail,WSOM_ask_object_type2(ptTargetAttchmnts[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_ECNRevision") == 0)
		{
			char *cpERPStatus = NULL;
			ITK(iFail,AOM_ask_value_string(ptTargetAttchmnts[0],"lbt9_ERP_Status",&cpERPStatus));
			if(cpERPStatus != NULL && tc_strcmp(cpERPStatus,"Teamcenter Only") == 0)
			{
				EMR_free(cpERPStatus);
				return ITK_ok;
			}
		}
		ITK(iFail, SA_ask_current_groupmember(&tGroupMemberTag));
		if(tGroupMemberTag != NULLTAG)
		{
			ITK(iFail, SA_ask_groupmember_group(tGroupMemberTag,&tGrouptag));
			if(tGrouptag != NULLTAG)
			{
				ITK(iFail, SA_ask_group_name2(tGrouptag,&cpGroupName));
			}
			ITK(iFail, SA_ask_groupmember_role(tGroupMemberTag,&tRoleTag));
			if(tRoleTag != NULLTAG)
			{
				ITK(iFail, SA_ask_role_name2(tRoleTag,&cpRoleName));
			}
			ITK(iFail, SA_ask_groupmember_user(tGroupMemberTag,&tUserTag));
			if(tUserTag != NULLTAG)
			{
				ITK(iFail, SA_ask_user_identifier2(tUserTag,&cpCurrentUser));
			}
			if(cpRoleName != NULL && cpGroupName != NULL && cpCurrentUser != NULL)
			{
				
				Temp = (char *)MEM_alloc(tc_strlen(cpGroupName) + tc_strlen("/") + tc_strlen(cpRoleName)  + tc_strlen("/") + tc_strlen(cpCurrentUser) + 2);
				tc_strcpy(Temp,"");
				tc_strcpy(Temp,cpGroupName);
				tc_strcat(Temp,"/");
				tc_strcat(Temp,cpRoleName);
				tc_strcat(Temp,"/");
				tc_strcat(Temp,cpCurrentUser);
			
			}
		}
		if(Temp != NULL)
		{
			ITK(iFail, FORM_create(Temp,"",CM_SIGNOFF_FORM_TYPE,&tFormTag));
		}
		if( tFormTag != NULLTAG)
		{			
			ITK(iFail,fnSetFormValuesForTransfer(tFormTag,tUserTag,cpStatus,"   "));
		}
		ITK(iFail,attachFormToRevision(tFormTag,ptTargetAttchmnts[0],Attr_SIGNOFF_HISTORY));
		EMR_free(cpStatus);
		EMR_free(cpGroupName);
		EMR_free(cpRoleName);
		EMR_free(ptTargetAttchmnts);
	}
	return ITK_ok;
 }

 /****************************************************************************************************
*	Handler name	:	LBT9_APPEND_COMPLETED_TO_APPROVER_FORM

*	Description		:	Action Handler - To Append the Completed to the name of the form when the Reviewer 
						Completed Task

******************************************************************************************************/

extern int LBT9_APPEND_COMPLETED_TO_APPROVER_FORM(EPM_action_message_t message)
{
	int   iFail							=	ITK_ok;
	int   iTrgtAtchmnts					=	0;
	tag_t tRootTask						=	NULLTAG;
	tag_t *ptTrgtAttmnts				=	NULL;


	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment, &iTrgtAtchmnts, &ptTrgtAttmnts));
	}
	if(iTrgtAtchmnts > 0 && iTrgtAtchmnts != NULL)
	{
		char * cpFormName		=	NULL;
		char *Temp = NULL;
		 
		ITK(iFail,AOM_ask_value_string(ptTrgtAttmnts[0],"object_name",&cpFormName));
		Temp = (char *)MEM_alloc(tc_strlen(cpFormName) + tc_strlen("_Completed") + 2);

		tc_strcpy(Temp,"");
		tc_strcpy(Temp,cpFormName);
		tc_strcat(Temp,"_Completed");

		ITK(iFail,AOM_lock(ptTrgtAttmnts[0]));
		ITK(iFail,AOM_set_value_string(ptTrgtAttmnts[0],"object_name",Temp));
		ITK(iFail,AOM_save(ptTrgtAttmnts[0]));
		ITK(iFail,AOM_unlock(ptTrgtAttmnts[0]));
		
		EMR_free(cpFormName);

	}
	return ITK_ok;

}

 /****************************************************************************************************
*	Handler name	:	LBT9_DATABASE_CA_TASK_ASSIGN

*	Description		:	Action Handler - To Assign the task to Database Change Analyst 

******************************************************************************************************/


extern int LBT9_DATABASE_CA_TASK_ASSIGN(EPM_action_message_t message)
{
	int iFail = ITK_ok;
	int iTargetAttmnts = 0;
	tag_t tUserTag  = NULLTAG;
	tag_t tRootTask = NULLTAG;
	tag_t *pTargetAttments = NULL;
	char *cpDBAUser = NULL;
	//Making it Generic for the MCO and ECN so asking for Target Attachments
	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTargetAttmnts,&pTargetAttments));
	}
	if(pTargetAttments != NULL && iTargetAttmnts > 0)
	{
		ITK(iFail,fnToGetDatabaseChangeAnalystUser(&cpDBAUser));
	}
	if(cpDBAUser != NULL)
	{
		ITK(iFail, SA_find_user2(cpDBAUser,&tUserTag));
	}
	if(tUserTag != NULLTAG)
	{
		ITK(iFail,EPM_assign_responsible_party(message.task,tUserTag));
	}
	return ITK_ok;
}
extern int LBT9_Custom_Handler(EPM_action_message_t msg)
{
	int retcode = ITK_ok;
	int iTrgtAtchmnts = 0;
	int iRefAtchmnts = 0;
	tag_t tRootTask = NULLTAG;
	tag_t tItemRevType = NULLTAG;
	tag_t *ptTargetAttmnts = NULL;	
	tag_t *ptRefAttmnts = NULL;	
	ITK(retcode,EPM_ask_root_task(msg.task, &tRootTask));
	
	ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	ITK(retcode,EPM_ask_attachments(tRootTask, EPM_reference_attachment, &iRefAtchmnts, &ptRefAttmnts));


	// code for updating derived to
	if(iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		if(iRefAtchmnts > 0 && ptRefAttmnts != NULL )
		{
			char * object_type= NULL;
			retcode = AOM_ask_value_string(ptRefAttmnts[0],"object_type",&object_type);

			if(tc_strcmp(object_type,CM_NOTE_FORM_TYPE ) == 0)
			{
				ITK(retcode,attachNotesFormToRevision(ptRefAttmnts[0], ptTargetAttmnts[0]));
			}

			if(tc_strcmp(object_type,"LBT9_Change_History") == 0)
			{
				ITK(retcode,attachFormToRevision2(ptRefAttmnts[0], ptTargetAttmnts[0]));
			}

			else
			{
				char * cObjString = NULL;
				retcode = AOM_ask_value_string(ptRefAttmnts[0],"object_string",&cObjString);

				if(cObjString != NULL)
				{
					int iNum = 0;
					char**cvalues = NULL;
					retcode =	AOM_refresh(ptTargetAttmnts[0],true);
					AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Derived_to",&iNum,&cvalues);
					if(iNum > 0 && cvalues != NULL)
					{
					if (retcode == ITK_ok)retcode =	AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Derived_to",iNum,cObjString);
					}
					else{
					if (retcode == ITK_ok)retcode =	AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Derived_to",0,cObjString);
					}
					if (retcode == ITK_ok)retcode =	AOM_save(ptTargetAttmnts[0]);
					if (retcode == ITK_ok)retcode =	AOM_refresh(ptTargetAttmnts[0],false);
					if (retcode == ITK_ok)printf("Operation successfull..!\n");
				}
			}
		}
		else{


	

		}
		
	}
	return retcode;
	

}

extern int LBT9_Custom_Handler_Update_History(EPM_action_message_t msg)
{
	int retcode = ITK_ok;
	int iTrgtAtchmnts = 0;
	int iRefAtchmnts = 0;
	tag_t tRootTask = NULLTAG;
	tag_t tItemRevType = NULLTAG;
	tag_t *ptTargetAttmnts = NULL;	
	tag_t *ptRefAttmnts = NULL;	
	ITK(retcode,EPM_ask_root_task(msg.task, &tRootTask));
	
	ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	//ITK(retcode,EPM_ask_attachments(tRootTask, EPM_reference_attachment, &iRefAtchmnts, &ptRefAttmnts));


	// code for updating derived to
	if(iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		fnUpdateChangeFormInRevision(ptTargetAttmnts[0]);
		
	}
	return retcode;
	

}

int fnUpdateChangeFormInRevision(tag_t tRevTag)
{
	int retcode   = ITK_ok;

	//ITEM_find_rev(cStrList[0],cStrList[1],&tRevTag);
	if (tRevTag != NULLTAG)
	{
		printf("Rev Tag Found..!\n");
		retcode = AOM_refresh(tRevTag,true);
				
		int iAttchItemCount = 0; 
			
		tag_t *tAttchItemTags = NULL;
		
		ITK(retcode, LBT_get_related_objects(tRevTag, "CMHasImpactedItem", &iAttchItemCount, &tAttchItemTags));
		printf("Related objects Found..!\n");

		ITK(retcode,fnUpdateChangeHistoryForm2(tRevTag, iAttchItemCount, tAttchItemTags))
		printf("Updated Form..!\n");
	}
	return retcode;
}
int fnUpdateChangeHistoryForm2(tag_t change_rev_tag,      /* <I> */
							  int n_impacted_items,      /* <I> */
							  tag_t *impacted_rev_tags   /* <I> */
                             )
{
	int retcode = ITK_ok;
	
	date_t change_release_date;
	
	ITK( retcode,AOM_ask_value_date(change_rev_tag,"date_released",&change_release_date));

	if( DATE_IS_NULL(change_release_date) == 1 )
	{
		return retcode;
	}
	else
	{
		tag_t change_item = NULLTAG;
		
		char *cpChangeItemID = NULL;
		
		ITK( retcode,ITEM_ask_item_of_rev(change_rev_tag, &change_item));
		
		ITK( retcode,ITEM_ask_id2(change_item, &cpChangeItemID));
		
		for (int inx = 0; inx < n_impacted_items; inx++)
		{              
			int n_forms = 0;
			tag_t *form_tags = NULL;
			
			ITK( retcode,AOM_ask_value_tags(impacted_rev_tags[inx], "lbt9_Change_History_List", &n_forms, &form_tags));

			for (int jnx = 0; jnx < n_forms; jnx++)
			{
				char *existing_form_name = NULL;

				ITK( retcode,AOM_ask_value_string(form_tags[jnx], "object_name", &existing_form_name));

				if( tc_strcmp(cpChangeItemID, existing_form_name) == 0 )
				{
					ITK(retcode, AOM_refresh(form_tags[jnx],TRUE));

					ITK(retcode, AOM_set_value_date(form_tags[jnx], "lbt9_Change_Release_Date", change_release_date));

					ITK( retcode,AOM_save(form_tags[jnx]));
					
					ITK( retcode,AOM_refresh(form_tags[jnx],FALSE));

					printf("Updated Date");
				}
			}
			MEM_free(form_tags);
		}
		MEM_free(cpChangeItemID);
	}
	return retcode;
}

int attachFormToRevision2(tag_t formTag,          /* <I> */
						 tag_t revTag            /* <I> */
					    )
{
	int retcode = ITK_ok;
   
	if( revTag != NULLTAG && formTag != NULLTAG )
	{
		int n_forms = 0;
	   
		tag_t itemTag =  NULLTAG;
		tag_t *form_tags = NULL;

		char *form_name = NULL;
	   
		retcode =ITEM_ask_item_of_rev(revTag, &itemTag);
	   
		retcode =AOM_ask_value_string(formTag, "object_name", &form_name);
	   
		// Remove the form if already existing
		retcode =deleteFormFromItem(itemTag, form_name);
	   
		//Attach the form to Revision
		//Find out if any forms are attached already. Since the property is a list of typed references, we need to add the form as a last element to the list
		retcode =AOM_ask_value_tags(revTag, "lbt9_Change_History_List", &n_forms, &form_tags);
	   
		if ( retcode == ITK_ok )
		{
			retcode =AOM_refresh(revTag, TRUE);
			retcode =AOM_set_value_tag_at(revTag, "lbt9_Change_History_List", n_forms, formTag);
			retcode =AOM_save(revTag);
			retcode =AOM_refresh(revTag, FALSE);
		}
	   
		//Attach the form to Item as well
		retcode =AOM_ask_value_tags(itemTag, "lbt9_Change_History_List", &n_forms, &form_tags);
	   
		if( retcode == ITK_ok )
		{
			retcode =AOM_refresh(itemTag, TRUE);
			retcode =AOM_set_value_tag_at(itemTag, "lbt9_Change_History_List", n_forms, formTag);
			retcode =AOM_save(itemTag);
			retcode =AOM_refresh(itemTag, FALSE);
		}
		MEM_free(form_tags);
		MEM_free(form_name);
	}
   
	return retcode;
}

int deleteFormFromItem(tag_t item_tag,         /* <I> */
					   char *form_name         /* <I> */
			          )
{
	int retcode = ITK_ok;
	int rev_count = 0;
	
	tag_t form_tag = NULLTAG;
	tag_t *rev_tags = NULL;
	
	retcode =ITEM_list_all_revs(item_tag, &rev_count, &rev_tags);
	
	//remove form from all revisions
	for (int inx = 0; inx < rev_count; inx++)
	{
		retcode =removeForm(rev_tags[inx], form_name, &form_tag);
	}
	//remove form from item
	retcode =removeForm(item_tag, form_name, &form_tag);
	
	//delete the form from the database
	if( form_tag != NULLTAG )
	{
		retcode =AOM_refresh(form_tag, TRUE);
		
		retcode =AOM_delete(form_tag);
	}
	
	return retcode;
}

//Remove Form
int removeForm(tag_t object,        /* <I> */
               char *form_name,     /* <I> */
			   tag_t *form_object   /* <O> */
			   )
{
	int retcode = ITK_ok;
	int n_forms = 0;
	
	tag_t *form_tags = NULL;
	
	*form_object = NULLTAG;
	
	retcode =AOM_ask_value_tags(object, "lbt9_Change_History_List", &n_forms, &form_tags);
	
	for (int inx = 0; inx < n_forms; inx++)
	{
		char *existing_form_name = NULL;
		
		retcode =AOM_ask_value_string(form_tags[inx], "object_name", &existing_form_name);
		
		if( tc_strcmp(form_name, existing_form_name) == 0 )
		{
			int values_index = -1;
			
			char *classname = NULL;
			
			tag_t inst_class_id = NULLTAG;
			tag_t chg_history_attr_id = NULLTAG;
			
			retcode =POM_class_of_instance(object, &inst_class_id);

			retcode =POM_name_of_class(inst_class_id, &classname);

			retcode =POM_attr_id_of_attr("lbt9_Change_History_List", classname, &chg_history_attr_id);
		
			if ( chg_history_attr_id != NULLTAG )
			{
				retcode =AOM_lock(object);

				retcode =POM_ask_index_of_tag(object, chg_history_attr_id, form_tags[inx], &values_index);
				
				if( values_index != -1 )
				{
					retcode =POM_remove_from_attr(1, &object, chg_history_attr_id, values_index, 1);
				}
				
				retcode =AOM_save(object);

				retcode =AOM_unlock(object);
			}
			retcode =deleteFormProperties(form_tags[inx]);
			*form_object = form_tags[inx];
			
			MEM_free(classname);
		}
		MEM_free(existing_form_name);
	}
	
	MEM_free(form_tags);
	
	return retcode;
}

int deleteFormProperties(tag_t change_form     /* <I> */)
{
	int retcode = ITK_ok;
   
	tag_t part_rev_tag_attr_id = NULLTAG;
	tag_t chg_rev_tag_attr_id = NULLTAG;
	tag_t form_storage_tag = NULLTAG;
	tag_t storage_class_id = NULLTAG;
   
	char *storage_classname = NULL;
   
	retcode =AOM_ask_value_tag(change_form, "data_file", &form_storage_tag);
	
	retcode =POM_class_of_instance(form_storage_tag, &storage_class_id);

	retcode =POM_name_of_class(storage_class_id, &storage_classname);
	
	printf("From Storage Class Name : %s\n", storage_classname);
	printf("From ID : %d\t Storage Form ID : %d\n", change_form, form_storage_tag);
	
	retcode =POM_attr_id_of_attr("lbt9_Part_Revs_Tag", "LBT9_Change_HistoryStorage", &part_rev_tag_attr_id);
   
	retcode =POM_attr_id_of_attr("lbt9_Change_Revs_Tag", "LBT9_Change_HistoryStorage", &chg_rev_tag_attr_id);
   
	retcode =AOM_lock(form_storage_tag);
   
	retcode =POM_set_attr_null(1, &form_storage_tag, chg_rev_tag_attr_id);
   
	retcode =POM_set_attr_null(1, &form_storage_tag, part_rev_tag_attr_id);
   
	retcode =AOM_save(form_storage_tag);

	retcode =AOM_unlock(form_storage_tag);
   
	MEM_free(storage_classname);
   
	return retcode;
}

int createNoteFormOptional(tag_t rev_tag,                           /* <I> */              
				   tag_t logged_in_group_member_tag,        /* <I> */
                   char *to_users_list,                     /* <I> */
				   char *to_email_id,                       /* <I> */
				   char *comments,  
				   tag_t *tForm/* <O> */
				  )
{
	int retcode = ITK_ok;
	*tForm = NULLTAG;
	
	char *current_date_string = NULL;
	
	date_t current_date = NULLDATE;
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	
	ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
	
	if ( logged_in_group_member_tag != NULLTAG )
	{
		int n_participants = 0;
	
		tag_t user_tag = NULLTAG;
		
		char * cStatusName	=	NULL;
		char * cECNId		=	NULL;
		char *assigned_by = NULL;
		char **participants_list = NULL;
		char *form_name = NULL;
		
		AOM_ask_value_string(rev_tag,"current_id",&cECNId);
		ITK(retcode,SA_ask_groupmember_user(logged_in_group_member_tag, &user_tag));
		
		ITK(retcode,SA_ask_user_identifier2(user_tag, &assigned_by));
		
		printf("To Users List : %s\n", to_users_list);
		printf("To Email ID List : %s\n", to_email_id);
		ITK(retcode,makePartcipantsList(to_users_list, to_email_id, &n_participants, &participants_list));
		
		/*form_name = (char *) MEM_alloc((tc_strlen("Notes_By_")+tc_strlen(assigned_by)+1)*sizeof(char));
		tc_strcpy(form_name, "Notes_By_");
		tc_strcat(form_name, assigned_by);*/
		
		form_name = (char *) MEM_alloc((tc_strlen(cECNId)+1)*sizeof(char));
		tc_strcpy(form_name,cECNId );
		/*  Create Form*/
		int istatusCount	=	0;
		char *cpTrimValue = "";
		tag_t formTag = NULLTAG;
		tag_t form_type_tag = NULLTAG;
		tag_t form_create_input_tag = NULLTAG;
		tag_t * tStatusTag		=		NULL;
		tag_t type_tag	=	NULL;
		ITK(retcode,FORM_create(form_name, "", CM_NOTE_FORM_TYPE, &formTag));
		ITK(retcode,TCTYPE_find_type(CM_NOTE_FORM_TYPE, NULL, &form_type_tag));
		
		ITK(retcode,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));
		
		AOM_ask_value_tags(rev_tag,"release_status_list",&istatusCount,&tStatusTag);
		AOM_ask_value_string(tStatusTag[0],"object_name",&cStatusName);
		
		if(tc_strstr(cStatusName,"LBT9_") != NULL)
		{
			string test = cStatusName;
			test.erase(0,5);
			
			cpTrimValue = (char *)alloca(test.size() + 1);
			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
			if(tc_strcmp(cpTrimValue,"CCB_For_Resume")==0)
			{
					cpTrimValue="CCB For Resume";
			}
			
				ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
		
		}
		else if(tc_strstr(cStatusName,"EMR_") != NULL)
		{
			string test = cStatusName;
			test.erase(0,4);
			cpTrimValue = (char *)alloca(test.size() + 1);
			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
			ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
		}
		else
		{
			ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Status",cStatusName));
		}

		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", form_name));			
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_NoteInitiator", assigned_by));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Notes", comments));
		//ERROR_CHECK(AOM_set_value_strings(form_create_input_tag, "lbt9_NotifiedParticipants", n_participants, participants_list));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_NotifiedParticipants",to_email_id));
		ERROR_CHECK(AOM_set_value_date(form_create_input_tag, "lbt9_NoteCreatedDate", current_date));
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_Subject", cECNId));
		
		
		printf("Form Name    : %s\n", form_name);
		printf("Assigned By  : %s\n", assigned_by);
		
		ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
		
		ERROR_CHECK(AOM_save(formTag));
		
		ERROR_CHECK(AOM_save_with_extensions(formTag));
		
		/* Attach the form to the Revision with LBT9_ECN_Observers_Rel relation*/
		//ITK(retcode,attachNotesFormToRevision(formTag, rev_tag));
		*tForm = formTag;
		
		EMR_free(participants_list);
		EMR_free(assigned_by);
		EMR_free(cStatusName);
		
	}
	
	EMR_free(current_date_string);
	
	return retcode;
}
// send note code


//int createNoteForm2(tag_t rev_tag,                           /* <I> */              
//				   char *user_id,        /* <I> */
//                   char *to_users_list,                     /* <I> */
//				   char *to_email_id,                       /* <I> */
//				   char *comments                           /* <I> */
//				  )
//{
//	int retcode = ITK_ok;
//	
//	char *current_date_string = NULL;
//	
//	date_t current_date = NULLDATE;
//	
//	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
//	
//	ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
//	
//	if ( user_id != NULL )
//	{
//		int n_participants = 0;
//	
//		tag_t user_tag = NULLTAG;
//		
//		char * cStatusName	=	NULL;
//		char * cECNId		=	NULL;
//		char *assigned_by = NULL;
//		char **participants_list = NULL;
//		char *form_name = NULL;
//		
//		AOM_ask_value_string(rev_tag,"current_id",&cECNId);
//		//ITK(SA_ask_groupmember_user(logged_in_group_member_tag, &user_tag));
//		
//		//ITK(SA_ask_user_identifier2(user_tag, &assigned_by));
//		
//		printf("To Users List : %s\n", to_users_list);
//		printf("To Email ID List : %s\n", to_email_id);
//		ITK(retcode,makePartcipantsList(to_users_list, to_email_id, &n_participants, &participants_list));
//		
//		/*form_name = (char *) MEM_alloc((tc_strlen("Notes_By_")+tc_strlen(assigned_by)+1)*sizeof(char));
//		tc_strcpy(form_name, "Notes_By_");
//		tc_strcat(form_name, assigned_by);*/
//		
//		form_name = (char *) MEM_alloc((tc_strlen(cECNId)+1)*sizeof(char));
//		tc_strcpy(form_name,cECNId );
//		/*  Create Form*/
//		int istatusCount	=	0;
//		char *cpTrimValue = "";
//		tag_t formTag = NULLTAG;
//		tag_t form_type_tag = NULLTAG;
//		tag_t form_create_input_tag = NULLTAG;
//		tag_t * tStatusTag		=		NULL;
//		tag_t type_tag	=	NULL;
//		ITK(retcode,FORM_create(form_name, "", CM_NOTE_FORM_TYPE, &formTag));
//		ITK(retcode,TCTYPE_find_type(CM_NOTE_FORM_TYPE, NULL, &form_type_tag));
//		
//		ITK(retcode,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));
//		
//		AOM_ask_value_tags(rev_tag,"release_status_list",&istatusCount,&tStatusTag);
//		AOM_ask_value_string(tStatusTag[0],"object_name",&cStatusName);
//		
//		if(tc_strstr(cStatusName,"LBT9_") != NULL)
//		{
//			string test = cStatusName;
//			test.erase(0,5);
//			
//			cpTrimValue = (char *)alloca(test.size() + 1);
//			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
//			if(tc_strcmp(cpTrimValue,"CCB_For_Resume")==0)
//			{
//					cpTrimValue="CCB For Resume";
//			}
//			
//				ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
//		
//		}
//		else if(tc_strstr(cStatusName,"EMR_") != NULL)
//		{
//			string test = cStatusName;
//			test.erase(0,4);
//			cpTrimValue = (char *)alloca(test.size() + 1);
//			memcpy(cpTrimValue, test.c_str(), test.size() + 1);
//			ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_Status", cpTrimValue));
//		}
//		else
//		{
//			ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_Status",cStatusName));
//		}
//
//		ITK(retcode,AOM_set_value_string(form_create_input_tag, "object_name", form_name));			
//		ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_NoteInitiator", user_id));
//		ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_Notes", comments));
//		//ERROR_CHECK(AOM_set_value_strings(form_create_input_tag, "lbt9_NotifiedParticipants", n_participants, participants_list));
//		ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_NotifiedParticipants",to_email_id));
//		ITK(retcode,AOM_set_value_date(form_create_input_tag, "lbt9_NoteCreatedDate", current_date));
//		ITK(retcode,AOM_set_value_string(form_create_input_tag, "lbt9_Subject", cECNId));
//		
//		
//		printf("Form Name    : %s\n", form_name);
//		printf("Assigned By  : %s\n", user_id);
//		
//		ITK(retcode,TCTYPE_create_object(form_create_input_tag, &formTag));
//		
//		ITK(retcode,AOM_save(formTag));
//		
//		ITK(retcode,AOM_save_with_extensions(formTag));
//		
//		/* Attach the form to the Revision with LBT9_ECN_Observers_Rel relation*/
//		ITK(retcode,attachNotesFormToRevision(formTag, rev_tag));
//		
//		MEM_free(participants_list);
//		MEM_free(user_id);
//		MEM_free(cStatusName);
//		
//	}
//	
//	MEM_free(current_date_string);
//	
//	return retcode;
//}

/**************************************************************************************
*	Function name	:	makePartcipantsList

*	Description		:	This Function consolidate list of User in one semi colon seperated list 

***************************************************************************************/


//int makePartcipantsList(char *users_list,              /* <I> */
//                        char *email_id_list,           /* <I> */
//                        int *n_participants,           /* <O> */
//                        char ***participants_list      /* <OF> */
//                       )
//{
//	int retcode = ITK_ok;
//	
//	*n_participants = 0;
//	*participants_list = NULL;
//	
//	if ( users_list != NULL && tc_strlen(users_list) > 0 )
//	{
//		int piStringCount = 0;
//		char **pppStringList = NULL;
//
//		/* Add to list*/
//		ITK(retcode,EPM__parse_string(users_list, USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));
//		
//		for (int inx = 0; inx < piStringCount; inx++)
//		{
//			*participants_list = (char **) MEM_realloc(*participants_list, (*n_participants+1)*sizeof(char *));
//			(*participants_list)[*n_participants] = pppStringList[inx];
//			*n_participants = *n_participants + 1;
//		}
//		
//		MEM_free(pppStringList);
//	}
//	
//	if ( email_id_list != NULL && tc_strlen(email_id_list) > 0 )
//	{
//		int piStringCount = 0;
//		char **pppStringList = NULL;
//
//		/* Add to list*/
//		ITK(retcode,EPM__parse_string(email_id_list, USERS_LIST_SEPERATOR, &piStringCount, &pppStringList));
//		
//		for (int inx = 0; inx < piStringCount; inx++)
//		{
//			*participants_list = (char **) MEM_realloc(*participants_list, (*n_participants+1)*sizeof(char *));
//			(*participants_list)[*n_participants] = pppStringList[inx];
//			*n_participants = *n_participants + 1;
//		}
//		
//		MEM_free(pppStringList);
//	}
//	
//	return retcode;
//}
//
//
///**************************************************************************************
//*	Function name	:	attachNotesFormToRevision
//
//*	Description		:	This Function is used to attach the note form to change object
//
//***************************************************************************************/
//int attachNotesFormToRevision(tag_t formTag,       /* <I> */
//						      tag_t revTag         /* <I> */
//						     )
//{
//	int retcode = ITK_ok;
//	tag_t referenceRelation = NULLTAG;
//
//	int iFail = ITK_ok;
//	int iExistingFormCount = 0;
//	tag_t *tAllFormTags = NULL;
//	ITK(retcode,AOM_ask_value_tags(revTag,Attr_Note_Form,&iExistingFormCount,&tAllFormTags));
//	ITK(retcode,AOM_refresh(revTag,TRUE));
//	ITK(retcode,AOM_set_value_tag_at(revTag,Attr_Note_Form,iExistingFormCount,formTag));
//	ITK(retcode,AOM_save(revTag));
//	ITK(retcode,AOM_refresh(revTag,FALSE));
//	
//	MEM_free(tAllFormTags);
//	return retcode;
//}
/**********************************************************************************************************************
*	Handler name	:	LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM

*	Description		:	Action Handler - This handler updates the release date on change history form when
                        the change is released. The change history forms are attached to the solution items or problem items of changes.
												
***********************************************************************************************************************/
extern int LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM(EPM_action_message_t msg)	
{
	int retcode = ITK_ok;
	int iTrgtAtchmnts = 0;
	tag_t tRootTask = NULLTAG;
	tag_t tItemRevType = NULLTAG;
	tag_t *ptTargetAttmnts = NULL;	
	ITK(retcode,EPM_ask_root_task(msg.task, &tRootTask));
	
	ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	
	ITK(retcode,TCTYPE_find_type("ItemRevision", "ItemRevision", &tItemRevType));
	
	for (int inx = 0; inx < iTrgtAtchmnts; inx++)
	{
		tag_t tAttTypeTag = NULLTAG;
		
		logical bIsItemRevType = false;
		
		ITK(retcode,TCTYPE_ask_object_type(ptTargetAttmnts[inx], &tAttTypeTag));

		ITK(retcode,TCTYPE_is_type_of(tAttTypeTag, tItemRevType, &bIsItemRevType));
		
		if( bIsItemRevType ) 
		{
			int iAttchItemCount = 0;
			
			char *cpObjectType = NULL;
			
			tag_t *tAttchItemTags = NULL;
			
			ITK(retcode,AOM_ask_value_string(ptTargetAttmnts[inx], "object_type", &cpObjectType));
			
			if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_ECNRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_DCNRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_MCORevision") == 0))
			{
				ITK(retcode,LBT_get_related_objects(ptTargetAttmnts[inx], SOLUTION_ITEMS_RELATION, &iAttchItemCount, &tAttchItemTags));
				
				if( iAttchItemCount > 0 )
				{
					ITK(retcode,fnUpdateChangeHistoryForm(ptTargetAttmnts[inx], iAttchItemCount, tAttchItemTags));
				}				
			}
			if(cpObjectType != NULL && (tc_strcmp(cpObjectType,"LBT9_ChgRequestRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_DeviationRevision") == 0 || tc_strcmp(cpObjectType,"LBT9_StopShipRevision") == 0))
			{
				//ITK(retcode,LBT_get_related_objects(ptTargetAttmnts[inx], IMPACTED_ITEMS_RELATION, &iAttchItemCount, &tAttchItemTags));
				//
				//if( iAttchItemCount > 0 )
				//{
				//	ITK(retcode,fnUpdateChangeHistoryForm(ptTargetAttmnts[inx], iAttchItemCount, tAttchItemTags));
				//}
				//char *command     = NULL;
				//char *cInString   = NULL;
				//char *cItemId     = NULL;
				//char *cRevId	  = NULL;

				//tag_t tItem       = NULLTAG;

				//command =(char*) MEM_alloc(1024);
				//cInString =(char*) MEM_alloc(512);				

				//ITK(retcode,AOM_ask_value_tag(ptTargetAttmnts[inx],"items_tag",&tItem));
				//if(tItem != NULLTAG)
				//{
				//	ITK(retcode,AOM_ask_value_string(tItem, "item_id", &cItemId));
				//}
				//ITK(retcode,AOM_ask_value_string(ptTargetAttmnts[inx], "item_revision_id", &cRevId));

				//if(cItemId != NULL && cRevId != NULL)
				//{
				//	tc_strcpy(cInString ,cItemId);
				//	tc_strcat(cInString , "|");
				//	tc_strcat(cInString ,cRevId);
				//	tc_strcat(cInString , "|");							
				//}
				//char * cPrefVal = NULL;
				//PREF_set_search_scope(TC_preference_site);
				//PREF_ask_char_value("LBT_BUS_EXE_LOC",0,&cPrefVal );
				//printf("Prefernece value is %s \n",cPrefVal);
				//tc_strcpy(command ,cPrefVal);
				//tc_strcat(command , " CR_Update_Change_History_Form");
				//tc_strcat(command , " ");
				//tc_strcat(command , "\"");
				//tc_strcat(command , cInString);
				//tc_strcat(command , "\"");

				//printf("command is %s \n", command);
				//if (system(command) != 0 )
				//{
				//	printf("System command Operation failed..!\n");
				//}
				//else
				//{
				//	printf("System command Operation Success..!\n");
				//}

				int * Type= NULL;
				tag_t *tComp = NULL;
				tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*1);
				Type = (int*) MEM_alloc(sizeof(int)*1);
				tComp[0] = ptTargetAttmnts[inx];
					
				//tComp[1] = formTag;
				Type[0] =  EPM_target_attachment;
				//Type[1] =  EPM_reference_attachment;
							
				//tComp[1] = new_rev[0];
		
		
				tag_t tProctemplate = NULLTAG;
				tag_t tProcess = NULLTAG;
				EPM_find_process_template("QuickUpdateChangeHistory",&tProctemplate);
				EPM_create_process("Test","Test",tProctemplate,1, tComp,Type,&tProcess);

			}
			
			MEM_free(cpObjectType);
			MEM_free(tAttchItemTags);
		}
	}
	MEM_free(ptTargetAttmnts);
	
	return retcode;
}


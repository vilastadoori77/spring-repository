
#define CLASS_MCO_REVISION                      "LBT9_MCORevision"
#define Attr_TARGET_STATUS						"lbt9_Target_Status"
#define Attr_CHANGE_FUNCTION					"lbt9_Change_Function"
#define	Attr_FIELD_MOD							"lbt9_Field_Mod"
#define	Attr_FINISHED_GOOD						"lbt9_Finished_Goods"
#define	Attr_NOTE								"lbt9_Note"
#define	Attr_ON_ORDER							"lbt9_On_Order"
#define	Attr_STOCK								"lbt9_Stock"
#define	Attr_WIP_STATUS							"lbt9_Work_In_Progress"
#define	Attr_CHANGE_DES							"lbt9_Description"
#define	PRE_APPROVAL_STATUS						"LBT9_PreApproval"
#define	SUBMITTED_STATUS						"LBT9_Submitted"
#define	CCB_STATUS								"LBT9_CCB"
#define	TASK_NAME_PRE_APPROVAL					"PreApproval"
#define	TASK_NAME_SUBMITTED						"Submitted"
#define	TASK_NAME_CCB							"CCB"
#define Attr_CHANGE_ANALYST						"lbt9_Change_Analyst"
#define SYSTEM_RECOMMENDED_REVIEWERS			"lbt9_Proposed_Reviewers"
#define PENDING_STATUS							"Pending"

#define LBT_NO_SOLUTION_ITEMS_MCO									(EMH_USER_error_base + 90 )
#define LBT_VALIDATION_MSG_MCO									    (EMH_USER_error_base + 91 )
#define	LBT_VALIDATION_MSG_CANCEL_MCO								(EMH_USER_error_base + 92 )

extern EPM_decision_t LBT9_VALIDATE_IMPLEMENT_MCO_WF(EPM_rule_message_t message);
extern EPM_decision_t LBT9_VALIDATE_CANCEL_MCO_WF(EPM_rule_message_t message);
extern int LBT_get_MCO_revision(tag_t task,           /* <I> */
								char *className,      /* <I> */
								int attachment_type,  /* <I> */
                                tag_t *object         /* <O> */
                               );
int fnGetMajorRevTags(tag_t *tsolutionRevTags,   /*<I>*/
					  int iSolutionRevsCount,    /*<I>*/
					  int *iMajorRevCount,       /*<O>*/
					  tag_t **tMajorRevTags        /*<OF>*/
					 );
int fnGetSolutionItemsNoPreliminaryStatus(tag_t *tsolutionRevTags,		/*<I>*/
										  int iSolutionRevsCount,		/*<I>*/
										  int *iSolutionItemsNoPreliminaryStatusCount,  /*<O>*/
										  tag_t **tSolutionItemsNoPreliminaryStatus		/*<OF>*/
										  );
int fnGetItemReleasedStatusNames(tag_t titemRev,
								 std::vector<std::string>& ReleasedStatusNames 
								);
int fnGetSolutionItemsPreviousWithPreliminaryStatus(tag_t *tsolutionRevTags,			/*<I>*/
													int iSolutionRevsCount,				/*<I>*/
													int *iInvalidPreviousRevCount,		/*<O>*/
													tag_t **tInvalidPreviousRevTags		/*<OF>*/
													);
int fnGetPreviousRevsWithPreliminaryStatus(tag_t tItemRevTag,								/*<I>*/
										   int *iPreviousRevWithPreliminaryStatusCount,		/*<O>*/
										   tag_t **tPreviousRevWithPreliminaryStatusTags	/*<OF>*/
										  );
logical IsItemRevWithPreliminaryStatus(tag_t tItemRevTag  /*<I>*/
									  );
int fnDisplayAlertForNoSolutionItems();
int LBT_ValidateSolutionItemRelationProperties(tag_t rev_tag,                         /* <I> */
                                                 int n_solution_revs,                 /* <I> */
												 tag_t *solution_rev_tags,			  /* <I> */												
												 char **cpSolItemNoRelProValues  /* <OF> */
												);
int fnGetEmptyPropertyValues(tag_t tRelationTag,	/*<I>*/
						 char **cpProNames		/*<OF>*/
						);

//Mail Notification Headers
extern int LBRT_MCO_Mail_Notify(EPM_action_message_t message);
int LBRT_MCO_Pre_Approval_Status_Notify(tag_t root_task,    /*<I>*/
										tag_t tCurrentTask  /*<I>*/
									   );
int fnGenerateMailBody (char *item_id,              /* <I> */
						char *item_rev_id,			/* <I> */
						tag_t item_rev_tag,			/* <I> */
						char **emailTemplatePath    /* <OF> */
					   );
extern int LBRT_MCO_Submitted_Status_Notify(tag_t root_task,    /*<I>*/
										tag_t tCurrentTask  /*<I>*/
										);
extern int LBRT_MCO_CCB_Status_Notify(tag_t root_task,    /*<I>*/
										tag_t tCurrentTask  /*<I>*/
										);
int fnGetUsersCommaSeparatedValue(char **cpUserList,				/*<I>*/
								  int iUserCount,					/*<I>*/
								  char **cpCommaSeperatedUserValue	/*<OF>*/
								 );
int fnGetEffectiveDatepatternMsg(char *cpInputString,  /*<I>*/
								 char **cpOutputString /*<OF>*/
								);
logical fnIsSolutionItemMinorRev(tag_t ItemRev		/*I*/
								);
int fnGetMinorRevTags(tag_t *tsolutionRevTags,   /*<I>*/
					  int iSolutionRevsCount,    /*<I>*/
					  int *iMinorRevCount,       /*<O>*/
					  tag_t **tMinorRevTags        /*<OF>*/
					 );
int fnGetAllSolutionItemWithTargetValueEmpty(tag_t rev_tag,                       /* <I> */
                                                 int n_solution_revs,                 /* <I> */
												 tag_t *solution_rev_tags,			  /* <I> */												
												 char **cpSolItemNoRelProValues		  /* <OF> */
												 );
int LBT_get_solution_items_with_no_target_Attribute_Value(tag_t rev_tag,                  /* <I> */
														  int n_solution_revs,            /* <I> */
														  tag_t *solution_rev_tags,       /* <I> */
														  char *cpAttributeValue,		  /* <I> */
														  int *n_no_target_sol_revs,      /* <O> */
														  tag_t **no_target_sol_rev_tags  /* <OF> */
														);
int fnGetAllMinorRevsWithPreliminaryStatus(tag_t *tMinorRevs,		/*<I>*/
										  int iMinorRevsCount,		/*<I>*/
										  int *iPreliminaryMinorRevCount,  /*<O>*/
										  tag_t **tPreliminaryMinorRevTags		/*<OF>*/
										  );
logical IsInitiatedUserValid(tag_t ItemRev);
logical ValidateMajorRevID(tag_t majorRevTag);

// MCO Auto Generated email headers
int fnMCOSubjectForAutoGeneratedMail	(char *MCOID,			/* <I> */
										 char *MCOName,			/* <I> */
										 const char *Title,		/* <I> */
										 char **subject			/* <OF> */
										);
int fnMCOBodyForPendingToPreApproval (	char *item_id,              /* <I> */
										char *item_rev_id,			/* <I> */
										tag_t item_rev_tag,			/* <I> */
										char **emailTemplatePath    /* <OF> */
									 );
int fnMCOBodyForPreApprovalToSubmitted (	char *item_id,              /* <I> */
											char *item_rev_id,			/* <I> */
											char *analyst_name,		    /* <I> */
											tag_t item_rev_tag,			/* <I> */
											char **emailTemplatePath    /* <OF> */
									   );
int fnMCOBodyForSubmittedToCCB      (   char *item_id,              /* <I> */
										char *item_rev_id,			/* <I> */
										tag_t item_rev_tag,			/* <I> */
										char **emailTemplatePath    /* <OF> */
								   );
int fnMCOBodyForPreApprovalToPending (	char *item_id,              /* <I> */
										char *item_rev_id,			/* <I> */
										char *originator_name,		/* <I> */
										tag_t item_rev_tag,			/* <I> */
										char **emailTemplatePath    /* <OF> */
									);
int fnMCOBodyForSubmittedToPending  (    char *item_id,              /* <I> */
										char *item_rev_id,			/* <I> */
										char *analyst,				/* <I> */
										char *decision_comments,    /* <I> */
										tag_t item_rev_tag,			/* <I> */
										char **emailTemplatePath    /* <OF> */
								   );
int fnMCOBodyForCCBToPending	(tag_t rev_tag,												/* <I> */
								 char *item_id,												/* <I> */
								 char *rev_id,												/* <I> */
								 char *AnaylstId,											/* <I> */
								 char **emailTemplatePath									/* <OF> */
								);
int fnMCOBodyForNotifyReleased	(tag_t rev_tag,												/* <I> */
								 char *item_id,												/* <I> */
								 char *rev_id,												/* <I> */
								 char *Analyst,												/* <I> */
								 char **emailTemplatePath									/* <OF> */
								);
int fnMCOBodyForNotifyImplemented	(tag_t rev_tag,												/* <I> */
									 char *item_id,												/* <I> */
									 char *rev_id,												/* <I> */
									 char *Originator,											/* <I> */
									 char **emailTemplatePath									/* <OF> */
									);
int fnMCOBodyForNotifyngAddedApprovers  (	  char *item_id,              /* <I> */
										      char *item_rev_id,		  /* <I> */
											  char *user_id,			  /* <I> */
											  tag_t item_rev_tag,		  /* <I> */
											  char **emailTemplatePath    /* <OF> */
										 );
int fnMCOBodyForNotifyngRemovedApprovers  (   char *item_id,              /* <I> */
										      char *item_rev_id,		  /* <I> */
											  char *user_id,			  /* <I> */
											  char *analyst_id,			  /* <I> */
											  tag_t item_rev_tag,		  /* <I> */
											  char **emailTemplatePath    /* <OF> */
										 );
int fnMCOBodyForOverallSignoff		 ( tag_t rev_tag,               /* <I> */
									   char *item_id,               /* <I> */
						               char *rev_id,                /* <I> */
                                       char **emailTemplatePath     /* <OF> */
						             );
int fnMCOBodyForApproveDecision	     ( tag_t rev_tag,               /* <I> */
									   char *item_id,               /* <I> */
						               char *rev_id,                /* <I> */
						               char *rejected_by_user_name, /* <I> */
									   char *decision_comments,     /* <I> */
                                       char **emailTemplatePath     /* <OF> */
						              );
int fnMCOBodyForRejectionDecision	 ( tag_t rev_tag,               /* <I> */
									   char *item_id,               /* <I> */
						               char *rev_id,                /* <I> */
						               char *rejected_by_user_name, /* <I> */
									   char *decision_comments,     /* <I> */
                                       char **emailTemplatePath     /* <OF> */
						              );
int fnMCOBodyForNotifyTaskAssignment(tag_t rev_tag,												/* <I> */
									 char *item_id,												/* <I> */
									 char *rev_id,												/* <I> */
									 char **emailTemplatePath									/* <OF> */
									);
int fnMCOBodyForPendingToCanceled	 (	char *item_id,              /* <I> */
										char *item_rev_id,			/* <I> */
										tag_t item_rev_tag,			/* <I> */
										char **emailTemplatePath    /* <OF> */
									 );
									 
int fnMCOBodyForNotifyLESIntegrationFailure (	char *item_id,              /* <I> */
												char *item_rev_id,			/* <I> */
												tag_t item_rev_tag,			/* <I> */
												char **emailTemplatePath    /* <OF> */
											);
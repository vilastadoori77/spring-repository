
/***************************************************************************************************
File			:	LBT9_BOMLine_header.h

Description		:	This file contains header files for BOMLines dll

Author			:   Ashok Raj S

Date Created    :   01/04/2015

****************************************************************************************************

History Log:

   Date         	 		Author							Action 

01/04/2015				  Ashok Raj S					Initial version

****************************************************************************************************/ 
#include <string.h>
#include <tc/tc.h>
#include <sa\am.h>
#include <bom/bom_msg.h>
#include <form/form.h>
#include <tccore/custom.h>
#include <pom/pom/pom.h>
#include <tccore/tctype.h>
#include <sa/groupmember.h>
#include <sa/group.h>
#include <sa/user.h>
#include <bom/bom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <tccore/custom.h>
#include <itk/mem.h>
#include <tccore/grm.h>
#include <tccore/method.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/signoff.h>
#include <epm/epm_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <fclasses/tc_date.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string>
#include <algorithm>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/iman_util.h>
#include <sa/tcfile.h>
#include <stdlib.h>
#include <tccore\workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <epm\epm_toolkit_tc_utils.h>
#include <tc\aliaslist.h>
#include <time.h>
#include <conio.h>
#include <ae/ae.h>
#include <stdio.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_string.h>
#include <res/res_itk.h>
#include <user_exits/user_exits.h>
#include <tccore/custom.h>
#include <tccore/method.h>
#include <exception>
#include <lov/lov.h>
#include <tccore/tc_msg.h>


#define ITK( argument )                                                   \
{                                                                         \
	int retcode = argument;                                               \
	if ( retcode != ITK_ok ) {                                            \
	char* s;                                                              \
	printf( " "#argument "\n" );                                          \
	printf( "  returns [%d]\n", retcode );                                \
	TC_write_syslog( " "#argument "\n" );                                 \
	TC_write_syslog( "  returns [%d]\n", retcode );                       \
	EMH_ask_error_text (retcode, &s);                                     \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);                 \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );          \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);        \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ ); \
	if (s != 0) MEM_free (s);                                             \
	}                                                                     \
}

#define ITK_NEW(ifail,argument)                                                               \
{                                                                                           \
   if ((ifail) == ITK_ok)                                                                   \
   {                                                                                        \
      if ( ( (ifail) = (argument) ) != ITK_ok )                                             \
      {                                                                                     \
         TC_write_syslog("\nFILE: %s LINE: %d\n", __FILE__, __LINE__);                      \
         printErrorMessage( ifail );                                               \
	  }                                                                                     \
   }                                                                                        \
}


// Constants for Bussiness Objects 

#define EMR_COMMERCIAL												"EMR_CommrclPart"
#define EMR_DOCUMENT												"EMR_Document"
#define BUSSINESS_DOC												"LBT9_BusDoc"
#define PRODUCT_DOC													"LBT9_SpecDoc"

// Constants for Business Objects properties

#define OBJECT_STRING												"object_string"
#define FIND_NO_PROP												"bl_sequence_no"
#define VALIDATE_QUANTITY											"bl_quantity"
#define ITEM_TYPE													"bl_item_object_type"
#define	UOM_VALUE													"bl_uom"
#define VALIDATE_REF_DESIGNATOR										"bl_ref_designator"
#define BOMLINE_PARENT												"bl_parent"
#define BOM_LINE_NAME												"bl_line_name"
#define BOM_LINE_OBJECT												"bl_line_object"
#define BOM_NOTES													"lbt9_bl_bom_notes"
#define BOM_NOTE_FORM												"LBT9_BomNote_Form"


#define LBT9_user_error_base									     (EMH_USER_error_base )
#define INVALID_QUANTITY_PSD										 (EMH_USER_error_base +  10)
#define VALUE_EMPTY                                                  (EMH_USER_error_base +  11)
#define INVALID_DOCUMENT_TYPE										 (EMH_USER_error_base +  12)
#define INVALID_FIND_NO												 (EMH_USER_error_base +  13)
#define INVALID_QUANTITY										     (EMH_USER_error_base +  14)
#define INVALID_QUANTITY_UOM										 (EMH_USER_error_base +  15)
#define UNEQUAL_REF_DESIGNATOR										 (EMH_USER_error_base +  16)
#define REF_DESIGNATOR_EXISTS										 (EMH_USER_error_base +  17)
#define FIND_NO_EXISTS                                               (EMH_USER_error_base +  18)
#define INVALID_UOM													 (EMH_USER_error_base +  19)
#define RESUME_COMMENTS												 (EMH_USER_error_base +  119)
#define MINOR_REV_VAL												 (EMH_USER_error_base +  501)


#ifdef __cplusplus
extern "C" {
#endif
 
extern DLLAPI int libLBT9_BOMLines_register_callbacks();
extern DLLAPI int libLBT9_BOMLines_register_handlers(int *decision, va_list args);

extern int LBT9_register_prop_methods();
extern int LBT9_validateQuantityPre (METHOD_message_t *message, va_list args);
extern int LBT9_validateFindNumber (METHOD_message_t *message, va_list args);
extern int LBT9_validateRefDesignator(METHOD_message_t *message, va_list args);
extern int LBT9_validateQuantityPost(METHOD_message_t *message, va_list args);
extern int LBT9_validateUOM(METHOD_message_t *message, va_list args);
extern int LBT9_Save_Bom_Notes(METHOD_message_t *message, va_list args);
extern int LBT9_Get_Bom_Notes(METHOD_message_t *message, va_list args);
extern int LBT9_Reset_Bom_Notes(METHOD_message_t *message, va_list args);
extern int LBT9_Reset_Bom_Notes_On_Delete_BVR(METHOD_message_t *message, va_list args);
extern int LBT9_Reset_Bom_Notes_Add(METHOD_message_t *message, va_list args);
extern int LBT9_val_Bom_Notes_modifiable(METHOD_message_t *message, va_list args);
int LBT9_ValidateMinorRev(tag_t line_tag, logical *decision);
void printErrorMessage								(int ifail													/* <I> */ 
													);
extern int LBT9_val_resume_comms(METHOD_message_t *message, va_list args);

void EMR_free(void* ptr);

#ifdef __cplusplus
}
#endif
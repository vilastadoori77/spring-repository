
/******************************************************************************************
File			:	LBT9_BOMLine_prop_methods.cpp

Description		:	For validating Property changes under BOM Line

Author			:   Ashok Raj S	

Date Created    :   01/04/2015

*******************************************************************************************

History Log:

  Date             Author                        Action

01/04/2015		Ashok Raj S			Added function LBT9_validateFindNumber

03/04/2015		Ashok Raj S			Added function LBT9_validateQuantityPre

06/04/2015		Ashok Raj S			Added function LBT9_validateRefDesignator		

10/08/2015		Ashok Raj S			Added function LBT9_validateQuantityPost

14/08/2015      Ashok Raj S			Added function LBT9_validateUOM
				
******************************************************************************************/

#include "LBT9_BOMLine_header.h"


/****************************************************************************************
 * Function Name	:  LBT9_validateFindNumber
   Method           :  METHOD_add_pre_condition
   Description      :  Validate Find Number Value entered by user
   Action           :  PreCondition
 ****************************************************************************************/

extern int LBT9_validateFindNumber(METHOD_message_t *message, va_list args)
{
   int  iFail				 = ITK_ok;
   int  ii                   = 0;
   int  iChildCount			 = 0;
   int 	iParentAttribute	 = 0;

   char*  cItemName  		 = NULL;
   char*  cDocType  		 = NULL;
   char*  value              = NULL;
   char*  cBomLineName		 = NULL;
   char*  cFindNoValue       = NULL;
   char*  ItemRev_string     = NULL;
     
   tag_t   bomLineTag		 = NULLTAG;
   tag_t   propTag			 = NULLTAG;
   tag_t   tParentTag		 = NULLTAG;
   tag_t  itemRevision_tag   = NULLTAG;
  
   tag_t* ptChildTag = NULL;

   propTag = va_arg(args, tag_t); 
   value = va_arg(args, char *);

   METHOD_PROP_MESSAGE_OBJECT(message, bomLineTag)
  
   if(propTag != NULLTAG)
   {
	    //Checks if given value is empty
	    if(tc_strcmp(value,"")==0)
		{
		     ITK(EMH_store_error(EMH_severity_error,VALUE_EMPTY));
			 return VALUE_EMPTY;
		}
		//Checks if given value is "0"
		if(tc_strcmp(value,"0")==0)
		{
			 ITK(AOM_ask_value_string(bomLineTag,ITEM_TYPE,&cItemName));
			 // Value can be "0" only for Document type
			 if(tc_strcmp(cItemName,EMR_DOCUMENT)!=0 && tc_strcmp(cItemName,EMR_COMMERCIAL)!=0 && tc_strcmp(cItemName,BUSSINESS_DOC)!=0 && tc_strcmp(cItemName,PRODUCT_DOC)!=0)
			 {
				  // Throws error is business object is other than Document 
			      ITK(EMH_store_initial_error(EMH_severity_error,INVALID_DOCUMENT_TYPE));
				  EMR_free(cItemName);
				  return INVALID_DOCUMENT_TYPE;
			 }
			 if(tc_strcmp(cItemName,EMR_COMMERCIAL)==0)
			 {
				 ITK(AOM_ask_value_tag(bomLineTag ,BOM_LINE_OBJECT, &itemRevision_tag));
                 ITK(AOM_ask_value_string(itemRevision_tag,OBJECT_STRING,&ItemRev_string));

				 // Throwserror is business object is Commercial Part
				 ITK(EMH_store_initial_error_s1(EMH_severity_error,INVALID_FIND_NO,ItemRev_string));
			     EMR_free(ItemRev_string);
				 EMR_free(cItemName);
				 return INVALID_FIND_NO;
			 }
		}
		//TO check if similar Find No exists
	    if(tc_strcmp(value,"")!=0)
		{			 
	    	ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
	        if(iParentAttribute !=NULL)
	        {
		    	ITK(BOM_line_ask_attribute_tag(bomLineTag,iParentAttribute,&tParentTag));
			    if(tParentTag != NULLTAG)
			    {
					// Getting Array of child tags
				    ITK(BOM_line_ask_child_lines(tParentTag,&iChildCount,&ptChildTag));
				    if(ptChildTag != NULLTAG)
				    {
						// Check the Find No. value against each Child lines
					    for ( ii = 0; ii < iChildCount; ii++)
					    {	
						   ITK(AOM_ask_value_string(ptChildTag[ii],FIND_NO_PROP,&cFindNoValue));
						   if(cFindNoValue!=NULL)
						   {
						       if(tc_strcmp(value,cFindNoValue)==0)
						       {
								   //To Skip the check with against the same child line
							       if(ptChildTag[ii]!=bomLineTag)
							       {
										ITK(AOM_ask_value_string(ptChildTag[ii],BOM_LINE_NAME,&cBomLineName));
										ITK(EMH_store_error_s2(EMH_severity_error,FIND_NO_EXISTS,value,cBomLineName));
										EMR_free(cItemName);
										EMR_free(cDocType);
										EMR_free(cBomLineName);
										EMR_free(cFindNoValue);
										EMR_free(ItemRev_string);
										EMR_free(ptChildTag);
										return FIND_NO_EXISTS;
							        }
							    }
						    }						 
					    }
				    }
			     }
		     }
		}
   }
   EMR_free(cItemName);
   EMR_free(cDocType);
   EMR_free(cBomLineName);
   EMR_free(cFindNoValue);
   EMR_free(ItemRev_string);
   EMR_free(ptChildTag);
   return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_validateQuantityPre
   Method           :  METHOD_add_pre_condition
   Description      :  Validate Quantity Value entered by user
   Action           :  PreCondition
 *******************************************************************************/

extern int LBT9_validateQuantityPre(METHOD_message_t *message, va_list args)
{
   int  iFail			  = ITK_ok;
   int  iUomAttribute     = 0;
   int  iRefDesigcount     = 0;
   int  iQuntityCount     = 0;

   char*  cItemType		  = NULL;
   char*  cUomValue		  = NULL;
   char*  value			  = NULL;
   char*  ItemRev_string  = NULL;
   char*  RefDesigValue   = NULL;
   
   char** RefDesigArray   = NULL;
  
   tag_t  bomLineTag	   = NULLTAG;
   tag_t  propTag		   = NULLTAG;
   tag_t  tUomValueTag	   = NULLTAG;
   tag_t  tUomTag		   = NULLTAG;
   tag_t  itemRevision_tag = NULLTAG;

   propTag = va_arg(args, tag_t); 
   value = va_arg(args, char *);

   METHOD_PROP_MESSAGE_OBJECT(message, bomLineTag)

   if(propTag != NULLTAG)
   {	
	    // Asks the name of the item
		ITK(AOM_ask_value_string(bomLineTag,ITEM_TYPE,&cItemType));
		if(cItemType!=NULL)
		{
			// Quantity value to be "0" always for PSD Document,else block
			if(tc_strcmp(value,"0")!=0)
			{
				if(tc_strcmp(cItemType,PRODUCT_DOC)==0)
				{				  				  
				  ITK(EMH_store_initial_error_s1(EMH_severity_error,INVALID_QUANTITY_PSD,"Product Specification Document"));
			      EMR_free(cItemType);
				  return INVALID_QUANTITY;
				}
			}
			if(tc_strcmp(value,"0")==0)
			{
				// Allow Quantity value to be "0" only for for Comercial part\Document
				if(tc_strcmp(cItemType,EMR_DOCUMENT)!=0 && tc_strcmp(cItemType,EMR_COMMERCIAL)!=0 && tc_strcmp(cItemType,BUSSINESS_DOC)!=0 && tc_strcmp(cItemType,PRODUCT_DOC)!=0)
				{				  				  
				  ITK(EMH_store_initial_error_s1(EMH_severity_error,INVALID_QUANTITY,cItemType));
			      EMR_free(cItemType);
				  return INVALID_QUANTITY;
				}
				// Allow Quantity value to be "0" for Comercial part if its UOM value is "RE" 
				if(tc_strcmp(cItemType,EMR_DOCUMENT)!=0 && tc_strcmp(cItemType,BUSSINESS_DOC)!=0 && tc_strcmp(cItemType,PRODUCT_DOC)!=0 && tc_strcmp(cItemType,EMR_COMMERCIAL)==0)
				{
					ITK(AOM_ask_value_tag(bomLineTag,UOM_VALUE,&tUomValueTag));
					if(tUomValueTag != NULLTAG)
					{
						ITK(BOM_line_look_up_attribute(UOM_VALUE,&iUomAttribute));
						ITK(BOM_line_ask_attribute_tag(bomLineTag,iUomAttribute,&tUomTag));
						if(tUomTag != NULLTAG)
						{
							ITK(BOM_line_ask_attribute_string(bomLineTag,iUomAttribute,&cUomValue));
							//Checks if Comercial part UOM value is "RE" , if Not throws error
							if(tc_strcmp(cUomValue,"RE")!=0)
							{																
								ITK(AOM_ask_value_tag(bomLineTag ,BOM_LINE_OBJECT, &itemRevision_tag))
                                ITK(AOM_ask_value_string(itemRevision_tag,OBJECT_STRING,&ItemRev_string))

				                ITK(EMH_store_initial_error_s1(EMH_severity_error,INVALID_QUANTITY_UOM,ItemRev_string));
			                    EMR_free(ItemRev_string);
								EMR_free(cItemType);
								EMR_free(cUomValue);
								return INVALID_QUANTITY_UOM;
							}
						}
					}
					//For handling UOM VAlue "each"( which holds value Null)
					if(tUomValueTag == NULLTAG)
					{
						 ITK(AOM_ask_value_tag(bomLineTag ,BOM_LINE_OBJECT, &itemRevision_tag))
                         ITK(AOM_ask_value_string(itemRevision_tag,OBJECT_STRING,&ItemRev_string))

				         ITK(EMH_store_initial_error_s1(EMH_severity_error,INVALID_QUANTITY_UOM,ItemRev_string));
			             EMR_free(cItemType);
						 EMR_free(ItemRev_string);
						 return INVALID_QUANTITY_UOM;
					}
			    }
		    }
	    }
   }
  EMR_free(cItemType);
  EMR_free(ItemRev_string);
  EMR_free(RefDesigValue);
  EMR_free(RefDesigArray);
  EMR_free(cUomValue);
  return iFail;
}

/********************************************************************************
 * Function Name	:  LBT9_validateRefDesignator
   Method           :  METHOD_add_action
   Description      :  Validate Reference Designator count against Quantity count
   Action           :  Post Action
 ********************************************************************************/

extern int LBT9_validateRefDesignator(METHOD_message_t *message, va_list args)
{ 
	int  iFail					= ITK_ok;
    int  iQuntityCount		    = 0; 
	int  iRefDesParsecount	    = 0;
	int  iRefDesCount			= 0;

	char** cRefDesigArray		= NULL;
	char** cParseArray		    = NULL;
    char*  cQuantity	        = NULL;
    char*  cRefDesValue		    = NULL;	
   
    tag_t  bomLineTag		    = NULLTAG;
    tag_t  propTag			    = NULLTAG;
	
    propTag = va_arg(args, tag_t); 
    cRefDesValue = va_arg(args, char *);

    METHOD_PROP_MESSAGE_OBJECT(message, bomLineTag)

	 if(propTag != NULLTAG)
	 {  //Get the Quantity Value
	    ITK(AOM_ask_value_string(bomLineTag,VALIDATE_QUANTITY,&cQuantity));
		iQuntityCount=atoi(cQuantity);
		//Get the parse array value
		ITK(EPM__parse_string(cRefDesValue,",",&iRefDesParsecount,&cRefDesigArray));
		//Displays warning if values are not equal
		for(int i=0;i<iRefDesParsecount;i++)
		{
			std::string str = cRefDesigArray[i];
			std::size_t strFind1 = str.find("(");
			std::size_t strFind2 = str.find(")");
			std::size_t strFind3 = str.find("[");
			std::size_t strFind4 = str.find("]");
			std::size_t strFind5 = str.find("-");
			
			if((strFind1!=std::string::npos) || (strFind2!=std::string::npos) || (strFind5!=std::string::npos))
			{
				logical bstrngFound = false;
				//checks if both open and closed paranthesis"( and )" are found in provided input
				if(strFind1!=std::string::npos)
				{				
					if(strFind2!=std::string::npos)
					{
						bstrngFound = true;
					}
				}				
				if(strFind2!=std::string::npos)
				{				
					if(strFind1!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				//checks if both open and closed brackets"[ and ]" are found in provided input
				if(strFind3!=std::string::npos)
				{				
					if(strFind4!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				if(strFind4!=std::string::npos)
				{				
					if(strFind3!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				//Gives the count of Ref. Desig. provided with "-" input. Eg. C1-C45. Here the count is 45
				if(!bstrngFound)
				{				
					if(strFind5!=std::string::npos)
					{
						int  iParsecount			= 0;	
						ITK(EPM__parse_string(cRefDesigArray[i],"-",&iParsecount,&cParseArray));
						if(iParsecount=2)
						{	
							int num[2]           = {0,0};						
							int iParseRefDesCount = 0;
							for(int j=0;j<iParsecount;j++)
							{								
								std::string str = cParseArray[j];							   
								sscanf_s(str.c_str(),"%*[^0123456789]%d",&num[j]);								
							}
							iParseRefDesCount = num[1] - num[0];
							iRefDesCount+=iParseRefDesCount;
						}
					}
				}
			}		
		}
		//Gives the total count of Ref. Designator proivded in BOMLine Ref. Desig column
		int iTotalCount = iRefDesCount + iRefDesParsecount;
		//Warning message is thrown to the user if there is a mismatch between count of "Ref. Designator" and "Quantity"
		if(iTotalCount!=iQuntityCount)
		{    ITK(EMH_clear_errors());
			 ITK(EMH_store_error(EMH_severity_warning,UNEQUAL_REF_DESIGNATOR));	
			 EMR_free(cQuantity);
             EMR_free(cRefDesigArray);
			 EMR_free(cRefDesValue);
			 return UNEQUAL_REF_DESIGNATOR;
		}
	 }
     EMR_free(cQuantity);
     EMR_free(cRefDesigArray);
	 EMR_free(cRefDesValue);
     return iFail;
}

/********************************************************************************
 * Function Name	:  LBT9_validateQuantityPost
   Method           :  METHOD_add_action
   Description      :  Validate Reference Designator count against Quantity count
   Action           :  Post Action
 ********************************************************************************/

extern int LBT9_validateQuantityPost(METHOD_message_t *message, va_list args)
{
	int  iFail					= ITK_ok;
    int  iQuntityCount		    = 0; 
	int  iRefDesParsecount	    = 0;
	int  iParsecount			= 0;	
	int  iRefDesCount			= 0;

	char** RefDesigArray		= NULL;
	char** ParseArray		    = NULL;
    char*  cQuantityValue	    = NULL;
    char*  RefDesigValue		= NULL;	
   
    tag_t  bomLineTag		    = NULLTAG;
    tag_t  propTag			    = NULLTAG;
	
    propTag = va_arg(args, tag_t); 
    cQuantityValue = va_arg(args, char *);

    METHOD_PROP_MESSAGE_OBJECT(message, bomLineTag)

	 if(propTag != NULLTAG)
	 {  //Get the Quantity Value
	    ITK(AOM_ask_value_string(bomLineTag,VALIDATE_REF_DESIGNATOR,&RefDesigValue));
		iQuntityCount=atoi(cQuantityValue);
		//Get the parse array value
		ITK(EPM__parse_string(RefDesigValue,",",&iRefDesParsecount,&RefDesigArray));
		//Displays warning if values are not equal
		for(int i=0;i<iRefDesParsecount;i++)
		{
			std::string str = RefDesigArray[i];
			std::size_t strFind1 = str.find("(");
			std::size_t strFind2 = str.find(")");
			std::size_t strFind3 = str.find("[");
			std::size_t strFind4 = str.find("]");
			std::size_t strFind5 = str.find("-");
			
			if((strFind1!=std::string::npos) || (strFind2!=std::string::npos) || (strFind5!=std::string::npos))
			{
				logical bstrngFound = false;
				//checks if both open and closed paranthesis"( and )" are found in provided input
				if(strFind1!=std::string::npos)
				{				
					if(strFind2!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				if(strFind2!=std::string::npos)
				{				
					if(strFind1!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				//checks if both open and closed brackets"[ and ]" are found in provided input
				if(strFind3!=std::string::npos)
				{				
					if(strFind4!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				if(strFind4!=std::string::npos)
				{				
					if(strFind3!=std::string::npos)
					{
						bstrngFound = true;
					}
				}
				//Gives the count of Ref. Desig. provided with "-" input. Eg. C1-C45. Here the count is 45
				if(!bstrngFound)
				{				
					if(strFind5!=std::string::npos)
					{
						ITK(EPM__parse_string(RefDesigArray[i],"-",&iParsecount,&ParseArray));
						if(iParsecount=2)
						{	
							int num[2]           = {0,0};					
							int parseRefDesCount = 0;
							for(int j=0;j<iParsecount;j++)
							{						
								std::string str = ParseArray[j];							   
								sscanf_s(str.c_str(),"%*[^0123456789]%d",&num[j]);
							}
							parseRefDesCount = num[1] - num[0];
							iRefDesCount+=parseRefDesCount;
						}
					}
				}
			}		
		}
		//Gives the total count of Ref. Designator proivded in BOMLine Ref. Desig column
		int iTotalCount = iRefDesCount + iRefDesParsecount;
		//Warning message is thrown to the user if there is a mismatch between count of "Ref. Designator" and "Quantity"
		if(iTotalCount!=iQuntityCount)
		{    ITK(EMH_clear_errors());
			 ITK(EMH_store_error(EMH_severity_warning,UNEQUAL_REF_DESIGNATOR));	
	         EMR_free(RefDesigArray);
			 EMR_free(RefDesigValue);
			 return UNEQUAL_REF_DESIGNATOR;
		}
	 }
     //EMR_free(cQuantityValue);
     EMR_free(RefDesigArray);
	 EMR_free(RefDesigValue);
     return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_validateUOM
   Method           :  METHOD_add_pre_condition
   Description      :  Validate UOM Value entered by user
   Action           :  PreCondition
 *******************************************************************************/

extern int LBT9_validateUOM(METHOD_message_t *message, va_list args)
{
   int  iFail					= ITK_ok;

   char*  cItemType				= NULL;
   char*  cUomValue				= NULL;

   tag_t  propTag				= NULLTAG;
   tag_t  bomLineTag		    = NULLTAG;

   propTag = va_arg(args, tag_t); 
   cUomValue = va_arg(args, char *);

   METHOD_PROP_MESSAGE_OBJECT(message, bomLineTag)

   if(propTag != NULLTAG)
   {	
	    //Get the name of the Item
		ITK(AOM_ask_value_string(bomLineTag,ITEM_TYPE,&cItemType));
		//UOM value to be "each" always for PSD, else throw error	
		if(tc_strcmp(cItemType,PRODUCT_DOC)==0)
		{				  				  
			if(cUomValue != NULL)
			{
		         ITK(EMH_store_error(EMH_severity_error,INVALID_UOM));
			     EMR_free(cItemType);				 
				 return INVALID_UOM;
			}
		}  
   }
   EMR_free(cItemType);
   return iFail;
}


/********************************************************************************
 * Function Name	:  LBT9_Save_Bom_Notes
   Method           :  PROP_set_value_string_msg
   Description      :  Set BOM Notes for BOMLine
   Action           :  Post Action
 ********************************************************************************/
extern int LBT9_Save_Bom_Notes(METHOD_message_t *message, va_list args)
{
	int iFail = ITK_ok;

    tag_t  tBomLineTag		    = NULLTAG;
    tag_t  tPropTag			    = NULLTAG;
	char * cBomNotes			= NULL;
	
    tPropTag = va_arg(args, tag_t); 
	cBomNotes = va_arg(args, char*);
	METHOD_PROP_MESSAGE_OBJECT(message, tBomLineTag)
	
	int iRevision = 0;
	int iOccId = 0;
	int iParentAttribute = 0;
	int iParentitemId = 0;
	int iBomLineTitle = 0;
	ITK(BOM_line_look_up_attribute("bl_revision", &iRevision));
	ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
	ITK(BOM_line_look_up_attribute("bl_item_item_id",&iParentitemId));
	ITK(BOM_line_look_up_attribute("bl_line_name",&iBomLineTitle));

	
	//ITK(BOM_line_look_up_attribute("bl_occ_fnd0objectId", &iOccId));
	if(tBomLineTag != NULLTAG)
	{
		logical decision = false;
		ITK(LBT9_ValidateMinorRev(tBomLineTag,&decision));
		if(!decision)
		{
			tag_t tRevisionTag = NULLTAG;
			tag_t tFormTag = NULLTAG; 
			char* cOccId = NULL;
			tag_t tParentTag = NULLTAG;

			char* cParentId = NULL;
			char* cBomLineTitle = NULL;
			ITK(BOM_line_ask_attribute_tag(tBomLineTag, iRevision, &tRevisionTag));
			ITK(BOM_line_ask_attribute_string(tBomLineTag,iBomLineTitle,&cBomLineTitle));
			//ITK(BOM_line_ask_attribute_string(tBomLineTag, iRevision, &cOccId));
			ITK(BOM_line_ask_attribute_tag(tBomLineTag,iParentAttribute,&tParentTag));
			ITK(BOM_line_ask_attribute_string(tParentTag,iParentitemId,&cParentId));
		


			//create a form and set the property on form
			char* cBomLineUid = NULL;
			//ITK(POM_tag_to_string(tBomLineTag, &cBomLineUid));
			ITK(FORM_create(cBomLineTitle, "", BOM_NOTE_FORM, &tFormTag));
			
				/* Construct a CreateInput object for Form */
			tag_t tFormTypeTag = NULLTAG;
			ITK(TCTYPE_find_type(BOM_NOTE_FORM,NULL, &tFormTypeTag));

			if(tFormTypeTag != NULLTAG)
			{
				tag_t tFormCreateInputTag = NULLTAG;
				ITK(TCTYPE_construct_create_input(tFormTypeTag, &tFormCreateInputTag));
				if(tFormCreateInputTag != NULLTAG)
				{
				
					ITK(AOM_set_value_string(tFormCreateInputTag, "object_name", cBomLineTitle));
					ITK(AOM_set_value_string(tFormCreateInputTag, "object_desc", cParentId));
					if(cBomNotes != NULL)
					{
						ITK(AOM_set_value_string(tFormCreateInputTag, "lbt9_Bom_Notes", cBomNotes));
					}

					ITK(TCTYPE_create_object(tFormCreateInputTag, &tFormTag));
			
			
					ITK(AOM_save(tFormTag));
			
					ITK(AOM_save_with_extensions(tFormTag));

					//set the form on the revision property
					if(tRevisionTag != NULLTAG)
					{
						int iFormCount	=	0;
						tag_t * tFormTags	=	NULL;
						ITK(AOM_ask_value_tags(tRevisionTag, "lbt9_BOM_Notes_Forms",&iFormCount,&tFormTags));

						int iNx = 0;
						logical lMatchForm	= false;
						for(iNx = 0; iNx < iFormCount ; iNx++)
						{
							char* cFormName = NULL;
							char* cFormDesc = NULL;
							//tag_t tBomLineFormtag = NULLTAG;
							ITK(AOM_ask_value_string(tFormTags[iNx], "object_name", &cFormName));
							ITK(AOM_ask_value_string(tFormTags[iNx], "object_desc", &cFormDesc));
							//ITK(POM_string_to_tag(cFormName, &tBomLineFormtag));
							if(tc_strcmp(cFormDesc ,cParentId) == 0 &&tc_strcmp(cFormName ,cBomLineTitle) == 0)
							{
								lMatchForm = true;
								ITK(AOM_refresh(tFormTags[iNx], POM_modify_lock));
								ITK(AOM_set_value_string(tFormTags[iNx], "lbt9_Bom_Notes", cBomNotes));
								ITK(AOM_save(tFormTags[iNx]));
								ITK(AOM_refresh(tFormTags[iNx], POM_no_lock));
							}
						}

						//set value on item rev
						if(!lMatchForm)
						{
							ITK(AOM_refresh(tRevisionTag, POM_modify_lock));
							ITK(AOM_set_value_tag_at(tRevisionTag,"lbt9_BOM_Notes_Forms", iFormCount, tFormTag));
							ITK(AOM_save(tRevisionTag));
							ITK(AOM_refresh(tRevisionTag, POM_no_lock));
						}


					}

				}

			}
		}

	}

	//if(tBomLineTag != NULLTAG)
	

    return iFail;
}

 int LBT9_ValidateMinorRev(tag_t line_tag, logical *decision)
{
	int iFail                  = ITK_ok;
	*decision = false;
	//tag_t line_tag	 = NULLTAG;
	tag_t tWindowTag  = NULLTAG;
	tag_t	tParentBL	= NULLTAG;
	//line_tag        = va_arg (args, tag_t);
	
	if (line_tag != NULL)
	{
		printf("Enter into LBT9_ValidateMinorRev...<line_tag> found...\n");
		BOM_line_ask_window(line_tag,&tWindowTag);
		
		if (tWindowTag != NULLTAG)
		{
			ITK(BOM_ask_window_top_line(tWindowTag,&tParentBL));
			if (tParentBL != NULLTAG)
			{
				int iRevision_Attribute	= 0;
				char *cpRevisionId = NULL;
				char *cpMinorRevFinder = NULL;
				char *cpRevisionIdChild = NULL;
				char *cpMinorRevFinderChild = NULL;
				
				BOM_line_look_up_attribute("bl_rev_current_revision_id",&iRevision_Attribute);
				
				if (iRevision_Attribute != 0)
				{
					BOM_line_ask_attribute_string(tParentBL,iRevision_Attribute,&cpRevisionId);	
					BOM_line_ask_attribute_string(line_tag,iRevision_Attribute,&cpRevisionIdChild);

					if (tc_strlen(cpRevisionId) > 0 && cpRevisionId != NULL)
					{
						cpMinorRevFinder = (char *)MEM_alloc(tc_strlen(cpRevisionId) + 1);
						tc_strcpy(cpMinorRevFinder,"");
						tc_strcpy(cpMinorRevFinder,tc_strstr(cpRevisionId,"."));
					}				
					if (tc_strlen(cpMinorRevFinder) > 0 && tc_strcmp(cpMinorRevFinder,"") != 0)
					{
						*decision = true;
					}
					if (tc_strlen(cpRevisionIdChild) > 0 && cpRevisionIdChild != NULL)
					{
						cpMinorRevFinderChild = (char *)MEM_alloc(tc_strlen(cpRevisionIdChild) + 1);
						tc_strcpy(cpMinorRevFinderChild,"");
						tc_strcpy(cpMinorRevFinderChild,tc_strstr(cpRevisionIdChild,"."));
					}				
					if (tc_strlen(cpMinorRevFinderChild) > 0 && tc_strcmp(cpMinorRevFinderChild,"") != 0)
					{
						*decision = true;
					}
				}

				if (cpRevisionIdChild != NULL)
				{
					MEM_free(cpRevisionIdChild);
				}
				if (cpMinorRevFinderChild != NULL)
				{
					MEM_free(cpMinorRevFinderChild);
				}
				if (cpRevisionId != NULL)
				{
					MEM_free(cpRevisionId);
				}
				if (cpMinorRevFinder != NULL)
				{
					MEM_free(cpMinorRevFinder);
				}
			}
		}
	}
	return iFail;
}
///Reset Bom Notes
/********************************************************************************
 * Function Name	:  LBT9_Reset_Bom_Notes
   Method           :  BOMLine_cut_msg
   Description      :  Reset BOM Notes for BOMLine
   Action           :  Post Action
 ********************************************************************************/

extern int LBT9_Reset_Bom_Notes(METHOD_message_t *message, va_list args)
{
	int iFail = ITK_ok;

    tag_t  tBomLineTag		    = NULLTAG;
    //tag_t  tPropTag			    = NULLTAG;
	//char * cBomNotes			= NULL;
	
    tBomLineTag = va_arg(args, tag_t); 
	//cBomNotes = va_arg(args, char*);
	//METHOD_PROP_MESSAGE_OBJECT(message, tBomLineTag)
	
	int iRevision = 0;
	int iOccId = 0;
	int iParentAttribute = 0;
	int iParentitemId = 0;
	int iBomLineTitle = 0;
	ITK(BOM_line_look_up_attribute("bl_revision", &iRevision));
	ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
	ITK(BOM_line_look_up_attribute("bl_item_item_id",&iParentitemId));
	ITK(BOM_line_look_up_attribute("bl_line_name",&iBomLineTitle));

	
	//ITK(BOM_line_look_up_attribute("bl_occ_fnd0objectId", &iOccId));

	if(tBomLineTag != NULLTAG)
	{
		tag_t tRevisionTag = NULLTAG;
		tag_t tFormTag = NULLTAG; 
		char* cOccId = NULL;
		tag_t tParentTag = NULLTAG;

		char* cParentId = NULL;
		char* cBomLineTitle = NULL;
		ITK(BOM_line_ask_attribute_tag(tBomLineTag, iRevision, &tRevisionTag));
		ITK(BOM_line_ask_attribute_string(tBomLineTag,iBomLineTitle,&cBomLineTitle));
		//ITK(BOM_line_ask_attribute_string(tBomLineTag, iRevision, &cOccId));
		ITK(BOM_line_ask_attribute_tag(tBomLineTag,iParentAttribute,&tParentTag));
		ITK(BOM_line_ask_attribute_string(tParentTag,iParentitemId,&cParentId));
		


		//create a form and set the property on form
		char* cBomLineUid = NULL;
		//set the form on the revision property
		if(tRevisionTag != NULLTAG)
		{
			int iFormCount	=	0;
			tag_t * tFormTags	=	NULL;
			ITK(AOM_ask_value_tags(tRevisionTag, "lbt9_BOM_Notes_Forms",&iFormCount,&tFormTags));

			int iNx = 0;
			logical lMatchForm	= false;
			for(iNx = 0; iNx < iFormCount ; iNx++)
			{
				char* cFormName = NULL;
				char* cFormDesc = NULL;
						//tag_t tBomLineFormtag = NULLTAG;
				ITK(AOM_ask_value_string(tFormTags[iNx], "object_name", &cFormName));
				ITK(AOM_ask_value_string(tFormTags[iNx], "object_desc", &cFormDesc));
						//ITK(POM_string_to_tag(cFormName, &tBomLineFormtag));
				if(tc_strcmp(cFormDesc ,cParentId) == 0 &&tc_strcmp(cFormName ,cBomLineTitle) == 0)
				{
					lMatchForm = true;
					ITK(AOM_refresh(tFormTags[iNx], POM_modify_lock));
					ITK(AOM_set_value_string(tFormTags[iNx], "lbt9_Bom_Notes", ""));
					ITK(AOM_save(tFormTags[iNx]));
					ITK(AOM_refresh(tFormTags[iNx], POM_no_lock));
				}
			}

		}

	}

    return iFail;
}

/********************************************************************************
 * Function Name	:  LBT9_Reset_Bom_Notes_Add
   Method           :  BOMLine_add_msg
   Description      :  Reset BOM Notes for BOMLine
   Action           :  Post Action
 ********************************************************************************/

extern int LBT9_Reset_Bom_Notes_Add(METHOD_message_t *message, va_list args)
{
	int iFail = ITK_ok;


	tag_t parent_tag = NULLTAG;
    tag_t item_tag   = NULLTAG;
    tag_t itemRev_tag = NULLTAG;
    tag_t bv_tag      = NULLTAG;
    //@param char *occType
    tag_t *tBomLineTag = NULL;
    //@param tag_t gde_tag
    //tag_t  tBomLineTag		    = NULLTAG;
    //tag_t  tPropTag			    = NULLTAG;
	//char * cBomNotes			= NULL;
	
    parent_tag = va_arg(args, tag_t); 
	item_tag = va_arg(args, tag_t); 
	itemRev_tag = va_arg(args, tag_t);
	tBomLineTag =  va_arg(args, tag_t*);
	//cBomNotes = va_arg(args, char*);
	//METHOD_PROP_MESSAGE_OBJECT(message, tBomLineTag)
	
	int iRevision = 0;
	int iOccId = 0;
	int iParentAttribute = 0;
	int iParentitemId = 0;
	int iBomLineTitle = 0;
	ITK(BOM_line_look_up_attribute("bl_revision", &iRevision));
	ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
	ITK(BOM_line_look_up_attribute("bl_item_item_id",&iParentitemId));
	ITK(BOM_line_look_up_attribute("bl_line_name",&iBomLineTitle));

	
	//ITK(BOM_line_look_up_attribute("bl_occ_fnd0objectId", &iOccId));

	if(parent_tag != NULLTAG)
	{
		tag_t tRevisionTag = NULLTAG;
		tag_t tFormTag = NULLTAG; 
		char* cOccId = NULL;
		tag_t tParentTag = NULLTAG;

		char* cParentId = NULL;
		char* cBomLineTitle = NULL;

		ITK(BOM_line_ask_attribute_string(parent_tag,iParentitemId,&cParentId));
		AOM_ask_value_string(itemRev_tag,"object_string",&cBomLineTitle);
		


		//create a form and set the property on form
		char* cBomLineUid = NULL;
		//set the form on the revision property
		if(itemRev_tag != NULLTAG)
		{
			int iFormCount	=	0;
			tag_t * tFormTags	=	NULL;
			ITK(AOM_ask_value_tags(itemRev_tag, "lbt9_BOM_Notes_Forms",&iFormCount,&tFormTags));

			int iNx = 0;
			logical lMatchForm	= false;
			for(iNx = 0; iNx < iFormCount ; iNx++)
			{
				char* cFormName = NULL;
				char* cFormDesc = NULL;
						//tag_t tBomLineFormtag = NULLTAG;
				ITK(AOM_ask_value_string(tFormTags[iNx], "object_name", &cFormName));
				ITK(AOM_ask_value_string(tFormTags[iNx], "object_desc", &cFormDesc));
						//ITK(POM_string_to_tag(cFormName, &tBomLineFormtag));
				if(tc_strcmp(cFormDesc ,cParentId) == 0 &&tc_strcmp(cFormName ,cBomLineTitle) == 0)
				{
					lMatchForm = true;
					ITK(AOM_refresh(tFormTags[iNx], POM_modify_lock));
					ITK(AOM_set_value_string(tFormTags[iNx], "lbt9_Bom_Notes", ""));
					ITK(AOM_save(tFormTags[iNx]));
					ITK(AOM_refresh(tFormTags[iNx], POM_no_lock));
				}
			}

		}

	}

    return iFail;
}
/********************************************************************************
 * Function Name	:  LBT9_Get_Bom_Notes
   Method           :  PROP_ask_value_string_msg
   Description      :  Getter method for BOM Notes property for BOMLine
   Action           :  Post Action
 ********************************************************************************/
extern int LBT9_Get_Bom_Notes(METHOD_message_t *message, va_list args)
{
	int iFail = ITK_ok;

    tag_t  tBomLineTag		    = NULLTAG;
    tag_t  tPropTag			    = NULLTAG;

	char** cBomNotes = NULL;
	
	tPropTag = va_arg(args, tag_t); 
	 
	cBomNotes = va_arg(args, char**);
	*cBomNotes = NULL;

	*cBomNotes = (char *)MEM_alloc(sizeof(char)*4001);
	METHOD_PROP_MESSAGE_OBJECT(message, tBomLineTag)

	char* cUserId = NULL;

	int iRevision = 0;
	int iParentAttribute = 0;
	int iParentitemId = 0;
	int iBomLineTitle = 0;

	ITK(BOM_line_look_up_attribute("bl_revision", &iRevision));
	ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
	ITK(BOM_line_look_up_attribute("bl_line_name",&iBomLineTitle))
	ITK(BOM_line_look_up_attribute("bl_item_item_id",&iParentitemId));
	if(tBomLineTag != NULLTAG)
	{
		tag_t tParentTag = NULLTAG;
		char* cParentId = NULL;
		tag_t tRevisionTag = NULLTAG;
		char* cBomLineTitle = NULL;

		ITK(BOM_line_ask_attribute_tag(tBomLineTag,iParentAttribute,&tParentTag));
		ITK(BOM_line_ask_attribute_string(tBomLineTag,iBomLineTitle,&cBomLineTitle));
		if(tParentTag != NULLTAG)
		{
			ITK(BOM_line_ask_attribute_string(tParentTag,iParentitemId,&cParentId));

			// ask for the revision and its forms

			ITK(BOM_line_ask_attribute_tag(tBomLineTag, iRevision, &tRevisionTag));

			if(tRevisionTag != NULLTAG)
			{
				int iFormCount	=	0;
				tag_t * tFormTags	=	NULL;
				ITK(AOM_ask_value_tags(tRevisionTag, "lbt9_BOM_Notes_Forms",&iFormCount,&tFormTags));

				int iNx = 0;
				logical lMatchForm	= false;
				char * cDisplayvalue = NULL;
				for(iNx = 0; iNx < iFormCount ; iNx++)
				{
					char* cFormName = NULL;
					char *cFormDesc = NULL;
				
					//tag_t tBomLineFormtag = NULLTAG;
					ITK(AOM_ask_value_string(tFormTags[iNx], "object_name", &cFormName));
					ITK(AOM_ask_value_string(tFormTags[iNx], "object_desc", &cFormDesc));
					//ITK(POM_string_to_tag(cFormName, &tBomLineFormtag));
					if(tc_strcmp(cFormName ,cBomLineTitle) == 0 && tc_strcmp(cFormDesc ,cParentId) == 0)
					{
					
						ITK(AOM_ask_value_string(tFormTags[iNx], "lbt9_Bom_Notes", &cDisplayvalue));
						break;

					}
				
				}
				if(cDisplayvalue != NULL)
				{
					strcpy(*cBomNotes,cDisplayvalue);
					MEM_free(cDisplayvalue);
				}
				if(cDisplayvalue == NULL)
				{
					strcpy(*cBomNotes,"");
					MEM_free(cDisplayvalue);
				}
			}
		}
		if(tParentTag == NULLTAG)
		{
			strcpy(*cBomNotes,"");
			//MEM_free(cDisplayvalue);
		}

	}	

	return iFail;
}
/***************************************************************************************
*	Function name	:	printErrorMessage

*	Description		:	This Function is used to get the ERROR Message
***************************************************************************************/

void printErrorMessage( int ifail )			/* <I> */					/* <I> */
{
   char *pcErrorText = NULL ;
   int iItkFail =	EMH_ask_error_text( ifail, &pcErrorText );
   TC_write_syslog("\nVADHandlers: Inside printErrorMessage");
  
 
   if ( iItkFail == ITK_ok )
   {
      if(pcErrorText != NULL)
      {
         TC_write_syslog( "\nMArkupHandlers ERR: Found ITK Error Code: %d  MSG: %s.\n", ifail, pcErrorText );
      }
   }
   else
   {
      TC_write_syslog( "\nMArkupHandlers ERR: Unable to get error message for %d \n", ifail );
   }
   if(pcErrorText != NULL)
   {
      EMR_free(pcErrorText );
      pcErrorText = NULL;
   }
}

/********************************************************************************
 * Function Name	:  LBT9_val_resume_comms
   Method           :  PROP_ask_value_string_msg
   Description      :  Getter method for StopShip resume comments property 
   Action           :  Pre Action
 ********************************************************************************/
extern int LBT9_val_resume_comms(METHOD_message_t *message, va_list args)
{
	tag_t tPropTag = NULLTAG;
	char* cResumeComm = NULL;
	tPropTag = va_arg(args, tag_t); 
    cResumeComm = va_arg(args, char *);

	//std::cout<<" The value of cResumeComm is "<<cResumeComm;
	//printf(" The value of cResumeComm is :%s",cResumeComm);

	if( cResumeComm != NULL)
	{

		tag_t tStopShiprevision = NULLTAG;
		tag_t townUser = NULLTAG;
		//printf(" The value of cResumeComm is :%s",cResumeComm);
		METHOD_PROP_MESSAGE_OBJECT(message, tStopShiprevision)
		if(tStopShiprevision != NULLTAG)
		{
			AOM_ask_value_tag(tStopShiprevision, "owning_user", &townUser);

			if( townUser != NULLTAG)
			{
				tag_t tmemberTag = NULLTAG;
				tag_t tloginUser = NULLTAG;
				// find the cpom_urrent user??
				POM_ask_member(&tmemberTag);
				SA_ask_groupmember_user(tmemberTag ,&tloginUser);
				if(tloginUser != townUser)
				{
					TC_write_syslog("\n error message is Users is not similar");
					ITK(EMH_clear_errors());
					ITK(EMH_store_error(EMH_severity_error,RESUME_COMMENTS));	
					
					return RESUME_COMMENTS;

				}
				else
				{
					TC_write_syslog("\n Resume Comments accepted as users are similar");
				}

			}
			

		}
		//EMR_free(cResumeComm);


	}
	return ITK_ok;
}
/********************************************************************************
 * Function Name	:  LBT9_val_Bom_Notes_modifiable
   Method           :  PROP_is_modifiable_msg
   Description      :  Validate is BomNotes Modifiable 
   Action           :  Post Action
 ********************************************************************************/
extern int LBT9_val_Bom_Notes_modifiable(METHOD_message_t *message, va_list args)
{
	//@param tag_t    prop_tag The tag of the property
    //@param logical*  value The value indicating whether a property can be modified by the user
	int iFail = ITK_ok;
	tag_t tPropTag = NULLTAG;
	logical *value = false;

	tPropTag = va_arg(args, tag_t); 
    value = va_arg(args, logical *);
	tag_t tBomLineTag = NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(message, tBomLineTag)

	if(*value)
	{
		logical decision = false;
		printf("User has no write access\n ");
		LBT9_ValidateMinorRev(tBomLineTag,&decision );
		if(decision)
		{
			int iParentAttribute = 0;
			int iParentLineAttribute = 0;
			tag_t tBomParTag = NULLTAG;
			char * cBomLineParent = NULL;
			ITK(BOM_line_look_up_attribute(BOMLINE_PARENT,&iParentAttribute));
			ITK(BOM_line_ask_attribute_tag(tBomLineTag, iParentAttribute, &tBomParTag));
			ITK(BOM_line_look_up_attribute("bl_indented_title",&iParentLineAttribute));
			ITK(BOM_line_ask_attribute_string(tBomParTag, iParentLineAttribute, &cBomLineParent));

			char * temp = NULL;

			temp = (char*) MEM_alloc(1024);

			tc_strcpy(temp, cBomLineParent);
			tc_strcat(temp, " cannot be modified. Please check your access rights");
			tc_strcat(temp, "\n");
			tc_strcat(temp, "The current user doesnot have write access to the object-");
			tc_strcat(temp, "\"");
			tc_strcat(temp, cBomLineParent);
			tc_strcat(temp, "\"");
			tc_strcat(temp, ".");


			ITK(EMH_store_error_s1(EMH_severity_error,MINOR_REV_VAL, temp));
			     //EMR_free(Temp);				 
			return MINOR_REV_VAL;
		}
	}

	return iFail;
}
/*******************************************************************************
*	Function name	:	EMR_free
*	Description		:	Frees the memory allocated to the pointer 'ptr'
*	Return type		:	void
*	Outputs 		:	N/A
 *******************************************************************************/

void EMR_free(void* ptr)	/* <I> */
{
	if(ptr != NULL)
	{
		MEM_free(ptr);
	}
}


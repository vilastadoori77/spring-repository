
/***************************************************************************************************
File			:	LBT9_BOMLine_register_handlers.cpp

Description		:	This file contains the functions to register the workflow handlers for Liebert

Author			:   Ashok Raj S

Date Created    :   01/04/2015

****************************************************************************************************

History Log:

   Date         	 		Author							Action 

01/04/2015				  Ashok Raj S					Initial version

01/04/2015				  Ashok Raj S					Added register callback methods

****************************************************************************************************/ 
#include "LBT9_BOMLine_header.h"
#include <user_exits/user_exits.h>
#include <tccore/custom.h>
#include <tccore/method.h>

extern DLLAPI int libLBT9_BOMLines_register_callbacks()
{
	int iFail = ITK_ok;
	
	ITK(CUSTOM_register_exit("libLBT9_BOMLines","USER_init_module",(CUSTOM_EXIT_ftn_t)libLBT9_BOMLines_register_handlers));
	return iFail;
}
extern DLLAPI int libLBT9_BOMLines_register_handlers(int *decision, va_list args)
{
	int iFail = ITK_ok;

	ITK(LBT9_register_prop_methods());

	return iFail;
}
extern int LBT9_register_prop_methods()
{
      int iFail = ITK_ok;      

	  //Identifies the registered method for adding Pre\Post action
	  METHOD_id_t LBT9_set_find_no_method_id;
	  METHOD_id_t LBT9_set_quantity_method_id;
	  METHOD_id_t LBT9_val_ref_des_method_id;
	  METHOD_id_t LBT9_val_quantity_id;
	  METHOD_id_t LBT9_set_uom_method_id;
	  METHOD_id_t LBT9_set_uom1_method_id;
	  METHOD_id_t LBT9_Save_Bom_Notes_id;
	  METHOD_id_t LBT9_Get_Bom_Notes_id;
	  METHOD_id_t LBT9_Reset_Bom_Notes_id;
	  METHOD_id_t LBT9_Reset_Bom_Notes_On_Delete_BVR_id;
	  METHOD_id_t LBT9_val_resume_comms_method_id;
	  METHOD_id_t LBT9_val_Bom_Notes_modifiable_method_id;

	  // Runtime Property Methods to validate values entered in Find No. column of BOMLINE
      ITK(METHOD_find_prop_method ("BOMLine", FIND_NO_PROP, PROP_set_value_string_msg, &LBT9_set_find_no_method_id));	 
      ITK(METHOD_add_pre_condition (LBT9_set_find_no_method_id, LBT9_validateFindNumber, 0));
	  
	  // Runtime Property Methods to validate values entered in Qunatity column of BOMLINE - Pre Condition
	  ITK(METHOD_find_prop_method ("BOMLine", VALIDATE_QUANTITY, PROP_set_value_string_msg, &LBT9_set_quantity_method_id));	 
      ITK(METHOD_add_pre_condition (LBT9_set_quantity_method_id, LBT9_validateQuantityPre, 0));

	  // Runtime Property Methods to validate values entered in Quantity column of BOMLINE - Post Action
	  ITK(METHOD_find_prop_method ("BOMLine", VALIDATE_QUANTITY, PROP_set_value_string_msg, &LBT9_val_quantity_id));	 
	  ITK(METHOD_add_action (LBT9_val_quantity_id,METHOD_post_action_type, LBT9_validateQuantityPost, 0));

	  // Runtime Property Methods to validate values entered in Reference Designator column of BOMLINE
	  ITK(METHOD_find_prop_method ("BOMLine", VALIDATE_REF_DESIGNATOR, PROP_set_value_string_msg, &LBT9_val_ref_des_method_id));	 
	  ITK(METHOD_add_action (LBT9_val_ref_des_method_id,METHOD_post_action_type, LBT9_validateRefDesignator, 0));

	  // Runtime Property Methods to validate values entered in Unit Of Measure column of BOMLINE
      ITK(METHOD_find_prop_method ("BOMLine", UOM_VALUE, PROP_validate_lov_string_msg, &LBT9_set_uom_method_id));	 
      ITK(METHOD_add_pre_condition (LBT9_set_uom_method_id, LBT9_validateUOM, 0));

	  // Runtime Property Methods for BOM Notes property on BOMLine
	  ITK(METHOD_find_prop_method ("BOMLine", BOM_NOTES, PROP_set_value_string_msg, &LBT9_Save_Bom_Notes_id));	 
	  ITK(METHOD_add_action (LBT9_Save_Bom_Notes_id,METHOD_post_action_type, LBT9_Save_Bom_Notes, 0));
	  ITK(METHOD_register_prop_method("BOMLine", BOM_NOTES, PROP_ask_value_string_msg, LBT9_Get_Bom_Notes,NULL,&LBT9_Get_Bom_Notes_id));
	  ITK(METHOD_attach_action("BOMLine", BOMLine_cut_msg, 2, LBT9_Reset_Bom_Notes,NULL));
	  ITK(METHOD_attach_action("BOMLine", BOMLine_add_msg, 2, LBT9_Reset_Bom_Notes_Add,NULL));

	  ITK(METHOD_find_prop_method ("BOMLine", BOM_NOTES, PROP_is_modifiable_msg, &LBT9_val_Bom_Notes_modifiable_method_id));	 
	  ITK(METHOD_add_action (LBT9_val_Bom_Notes_modifiable_method_id,METHOD_post_action_type, LBT9_val_Bom_Notes_modifiable, 0));


	  //Sto[ship Property Validation

	  ITK(METHOD_find_prop_method ("LBT9_StopShipRevision", "lbt9_Resume_Comments", PROP_set_value_string_msg, &LBT9_val_resume_comms_method_id));	 
	  ITK(METHOD_add_action (LBT9_val_resume_comms_method_id,METHOD_pre_action_type, LBT9_val_resume_comms, 0));
	  //ITK(METHOD_add_action (LBT9_val_ref_des_method_id,METHOD_post_action_type, LBT9_validateRefDesignator, 0));
	  
	  return iFail;
}

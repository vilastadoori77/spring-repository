        

/******************************************************************************************
File        :	LBRT_register_handlers.c

Description :	This file contains the functions to register the workflow handlers
				for Liebert.

*******************************************************************************************
History Log:

Date Created         	 							Author                      

18/02/2015										 Ashok Raj S            

******************************************************************************************/ 
#include "LBT9_Change_Handler.h"


extern DLLAPI int libLBT9_Change_register_callbacks()
{
	int iFail = ITK_ok;
	ITK(iFail,CUSTOM_register_exit("libLBT9_Change", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t) wiprocustom_userservice_register_methods));
	ITK(iFail,CUSTOM_register_exit("libLBT9_Change","USER_init_module",(CUSTOM_EXIT_ftn_t)libLBT9_Change_register_handlers));
	return iFail;
}
extern DLLAPI int libLBT9_Change_register_handlers(int *decision, va_list args)
{
	int iFail = ITK_ok;

	ITK(iFail,LBRT_register_action_handlers());
	ITK(iFail,LBRT_register_rule_handlers());
	return iFail;
}
extern int LBRT_register_action_handlers()
{
	int iFail = ITK_ok;
	//Handler from LBT9_LES_Integration.cpp
	ITK(iFail,EPM_register_action_handler("LBT9_BOM_EXP","",LBT9_BOM_EXP));

	//Handler from LBT9_Preliminary_ECN.cpp
	ITK(iFail,EPM_register_action_handler("LBT9_SET_PROTOTYPE_STATUS","",LBT9_SET_PROTOTYPE_STATUS));

	//Handlers From LBT9_Generic_Hanlders.cpp
	ITK(iFail,EPM_register_action_handler("LBT9_SET_VALUES_ON_CHANGE_OBJECT","",LBT9_SET_VALUES_ON_CHANGE_OBJECT));
	ITK(iFail,EPM_register_action_handler("LBT9_ASSIGN_TASK_TO_CA","",LBT9_ASSIGN_TASK_TO_CA));
	ITK(iFail,EPM_register_action_handler("LBT9_ASSIGN_ROUTING_TASK_TO_CA","",LBT9_ASSIGN_ROUTING_TASK_TO_CA));
	ITK(iFail,EPM_register_action_handler("LBT9_CHANGE_HISTORY","",LBT9_CHANGE_HISTORY));
	ITK(iFail,EPM_register_action_handler("LBT9_CREATE_CCB_SUBPROCESS","",LBT9_CREATE_CCB_SUBPROCESS));
	ITK(iFail,EPM_register_action_handler("LBT9_Set_Iteration_Property","",LBT9_Set_Iteration_Property));
	ITK(iFail,EPM_register_action_handler("LBT9_COMPLETE_ROUTING_TASK","",LBT9_COMPLETE_ROUTING_TASK));
	ITK(iFail,EPM_register_action_handler("LBT9_COMPLETE_CONDITION_TASK","",LBT9_COMPLETE_CONDITION_TASK));
	ITK(iFail,EPM_register_action_handler("LBT9_Set_Approval_Comments","",LBT9_Set_Approval_Comments));
	ITK(iFail,EPM_register_action_handler("LBT9_ASSIGN_PARTCIPANT","",LBT9_ASSIGN_PARTCIPANT));
	ITK(iFail,EPM_register_action_handler("LBT9_LES_FILE_IMPLEMENTED","",LBT9_LES_FILE_IMPLEMENTED));
	ITK(iFail,EPM_register_action_handler("LBT9_APPEND_COMPLETED_TO_APPROVER_FORM","",LBT9_APPEND_COMPLETED_TO_APPROVER_FORM));
	ITK(iFail,EPM_register_action_handler("LBT9_DATABASE_CA_TASK_ASSIGN","",LBT9_DATABASE_CA_TASK_ASSIGN));
	ITK(iFail,EPM_register_action_handler("LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM","",LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM));
	ITK(iFail,EPM_register_action_handler("LBT9_RELEASE_DATASET","",LBT9_RELEASE_DATASET));
	//For StopShip Action handler extern int LBT9_COMPLETE_RESUME_CONDITION_TASK(EPM_action_message_t message);
	ITK(iFail,EPM_register_action_handler("LBT9_COMPLETE_RESUME_CONDITION_TASK","",LBT9_COMPLETE_RESUME_CONDITION_TASK));

	ITK(iFail,EPM_register_action_handler("LBT9_DELEGATE_MAIL","",LBT9_DELEGATE_MAIL));

	//Hanlders from LBT9_ECN_Workflow.cpp
	ITK(iFail,EPM_register_action_handler("LBT9_ECN_SET_VALUES_ON_SOLUTION_ITEMS","",LBT9_ECN_SET_VALUES_ON_SOLUTION_ITEMS));
	ITK(iFail,EPM_register_action_handler("LBT9_Proposed_Reviewers","",LBT9_Proposed_Reviewers));
	ITK(iFail,EPM_register_action_handler("LBT9_val_and_Release_Design","",LBT9_val_and_Release_Design));
	
	//Handlers from LBT9_Mail_Generic_Handler.cpp
	ITK(iFail,EPM_register_action_handler("LBT9_PreApproval_Originator_Notify","",LBT9_PreApproval_Originator_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_Pending_Notify","",LBT9_Originator_Pending_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_Submitted_Notify","",LBT9_Analyst_Submitted_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_CCB_Notify","",LBT9_Analyst_CCB_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_Submitted_to_Pending_Notify","",LBT9_Analyst_Submitted_to_Pending_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Notify_Rejection","",LBT9_Notify_Rejection));
	ITK(iFail,EPM_register_action_handler("LBT9_Notify_Approval","",LBT9_Notify_Approval));
	ITK(iFail,EPM_register_action_handler("LBT9_Notify_Change_Analyst_After_All_Signoffs","",LBT9_Notify_Change_Analyst_After_All_Signoffs));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_CCB_To_Pending_Notify","",LBT9_Originator_CCB_To_Pending_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_CCB_To_Resumed_Rejection_Notify","",LBT9_Originator_CCB_To_Resumed_Rejection_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_Released_Notify","",LBT9_Originator_Released_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_Task_Notify","",LBT9_Analyst_Task_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Dev_Expire_Notify","",LBT9_Dev_Expire_Notify));
	
	//ITK(iFail,EPM_register_action_handler("LBT9_Originator_After_Release_Task_Notify","",LBT9_Originator_After_Release_Task_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_Task_Notify","",LBT9_Originator_Task_Notify));
	
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_Implemented_Notify","",LBT9_Analyst_Implemented_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_Or_Analyst_Canceled_Notify","",LBT9_Originator_Or_Analyst_Canceled_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_LES_Implementation_failed_notify","",LBT9_LES_Implementation_failed_notify));
	//LBT9_VALIDATE_CANCEL_StopShip_WF
	ITK(iFail,EPM_register_action_handler("LBT9_Originator_Or_Analyst_Canceled_StopShip_Notify","",LBT9_Originator_Or_Analyst_Canceled_StopShip_Notify));
	
	//CR Email handlers 
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_closed_Notify","",LBT9_Analyst_closed_Notify));

	//Preliminary ECN Workflow Email handler
	ITK(iFail,EPM_register_action_handler("LBT9_LES_Originator_Task_Notify","",LBT9_LES_Originator_Task_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Prelimn_LES_Integration_Failed","",LBT9_Prelimn_LES_Integration_Failed));
	ITK(iFail,EPM_register_action_handler("LBT9_Prelimn_LES_Integration_Succeeded","",LBT9_Prelimn_LES_Integration_Succeeded));
	

	//StopShip Email Handlers
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_Resumed_to_Released_Notify","",LBT9_Analyst_Resumed_to_Released_Notify));
	ITK(iFail,EPM_register_action_handler("LBT9_Analyst_CCB_Resume_Notify","",LBT9_Analyst_CCB_Resume_Notify));
	ITK(iFail, EPM_register_action_handler("LBT9_CREATE_CCB_SUBPROCESS_RESUME","",LBT9_CREATE_CCB_SUBPROCESS_RESUME));
	//LBT9_Analyst_Resume_Comments_Notify
	ITK(iFail, EPM_register_action_handler("LBT9_Analyst_Resume_Comments_Notify","",LBT9_Analyst_Resume_Comments_Notify));
	//Mailnotification for Resumed
	//extern int LBT9_Analyst_Resumed_to_Released_Notify(EPM_action_message_t message);
	ITK(iFail, EPM_register_action_handler("LBT9_Originator_Resumed_Notify","",LBT9_Originator_Resumed_Notify));
	ITK(iFail, EPM_register_action_handler("LBT9_Originator_Resume_Comments_Notify","",LBT9_Originator_Resume_Comments_Notify));
	//LBT9_VALIDATE_CANCEL_StopShip_WF
	ITK(iFail, EPM_register_action_handler("Custom Action Handler","",LBT9_Custom_Handler));
	ITK(iFail, EPM_register_action_handler("LBT9_Change_History_Update","",LBT9_Custom_Handler_Update_History));

	ITK(iFail, EPM_register_action_handler("LBT9_Add_Release_Status","",LBT9_Add_Release_Status));

	//Action handlers for updating PRECISE BOM
	ITK(iFail,EPM_register_action_handler("LBT9_GET_PRECISE_BOM","",LBT9_GET_PRECISE_BOM));
    ITK(iFail,EPM_register_action_handler("LBT9_UPDATE_PRECISE_BOM","",LBT9_UPDATE_PRECISE_BOM));

	return iFail;
}
extern int LBRT_register_rule_handlers()
{
	int iFail = ITK_ok;
	//Common Validation in Routing Task
	ITK(iFail,EPM_register_rule_handler("LBT9_Change_Analyst_validation","",LBT9_Change_Analyst_validation));
	
	//Preliminary ECN workflow Validation
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_ECN","",LBT9_VALIDATE_ECN));
	
	//Implement ECN Workflow Validation
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_IMPLEMENT_ECN_WF","",LBT9_VALIDATE_IMPLEMENT_ECN_WF));
	ITK(iFail,EPM_register_rule_handler("LBT9_Cancel_ECN_Validation","",LBT9_Cancel_ECN_Validation));

	// Cancel MCO Workflow	
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_CANCEL_MCO_WF","",LBT9_VALIDATE_CANCEL_MCO_WF));
	
	//LES Flat File Generation Workflow
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_LES_WORKFLOW","",LBT9_VALIDATE_LES_WORKFLOW));
	
	//Change Request Workflow Validation
    ITK(iFail,EPM_register_rule_handler("LBT9_CR_Validation","",LBT9_CR_Validation));
    ITK(iFail,EPM_register_rule_handler("LBT9_Cancel_CR_Validation","",LBT9_Cancel_CR_Validation));
	
	//ITK(iFail,EPM_register_rule_handler("LBT9_DCN_Validation","",LBT9_DCN_Validation));
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_IMPLEMENT_MCO_WF","",LBT9_VALIDATE_IMPLEMENT_MCO_WF));

	//Deviation Workflow Validation
    ITK(iFail,EPM_register_rule_handler("LBT9_DEV_RELEASE_VALIDATION","",LBT9_DEV_RELEASE_VALIDATION));
	ITK(iFail,EPM_register_rule_handler("LBT9_DEV_CANCEL_VALIDATION","",LBT9_DEV_CANCEL_VALIDATION));
	ITK(iFail,EPM_register_rule_handler("LBT9_DEV_EXPIRE_VALIDATION","",LBT9_DEV_EXPIRE_VALIDATION));

	//Implement DCN Workflow Validation
    ITK(iFail,EPM_register_rule_handler("LBT9_DCN_Validation","",LBT9_DCN_Validation));
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_CANCEL_DCN_WF","",LBT9_VALIDATE_CANCEL_DCN_WF));

	//Implement StopShip Workflow Validation
	ITK(iFail,EPM_register_rule_handler("LBT9_StopShip_Validation","",LBT9_StopShip_Validation));
	//LBT9_Resume_Comments_Validation
	ITK(iFail,EPM_register_rule_handler("LBT9_Resume_Comments_Validation","",LBT9_Resume_Comments_Validation));

	//LBT9_VALIDATE_CANCEL_StopShip_WF
	ITK(iFail,EPM_register_rule_handler("LBT9_VALIDATE_CANCEL_StopShip_WF","",LBT9_VALIDATE_CANCEL_StopShip_WF));
	
	//Task Delegation Validation
	ITK(iFail,EPM_register_rule_handler("LBT9_DELEGATE_VALIDATION","",LBT9_DELEGATE_VALIDATION));

	return iFail;
}

extern DLLAPI int wiprocustom_userservice_register_methods(int *decision, va_list args)
{
    /*
     * This function  registers the server side user defined functions for the CORBA
     * Server
     */

    /*
    *  Sample Call
    *  USERSERVICE_register_method("myfunction",myfunctionPtr,nArguments,inputArguments,returnParameter);
    */

    int retcode = ITK_ok;
	
	int nargs = 6;
	int retValueType;
	int *inputArgTypes;
	*decision = ALL_CUSTOMIZATIONS;
	
	//USER_function_t createOrRemoveSubProcess = createOrRemoveSubProcess;
	inputArgTypes = (int *) MEM_alloc(nargs * sizeof(int));

	inputArgTypes[0] = USERARG_TAG_TYPE;      /* Item Revision Tag */
	inputArgTypes[1] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;  /* Newly Added Group Member Tags*/
	inputArgTypes[2] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;  /* Removed Group Member Tags */
	inputArgTypes[3] = USERARG_STRING_TYPE; /* Logged in User String*/
	inputArgTypes[4] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;   /* Added Observers */
	inputArgTypes[5] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;   /* Removed Observers */ 
	
	retValueType = USERARG_INT_TYPE;
	
	retcode = USERSERVICE_register_method("createOrRemoveSubProcess", (USER_function_t) createOrRemoveSubProcess, nargs, inputArgTypes, retValueType );
	
	int nargs_note = 7;
	int *inputArgTypes_note;
	
	inputArgTypes_note = (int *) MEM_alloc(nargs_note * sizeof(int));

	inputArgTypes_note[0] = USERARG_TAG_TYPE;        /* Item Revision Tag */
	inputArgTypes_note[1] = USERARG_TAG_TYPE;        /* Logged in User Group Member Tag*/
	inputArgTypes_note[2] = USERARG_STRING_TYPE;     /* To List Separated by ;*/
	inputArgTypes_note[3] = USERARG_STRING_TYPE;     /* Comments ;*/
	inputArgTypes_note[4] = USERARG_STRING_TYPE;     /* isOriginator Selected <Yes/No>*/
	inputArgTypes_note[5] = USERARG_STRING_TYPE;     /* isCCB Members Selected <Yes/No>*/
	inputArgTypes_note[6] = USERARG_STRING_TYPE;     /* isAnalyst Selected <Yes/No>*/
	
	retcode = USERSERVICE_register_method("sendNote", (USER_function_t) sendNote, nargs_note, inputArgTypes_note, retValueType );
	
	int imasschange_args_count = 5;
	int *masschange_args;

	int retValueForMassChange = USERARG_INT_TYPE;

	masschange_args = (int *) MEM_alloc(imasschange_args_count * 2 * sizeof(int));
	masschange_args[0] = USERARG_STRING_TYPE; // Assembly string
	masschange_args[1] = USERARG_STRING_TYPE; // Part number to be mass changed
	masschange_args[2] = USERARG_STRING_TYPE; // Mode - Replace or Remove
	masschange_args[3] = USERARG_STRING_TYPE; // Replacing Part number
	masschange_args[4] = USERARG_STRING_TYPE; // ECN Number
	retcode = USERSERVICE_register_method("performMassChange", (USER_function_t) performMassChange, imasschange_args_count, masschange_args, retValueForMassChange );
	
	int ideriveChange_args_count = 4;
	int *deriveChange_args;

	deriveChange_args = (int *) MEM_alloc(ideriveChange_args_count * 4 * sizeof(int));
	deriveChange_args[0] = USERARG_STRING_TYPE;		// Selected Object Id
	deriveChange_args[1] = USERARG_STRING_TYPE;		// target Type
	deriveChange_args[2] = USERARG_STRING_TYPE;		// is CommonProperties Selected yes/no
	deriveChange_args[3] = USERARG_STRING_TYPE;		// is Datasets Selected yes/no
	
	retcode = USERSERVICE_register_method("deriveChange", (USER_function_t) deriveChange, ideriveChange_args_count, deriveChange_args, USERARG_STRING_TYPE );

    return retcode;
}

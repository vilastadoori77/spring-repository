	
/******************************************************************************************

File			:	LBRT_Preliminary_ECN_Validation.cpp

Description		:	Workflow action handlers for Libert

Author			:	Krupakar Reddy G

Date created	:   10/05/2015

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added LBT_get_past_effective_solution_items

01/06/2015		Krupkar Reddy G             Added LBT9_get_solution_items_with_no_disposition_values

28/10/2015		Krupkar Reddy G             Added LBT9_get_solution_items_with_no_ESD_value

01/06/2015		Krupkar Reddy G             Added LBRT_VALIDATE_IMPLEMENT_ECN_WF

07/07/2015		Krupkar Reddy G             Added fnForComparingDates
					
******************************************************************************************/
#include "LBT9_Change_Handler.h"




/****************************************************************************************************
*	Handler name	:	LBT_get_past_effective_solution_items

*	Description		:	function used to get the effectivity date of the solution item and validate 
						whether the date is after current date or not

******************************************************************************************************/


int LBT_get_past_effective_solution_items(tag_t ecn_rev,                 /* <I> */
										  int n_sol_revs,                /* <I> */
										  tag_t *sol_rev_tags,           /* <I> */
										  int *n_past_effect_revs,       /* <I> */ 
										  tag_t **past_effect_rev_tags   /* <I> */
										 )
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	char *current_date_string = NULL;
	
	date_t currentDate = NULLDATE;

	*n_past_effect_revs = 0;
	*past_effect_rev_tags = NULL;
	
	ITK(retcode,GRM_find_relation_type("CMHasSolutionItem", &relation_type_tag));
	
	if ( relation_type_tag == NULLTAG )
	{
		return retcode;
	}
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	
	ITK(retcode,ITK_string_to_date(current_date_string, &currentDate));
	
	for (int inx = 0; inx < n_sol_revs; inx++)
	{
		tag_t relation_tag = NULLTAG;
		
		ITK(retcode,GRM_find_relation(ecn_rev, sol_rev_tags[inx], relation_type_tag, &relation_tag));
		
		if ( relation_tag != NULLTAG )
		{
			int answer;
			
			date_t effective_date = NULLDATE;
			
			ITK(retcode,AOM_ask_value_date(relation_tag, "lbt9_Effective_Date", &effective_date));
			
			ITK(retcode,POM_compare_dates(effective_date, currentDate, &answer));
			
			
			if ( answer == -1 )
			{
				logical Value = false;
				fnForComparingDates(effective_date,currentDate,&Value);
				
				if(!Value)
				{
					*past_effect_rev_tags = (tag_t *) MEM_realloc(*past_effect_rev_tags,(*n_past_effect_revs+1)*sizeof(tag_t));
					(*past_effect_rev_tags)[*n_past_effect_revs] = sol_rev_tags[inx];
					*n_past_effect_revs = *n_past_effect_revs + 1;
				}
			}

			
		}
		else
		{
			*past_effect_rev_tags = (tag_t *) MEM_realloc(*past_effect_rev_tags,(*n_past_effect_revs+1)*sizeof(tag_t));
			(*past_effect_rev_tags)[*n_past_effect_revs] = sol_rev_tags[inx];
			*n_past_effect_revs = *n_past_effect_revs + 1;
		}
	}
	
	EMR_free(current_date_string);
	
	return retcode;
}

/****************************************************************************************************
*	Handler name	:	fnForComparingDates

*	Description		:	function used to check the effective date is same as current date

******************************************************************************************************/

int fnForComparingDates(date_t effective_date,			/* <I> */
						date_t currentDate,				/* <I> */
						logical *Value					/* <O> */
						)
{
	int retcode			=	ITK_ok;
	char *	DateFormat	=	NULL;
	char * cEffDate		=	NULL;
	char * cCurrtDate	=	NULL;
	int		iEffMonth	=	0;
	int		iEffDay		=	0;
	int		iEffYear	=	0;
	int		iEffHour	=	0;
	int		iEffMinute	=	0;
	int		iEffSecond	=	0;
	int		iCurrMonth	=	0;
	int		iCurrDay	=	0;
	int		iCurrYear	=	0;
	int		iCurrHour	=	0;
	int		iCurrMinute	=	0;
	int		iCurrSecond	=	0;
	*Value	=	false;
	ITK(retcode,DATE_get_internal_date_string_format(&DateFormat));
	ITK(retcode,DATE_date_to_string(effective_date,DateFormat,&cEffDate));
	ITK(retcode,DATE_date_to_string(currentDate,DateFormat,&cCurrtDate));

	DATE_string_to_date(cEffDate,DateFormat,&iEffMonth,&iEffDay,&iEffYear,&iEffHour,&iEffMinute,&iEffSecond);	
	DATE_string_to_date(cCurrtDate,DateFormat,&iCurrMonth,&iCurrDay,&iCurrYear,&iCurrHour,&iCurrMinute,&iCurrSecond);

	if((iEffYear == iCurrYear) && (iEffMonth == iCurrMonth) && (iEffDay == iCurrDay))
	{
		*Value	= true;
	}
	else
	{
		*Value	= false;
	}
	EMR_free(DateFormat);
	EMR_free(cEffDate);
	EMR_free(cCurrtDate);
	return retcode;
}

/****************************************************************************************************
*	Handler name	:	LBT9_get_solution_items_with_no_disposition_values

*	Description		:	function used to check the modify solution item properties of the solution items

******************************************************************************************************/

int LBT9_get_solution_items_with_no_disposition_values(tag_t rev_tag,	 	      /* <I> */
													   int n_solution_revs,       /* <I> */
													   tag_t *solution_rev_tags,  /* <I> */
													   const char* property_name, /* <I> */
													   int *n_no_sol_revs,		  /* < O > */
													   tag_t **no_sol_rev_tags	  /*< OF >*/
													   )
{
	int retcode				=	ITK_ok;
	char *cPropertyValue	=	NULL;
	tag_t relation_type_tag	=	NULLTAG;
	tag_t relation_tag		=	NULLTAG;
	
	ITK(retcode,GRM_find_relation_type("CMHasSolutionItem", &relation_type_tag));
	if(relation_type_tag != NULLTAG)
	{
		for(int i=0;i<n_solution_revs;i++)
		{
			ITK(retcode,GRM_find_relation(rev_tag, solution_rev_tags[i], relation_type_tag, &relation_tag));
			if(relation_tag	!= NULLTAG)
			{
				AOM_ask_value_string(relation_tag,property_name,&cPropertyValue);
				printf("Property Value is %s",cPropertyValue);
				if (tc_strcmp(cPropertyValue,"")==0 )
				//if ( cPropertyValue == NULL || tc_strlen(cPropertyValue) <= 0 )
				{
					*no_sol_rev_tags = (tag_t *) MEM_realloc(*no_sol_rev_tags,(*n_no_sol_revs+1)*sizeof(tag_t));
					(*no_sol_rev_tags)[*n_no_sol_revs] = solution_rev_tags[i];
					*n_no_sol_revs = *n_no_sol_revs + 1;
				}
			}
			EMR_free(cPropertyValue);
		}
	}
	return retcode;
}


/****************************************************************************************************
*	Handler name	:	LBT9_get_solution_items_with_no_ESD_value

*	Description		:	function used to check the modify solution item properties of the solution items

******************************************************************************************************/

int LBT9_get_solution_items_with_no_ESD_value(tag_t rev_tag,	 	      /* <I> */
											  int n_solution_revs,       /* <I> */
										      tag_t *solution_rev_tags,  /* <I> */
										      const char* property_name, /* <I> */
											  int *n_no_sol_revs,		  /* < O > */
											  tag_t **no_sol_rev_tags	  /*< OF >*/
											 )
{
	int retcode				=	ITK_ok;
	char *cPropertyValue	=	NULL;
	
	
	
	for(int i=0;i<n_solution_revs;i++)
	{
		char * cpObjectType	=	NULL;
		ITK(retcode,WSOM_ask_object_type2(solution_rev_tags[i],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp(cpObjectType,"EMR_CommrclPart Revision")==0)
		{
			char *  cPropertyValue	=	NULL;
			ITK(retcode,AOM_ask_value_string(solution_rev_tags[i],property_name,&cPropertyValue));
				
			if ( tc_strcmp(cPropertyValue,"")==0 )
			{
				*no_sol_rev_tags = (tag_t *) MEM_realloc(*no_sol_rev_tags,(*n_no_sol_revs+1)*sizeof(tag_t));
				(*no_sol_rev_tags)[*n_no_sol_revs] = solution_rev_tags[i];
				*n_no_sol_revs = *n_no_sol_revs + 1;
			}
			
			EMR_free(cPropertyValue);
		}
			
		EMR_free(cpObjectType);
	}

	return retcode;
}

/****************************************************************************************************
*	Handler name	:	LBT9_VALIDATE_IMPLEMENT_ECN_WF

*	Description		:	Rule Handler- used to validate the Implement ECN Workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_VALIDATE_IMPLEMENT_ECN_WF(EPM_rule_message_t message)
{
	int retcode = ITK_ok;
	tag_t root_task = NULLTAG;
	tag_t rev_tag = NULLTAG;
	EPM_decision_t decision = EPM_nogo;
	logical validationFailed = false;
	logical all_ok = true;
	int j = 0;
	int i = 0;
	int m = 0;
	char *past_solution_revs = NULL;
	char *no_target_solution_revs = NULL;
	char *no_change_function_solution_revs = NULL;
	char *no_ESD_value_solution_revs	=	NULL;
	char *child_not_in_solution_list = NULL;
	char *obsolete_child_list = NULL;
	char *inactive_child_list = NULL;
	tag_t *tObsoleteParenttags					=	NULL;
	tag_t *tInactiveParenttags					=	NULL;
	tag_t *tUnreleasedParenttags				=	NULL;
	logical ValidationObsoleteChild = false;
	logical ValidationInactiveChild = false;
	logical ValidationUnreleasedChild = false;

	ITK(retcode,EPM_ask_root_task (message.task, &root_task));		
	ITK(retcode,LBT_get_ecn_revision(root_task, CLASS_ECN_REVISION, EPM_target_attachment, &rev_tag));

	if(rev_tag != NULLTAG)
	{
		int n_solution_revs = 0;
		
		tag_t *solution_rev_tags = NULL;
		
		logical UserIsOriginator = false;
		ITK(retcode, fnToCheckCurrentUserIsOriginator(rev_tag, &UserIsOriginator));
		if(UserIsOriginator)
		{
			logical validationForStatus = false;	
			ITK(retcode, fnToValidateChangeObjectStatus(rev_tag,PENDING_STATUS,&validationForStatus));
			if(validationForStatus)
			{
				ITK(retcode,LBT_get_related_objects(rev_tag, "CMHasSolutionItem", &n_solution_revs, &solution_rev_tags));
		
				if ( n_solution_revs == 0 )
				{
					EMH_clear_errors();
					EMH_store_initial_error_s1(EMH_severity_user_error, LBT_NO_SOLUTION_ITEMS,"");
					decision = EPM_nogo;
					validationFailed = true;
					return decision;
				}
				else if(n_solution_revs > 0 && solution_rev_tags != NULLTAG)
				{
					char *Temp = NULL;
					char *released_solution_revs = NULL;
					char *prelimn_sol_prev_revs = NULL;
					for (int inx = 0; inx < n_solution_revs; inx++)
					{
						logical IsSolutionItemStausNotPreliminary = false;
						int n_rel_sol_revs = 0;
						tag_t *rel_sol_rev_tags = NULL;
						int n_prelimn_sol_prev_revs = 0;
						tag_t *prelimn_sol_prev_revs_tags = NULL;
						tag_t *past_sol_rev_tags = NULL;
						tag_t *no_target_sol_rev_tags = NULL;
						tag_t *no_change_function_sol_rev_tags = NULL;
						tag_t *no_ESD_value_sol_rev_tags   = NULL;
						// checking the Status of the Solution Item
						ITK(retcode,LBT_Is_Solution_Items_Status_Preliminary_or_Prototype(n_solution_revs,solution_rev_tags,&n_rel_sol_revs, &rel_sol_rev_tags,&IsSolutionItemStausNotPreliminary));
						if (IsSolutionItemStausNotPreliminary)
						{	

							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_rel_sol_revs, rel_sol_rev_tags, &released_solution_revs));
							EMR_free(rel_sol_rev_tags);
							decision = EPM_nogo;
							all_ok = false;
						}
						int bvrCount = 0;
						tag_t *bvrTags = NULL;
						//checking the Status of the previous revisions of the solution items it should not be preliminary
						ITK(retcode,LBT_get_lower_rev_solution_items(n_solution_revs,solution_rev_tags,&n_prelimn_sol_prev_revs,&prelimn_sol_prev_revs_tags));
						if(n_prelimn_sol_prev_revs > 0 && prelimn_sol_prev_revs_tags != NULL)
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_prelimn_sol_prev_revs,prelimn_sol_prev_revs_tags,&prelimn_sol_prev_revs));
							EMR_free(prelimn_sol_prev_revs_tags);
							all_ok = false;
						}
						//checking the BOM view revision of the Soluiton item having Obsolete status or not
						ITK(retcode,ITEM_rev_list_bom_view_revs(solution_rev_tags[inx], &bvrCount, &bvrTags));
						for (int jnx = 0; jnx < bvrCount; jnx++)
						{
							int n_unreleased_child = 0;
							int n_child_not_in_solutions = 0;
							int n_obsolete_child = 0;
							int n_inactive_child = 0;
							tag_t *unreleased_child_tags = NULL;
							tag_t *child_not_in_solution = NULL;
							tag_t *obsolete_children = NULL;
							tag_t *inactive_children = NULL;

							ITK(retcode,LBT_get_obsolete_children(solution_rev_tags[inx], bvrTags[jnx], &n_obsolete_child, &obsolete_children));
							if(obsolete_children != NULL && n_obsolete_child > 0)
							{
								tObsoleteParenttags = (tag_t *)MEM_realloc(tObsoleteParenttags,sizeof(tag_t)*(i+1));
								tObsoleteParenttags[i] = solution_rev_tags[inx];
								i++;
								ValidationObsoleteChild = true;
							}
							if(ValidationObsoleteChild)
							{
								all_ok = false;
							}
							if(obsolete_children != NULL)
							{
								EMR_free(obsolete_children);
							}
							ITK(retcode,LBT_get_inactive_children(solution_rev_tags[inx], bvrTags[jnx], &n_inactive_child, &inactive_children));
							if(inactive_children != NULL && n_inactive_child > 0)
							{
								tInactiveParenttags = (tag_t *)MEM_realloc(tInactiveParenttags,sizeof(tag_t)*(m+1));
								tInactiveParenttags[m] = solution_rev_tags[inx];
								m++;
								ValidationInactiveChild = true;
							}
							if(ValidationInactiveChild)
							{
								all_ok = false;
							}
							if(inactive_children != NULL)
							{
								EMR_free(inactive_children);
							}
							ITK(retcode,LBT_get_unreleased_children(solution_rev_tags[inx], bvrTags[jnx], &n_unreleased_child, &unreleased_child_tags));
				
							ITK(retcode,LBT_checkif_unreleased_revs_exist_in_solutions(n_solution_revs, solution_rev_tags, n_unreleased_child, unreleased_child_tags, &n_child_not_in_solutions, &child_not_in_solution));
				
							if ( n_child_not_in_solutions > 0 )
							{
								tUnreleasedParenttags = (tag_t *)MEM_realloc(tUnreleasedParenttags,sizeof(tag_t)*(j+1));
								tUnreleasedParenttags[j] = solution_rev_tags[inx];
								j++;
								ValidationUnreleasedChild = true;
								EMR_free(unreleased_child_tags);
								EMR_free(child_not_in_solution);
							}
							if(ValidationUnreleasedChild)
							{
								all_ok = false;
							}
						}
						EMR_free(bvrTags);
						int n_past_sol_revs = 0;
						ITK(retcode,LBT_get_past_effective_solution_items(rev_tag, n_solution_revs, solution_rev_tags, &n_past_sol_revs, &past_sol_rev_tags));
						if ( n_past_sol_revs > 0 )
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_past_sol_revs, past_sol_rev_tags, &past_solution_revs));
							EMR_free(past_sol_rev_tags);
							decision = EPM_nogo;
							all_ok = false;
						}
						int n_no_target_sol_revs = 0;
						ITK(retcode,LBT9_get_solution_items_with_no_disposition_values(rev_tag, n_solution_revs, solution_rev_tags,TARGET_STATUS, &n_no_target_sol_revs, &no_target_sol_rev_tags));
						if ( n_no_target_sol_revs > 0 )
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_no_target_sol_revs, no_target_sol_rev_tags, &no_target_solution_revs));
							decision = EPM_nogo;
							all_ok = false;
							EMR_free(no_target_sol_rev_tags);
						}
						int n_no_change_function_sol_revs = 0;
						ITK(retcode,LBT9_get_solution_items_with_no_disposition_values(rev_tag, n_solution_revs, solution_rev_tags,CHANGE_FUNCTION, &n_no_change_function_sol_revs, &no_change_function_sol_rev_tags));
						if ( n_no_change_function_sol_revs > 0 )
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_no_change_function_sol_revs, no_change_function_sol_rev_tags, &no_change_function_solution_revs));
							decision = EPM_nogo;
							all_ok = false;
							EMR_free(no_change_function_sol_rev_tags);
						}
						int n_no_ESD_value_sol_revs	= 0;
						ITK(retcode,LBT9_get_solution_items_with_no_ESD_value(rev_tag, n_solution_revs, solution_rev_tags,"lbt9_ESD_Sensitive", &n_no_ESD_value_sol_revs, &no_ESD_value_sol_rev_tags));
						if ( n_no_ESD_value_sol_revs > 0 )
						{
							ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(n_no_ESD_value_sol_revs, no_ESD_value_sol_rev_tags, &no_ESD_value_solution_revs));
							decision = EPM_nogo;
							all_ok = false;
							EMR_free(no_ESD_value_sol_rev_tags);
						}
					}
					if(ValidationObsoleteChild)
					{
						ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(i, tObsoleteParenttags, &obsolete_child_list));
						EMR_free(tObsoleteParenttags);
						decision = EPM_nogo;
					}
					if(ValidationInactiveChild)
					{
						ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(m, tInactiveParenttags, &inactive_child_list));
						EMR_free(tInactiveParenttags);
						decision = EPM_nogo;
					}
					if(ValidationUnreleasedChild)
					{
						ITK(retcode,LBT_getCommaSeparatedListOfItemRevs(j, tUnreleasedParenttags, &child_not_in_solution_list));
						EMR_free(tUnreleasedParenttags);
						decision = EPM_nogo;
					}
					Temp = (char *)MEM_alloc(tc_strlen("1. Following Solution Items are not in Preliminary or Prototype State:") + tc_strlen("2. Following Solution Items have Obsolete children") + tc_strlen("\n-- Following Solution Items have Inactive children:\n") + tc_strlen("3. Following Solution Items have Unreleased children which have not been added to the same ECN") + tc_strlen(obsolete_child_list) + tc_strlen(child_not_in_solution_list) + tc_strlen(released_solution_revs) + 1700 * n_solution_revs + 1);
					tc_strcpy(Temp,"");
					if(released_solution_revs != NULL)
					{
						tc_strcat(Temp,"\n--  Following Solution Items are not in Preliminary or Prototype State:\n");
						tc_strcat(Temp,released_solution_revs);
					}
					if(prelimn_sol_prev_revs != NULL)
					{
						tc_strcat(Temp,"\n-- Following Solution Items have previous revisions which are not in Prototype or Obsolete or Inactive or Released:\n");
						tc_strcat(Temp,prelimn_sol_prev_revs);
					}
					if(obsolete_child_list != NULL)
					{
						tc_strcat(Temp,"\n--  Following Solution Items have Obsolete children:\n");
						tc_strcat(Temp,obsolete_child_list);
					}
					if(inactive_child_list != NULL)
					{
						tc_strcat(Temp,"\n-- Following Solution Items have Inactive children:\n");
						tc_strcat(Temp,inactive_child_list);	
					}
					if(child_not_in_solution_list != NULL)
					{
						tc_strcat(Temp,"\n-- Following Solution Items have Unreleased children which have not been added to the same ECN:\n");
						tc_strcat(Temp,child_not_in_solution_list);
					}
					if(past_solution_revs != NULL || no_target_solution_revs != NULL || no_change_function_solution_revs != NULL || no_ESD_value_solution_revs != NULL)
					{
						tc_strcat(Temp,"\n--  Following Solution Items do not have a few mandatory values to be set for ECN submission:");
						if(past_solution_revs != NULL)
						{
							tc_strcat(Temp,"\n--  Solution Item Effective date is Past or not set: ");
							tc_strcat(Temp,past_solution_revs);
							EMR_free(past_solution_revs);
					
						}
						if(no_target_solution_revs != NULL)
						{
							tc_strcat(Temp,"\n--  Solution Item Target status is not set: ");
							tc_strcat(Temp,no_target_solution_revs);
							EMR_free(no_target_solution_revs);
						}
						if(no_change_function_solution_revs != NULL)
						{
							tc_strcat(Temp,"\n--  Solution Item Change function is not set: ");
							tc_strcat(Temp,no_change_function_solution_revs);
							EMR_free(no_change_function_solution_revs);
						}
						if(no_ESD_value_solution_revs != NULL)
						{
							tc_strcat(Temp,"\n--  Solution Item Electric Static Discharge Sensitive is not set: ");
							tc_strcat(Temp,no_ESD_value_solution_revs);
							EMR_free(no_ESD_value_solution_revs);
						}
					}
					EMR_free(released_solution_revs);
					EMR_free(prelimn_sol_prev_revs);
					EMR_free(obsolete_child_list);
					EMR_free(inactive_child_list);
					EMR_free(child_not_in_solution_list);
					if(!all_ok)
					{
						EMH_store_initial_error_s1(EMH_severity_user_error, LBT_NO_SOLUTION_ITEMS_FOUND, Temp);
						decision = EPM_nogo;
					}
					else if(all_ok)
					{
						decision = EPM_go;
					}
			
				}
			}
			else if(!validationForStatus)
			{
				EMH_store_initial_error_s1(EMH_severity_user_error,LBT_ECN_SELCTED_IS_NOT_IN_PENDING, "");
				decision = EPM_nogo;
				return decision;
			}
		}
		else 
		{
			EMH_store_initial_error_s1(EMH_severity_user_error,LBT_ORIGINATOR_SHOULD_INITIATE_PRELIM_WORKFLOW, "");
			decision = EPM_nogo;
			return decision;
		}
	}
	else
	{
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT_REVISION_SELECTED_IS_NOT_ECN_REVISION, "");
		decision = EPM_nogo;
	}
	return decision;
}

/****************************************************************************************************
*	Handler name	:	LBT9_Cancel_ECN_Validation

*	Description		:	Rule Handler- used to validate the Cancel ECN Workflow

******************************************************************************************************/

extern EPM_decision_t LBT9_Cancel_ECN_Validation(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	char *cpUserId = NULL;
	char *cpStatus = NULL;
	tag_t tRootTask			=	NULLTAG;
	tag_t *tAttchItemTag	=	NULL;
	int iTargetAttchmnt		=	0;
	int iImpactedItemCount	=	0;
	tag_t *tImpactedItemTag	=	NULL;
	logical validationFailed = false;
	logical all_ok = true;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		tag_t tCurrentGrpMemberTag = NULLTAG;
	
		ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		ITK(iFail,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
		if(tCurrentGrpMemberTag != NULLTAG)
		{
			tag_t tUserTag	= NULLTAG;
			ITK(iFail,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
			if(tUserTag != NULLTAG)
			{
				ITK(iFail,SA_ask_user_identifier2(tUserTag,&cpUserId));
			}
		}
		//Cancel ECN workflow should only work for the ECN Revision
		if(cpObjectType != NULL && tc_strcmp("LBT9_ECNRevision",cpObjectType) == 0)
		{
			validationFailed = true;
			EMR_free(cpObjectType);
		}
	}
	//Only Change Analyst and Originator of the ECN are allowed to use this workflow
	if(validationFailed && cpUserId != NULL)
	{
		tag_t tOriginatorTag = NULLTAG;
		char *cpOriginatorId = NULL;
		char *cpAnalystId = NULL;
		ITK(iFail,AOM_ask_value_string(tAttchItemTag[0],"lbt9_Change_Analyst",&cpAnalystId));
		ITK(iFail,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
		if(tOriginatorTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
		}
		if(cpAnalystId != NULL && cpOriginatorId != NULL)
		{
			if(tc_strcmp(cpUserId,cpAnalystId) == 0 || tc_strcmp(cpUserId,cpOriginatorId) == 0)
			{
				all_ok = false;
			}
			else
			{
				all_ok = true;
			}
			EMR_free(cpAnalystId);
			EMR_free(cpOriginatorId);
		}
		EMR_free(cpUserId);
	}
	else if(!validationFailed)
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_ECN_WF_ITEM_IS_NOT_ECN,"");
		decision = EPM_nogo;
		EMR_free(cpUserId);
		EMR_free(tAttchItemTag);
		return decision;
	}
	//Cancel ECN workflow can only be used when ECN is in pending state
	if(!all_ok)
	{
		int iStatusCount = 0;
		tag_t *tStatusTags = NULL;
		ITK(iFail,AOM_ask_value_tags(tAttchItemTag[0],"release_status_list",&iStatusCount,&tStatusTags));
		if(tStatusTags != NULL && iStatusCount > 0)
		{
			ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatus));
			if(cpStatus != NULL && tc_strcmp(cpStatus,PENDING_STATUS) == 0)
			{
				decision =  EPM_go;
				EMR_free(cpStatus);
			}
			else
			{
				EMH_clear_errors();
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_ECN_WF_ITEM_STATUS_IS_INVALID,"");
				decision = EPM_nogo;
			}
			EMR_free(tStatusTags);
		}
		EMR_free(tAttchItemTag);
	}
	else
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_ECN_WF_USER_IS_NOT_AUTHORIZED,"");
		decision = EPM_nogo;
		EMR_free(tAttchItemTag);
	}
	return decision;
}
/******************************************************************************************
File        :	LBT9_StopShip_Validation.cpp
Description :	Workflow action handlers for Libert.  

History Log:

Date          		Author                          Action

08/10/2015		  Ashok Raj S                  Added LBT9_StopShip_Validation
												

					
******************************************************************************************/
#include "LBT9_Change_Handler.h"


//using namespace std;

/**
*	Function name	:	LBRT_StopShip_Validation
*	Description		:	This function is used to validate if there are any unreleased revisions
						in the Impacted Item folder of Stop Ship.
*	Return type		:	int
*	Outputs 		:	N/A
*					 					  					 					  

******************************************************************************************/
extern EPM_decision_t LBT9_StopShip_Validation(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	tag_t tRootTask			=	NULLTAG;
	tag_t *tAttchItemTag	=	NULL;
	int iTargetAttchmnt		=	0;
	int iImpactedItemCount	=	0;
	int iNotALatestRev		=	0;
	char *cNotALatestrevList    =  NULL;
	int iUnreleasedItemCount    =  0;
	char *cTempImpacted         =  NULL;
	tag_t *tNotALatestRev	=  NULL;
	char *cpUnreleasedItemList   =  NULL;
	tag_t *UnreleasedItemTags	= NULL;
	tag_t *tImpactedItemTag	=	NULL;
	logical validationFailed = false;
	logical unReleased = false;
	logical impactedValidationFailed  =  false;
	
	logical all_ok = true;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp("LBT9_StopShipRevision",cpObjectType) == 0)
		{
			logical UserIsOriginator = false;
			//ITK(iFail,LBT_get_related_objects(tAttchItemTag[0],"CMHasImpactedItem",&iImpactedItemCount,&tImpactedItemTag));
			ITK(iFail,fnToCheckCurrentUserIsOriginator(tAttchItemTag[0],&UserIsOriginator));
			if(UserIsOriginator)
			{
				int iStatusCount = 0;
				tag_t *tStatusTags = NULL;
				char *cpStatusValue = NULL;
				ITK(iFail,AOM_ask_value_tags(tAttchItemTag[0],"release_status_list"	,&iStatusCount,&tStatusTags));
				if(iStatusCount > 0 && tStatusTags != NULL)
				{
					ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusValue));
					if(cpStatusValue != NULL && tc_strcmp(cpStatusValue,PENDING_STATUS) == 0)
					{
						ITK(iFail,LBT_get_related_objects(tAttchItemTag[0],"CMHasImpactedItem",&iImpactedItemCount,&tImpactedItemTag));
						EMR_free(tStatusTags);
						EMR_free(cpStatusValue);
						EMR_free(cpObjectType);
					}
					else
					{
						EMH_clear_errors();
						EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_StopShip_IS_NOT_IN_PENDING,"");
						decision = EPM_nogo;
						validationFailed = true;
						EMR_free(tStatusTags);
						EMR_free(cpStatusValue);
						EMR_free(cpObjectType);
						EMR_free(tAttchItemTag);
						return decision;
					}
				}
			}
			else
			{

				EMH_clear_errors();
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_STOPSHIP_USER_IS_NOT_ORIGINATOR,"");
				decision = EPM_nogo;
				validationFailed = true;
				EMR_free(cpObjectType);
				EMR_free(tAttchItemTag);
				return decision;

			}
			//MEM_free(cpObjectType);
		}
		else
		{
			EMH_clear_errors();
			EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_ITEM_SELECTED_IS_NOT_STOPSHIP,"");
			decision = EPM_nogo;
			validationFailed = true;
			return decision;
		}
	}

	//if(tImpactedItemTag == NULL && iImpactedItemCount == 0)
	//{
	//	EMH_clear_errors();
	//	EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_StopShip_NO_IMPACTED_ITEMS,"");
	//	decision = EPM_nogo;
	//	validationFailed = true;
	//	return decision;
	//} 

	//if(tImpactedItemTag != NULL && iImpactedItemCount > 0)
	//{
	//	

	//	ITK(iFail,LBT9_StopShip_get_unreleased_impacted_items(iImpactedItemCount,tImpactedItemTag, &iUnreleasedItemCount, &UnreleasedItemTags));
	//	if(iUnreleasedItemCount > 0 && UnreleasedItemTags != NULL)
	//	{
	//		
	//		EMH_clear_errors();
	//		ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iUnreleasedItemCount,UnreleasedItemTags,&cpUnreleasedItemList));
	//		//EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_StopShip_UNRELEASED_IMPACTED_ITEMS,cpUnreleasedItemList);
	//		decision = EPM_nogo;
	//		validationFailed = true;
	//		unReleased = true;
	//	}
	//	EMR_free(UnreleasedItemTags);

	//	ITK(iFail,LBT_get_notALatestRev_impacted_items(iImpactedItemCount,tImpactedItemTag, &iNotALatestRev, &tNotALatestRev));
	//	if(iNotALatestRev > 0 && tNotALatestRev != NULL)
	//			{			 
	//				ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iNotALatestRev,tNotALatestRev,&cNotALatestrevList));
	//				decision = EPM_nogo;
	//				validationFailed = true;
	//			}
	//	EMR_free(tNotALatestRev);

	//}

	//if(validationFailed)
	//{
	//	cTempImpacted = (char *)MEM_alloc(15*iUnreleasedItemCount + 15*iNotALatestRev + 2);
	//	tc_strcpy(cTempImpacted,"");
	//	tc_strcat(cTempImpacted,"\n");
	//	//If unreleased items are present add comma seperated list of cUnreleasedItemList to error message
	//		if(iUnreleasedItemCount>0)
	//		{				      
	//			tc_strcat(cTempImpacted,cpUnreleasedItemList);
	//		}

	//	//If Released items are present which are not the Latest Released Revision then add Comma seperated list of cNotALatestrevList to error message
	//		if(iNotALatestRev>0)
	//		{
	//			if(iUnreleasedItemCount>0)
	//			{
	//				tc_strcat(cTempImpacted,",");					  
	//			}
	//			tc_strcat(cTempImpacted,cNotALatestrevList);
	//		}

	//		if( unReleased)
	//		{
	//			EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_StopShip_UNRELEASED_IMPACTED_ITEMS,cpUnreleasedItemList);
	//		}
	//		else
	//		{
	//			EMH_store_initial_error_s1(EMH_severity_error,LBT9_STOPSHIP_INVALID_IMPACTED_ITEMS,cTempImpacted);
	//		}
	//		decision = EPM_nogo;
	//		EMR_free(cTempImpacted);
	//}
	//
	//EMR_free(tAttchItemTag);
	//EMR_free(tImpactedItemTag);

	// if(!validationFailed)
	//{
	//	 decision = EPM_go;
	//}
	//return decision;

	 if(tImpactedItemTag != NULL && iImpactedItemCount > 0)
			 {
				int iUnreleasedItemCount    =  0;
				int iNotALatestRev		    =  0;

				char *cTempImpacted         =  NULL;
				char *cUnreleasedItemList   =  NULL;
				char *cNotALatestrevList    =  NULL;	

				tag_t *tUnreleasedItem	    =  NULL;			 
				tag_t *tNotALatestRev	    =  NULL;
			   	
				//Gets the tag of Commercial Part/Document which are not in Released Status
				ITK(iFail,LBT_get_unreleased_impacted_items(iImpactedItemCount,tImpactedItemTag, &iUnreleasedItemCount, &tUnreleasedItem));
				if(iUnreleasedItemCount > 0 && tUnreleasedItem != NULL)
				{			 
					ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iUnreleasedItemCount,tUnreleasedItem,&cUnreleasedItemList));
					decision = EPM_nogo;
					impactedValidationFailed = true;
				}
				EMR_free(tUnreleasedItem);

				//Gets the tag of Commercial Part/Document which is in Released Status and not latest Released Revision
				ITK(iFail,LBT_get_notALatestRev_impacted_items(iImpactedItemCount,tImpactedItemTag, &iNotALatestRev, &tNotALatestRev));
				if(iNotALatestRev > 0 && tNotALatestRev != NULL)
				{			 
					ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iNotALatestRev,tNotALatestRev,&cNotALatestrevList));
					decision = EPM_nogo;
					impactedValidationFailed = true;
				} 
				EMR_free(tNotALatestRev);

				if(impactedValidationFailed)
				{					
					cTempImpacted = (char *)MEM_alloc(15*iUnreleasedItemCount + 15*iNotALatestRev + 2);
					tc_strcpy(cTempImpacted,"");
					tc_strcat(cTempImpacted,"\n");
					
					//If unreleased items are present add comma seperated list of cUnreleasedItemList to error message
					if(iUnreleasedItemCount>0)
					{				      
						tc_strcat(cTempImpacted,cUnreleasedItemList);
					}
					//If Released items are present which are not the Latest Released Revision then add Comma seperated list of cNotALatestrevList to error message
					if(iNotALatestRev>0)
					{
						if(iUnreleasedItemCount>0)
						{
							tc_strcat(cTempImpacted,",");					  
						}
						tc_strcat(cTempImpacted,cNotALatestrevList);
					}				
					EMH_store_initial_error_s1(EMH_severity_error,LBT9_STOPSHIP_INVALID_IMPACTED_ITEMS,cTempImpacted);
					decision = EPM_nogo;
					EMR_free(cTempImpacted);
					
				}

				if(!impactedValidationFailed)
				{
					decision = EPM_go;
				}

				return decision;
	 }
	 }
/*****************************************************************************************
*	Function name	:	LBT9_StopShip_get_unreleased_impacted_items
*	Description		:	Gets the unreleased revision from Impacted items folder
*	Return type		:	int
*	Outputs 		:	N/A
*	 					  					 					  

******************************************************************************************/

int LBT9_StopShip_get_unreleased_impacted_items(int n_imp_revs,              /* <I> */
										   tag_t *imp_rev_tags,         /* <I> */
									       int *n_unreleased_revs,        /* <O> */ 
									       tag_t **unreleased_rev_tags    /* <OF> */ 
										  )
{
	int iFail = ITK_ok;
	
	*n_unreleased_revs = 0;
	*unreleased_rev_tags = NULL;
	
	for (int inx = 0; inx < n_imp_revs; inx++)
	{
		int statusCount = 0;
		
		tag_t *statusTags = NULL;
		
		ITK(iFail,AOM_ask_value_tags(imp_rev_tags[inx], "release_status_list", &statusCount, &statusTags));
		
		if ( statusCount > 0 )
		{
			char *status_value = NULL;
			ITK(iFail, AOM_ask_value_string(statusTags[0],"object_name",&status_value));
			if(status_value != NULL && tc_strcmp(status_value,RELEASE_STATUS) != 0)
			{
				*unreleased_rev_tags = (tag_t *) MEM_realloc(*unreleased_rev_tags,(*n_unreleased_revs+1)*sizeof(tag_t));
				(*unreleased_rev_tags)[*n_unreleased_revs] = imp_rev_tags[inx];
				*n_unreleased_revs = *n_unreleased_revs + 1;
				MEM_free(status_value);
			}
		}		
		MEM_free(statusTags);
	}
	
	return iFail;
}


/*****************************************************************************************
*	Function name	:	LBT9_Resume_Comments_Validation
*	Description		:	Validates the Resume comments to ensure it is not empty
*	Return type		:	int
*	Outputs 		:	N/A
*	 					  					 					  

******************************************************************************************/

extern EPM_decision_t LBT9_Resume_Comments_Validation(EPM_rule_message_t message)
 {
	int iFail = ITK_ok;
	tag_t tRootTask = NULLTAG;
	int iTargetCount = 0;
	tag_t *ptTargetAttchmnts = NULL;
	EPM_decision_t decision = EPM_nogo;
	logical validationFailed = false;


	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULL)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTargetCount,&ptTargetAttchmnts));
	}
	if(iTargetCount > 0 && ptTargetAttchmnts != NULL )
	{
		
		char *cpObjectType	  = NULL;
		
		ITK(iFail,WSOM_ask_object_type2(ptTargetAttchmnts[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp(cpObjectType,"LBT9_StopShipRevision") == 0)
		{
			char *stopShipResumeCmts = NULL;
			ITK(iFail,AOM_ask_value_string(ptTargetAttchmnts[0],"lbt9_Resume_Comments",&stopShipResumeCmts));
			if(tc_strcmp(stopShipResumeCmts,"") == 0 )
			{
					EMH_clear_errors();
					EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_RESUME_COMMENTS_NOT_ENTERED,"");
					decision = EPM_nogo;
					validationFailed = true;
					return decision;
			}
		}
		EMR_free(ptTargetAttchmnts);
	}

	if(!validationFailed)
	{
		decision = EPM_go;
	}
	return decision;
	
 }

/**********************************************************************************************************************
*	Handler Name	:	LBT9_VALIDATE_CANCEL_StopShip_WF

*	Description		:	This Function is used to Validate the StopShip When Cancel StopShip Workflow is initiated
																	
***********************************************************************************************************************/

extern EPM_decision_t LBT9_VALIDATE_CANCEL_StopShip_WF(EPM_rule_message_t message)
{
	int iFail = ITK_ok;
	EPM_decision_t decision = EPM_nogo;
	char *cpUserId = NULL;
	char *cpStatus = NULL;
	tag_t tRootTask			=	NULLTAG;
	tag_t *tAttchItemTag	=	NULL;
	int iTargetAttchmnt		=	0;
	int iImpactedItemCount	=	0;
	tag_t *tImpactedItemTag	=	NULL;
	logical validationFailed = false;
	logical all_ok = true;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
		char *cpObjectType = NULL;
		tag_t tCurrentGrpMemberTag = NULLTAG;
	
		ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
		ITK(iFail,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
		if(tCurrentGrpMemberTag != NULLTAG)
		{
			tag_t tUserTag	= NULLTAG;
			ITK(iFail,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
			if(tUserTag != NULLTAG)
			{
				ITK(iFail,SA_ask_user_identifier2(tUserTag,&cpUserId));
			}
		}
		//Cancel Stopship workflow should only work for the Stopship Revision
		if(cpObjectType != NULL && tc_strcmp("LBT9_StopShipRevision",cpObjectType) == 0)
		{
			validationFailed = true;
			EMR_free(cpObjectType);
		}
	}
	//Only Change Analyst and Originator of the stopship are allowed to use this workflow
	if(validationFailed && cpUserId != NULL)
	{
		tag_t tOriginatorTag = NULLTAG;
		char *cpOriginatorId = NULL;
		char *cpAnalystId = NULL;
		ITK(iFail,AOM_ask_value_string(tAttchItemTag[0],"lbt9_Change_Analyst",&cpAnalystId));
		ITK(iFail,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
		if(tOriginatorTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
		}
		if(cpAnalystId != NULL && cpOriginatorId != NULL)
		{
			if(tc_strcmp(cpUserId,cpAnalystId) == 0 || tc_strcmp(cpUserId,cpOriginatorId) == 0)
			{
				all_ok = false;
			}
			else
			{
				all_ok = true;
			}
			EMR_free(cpAnalystId);
			EMR_free(cpOriginatorId);
		}
		EMR_free(cpUserId);
	}
	else if(!validationFailed)
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_STOPSHIP_WORKFLOW_STATUS,"");
		decision = EPM_nogo;
		EMR_free(cpUserId);
		EMR_free(tAttchItemTag);
		return decision;
	}
	//Cancel Stopship workflow can only be used when Stopship is in Pending state
	if(!all_ok)
	{
		int iStatusCount = 0;
		tag_t *tStatusTags = NULL;
		ITK(iFail,AOM_ask_value_tags(tAttchItemTag[0],"release_status_list",&iStatusCount,&tStatusTags));
		if(tStatusTags != NULL && iStatusCount > 0)
		{
			ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatus));
			if(cpStatus != NULL && tc_strcmp(cpStatus,PENDING_STATUS) == 0)
			{
				decision =  EPM_go;
				EMR_free(cpStatus);
			}
			else
			{
				EMH_clear_errors();
				EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_STOPSHIP_INVALID_REVISION,"");
				decision = EPM_nogo;
			}
			EMR_free(tStatusTags);
		}
		EMR_free(tAttchItemTag);
	}
	else
	{
		EMH_clear_errors();
		EMH_store_initial_error_s1(EMH_severity_user_error, LBT9_CANCEL_STOPSHIP_WORKFLOW_USER,"");
		decision = EPM_nogo;
		EMR_free(tAttchItemTag);
	}
	return decision;
}
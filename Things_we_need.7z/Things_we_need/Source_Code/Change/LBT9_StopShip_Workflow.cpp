/******************************************************************************************
File        :	LBT9_StopShip_Validation.cpp
Description :	Workflow action handlers for Libert.  

History Log:

Date          		Author                          Action

08/10/2015		  Ashok Raj S                  Added LBT9_StopShip_Workflow
												

					
******************************************************************************************/

#include "LBT9_Change_Handler.h"




/**************************************************************************************
*	Function name	:	createAddApproverSubProcessesStopShip

*	Description		:	This Function is used for Creating subprocess For Approver

***************************************************************************************/

int createAddApproverSubProcessesStopShip	(tag_t revTag,                      /* <I> */
											int n_added_groupmembers,          /* <I> */
											tag_t *added_group_member_tags,    /* <I> */
											char *logged_in_user,               /* <I> */
											const char *cpAction
											)
{
	int iFail = ITK_ok;
	int n_jobs = 0;
	logical Flag = false;
	
	tag_t *job_tags = NULL;
	
	ITK(iFail,EPM_ask_active_job_for_target(revTag, &n_jobs, &job_tags));
	
	if ( n_jobs > 0 )
	{
		tag_t parent_root_task_tag = NULLTAG;
		tag_t routingTaskTag = NULLTAG;
		tag_t routingTaskTagStopShip = NULLTAG;
		
		EPM_state_t routingTaskState;
		
		ITK(iFail,EPM_ask_root_task(job_tags[0], &parent_root_task_tag));
				
		ITK(iFail,getRoutingDoTaskOfJob(job_tags[0], CM_ROUTING_DO_TASK_NAME, &routingTaskTag));
	
		if ( routingTaskTag == NULLTAG )
		{
			TC_write_syslog("libWiproLiebert --- No DO Task exists with name %s in the current workflow process\n", CM_ROUTING_DO_TASK_NAME);
			return ITK_ok;
		}
		
		ITK(iFail,EPM_ask_state(routingTaskTag, &routingTaskState));
		
		if (tc_strcmp(cpAction,"ClientTrigger") == 0)
		{
			if( routingTaskState == EPM_started )
			{
				ITK(iFail,validateProcess(n_added_groupmembers, added_group_member_tags, logged_in_user, parent_root_task_tag, revTag, job_tags, routingTaskTag));
			}
			else
			{
				ITK(iFail,getRoutingDoTaskOfJob(job_tags[0], CM_RESUME_ROUTING_DO_TASK_NAME, &routingTaskTagStopShip));
				ITK(iFail,validateProcess(n_added_groupmembers, added_group_member_tags, logged_in_user, parent_root_task_tag, revTag, job_tags, routingTaskTagStopShip));
				TC_write_syslog("libWiproLiebert --- %s need to test the second part.\n", CM_RESUME_ROUTING_DO_TASK_NAME);

			}
			Flag = true;
		}
		else if (tc_strcmp(cpAction,"ServerTrigger") == 0)
		{
			Flag = true;
			ITK(iFail,getRoutingDoTaskOfJob(job_tags[0], CM_RESUME_ROUTING_DO_TASK_NAME, &routingTaskTagStopShip));
			ITK(iFail,validateProcess(n_added_groupmembers, added_group_member_tags, logged_in_user, parent_root_task_tag, revTag, job_tags, routingTaskTagStopShip));
		}
		if (!Flag)
		{
			return ITK_ok;
		}
		
	}
	return iFail;
}


int validateProcess(int n_added_groupmembers, 
					tag_t *added_group_member_tags, 
					char* logged_in_user, 
					tag_t parent_root_task_tag, 
					tag_t revTag, 
					tag_t *job_tags, 
					tag_t routingTaskTag )

{
	int iFail =ITK_ok;


	for (int inx = 0; inx < n_added_groupmembers; inx++)
		{
			tag_t groupTag = NULLTAG;
			tag_t roleTag = NULLTAG;
			tag_t userTag = NULLTAG;
			tag_t formTag = NULLTAG;
			tag_t subProcessTag = NULLTAG;
			
			char *current_date_string = NULL;
			char *groupName = NULL;
			char *roleName = NULL;
			char *userId = NULL;
			char *person_name = NULL;
			char *ItemId = NULL;
			char formName[256];
			char TaskName[256];
			int IterationCount = 0;
			date_t current_date = NULLDATE;
			char *AnalystId = NULL;
			tag_t tDelegateMemberTag			= NULLTAG;
			tag_t tDelegateUserTag				= NULLTAG;
			date_t DelegateUsetStartDate;
			date_t DelegateUsetEndDate;
			logical DelegationFalg				= false;
			
			ITK(iFail,AOM_ask_value_string(revTag,"lbt9_Change_Analyst",&AnalystId));
			ITK(iFail,AOM_ask_value_int(revTag,"lbt9_Iteration",&IterationCount));
			ITK(iFail,AOM_ask_value_string(revTag,"item_id",&ItemId));

			char * resoucepool_name = NULL;
			tag_t tClassId = NULLTAG;
			//ITK(iFail,EPM_get_resource_pool_name(added_group_member_tags[inx], &resoucepool_name));

			ITK(iFail,POM_class_of_instance(added_group_member_tags[inx],&tClassId));

			ITK(iFail,POM_name_of_class(tClassId, &resoucepool_name));

			
			if(tc_strcmp(resoucepool_name, "GroupMember") == 0)
			{
				iFail = ITK_ok;
				printf("CA Resouce Pool Task\n");
				ITK(iFail,SA_ask_groupmember_group(added_group_member_tags[inx], &groupTag));
				ITK(iFail,SA_ask_groupmember_role(added_group_member_tags[inx], &roleTag));
				ITK(iFail,SA_ask_groupmember_user(added_group_member_tags[inx], &userTag));
			}
			else if(tc_strcmp(resoucepool_name, "ResourcePool") == 0)
			{
				logical is_sub = false;
				ITK(iFail,EPM_ask_resource_pool_group_role(added_group_member_tags[inx],&groupTag,&roleTag, &is_sub));
				ITK(iFail,SA_find_user2(AnalystId, &userTag));
			}

			//checking deligation user for CCB Reviewer member
			if (userTag != NULLTAG)
			{
				ITK(iFail,EPM_ask_out_of_office(userTag,&tDelegateMemberTag,&DelegateUsetStartDate,&DelegateUsetEndDate));

				if (tDelegateMemberTag != NULLTAG)
				{
					DelegationFalg = true;
				}
			}
			
			ITK(iFail,SA_ask_group_full_name(groupTag, &groupName));
			ITK(iFail,SA_ask_role_name2(roleTag, &roleName));
			ITK(iFail,SA_ask_user_identifier2(userTag, &userId));
			ITK(iFail,SA_ask_user_person_name2(userTag, &person_name));
			if (DelegationFalg)
			{
				ITK(iFail,fnForNotifyingOOFAddedApprovers(revTag,userTag,userId));
				return iFail;
			}
			
			ITK(iFail,ITK_ask_default_date_format(&current_date_string));
			ITK(iFail,ITK_string_to_date(current_date_string, &current_date));
			
			/*This is used to concatenate the lenght to remove the below error to fix the below
			//The Form "Engineering.United_States.Liebert.ENP/Engineer/test_eng" could not be saved.
			//Unable to set value on property .
			//Unable to set value on property Approver Group.
			//The input string is too long. * -- BUG #234 */
			char **cpFormGrpName = NULL;
			int iValueCount = 0;
			if(groupName != NULL)
			{						
				ITK(iFail,EPM__parse_string(groupName,".",&iValueCount,&cpFormGrpName));
			}
			
			tc_strcpy(formName, groupName);
			tc_strcat(formName, "/");
			tc_strcat(formName, roleName);
			tc_strcat(formName, "/");
			tc_strcat(formName, userId);
			
			if( AnalystId != NULL && tc_strcmp(AnalystId,userId) == 0)
			{
				tc_strcpy(TaskName, "CA Review");
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, ItemId);
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, userId);
				EMR_free(AnalystId);
			}
			else if( AnalystId != NULL && tc_strcmp(AnalystId,userId) != 0)
			{
				tc_strcpy(TaskName, "CCB Review");
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, ItemId);
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, userId);
				EMR_free(AnalystId);
			}
			
			/* Create a form*/
			ITK(iFail,FORM_create(formName, "", CM_FORM_TYPE, &formTag));
			
			 /* Construct a CreateInput object for Form */
			tag_t form_type_tag = NULLTAG;
			ITK(iFail,TCTYPE_find_type(CM_FORM_TYPE, NULL, &form_type_tag));

			tag_t form_create_input_tag = NULLTAG;
			ITK(iFail,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

			ITK(iFail,AOM_set_value_string(form_create_input_tag, "object_name", formName));			
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverUserID", userId));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverName", person_name));
			
			//ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverGroup", groupName));
			//Removing the groupName and passing cpFormGrpName to remove the error leading to
			//The Form "Engineering.United_States.Liebert.ENP/Engineer/test_eng" could not be saved.
			if(cpFormGrpName != NULL)
			{
				ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverGroup", cpFormGrpName[0]));
			}
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverRole", roleName));
		    ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_AssignedBy", logged_in_user));
			ITK(iFail,AOM_set_value_date(form_create_input_tag, "lbt9_AssignedDate", current_date));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_SignoffStatus", ""));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverStatus", "Assigned"));
			ITK(iFail,AOM_set_value_int(form_create_input_tag, "lbt9_Iteration", IterationCount)); // added by Tanay for Iteration					

			printf("Form Name : %s\n", formName);
			printf("Approver User ID : %s\n", userId);
			printf("Approver Name    : %s\n", person_name);
			printf("Assigned By      : %s\n", logged_in_user);
			printf("Signoff Status   : In Process\n");
			printf("Approver Status  : Active\n");
			TC_write_syslog("libWiproLiebert --- after creating approverform");
			ITK(iFail,TCTYPE_create_object(form_create_input_tag, &formTag));
			
			ITK(iFail,AOM_save(formTag));
			
			ITK(iFail,AOM_save_with_extensions(formTag));
			
			///* Add the form as reference attachment to the parent root task */
			ITK(iFail,addAttachment(parent_root_task_tag, formTag, EPM_reference_attachment));
			//
			///* Attach the form to the Revision with LBT9_ECN_Approver_Rel relation*/
			ITK(iFail,attachFormToRevision(formTag, revTag,Attr_ECN_REVIEWERS_LIST));
			
			/*Initiate subprocess on the form*/
			ITK(iFail,initiateSubProcess(TaskName, formTag, revTag, &subProcessTag));
			
			if ( subProcessTag != NULLTAG )
			{
				int taskCount = 0;
				int *attachType = NULL;
				
				tag_t sub_process_perform_task = NULLTAG;
				tag_t subprocess_root_task = NULLTAG;
				tag_t *taskTags = NULL;
				
				attachType = (int *)MEM_alloc(sizeof(int)*1);
				attachType[0] = EPM_interprocess_task_attachment;

				/* Attach the sub process to parent process */
				ITK(iFail,EPM_attach_sub_processes(job_tags[0], 1, &subProcessTag));
				
				/*Get the Perform Signoff Task of Sub Process*/
				ITK(iFail,getPerformSignoffTaskOfReview(subProcessTag, CM_SUBPROCESS_DEPENDENT_REVIEW_TASK, &sub_process_perform_task));
				
				/* Commented the above and add the below line to change the dependency task*/
				ITK(iFail,getSubProcessDependencyTask1(subProcessTag, CM_SUBPROCESS_DEPENDENT_TASK, &sub_process_perform_task));
				
				if ( sub_process_perform_task == NULLTAG )
				{
					printf("dependency task %s not found in the sub process\n", CM_SUBPROCESS_DEPENDENT_TASK);
					
					return iFail;
				}
				
				/* Add the Dependency between Routing Task of Parent Process and Perform Signoff Task of Sub Process */			
				ITK(iFail,EPM_add_attachments(routingTaskTag, 1, &sub_process_perform_task, attachType));
				
				/* Get the Root Task of Sub Process and Start the Sub Process*/
				ITK(iFail,EPM_ask_root_task(subProcessTag, &subprocess_root_task));
				
				ITK(iFail,EPM_trigger_action(subprocess_root_task, EPM_complete_action, "Started the sub process"));
				
				ITK(iFail,EPM_get_type_tasks(subProcessTag, eEPMSelectSignoffTask , &taskCount, &taskTags));
				
				if ( taskCount > 0 )
				{
					int count = 0;

					tag_t *signoffs = NULLTAG;
					
					ITK(iFail,AOM_refresh(taskTags[0],true));

					ITK(iFail,EPM_create_adhoc_signoff(taskTags[0], added_group_member_tags[inx], &count, &signoffs));
					printf("No. of Signoffs created : %d\n", count);
					TC_write_syslog("libWiproLiebert --- No. of Signoffs created : %d\n", count);

					ITK(iFail,EPM_set_adhoc_signoff_selection_done(taskTags[0], TRUE));
					
					ITK(iFail,EPM_trigger_action(taskTags[0], EPM_complete_action, "Started the sub process"));
					
					ITK(iFail,AOM_save(taskTags[0]));
					ITK(iFail,AOM_refresh(taskTags[0], false));

					EMR_free(signoffs);
				}
				else
				{
					TC_write_syslog("libWiproLiebert --- Could not find SelectSignoffTask\n");
				}
				
				ITK(iFail,fnForNotifyingAddedApprovers(revTag,userTag,userId));			//added by tanay
				
				EMR_free(taskTags);
			}
			else
			{
				TC_write_syslog("libWiproLiebert --- Unable to create the sub process.\n");
			}
			
			EMR_free(groupName);
			EMR_free(roleName);
			EMR_free(userId);
			EMR_free(ItemId);
			EMR_free(current_date_string);
		}
		return iFail;
}



/****************************************************************************************************
*	Handler name	:	LBT9_CREATE_CCB_SUBPROCESS_RESUME

*	Description		:	Action Handler - For initiating a subprocess for Reviewers when the Status of 
						change object is CCB Resume
******************************************************************************************************/

extern int LBT9_CREATE_CCB_SUBPROCESS_RESUME(EPM_action_message_t message)
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=   0;
	int iParentJobcount					=   0;
	int iArgumentsCount					=	0;
	tag_t tRootTask						= NULLTAG;	
	tag_t *ptTargetAttmnts				= NULL;
	tag_t *tParentJobTags				= NULL;
	char *cpAddressList					= NULL;
	int iAddressListUserCount           = 0;
	tag_t *tAddressListUserTags			= NULL;
	int iECNPlantsCount					= 0;
	char **cpECNPlantsValue				= NULL;
	/*std::vector<tag_t> Vuser;
	Vuser.clear();*/
	int iCCBReviewersCount = 0;
	tag_t *tCCBUsers = NULL;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if (tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTrgtAtchmnts, &ptTargetAttmnts));
	}

	if (iTrgtAtchmnts > 0 && ptTargetAttmnts != NULL)
	{
		ITK(iFail,EPM_ask_active_job_for_target( ptTargetAttmnts[0],&iParentJobcount,&tParentJobTags));
	}
	
	//Get current user tag
	tag_t tCurrentGroupmember = NULLTAG;
	tag_t tCurrentUserTag = NULLTAG;
	char *cploginUserID = NULL;
	SA_ask_current_groupmember(&tCurrentGroupmember);
	if (tCurrentGroupmember != NULLTAG)
	{
		ITK(iFail,SA_ask_groupmember_user(tCurrentGroupmember, &tCurrentUserTag));

		if (tCurrentUserTag != NULLTAG)
		{
			SA_ask_user_identifier2(tCurrentUserTag,&cploginUserID);
		}
	}
	
	//Get Change Analyst usertag
	int iChangeAnalystUserCount = 0;
	tag_t *tChangeAnalystUserTags = NULL;
	ITK(iFail,fnGetParticipantUsersList1(ptTargetAttmnts[0],CHANGE_ANALYST,&iChangeAnalystUserCount,&tChangeAnalystUserTags));

	////Initiate sub workflow for change analyst
	//if (iChangeAnalystUserCount > 0 && tChangeAnalystUserTags != NULL && tc_strlen(cploginUserID) > 0 && cploginUserID != NULL)
	//{		
	//	ITK(iFail,createAddApproverSubProcessesStopShip(ptTargetAttmnts[0],iChangeAnalystUserCount,tChangeAnalystUserTags,cploginUserID,"ServerTrigger"));
	//}

	// code for resouce pool task
	tag_t tRoleTag = NULLTAG;
	tag_t tGrpTag = NULLTAG;
	tag_t tRsrcPoolTag = NULLTAG;
	ITK(iFail,SA_find_group("Change Management.United_States.Liebert.ENP",&tGrpTag));
	ITK(iFail,SA_find_role2("Change Analyst Standard",&tRoleTag));
	ITK(iFail,EPM_get_resource_pool(tGrpTag,tRoleTag, false, &tRsrcPoolTag));

	if (tRsrcPoolTag != NULLTAG && tc_strlen(cploginUserID) > 0 && cploginUserID != NULL)
	{		
		ITK(iFail,createAddApproverSubProcessesStopShip(ptTargetAttmnts[0],1,&tRsrcPoolTag,cploginUserID,"ServerTrigger"));
	}

	if (tChangeAnalystUserTags != NULL)
	EMR_free(tChangeAnalystUserTags);

	//Get Proposed Reviewers of ECN
	int iProposedUserCount = 0;
	char **cpProposedUser = NULL;
	tag_t * tProposedUserTags = NULL;
	ITK(iFail,AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&iProposedUserCount,&cpProposedUser));
	

	tag_t *tProposedMembrTags = NULL;
	if(iProposedUserCount > 0)
	{
		
		for(int knx = 0; knx < iProposedUserCount; knx++)
		{
	//Initiate subworkflow for Proposed Reviewers
			tag_t tAddressUserTag = NULLTAG;
			int icount = 0;
			ITK(iFail,SA_find_user2(cpProposedUser[knx],&tAddressUserTag));
			if(tAddressUserTag != NULLTAG)
			{
				ITK(iFail,SA_find_groupmember_by_user(tAddressUserTag,&icount,&tProposedMembrTags));
				tProposedUserTags = (tag_t *)MEM_realloc(tProposedUserTags,sizeof(tag_t)*(1+1));
				tProposedUserTags[0] = tProposedMembrTags[0];
				if (tProposedUserTags != NULL && tc_strlen(cploginUserID) > 0 && cploginUserID != NULL)
				{		
					ITK(iFail,createAddApproverSubProcessesStopShip(ptTargetAttmnts[0],1,tProposedUserTags,cploginUserID,"ServerTrigger"));
				}
			}
		}
	}
	EMR_free(tProposedMembrTags);
	EMR_free(tProposedUserTags);
	EMR_free(ptTargetAttmnts);
	EMR_free(tParentJobTags);
	EMR_free(cploginUserID);
	return ITK_ok;
}



/****************************************************************************************************
*	Handler name	:	LBT9_COMPLETE_RESUME_CONDITION_TASK

*	Description		:	Action Handler - To complete the Condition task and direct the path of the
						workflow based on the Change Analyst decision

******************************************************************************************************/


extern int LBT9_COMPLETE_RESUME_CONDITION_TASK(EPM_action_message_t message)
{
	int iFail							=	ITK_ok;
	int iTrgtAtchmnts					=   0;
	int iArgumentsCount					=	0;
	int iTaskCount						=	0;
	tag_t tRootTask						= NULLTAG;
	tag_t *tTaskTags					= NULL;
	tag_t *ptTargetAttmnts				= NULL;
	
	ITK(iFail,EPM_ask_root_task(message.task, &tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask,EPM_target_attachment,&iTrgtAtchmnts,&ptTargetAttmnts));
	}
	if(ptTargetAttmnts != NULL && iTrgtAtchmnts > 0)
	{
		int iFormCount = 0;
		tag_t *tFormTags = NULL;
		ITK(iFail, AOM_ask_value_tags(ptTargetAttmnts[0],"lbt9_Approver_Form",&iFormCount,&tFormTags));
		if(iFormCount > 0 && tFormTags != NULL)
		{
			char *cpAnalystId = NULL;
			ITK(iFail,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpAnalystId));
			if(cpAnalystId != NULL)
			{
				char *Result = NULL;
				char *TaskName = NULL;
				ITK(iFail,EPM_ask_name2(message.task,&TaskName));
				// function to get the Change Analyst current decision
				ITK(iFail,fnToGetTheLatestChangeAnalystResult(iFormCount,tFormTags,ptTargetAttmnts[0],cpAnalystId,&Result));
				if(TaskName != NULL && tc_strcmp(TaskName,"System Complete Condition Resume Task") == 0)
				{
					if(Result != NULL && tc_strcmp(Result,"Approved") == 0)
					{
						ITK(iFail,AOM_refresh(message.task,TRUE));
						ITK(iFail, EPM_set_task_result(message.task,Result));
						ITK(iFail,AOM_save(message.task));
						ITK(iFail,AOM_refresh(message.task,FALSE));						
						EMR_free(Result);
					}
					else if(Result != NULL && tc_strcmp(Result,"Rejected") == 0)
					{					
						ITK(iFail,AOM_refresh(message.task,TRUE));
						ITK(iFail, EPM_set_task_result(message.task,Result));
						ITK(iFail,AOM_save(message.task));
						ITK(iFail,AOM_refresh(message.task,FALSE));
						EMR_free(Result);
					}
					EMR_free(TaskName);
				}
				EMR_free(cpAnalystId);
			}
			EMR_free(tFormTags);
		}
	}
	EMR_free(ptTargetAttmnts);
	return ITK_ok;
}

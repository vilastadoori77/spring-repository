	
/******************************************************************************************

File			:	LBT9_Generic_Methods.cpp

Description		:	Functions for Workflow action handlers 

Author			:  Krupakar Reddy G

Date created	:   10/05/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

01/06/2015		Krupkar Reddy G		 		Inital version

01/06/2015		Krupkar Reddy G             Added printErrorMessage

01/06/2015		Krupkar Reddy G             Added LBT9_EMR_free_Strings

01/06/2015		Krupkar Reddy G             Added EMR_free

01/06/2015		Krupkar Reddy G             Added fnSetFormValuesForTransfer

01/06/2015		Krupkar Reddy G             Added createOrRemoveSubProcess

02/06/2015		Krupkar Reddy G             Added findForm

02/06/2015		Krupkar Reddy G             Added LBT_getActiveApprovalForms

03/06/2015		Krupkar Reddy G             Added clearProcess

03/06/2015		Krupkar Reddy G             Added deleteApproverSubprocesses

04/06/2015		Krupkar Reddy G 			Added LBT_getUniqueObjects

04/06/2015		Krupkar Reddy G				Added addAttachment

04/06/2015		Krupkar Reddy G				Added attachFormToRevision

04/06/2015		Krupkar Reddy G 			Added initiateSubProcess

04/06/2015		Krupkar Reddy G				Added getSubProcessDependencyTask1

04/06/2015		Krupkar Reddy G				Added getPerformSignoffTaskOfReview

04/06/2015		Krupkar Reddy G				Added createAddApproverSubProcesses

04/06/2015		Krupkar Reddy G				Added getRoutingDoTaskOfJob

04/06/2015		Krupkar Reddy G				Added fnSetFormValues

04/06/2015		Krupkar Reddy G				Added fnGetParticipantUsersList1

04/06/2015		Krupkar Reddy G				Added addObservers

04/06/2015		Krupkar Reddy G				Added attachObserverFormToRevision

04/06/2015		Krupkar Reddy G				Added getConsolidatedObservers

04/06/2015		Krupkar Reddy G				Added getNewlyAddedObservers

04/06/2015		Krupkar Reddy G				Added CreateObserverForms

04/06/2015		Krupkar Reddy G				Added removeObservers

04/06/2015		Krupkar Reddy G				Added getLeftOverObservers

04/06/2015		Krupkar Reddy G				Added LBT_removeValueFromMultiListString

04/06/2015		Krupkar Reddy G				Added findObserverForm	

04/06/2015		Krupkar Reddy G				Added fnsubString	

04/06/2015		Krupkar Reddy G				Added fnGetParticipantUsersList

04/06/2015		Tanay Gupta					Added LBT_get_unreleased_impacted_items

04/07/2015		Tanay Gupta					Added fnToGetShortObjectNameForChangeObject

06/07/2015		Tanay Gupta					Added fnToGetDatabaseChangeAnalystUser

10/07/2015		Tanay Gupta 				Added fnToValidateChangeObjectStatuss

10/07/2015		Ashok Raj S					Added LBT_get_notALatestRev_impacted_items

28/07/2015      VenuBabu Avala				Added fnUpdateChangeHistoryForm

30/08/2015		Tanay Gupta					Added fnToGetCurrentUserId

30/08/2015		Tanay Gupta					Added fnToCheckCurrentUserIsOriginator
28/07/2015      Ashok Raj S					Added fnAddItemsForBOMUpdate

28/07/2015      Ashok Raj S					Added fnUpdateBOMPrecise

29/07/2015      Ashok Raj S					Added validateRevLRR
******************************************************************************************/
#include "LBT9_Change_Handler.h"

using namespace std;


/**************************************************************************************
*	Function name	:	printErrorMessage

*	Description		:	This Function is used to get the ERROR Message
***************************************************************************************/

void printErrorMessage( int ifail )			/* <I> */					/* <I> */
{
   char *pcErrorText = NULL ;
   int iItkFail =	EMH_ask_error_text( ifail, &pcErrorText );
   TC_write_syslog("\nlibLBT9_Change: Inside printErrorMessage");
  
 
   if ( iItkFail == ITK_ok )
   {
      if(pcErrorText != NULL)
      {
         TC_write_syslog( "\nlibLBT9_Change ERR: Found ITK Error Code: %d  MSG: %s.\n", ifail, pcErrorText );
      }
   }
   else
   {
      TC_write_syslog( "\nlibLBT9_Change ERR: Unable to get error message for %d \n", ifail );
   }
   if(pcErrorText != NULL)
   {
      EMR_free(pcErrorText );
      pcErrorText = NULL;
   }
}


/**************************************************************************************
*	Function name	:	LBT9_EMR_free_Strings

*	Description		:	This Function is used to Memory free String of array

***************************************************************************************/


int LBT9_MEM_free_Strings(char ** PropertyName,			/* <I> */
						  int PropertyCount 			/* <I> */
						 )
{
	int iFail = ITK_ok;
	for(int i = 0; i < PropertyCount; i++)
	{
		if(PropertyName[i] != NULL)
		{
			MEM_free(PropertyName[i]);
		}	
	}
	return ITK_ok;
}

/*******************************************************************************
*	Function name	:	EMR_free
*	Description		:	Frees the memory allocated to array of tag
*	Return type		:	void
*	Outputs 		:	N/A
 *******************************************************************************/

void EMR_free(void* ptr)	/* <I> */
{
	if(ptr != NULL)
	{
		MEM_free(ptr);
	}
}

/**********************************************************************************************************************
*	Function name	:	fnSetFormValuesForTransfer
*	Description		:	 This Function is used for setting values on Form 
												

***********************************************************************************************************************/


int fnSetFormValuesForTransfer (	tag_t FormTag,			/*<I>*/
									tag_t UserTag,			/*<I>*/
									char *Status,			/*<I>*/
									const char *Comments	/*<I>*/
								)
{
	int retcode = ITK_ok;
	char *current_date_string = NULL;
	char *userId = NULL;
	char *cpformId = NULL;
	char *cpComments = NULL;
	cpComments = (char *)MEM_alloc(tc_strlen(Comments));
	tc_strcpy(cpComments,Comments);
	char *cpStatus = NULL;
	cpStatus = (char *)MEM_alloc(tc_strlen(Status));
	tc_strcpy(cpStatus,Status);
	date_t currentDate = NULLDATE;
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	ITK(retcode,ITK_string_to_date(current_date_string, &currentDate));
	ITK(retcode,SA_ask_user_identifier2(UserTag,&userId));
	//ITK(retcode,AOM_ask_value_string(FormTag, "current_name",&cpformId));
	ITK(retcode,AOM_lock(FormTag));
	if(userId != NULL && cpStatus != NULL && cpComments != NULL)
	{
		ITK(retcode,AOM_set_value_string(FormTag, SIGNOFF_USER, userId));
		ITK(retcode,AOM_set_value_string(FormTag, SIGNOFF_TYPE,"Transfer"));
		ITK(retcode,AOM_set_value_string(FormTag, "lbt9_history_status",cpStatus));
		ITK(retcode,AOM_set_value_date(FormTag, SIGNOFF_DATE, currentDate));
		ITK(retcode,AOM_set_value_string(FormTag, "lbt9_history_comments",cpComments));
		
		ITK(retcode,AOM_save(FormTag));
		ITK(retcode,AOM_unlock(FormTag));
		EMR_free(current_date_string);
		EMR_free(userId);
	}
	return ITK_ok;
}


/**********************************************************************************************************************
*	Function name	:	createOrRemoveSubProcess

*	Description		:	 This Function is used for creating or removing subprocess 
												

***********************************************************************************************************************/

extern int createOrRemoveSubProcess(void *returnValueType)
{
	int iFail = ITK_ok;
	int n_added_users = 0;
	int n_removed_users = 0;
	int n_add_observers = 0;
	int n_removed_observers = 0;
	
	tag_t revTag = NULLTAG;
	tag_t *added_user_tags = NULL;
	tag_t *removed_user_tags = NULL;
	tag_t *added_observer_tags = NULL;
	tag_t *removed_observer_tags = NULL;
	
	char *logged_in_user = NULL;
	
	/* Get the revision tag */
	ITK(iFail,USERARG_get_tag_argument(&revTag));
	
	/* Get the user tags of all the users that were selected in the rich client */
	ITK(iFail,USERARG_get_tag_array_argument(&n_added_users, &added_user_tags));	
	
	/* Get the user tags of all the users that were removed in the rich client */
	ITK(iFail,USERARG_get_tag_array_argument(&n_removed_users, &removed_user_tags));
	
	/* Get the logged in user info from rich client */
	ITK(iFail,USERARG_get_string_argument(&logged_in_user));
	
	/* Get the user tags of all the users that were removed in the rich client */
	ITK(iFail,USERARG_get_tag_array_argument(&n_add_observers, &added_observer_tags));
	
	/* Get the user tags of all the users that were removed in the rich client */
	ITK(iFail,USERARG_get_tag_array_argument(&n_removed_observers, &removed_observer_tags));
	
	if ( revTag != NULLTAG )
	{
		tag_t itemTag = NULLTAG;
		//Get the Basic Info of Revision
		char *item_id = NULL;
		char *rev_id = NULL;
		char *object_type = NULL;
		ITK(iFail,ITEM_ask_item_of_rev(revTag, &itemTag));
		
		ITK(iFail,ITEM_ask_id2(itemTag, &item_id));
		
		ITK(iFail,ITEM_ask_rev_id2(revTag, &rev_id));
		
		TC_write_syslog("libWiproLiebert --- Change Item Revision : %s/%s\n", item_id, rev_id);
		
		if ( n_added_users > 0 && added_user_tags != NULL )
		{
			int n_unique_added = 0;
			tag_t *unique_added = NULL;
						
			ITK(iFail,LBT_getUniqueObjects(n_added_users, added_user_tags, &n_unique_added, &unique_added));
			
			if ( n_unique_added > 0 && unique_added != NULL)
			{
				ITK(iFail,WSOM_ask_object_type2(revTag,&object_type));
				if(object_type != NULL && tc_strcmp(object_type,"LBT9_StopShipRevision")==0)
				{
					ITK(iFail,createAddApproverSubProcessesStopShip(revTag, n_unique_added, unique_added, logged_in_user,"ClientTrigger"));
				}
				else
				{
					ITK(iFail,createAddApproverSubProcesses(revTag, n_unique_added, unique_added, logged_in_user,"ClientTrigger"));
				}
			}
			
			////ITK(createAddApproverSubProcesses(revTag, n_added_users, added_user_tags, logged_in_user));

			EMR_free(unique_added);
		}
		
		if ( n_removed_users > 0 && removed_user_tags != NULL )
		{
			ITK(iFail,deleteApproverSubprocesses(revTag, n_removed_users, removed_user_tags, logged_in_user));
		}
		
		if( n_add_observers > 0 && added_observer_tags != NULL )
		{
			////ITK(addObservers(revTag, n_add_observers, added_observer_tags, logged_in_user));
			
			int n_unique_obs_added = 0;
			tag_t *unique_obs_tags = NULL;
						
			ITK(iFail,LBT_getUniqueObjects(n_add_observers, added_observer_tags, &n_unique_obs_added, &unique_obs_tags));
			
			if ( n_unique_obs_added > 0 && unique_obs_tags != NULL )
			{
				ITK(iFail,addObservers(revTag, n_unique_obs_added, unique_obs_tags, logged_in_user));
			}

			EMR_free(unique_obs_tags);
		}
		
		if( n_removed_observers > 0 && removed_observer_tags != NULL )
		{
			ITK(iFail,removeObservers(revTag, n_removed_observers, removed_observer_tags, logged_in_user));
		}
		
		EMR_free(item_id);
		EMR_free(rev_id);
	}
	
	EMR_free(added_user_tags);
	EMR_free(removed_user_tags);
	EMR_free(logged_in_user);
	EMR_free(added_observer_tags);
	EMR_free(removed_observer_tags);
	
	return iFail;
}


/**************************************************************************************
*	Function name	:	findForm

*	Description		:	 This Function is used for finding the ApproverForm attached To 
						 Change Object

***************************************************************************************/
extern int findForm(tag_t revTag,      /* <I> */
			 char *formName,    /* <I> */
			 tag_t *formTag     /* <O> */
			)
{
	int retcode = ITK_ok;
	int iApproverFormCount		= 0;
	tag_t *tApproverFormTags	= NULL;

	AOM_ask_value_tags(revTag,Attr_ECN_REVIEWERS_LIST,&iApproverFormCount,&tApproverFormTags);

	if (iApproverFormCount > 0 && tApproverFormTags != NULL)
	{
		for (int inx = 0; inx < iApproverFormCount; inx++)
		{
			char *cpApproverFormName = NULL;
			char *cpApproverFormType = NULL;
			ITK(retcode,AOM_ask_value_string(tApproverFormTags[inx], "object_name", &cpApproverFormName));
			ITK(retcode,AOM_ask_value_string(tApproverFormTags[inx], "object_type", &cpApproverFormType));

			if ( tc_strcmp(cpApproverFormType, CM_FORM_TYPE) == 0 && tc_strcmp(cpApproverFormName, formName) == 0 )
			{
				*formTag = tApproverFormTags[inx];
				break;
			}
			EMR_free(cpApproverFormName);
			EMR_free(cpApproverFormType);
		}		
	}
	
	
	return retcode;
}



/**************************************************************************************
*	Function name	:	LBT_getActiveApprovalForms

*	Description		:	 This Function is used for Getting Active Approval Forms of 
						 Change Object 

***************************************************************************************/

extern int LBT_getActiveApprovalForms(tag_t ecn_rev_tag,            /* <I> */
							   int *n_active_forms,          /* <O> */
                               tag_t **active_form_tags      /* <OF> */
                              )
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	*n_active_forms = 0;
	*active_form_tags = NULL;
	
	ITK(retcode,GRM_find_relation_type("LBT9_ECN_Approver_Rel", &relation_type_tag));
	
	if( relation_type_tag != NULLTAG )
	{
		int n_forms = 0;
		
		tag_t *form_tags = NULL;
		
		ITK(retcode,GRM_list_secondary_objects_only(ecn_rev_tag, relation_type_tag, &n_forms, &form_tags));
		
		for (int inx = 0; inx < n_forms; inx++)
		{
			char *form_name = NULL;
			char *signoff_status = NULL;
			
			ITK(retcode,AOM_ask_value_string(form_tags[inx], "object_name", &form_name));
				
			ITK(retcode,AOM_ask_value_string(form_tags[inx], "lbt9_SignoffStatus", &signoff_status));
			
			if ( tc_strcmp(signoff_status, "In Process") == 0 && tc_strstr(form_name, "_Removed") == NULL )
			{
				*active_form_tags = (tag_t *) MEM_realloc(*active_form_tags,(*n_active_forms+1)*sizeof(tag_t));
				(*active_form_tags)[*n_active_forms] = form_tags[inx];
				*n_active_forms = *n_active_forms + 1;
			}
			
			EMR_free(form_name);
			EMR_free(signoff_status);
		}
		
		EMR_free(form_tags);
	}
	
	return retcode;
}
extern int LBT_get_single_preference_value(char *preference_name,      /* <I> */
										   char **preference_value     /* <OF> */
										  )
{
    int retcode = ITK_ok;

    TC_preference_search_scope_t scope;

    *preference_value = NULL;

    ITK(retcode,PREF_ask_search_scope(&scope));

    ITK(retcode,PREF_set_search_scope(TC_preference_all));

    ITK(retcode,PREF_ask_char_value(preference_name, 0, preference_value));

    ITK(retcode,PREF_set_search_scope(scope));

    return retcode;
}

extern int get_ecn_rev_master_form(tag_t rev_tag,                /* <I> */
                            tag_t *rev_master_form_tag    /* <I> */
						   )
{
	int retcode = ITK_ok;
	
	tag_t relation_type_tag = NULLTAG;
	
	*rev_master_form_tag = NULLTAG;
	
	ITK(retcode,GRM_find_relation_type("IMAN_master_form", &relation_type_tag));
	
	if ( relation_type_tag != NULLTAG )
	{
		int secCount = 0;
		
		tag_t *secObjects = NULL;
		
		ITK(retcode,GRM_list_secondary_objects_only(rev_tag, relation_type_tag, &secCount, &secObjects));
		
		if ( secCount > 0 )
		{
			*rev_master_form_tag = secObjects[0];
		}
		
		EMR_free(secObjects);
	}
	
	return retcode;
}


/**************************************************************************************
*	Function name	:	clearProcess

*	Description		:	 This Function is used for clearing the process when the Reviewer 
						 is removed from Process 

***************************************************************************************/

extern int clearProcess(tag_t objectTag,               /* <I> */
				 tag_t parent_process_tag       /* <I> */
				)
{
	int retcode = ITK_ok;
	
	int n_jobs = 0;
	
	tag_t *job_tags = NULL;
	
	ITK(retcode,EPM_ask_active_job_for_target(objectTag, &n_jobs, &job_tags));
	
	if ( n_jobs > 0 )
	{
		tag_t rootTask = NULLTAG;
		tag_t parent_routing_task = NULLTAG;
		tag_t parent_routing_task_resume = NULLTAG;
		tag_t sub_process_perform_task = NULLTAG;
		tag_t sub_process_perform_task_resume = NULLTAG;
		EPM_state_t routingTaskState;
		
		ITK(retcode,getRoutingDoTaskOfJob(parent_process_tag, CM_ROUTING_DO_TASK_NAME, &parent_routing_task));
	
		//ITK(getPerformSignoffTaskOfReview(job_tags[0], CM_SUBPROCESS_DEPENDENT_REVIEW_TASK, &sub_process_perform_task));
		
		ITK(retcode,getSubProcessDependencyTask1(job_tags[0], CM_SUBPROCESS_DEPENDENT_TASK, &sub_process_perform_task));
	
		ITK(retcode,EPM_ask_state(parent_routing_task, &routingTaskState));

		// To ensure that the first routing task is active, if the task is not active 
		if( routingTaskState == EPM_started )
		{
			if ( parent_routing_task != NULLTAG && sub_process_perform_task != NULLTAG )
			{
				ITK(retcode,AOM_lock(parent_routing_task));
		
			ITK(retcode,EPM_remove_attachments(parent_routing_task, 1, &sub_process_perform_task));
			
			ITK(retcode,AOM_save(parent_routing_task));
			
				ITK(retcode,AOM_unlock(parent_routing_task));
			}
			else
			{
				TC_write_syslog("libWiproLiebert --- Either Parent Routing Task or Sub Process Perform Task are null\n");
			}
		}
		//Should jumpto the second routing task when the Routing for Resume starts
		else
		{
			ITK(retcode,getRoutingDoTaskOfJob(parent_process_tag, CM_RESUME_ROUTING_DO_TASK_NAME, &parent_routing_task_resume));
			ITK(retcode,getSubProcessDependencyTask1(job_tags[0], CM_SUBPROCESS_DEPENDENT_TASK, &sub_process_perform_task_resume));
			
			if ( parent_routing_task_resume != NULLTAG && sub_process_perform_task_resume != NULLTAG )
			{
				ITK(retcode,AOM_lock(parent_routing_task_resume));
		
				ITK(retcode,EPM_remove_attachments(parent_routing_task_resume, 1, &sub_process_perform_task_resume));
			
				ITK(retcode,AOM_save(parent_routing_task_resume));
			
				ITK(retcode,AOM_unlock(parent_routing_task_resume));
			
			}
			else
			{
				TC_write_syslog("libWiproLiebert --- Either Parent Routing Task Resume or Sub Process Perform Task Resume are null\n");
			
			}			
		
		}
		ITK(retcode,EPM_ask_root_task(job_tags[0], &rootTask));
		
		TC_write_syslog("libWiproLiebert --- Detaching from Parent Process\n");
		
		ITK(retcode,AOM_lock(parent_process_tag));
		
		ITK(retcode,EPM_remove_sub_processes(parent_process_tag, 1, job_tags));
		
		ITK(retcode,AOM_save(parent_process_tag));
		
		TC_write_syslog("libWiproLiebert --- Successfully Detached from Parent Process\n");
		
		ITK(retcode,AOM_unlock(parent_process_tag));
		
		ITK(retcode,AOM_load(job_tags[0]));
		
		TC_write_syslog("libWiproLiebert --- Deleting the child process\n");
		
		ITK(retcode,AOM_delete(job_tags[0]));
		
		TC_write_syslog("libWiproLiebert --- Successfully deleted the Child Process\n");
	}
	EMR_free(job_tags);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	deleteApproverSubprocesses

*	Description		:	 This Function is used for deleting the SubProcess initiated for 
						 Approver					 

***************************************************************************************/

int deleteApproverSubprocesses(tag_t revTag,                      /* <I> */
							   int n_removed_groupmembers,        /* <I> */
                               tag_t *removed_group_member_tags,  /* <I> */
							   char *logged_in_user               /* <I> */
							  )
{
	int iFail = ITK_ok;
	int n_jobs = 0;
	char *AnalystId = NULL;
	tag_t *job_tags = NULL;
	
	ITK(iFail,EPM_ask_active_job_for_target(revTag, &n_jobs, &job_tags));
	ITK(iFail,AOM_ask_value_string(revTag,"lbt9_Change_Analyst",&AnalystId));
	if ( n_jobs > 0 )
	{
		for (int inx = 0; inx < n_removed_groupmembers; inx++)
		{
			tag_t groupTag = NULLTAG;
			tag_t roleTag = NULLTAG;
			tag_t userTag = NULLTAG;
			tag_t formTag = NULLTAG;
			
			char *userId = NULL;
			char *groupName = NULL;
			char *roleName = NULL;
			char formName[256];
			int IterationCount = 0;
			char *ItemId = NULL;
			ITK(iFail,AOM_ask_value_int(revTag,"lbt9_Iteration",&IterationCount));
			ITK(iFail,AOM_ask_value_string(revTag,"item_id",&ItemId));
			ITK(iFail,SA_ask_groupmember_group(removed_group_member_tags[inx], &groupTag));
			ITK(iFail,SA_ask_groupmember_role(removed_group_member_tags[inx], &roleTag));
			ITK(iFail,SA_ask_groupmember_user(removed_group_member_tags[inx], &userTag));
			
			ITK(iFail,SA_ask_group_full_name(groupTag, &groupName));
			ITK(iFail,SA_ask_role_name2(roleTag, &roleName));
			ITK(iFail,SA_ask_user_identifier2(userTag, &userId));
			
			if(userId != NULL && AnalystId != NULL && tc_strcmp(AnalystId,userId) != 0)
			{
				TC_write_syslog("libWiproLiebert --- Removed User [%d] Group/Role/User: %s/%s/%s\n", inx, groupName, roleName, userId);
				tc_strcpy(formName,groupName);
				tc_strcat(formName, "/");
				tc_strcat(formName, roleName);
				tc_strcat(formName, "/");
				tc_strcat(formName, userId);
				/* find the form attached to the item revision*/
				ITK(iFail,findForm(revTag, formName, &formTag));
			
				if( formTag != NULLTAG )
				{
				
					ITK(iFail,clearProcess(formTag, job_tags[0]));
				
					tc_strcat(formName, "_Removed");
				
					ITK(iFail,AOM_lock(formTag));
				
					ITK(iFail,AOM_set_value_string(formTag, "object_name", formName));
					ITK(iFail,AOM_set_value_string(formTag, "lbt9_ApproverStatus", "Removed"));
					ITK(iFail,AOM_set_value_string(formTag, "lbt9_SignoffStatus", ""));
				
					ITK(iFail,AOM_save(formTag));
				
					ITK(iFail,AOM_unlock(formTag));
				}
				ITK(iFail,fnForNotifyingRemoveApprovers(revTag,userTag,userId)); //added by Tanay
				EMR_free(userId);
				EMR_free(ItemId);
			}
		}
	}
	
	return iFail;
}

/**************************************************************************************
*	Function name	:	LBT_getUniqueObjects

*	Description		:	 This Function is used for  getting Unique Objects 

***************************************************************************************/
int LBT_getUniqueObjects(int n_objects,                  /* <I> */
					     tag_t *object_tags,             /* <I> */
						 int *n_unique_obects,           /* <O> */
						 tag_t **unique_object_tags      /* <OF> */
						)
{
	int retcode = ITK_ok;
	
	*n_unique_obects = 0;
	*unique_object_tags = NULL;
	
	for (int inx = 0; inx < n_objects; inx++)
	{
		if ( inx == 0 )
		{
			*unique_object_tags = (tag_t *) MEM_realloc(*unique_object_tags,(*n_unique_obects+1)*sizeof(tag_t));
            (*unique_object_tags)[*n_unique_obects] = object_tags[inx];
            *n_unique_obects = *n_unique_obects + 1;
		}
		else
		{
			if ( *n_unique_obects >= 1 )
			{	
				logical flag = false;
				for (int jnx = 0; jnx < *n_unique_obects; jnx++)
				{
					if ( (*unique_object_tags)[jnx] == object_tags[inx] )
					{
						flag = true;
						break;
					}
				}
				if ( !flag )
				{
					*unique_object_tags = (tag_t *) MEM_realloc(*unique_object_tags,(*n_unique_obects+1)*sizeof(tag_t));
					(*unique_object_tags)[*n_unique_obects] = object_tags[inx];
					*n_unique_obects = *n_unique_obects + 1;
				}
			}
		}
	}
	
	return retcode;
}


/**************************************************************************************
*	Function name	:	addAttachment

*	Description		:	This Function is used for attaching the Change Object to the Process
						as target

***************************************************************************************/
int addAttachment(tag_t rootTask,       /* <I> */		
				  tag_t objectTag,      /* <I> */
				  int attachment_type   /* <I> */
				 )
{
	int iFail = ITK_ok;
	int *attachType = NULL;
	
	tag_t *processAtt = NULL;
	
	processAtt = (tag_t *)MEM_alloc(sizeof(tag_t)*1);
	processAtt[0] = objectTag;
	
	attachType = (int *)MEM_alloc(sizeof(int)*1);
	attachType[0] = attachment_type;
	
	ITK(iFail,EPM_add_attachments(rootTask, 1, processAtt, attachType));
	
	return iFail;
}

/**************************************************************************************
*	Function name	:	attachFormToRevision

*	Description		:	This Function is used for attaching the Form  to the Change Object

***************************************************************************************/

int attachFormToRevision(tag_t formTag,										/* <I> */
						 tag_t revTag,										/* <I> */
						 const char *cpECNPropertyName						/* <I> */
						)
{
	int iFail = ITK_ok;
	tag_t referenceRelation = NULLTAG;
	int iExistingFormCount = 0;
	tag_t *tAllFormTags = NULL;
	ITK(iFail,AOM_ask_value_tags(revTag,cpECNPropertyName,&iExistingFormCount,&tAllFormTags));
	ITK(iFail,AOM_refresh(revTag,TRUE));
	ITK(iFail,AOM_set_value_tag_at(revTag,cpECNPropertyName,iExistingFormCount,formTag));
	ITK(iFail,AOM_save(revTag));
	ITK(iFail,AOM_refresh(revTag,FALSE));
	EMR_free(tAllFormTags);
	return iFail;
}


/**************************************************************************************
*	Function name	:	initiateSubProcess

*	Description		:	This Function is used for initiating the subprocess for target and 
						reference of a process

***************************************************************************************/
int initiateSubProcess(char *processName,         /* <I> */
					   tag_t targetObject,        /* <I> */
					   tag_t referenceObject,     /* <I> */
					   tag_t *subProcessTag       /* <O> */
					  )
{
	int iFail = ITK_ok;	
	int *attachType = NULL;

	tag_t processTemplate = NULLTAG;                                                
	tag_t newProcess = NULLTAG;
	tag_t *processAtt = NULL;
	*subProcessTag = NULLTAG;
	
	processAtt = (tag_t *)MEM_alloc(sizeof(tag_t)*2);
	processAtt[0] = targetObject;
	processAtt[1] = referenceObject;
	
	attachType = (int *)MEM_alloc(sizeof(int)*2);
	attachType[0] = EPM_target_attachment;
	attachType[1] = EPM_reference_attachment;

	ITK(iFail,EPM_find_process_template(CM_SUB_PROCESS_NAME, &processTemplate));
	
	if ( processTemplate != NULLTAG ) 
	{
		//ITK(EPM_create_process(processName, "", processTemplate, 2, processAtt, attachType, &newProcess));
		
		ITK(iFail,EPM_create_process_deferred_start(processName, "", processTemplate, 2, processAtt, attachType, &newProcess));
		
		*subProcessTag = newProcess;
	}
	else
	{
		TC_write_syslog("libWiproLiebert --- Process Template \"%s\" not found in Teamcenter\n", CM_SUB_PROCESS_NAME);
	}

	EMR_free(attachType);
	EMR_free(processAtt);
	
	return iFail;
}

/**************************************************************************************
*	Function name	:	getSubProcessDependencyTask1

*	Description		:	This Function is used for getting Subprocess Dependency task

***************************************************************************************/

int getSubProcessDependencyTask1(tag_t job_tag,          /* <I> */
                                char *task_name,        /* <I> */
                                tag_t *task_tag         /* <I> */
                               )
{
	int iFail = ITK_ok;
	
	tag_t root_task = NULLTAG;
	tag_t sub_task_tag = NULLTAG;
	
	*task_tag = NULLTAG;
	
	ITK(iFail,EPM_ask_root_task(job_tag, &root_task));
	
	ITK(iFail,EPM_ask_sub_task(root_task, task_name, &sub_task_tag));
	
	if ( sub_task_tag != NULLTAG )
	{
		*task_tag = sub_task_tag;
	}
	else
	{
		printf("No Task found with the given name %s\n", task_name);
	}
	
	return iFail;
}

/**************************************************************************************
*	Function name	:	getPerformSignoffTaskOfReview

*	Description		:	This Function is used for getting Subprocess Dependency task

***************************************************************************************/

int getPerformSignoffTaskOfReview(tag_t job_tag,              /* <I> */
                                  char *review_task_name,     /* <I> */
						          tag_t *task_tag             /* <O> */
						         )
{
	int iFail = ITK_ok;
	int taskCount = 0;
	
	tag_t *taskTags = NULL;
	*task_tag = NULLTAG;
	
	ITK(iFail,EPM_get_type_tasks(job_tag, eEPMPerformSignoffTask , &taskCount, &taskTags));
	
	for (int inx = 0; inx < taskCount; inx++)
	{
		tag_t reviewTaskTag = NULLTAG;
		
		char *task_name = NULL;
		
		ITK(iFail,EPM_ask_parent_task(taskTags[inx], &reviewTaskTag));
		
		ITK(iFail,EPM_ask_name2(reviewTaskTag, &task_name));
		
		if( tc_strcmp(task_name, review_task_name) == 0 )
		{
			*task_tag = taskTags[inx];
			break;
		}
		
		EMR_free(task_name);
	}
	
	EMR_free(taskTags);
		
	return iFail;
}

/**************************************************************************************
*	Function name	:	createAddApproverSubProcesses

*	Description		:	This Function is used for Creating subprocess For Approver

***************************************************************************************/

int createAddApproverSubProcesses(tag_t revTag,                      /* <I> */
								  int n_added_groupmembers,          /* <I> */
                                  tag_t *added_group_member_tags,    /* <I> */
								  char *logged_in_user,               /* <I> */
								  const char *cpAction
								 )
{
	int iFail = ITK_ok;
	int n_jobs = 0;
	logical Flag = false;
	
	tag_t *job_tags = NULL;
	
	ITK(iFail,EPM_ask_active_job_for_target(revTag, &n_jobs, &job_tags));
	
	if ( n_jobs > 0 )
	{
		tag_t parent_root_task_tag = NULLTAG;
		tag_t routingTaskTag = NULLTAG;
		
		EPM_state_t routingTaskState;
		
		ITK(iFail,EPM_ask_root_task(job_tags[0], &parent_root_task_tag));
				
		ITK(iFail,getRoutingDoTaskOfJob(job_tags[0], CM_ROUTING_DO_TASK_NAME, &routingTaskTag));
	
		if ( routingTaskTag == NULLTAG )
		{
			TC_write_syslog("libWiproLiebert --- No DO Task exists with name %s in the current workflow process\n", CM_ROUTING_DO_TASK_NAME);
			return ITK_ok;
		}
		
		ITK(iFail,EPM_ask_state(routingTaskTag, &routingTaskState));
		
		if (tc_strcmp(cpAction,"ClientTrigger") == 0)
		{
			if( routingTaskState != EPM_started )
			{
				TC_write_syslog("libWiproLiebert --- %s has not yet started.\n", CM_ROUTING_DO_TASK_NAME);
				return ITK_ok;
			}
			Flag = true;
		}
		else if (tc_strcmp(cpAction,"ServerTrigger") == 0)
		{
			Flag = true;
		}
		if (!Flag)
		{
			return ITK_ok;
		}
		for (int inx = 0; inx < n_added_groupmembers; inx++)
		{
			tag_t groupTag = NULLTAG;
			tag_t roleTag = NULLTAG;
			tag_t userTag = NULLTAG;
			tag_t formTag = NULLTAG;
			tag_t subProcessTag = NULLTAG;
			
			char *current_date_string = NULL;
			char *groupName = NULL;
			char *roleName = NULL;
			char *userId = NULL;
			char *person_name = NULL;
			char *ItemId = NULL;
			char formName[256];
			char TaskName[256];
			int IterationCount = 0;
			date_t current_date = NULLDATE;
			char *AnalystId = NULL;
			tag_t tDelegateMemberTag			= NULLTAG;
			tag_t tDelegateUserTag				= NULLTAG;
			date_t DelegateUsetStartDate;
			date_t DelegateUsetEndDate;
			logical DelegationFalg				= false;
			
			ITK(iFail,AOM_ask_value_string(revTag,"lbt9_Change_Analyst",&AnalystId));
			ITK(iFail,AOM_ask_value_int(revTag,"lbt9_Iteration",&IterationCount));
			ITK(iFail,AOM_ask_value_string(revTag,"item_id",&ItemId));

			char * resoucepool_name = NULL;
			tag_t tClassId = NULLTAG;
			//ITK(iFail,EPM_get_resource_pool_name(added_group_member_tags[inx], &resoucepool_name));

			ITK(iFail,POM_class_of_instance(added_group_member_tags[inx],&tClassId));

			ITK(iFail,POM_name_of_class(tClassId, &resoucepool_name));

			
			if(tc_strcmp(resoucepool_name, "GroupMember") == 0)
			{
				iFail = ITK_ok;
				printf("CA Resouce Pool Task\n");
				ITK(iFail,SA_ask_groupmember_group(added_group_member_tags[inx], &groupTag));
				ITK(iFail,SA_ask_groupmember_role(added_group_member_tags[inx], &roleTag));
				ITK(iFail,SA_ask_groupmember_user(added_group_member_tags[inx], &userTag));
			}
			else if(tc_strcmp(resoucepool_name, "ResourcePool") == 0)
			{
				logical is_sub = false;
				ITK(iFail,EPM_ask_resource_pool_group_role(added_group_member_tags[inx],&groupTag,&roleTag, &is_sub));
				ITK(iFail,SA_find_user2(AnalystId, &userTag));
			}
			//checking deligation user for CCB Reviewer member
			if (userTag != NULLTAG)
			{
				ITK(iFail,EPM_ask_out_of_office(userTag,&tDelegateMemberTag,&DelegateUsetStartDate,&DelegateUsetEndDate));

				if (tDelegateMemberTag != NULLTAG)
				{
					DelegationFalg = true;
				}
			}				
			ITK(iFail,SA_ask_group_full_name(groupTag, &groupName));
			ITK(iFail,SA_ask_role_name2(roleTag, &roleName));
			ITK(iFail,SA_ask_user_identifier2(userTag, &userId));
			ITK(iFail,SA_ask_user_person_name2(userTag, &person_name));
			//Send email if deligation user exist for CCB Reviewer member
			if (DelegationFalg)
			{
				if(tc_strcmp(userId,AnalystId)!=0)
				{
					ITK(iFail,fnForNotifyingOOFAddedApprovers(revTag,userTag,userId));
					return iFail;
				}
			}

			ITK(iFail,ITK_ask_default_date_format(&current_date_string));
			ITK(iFail,ITK_string_to_date(current_date_string, &current_date));
			char **cpFormGrpName = NULL;
			int iValueCount = 0;
			if(groupName != NULL)
			{						
				ITK(iFail,EPM__parse_string(groupName,".",&iValueCount,&cpFormGrpName));
			}
			tc_strcpy(formName, groupName); 
			tc_strcat(formName, "/");
			tc_strcat(formName, roleName);
			tc_strcat(formName, "/");
			tc_strcat(formName, userId);
			
			if( AnalystId != NULL && tc_strcmp(AnalystId,userId) == 0)
			{
				tc_strcpy(TaskName, "CA Review");
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, ItemId);
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, userId);
			}
			else if( AnalystId != NULL && tc_strcmp(AnalystId,userId) != 0)
			{
				tc_strcpy(TaskName, "CCB Review");
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, ItemId);
				tc_strcat(TaskName, "/");
				tc_strcat(TaskName, userId);
			}
			
			/* Create a form*/
			ITK(iFail,FORM_create(formName, "", CM_FORM_TYPE, &formTag));
			
			 /* Construct a CreateInput object for Form */
			tag_t form_type_tag = NULLTAG;
			ITK(iFail,TCTYPE_find_type(CM_FORM_TYPE, NULL, &form_type_tag));

			tag_t form_create_input_tag = NULLTAG;
			ITK(iFail,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

			ITK(iFail,AOM_set_value_string(form_create_input_tag, "object_name", formName));			
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverUserID", userId));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverName", person_name));
			if(cpFormGrpName != NULL)
			{
				ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverGroup", cpFormGrpName[0]));
			}
			if(roleName != NULL)
			{
				ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverRole", roleName));
			}
		    ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_AssignedBy", logged_in_user));
			ITK(iFail,AOM_set_value_date(form_create_input_tag, "lbt9_AssignedDate", current_date));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_SignoffStatus", ""));
			ITK(iFail,AOM_set_value_string(form_create_input_tag, "lbt9_ApproverStatus", "Assigned"));
			ITK(iFail,AOM_set_value_int(form_create_input_tag, "lbt9_Iteration", IterationCount)); // added by Tanay for Iteration
			
		

			printf("Form Name : %s\n", formName);
			printf("Approver User ID : %s\n", userId);
			printf("Approver Name    : %s\n", person_name);
			printf("Assigned By      : %s\n", logged_in_user);
			printf("Signoff Status   : In Process\n");
			printf("Approver Status  : Active\n");
			TC_write_syslog("libWiproLiebert --- after creating approverform");
			ITK(iFail,TCTYPE_create_object(form_create_input_tag, &formTag));
						
			ITK(iFail,AOM_save_with_extensions(formTag));
			
			///* Add the form as reference attachment to the parent root task */
			ITK(iFail,addAttachment(parent_root_task_tag, formTag, EPM_reference_attachment));
			//
			///* Attach the form to the Revision with LBT9_ECN_Approver_Rel relation*/
			ITK(iFail,attachFormToRevision(formTag, revTag,Attr_ECN_REVIEWERS_LIST));
			
			/*Initiate subprocess on the form*/
			ITK(iFail,initiateSubProcess(TaskName, formTag, revTag, &subProcessTag));
			
			if ( subProcessTag != NULLTAG )
			{
				int taskCount = 0;
				int *attachType = NULL;
				
				tag_t sub_process_perform_task = NULLTAG;
				tag_t subprocess_root_task = NULLTAG;
				tag_t *taskTags = NULL;
				
				attachType = (int *)MEM_alloc(sizeof(int)*1);
				attachType[0] = EPM_interprocess_task_attachment;

				/* Attach the sub process to parent process */
				ITK(iFail,EPM_attach_sub_processes(job_tags[0], 1, &subProcessTag));
				
				/*Get the Perform Signoff Task of Sub Process*/
				ITK(iFail,getPerformSignoffTaskOfReview(subProcessTag, CM_SUBPROCESS_DEPENDENT_REVIEW_TASK, &sub_process_perform_task));
				
				/* Commented the above and add the below line to change the dependency task*/
				ITK(iFail,getSubProcessDependencyTask1(subProcessTag, CM_SUBPROCESS_DEPENDENT_TASK, &sub_process_perform_task));
				
				if ( sub_process_perform_task == NULLTAG )
				{
					printf("dependency task %s not found in the sub process\n", CM_SUBPROCESS_DEPENDENT_TASK);
					
					return iFail;
				}
				
				/* Add the Dependency between Routing Task of Parent Process and Perform Signoff Task of Sub Process */			
				ITK(iFail,EPM_add_attachments(routingTaskTag, 1, &sub_process_perform_task, attachType));
				
				/* Get the Root Task of Sub Process and Start the Sub Process*/
				ITK(iFail,EPM_ask_root_task(subProcessTag, &subprocess_root_task));
				
				tag_t tAnalystTag = NULLTAG;
				
				char *cpTaskName = NULL;

				ITK(iFail,SA_find_user2(AnalystId,&tAnalystTag));

				ITK(iFail,EPM_ask_name2(subprocess_root_task,&cpTaskName));

				printf("\n Approval Subprocess Task Name : %s \n",cpTaskName);
				
				ITK(iFail,EPM_trigger_action(subprocess_root_task, EPM_complete_action, "Started the sub process"));
				
				ITK(iFail,EPM_get_type_tasks(subProcessTag, eEPMSelectSignoffTask , &taskCount, &taskTags));
				
				if ( taskCount > 0 )
				{
					int count = 0;

					tag_t *signoffs = NULLTAG;
					
					ITK(iFail,AOM_refresh(taskTags[0],true));

					ITK(iFail,EPM_create_adhoc_signoff(taskTags[0], added_group_member_tags[inx], &count, &signoffs));
					printf("No. of Signoffs created : %d\n", count);
					TC_write_syslog("libWiproLiebert --- No. of Signoffs created : %d\n", count);

					ITK(iFail,EPM_set_adhoc_signoff_selection_done(taskTags[0], TRUE));
					
					ITK(iFail,EPM_trigger_action(taskTags[0], EPM_complete_action, "Started the sub process"));
					
					ITK(iFail,AOM_save(taskTags[0]));
					ITK(iFail,AOM_refresh(taskTags[0], false));

					EMR_free(signoffs);
				}
				else
				{
					TC_write_syslog("libWiproLiebert --- Could not find SelectSignoffTask\n");
				}
				
				int iAllTaskCount = 0;
				tag_t *tSubTaskTags = NULL;
				
				ITK(iFail,EPM_ask_sub_tasks(subprocess_root_task,&iAllTaskCount,&tSubTaskTags));

				if(tSubTaskTags != NULL && iAllTaskCount > 0)
				{
					for(int inx = 0; inx < iAllTaskCount; inx++)
					{
						ITK(iFail,EPM_assign_responsible_party(tSubTaskTags[inx],tAnalystTag))
					}
				}
				ITK(iFail,EPM_assign_responsible_party(subprocess_root_task,tAnalystTag));
				
				ITK(iFail,fnForNotifyingAddedApprovers(revTag,userTag,userId));			//added by tanay
				
				EMR_free(taskTags);
				for(int jnx =  0; jnx < iValueCount; jnx++)
				{
					EMR_free(cpFormGrpName[jnx]);
				}
			}
			else
			{
				TC_write_syslog("libWiproLiebert --- Unable to create the sub process.\n");
			}
			EMR_free(AnalystId);			
			EMR_free(groupName);
			EMR_free(roleName);
			EMR_free(userId);
			EMR_free(ItemId);
			EMR_free(current_date_string);
		}
	}
	return iFail;
}

/**************************************************************************************
*	Function name	:	getRoutingDoTaskOfJob

*	Description		:	This Function is used getting Routing Task of Job

***************************************************************************************/
int getRoutingDoTaskOfJob(tag_t job_tag,      /* <I> */
						  char *taskName,     /* <I> */
						  tag_t *task_tag     /* <O> */
						 )
{
	int iFail = ITK_ok;
	int taskCount = 0;
	
	tag_t *taskTags = NULL;
	*task_tag = NULLTAG;
	
	ITK(iFail,EPM_get_type_tasks(job_tag, eEPMDoTask , &taskCount, &taskTags));
	
	for (int inx = 0; inx < taskCount; inx++)
	{
		char *task_name = NULL;
		
		ITK(iFail,EPM_ask_name2(taskTags[inx], &task_name));
		
		if( tc_strcmp(task_name, taskName) == 0 )
		{
			*task_tag = taskTags[inx];
			break;
		}
		
		EMR_free(task_name);
	}
	
	EMR_free(taskTags);
		
	return iFail;
}

/**************************************************************************************
*	Function name	:	fnSetFormValues

*	Description		:	This Function is used setting the values on Form

***************************************************************************************/

int fnSetFormValues (	tag_t FormTag			/*<I>*/,
						tag_t UserTag			/*<I>*/,
						char* status			/*<O>*/
				    )
{
	int retcode = ITK_ok;
	char *current_date_string = NULL;
	char *userId = NULL;
	char *cpformId = NULL;
	
	
	date_t currentDate = NULLDATE;
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	ITK(retcode,ITK_string_to_date(current_date_string, &currentDate));
	ITK(retcode,SA_ask_user_identifier2(UserTag,&userId));
	//ITK(retcode,AOM_ask_value_string(FormTag, "current_name",&cpformId));
	ITK(retcode,AOM_lock(FormTag));
	if(userId != NULL)
	{
		ITK(retcode,AOM_set_value_string(FormTag, "lbt9_history_user", userId));
		ITK(retcode,AOM_set_value_string(FormTag, "lbt9_history_type", "Sign-Off"));
		ITK(retcode,AOM_set_value_string(FormTag, "lbt9_history_status", status));
		ITK(retcode,AOM_set_value_date(FormTag, "lbt9_history_date", currentDate));
		ITK(retcode,AOM_save(FormTag));
		ITK(retcode,AOM_unlock(FormTag));
		EMR_free(current_date_string);
		EMR_free(userId);
	}
	return ITK_ok;
}

/**************************************************************************************
*	Function name	:	fnGetParticipantUsersList1

*	Description		:	This Function is used for getting ParticipantsList

***************************************************************************************/

int fnGetParticipantUsersList1(tag_t tTargetAttachment,										/* <I> */
							  const char *ParticipantType,									/* <I> */
							  int *iReviewersCount,											/* <O> */
							  tag_t **tReviewersTags										/* <OF> */
							 )
{
	int iFail							=	ITK_ok;
	int iParticipantCount				= 0;
	tag_t tParticipantType				= NULLTAG;
	tag_t tAssignee						= NULLTAG;
	tag_t tUserTag						= NULLTAG;
	tag_t *participant_list				= NULL;
	char *cpParticipantType				= NULL;

	*iReviewersCount = 0;
	*tReviewersTags = NULL;			
	
	
	cpParticipantType=(char *) MEM_alloc(tc_strlen(ParticipantType) + 2);
	tc_strcpy(cpParticipantType,"");
	tc_strcpy(cpParticipantType,ParticipantType);
	ITK(iFail,EPM_get_participanttype(cpParticipantType,&tParticipantType));
	if (tParticipantType != NULLTAG)
	{
		ITK(iFail,ITEM_rev_ask_participants(tTargetAttachment,tParticipantType,&iParticipantCount,&participant_list));
	}	

	if (participant_list != NULL)
	{
		*tReviewersTags = (tag_t *) MEM_realloc(*tReviewersTags,(iParticipantCount+1)*sizeof(tag_t));
		for (int i = 0; i < iParticipantCount; i++)
		{
			ITK(iFail,AOM_ask_value_tag(participant_list[i],ASSIGNEE_USER,&tAssignee));

			if (tAssignee != NULLTAG)
			{
				//ITK(iFail,AOM_ask_value_tag(tAssignee,USER,&tUserTag));

				//if (tUserTag != NULLTAG)
				//{
					//Vuser.push_back(tUserTag);
					(*tReviewersTags)[*iReviewersCount] = tAssignee;
					 *iReviewersCount = *iReviewersCount + 1;
				//}
			}
		}
	}
	EMR_free(participant_list);
	return ITK_ok;
}

/**************************************************************************************
*	Function name	:	addObservers

*	Description		:	This Function is used for adding the Observers to the Change Object

***************************************************************************************/
int addObservers(tag_t revTag,                 /* <I> */
                 int n_added_observers,        /* <I> */
				 tag_t *added_observer_tags,   /* <I> */
				 char *logged_in_user          /* <I> */
				)
{
	int retcode = ITK_ok;
	int n_existing_observers = 0;
	int n_new_observers = 0;
	int n_con_observers = 0;
	
	char **observers_list = NULL;
	char **existing_observers_list = NULL;
	char **con_observers_list = NULL;
	char **new_observers_list = NULL;
	
	ITK(retcode,AOM_ask_value_strings(revTag, "lbt9_observers", &n_existing_observers, &existing_observers_list));
	
	for (int inx = 0; inx < n_added_observers; inx++)
	{
		tag_t groupTag = NULLTAG;
		tag_t roleTag = NULLTAG;
		tag_t userTag = NULLTAG;
		
		char *groupName = NULL;
		char *roleName = NULL;
		char *userId = NULL;
		char *person_name = NULL;
		char *formName = NULL;
		
		ITK(retcode,SA_ask_groupmember_group(added_observer_tags[inx], &groupTag));
		ITK(retcode,SA_ask_groupmember_role(added_observer_tags[inx], &roleTag));
		ITK(retcode,SA_ask_groupmember_user(added_observer_tags[inx], &userTag));
		
		ITK(retcode,SA_ask_group_full_name(groupTag, &groupName));
		ITK(retcode,SA_ask_role_name2(roleTag, &roleName));
		ITK(retcode,SA_ask_user_identifier2(userTag, &userId));
		ITK(retcode,SA_ask_user_person_name2(userTag, &person_name));
		
		TC_write_syslog("libWiproLiebert --- Assigner Observer [%d] Group/Role/User: %s/%s/%s\n", inx, groupName, roleName, userId);
		
		observers_list = (char **)MEM_realloc( observers_list, n_added_observers*sizeof(char *));
		
		observers_list[inx] = (char *) MEM_alloc((tc_strlen(groupName)+tc_strlen(roleName)+tc_strlen(userId)+3)*sizeof(char));
		
		tc_strcpy(observers_list[inx], groupName);
		tc_strcat(observers_list[inx], "/");
		tc_strcat(observers_list[inx], roleName);
		tc_strcat(observers_list[inx], "/");
		tc_strcat(observers_list[inx], userId);
	}
		
	ITK(retcode,getConsolidatedObservers(n_existing_observers, existing_observers_list, n_added_observers, observers_list, &n_con_observers, &con_observers_list));
	
	if ( n_con_observers > 0 )
	{
		ITK(retcode,AOM_lock(revTag));
		
		ITK(retcode,AOM_set_value_strings(revTag, "lbt9_observers", n_con_observers, con_observers_list));
		
		ITK(retcode,AOM_save(revTag));
		
		ITK(retcode,AOM_unlock(revTag));
	}
	
	ITK(retcode,getNewlyAddedObservers(n_existing_observers, existing_observers_list, n_added_observers, observers_list, &n_new_observers, &new_observers_list));
	
	if( n_new_observers > 0 )
	{
		char *to_users_list = NULL;
		
		ITK(retcode,CreateObserverForms(revTag, n_new_observers, new_observers_list, logged_in_user));

	}
	
	EMR_free(existing_observers_list);
	EMR_free(con_observers_list);
	EMR_free(new_observers_list);
	EMR_free(observers_list);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	attachObserverFormToRevision

*	Description		:	This Function is used for attaching the observer form to 
						ChangeObject Revision

***************************************************************************************/
int attachObserverFormToRevision(tag_t formTag,       /* <I> */
						         tag_t revTag         /* <I> */
						        )
{
	int retcode = ITK_ok;
	tag_t referenceRelation = NULLTAG;

	ITK(retcode,attachFormToRevision(formTag, revTag,Attr_ECN_OBSERVER_LIST));
	
	return retcode;
}
/**************************************************************************************
*	Function name	:	getConsolidatedObservers

*	Description		:	This Function is used for consolidating the Observers

***************************************************************************************/
int getConsolidatedObservers(int n_existing_observers,               /* <I> */
                             char **existing_observers_list,         /* <I> */
						     int n_added_observers,                  /* <I> */
						     char **added_observers_list,            /* <I> */
						     int *n_con_observers,                   /* <O> */
						     char ***con_observers_list              /* <OF> */
						    )
{
	int retcode = ITK_ok;
	
	*n_con_observers = 0;
	*con_observers_list = NULL;
	
	if ( n_existing_observers == 0 )
	{
		for (int inx = 0; inx < n_added_observers; inx++)
		{
			*con_observers_list = (char **) MEM_realloc(*con_observers_list, (*n_con_observers+1)*sizeof(char *));
			(*con_observers_list)[*n_con_observers] = added_observers_list[inx];
			*n_con_observers = *n_con_observers + 1;
		}
		return retcode;
	}
	
	for(int inx = 0; inx < n_existing_observers; inx++)
	{
		*con_observers_list = (char **) MEM_realloc(*con_observers_list, (*n_con_observers+1)*sizeof(char *));
		(*con_observers_list)[*n_con_observers] = existing_observers_list[inx];
		*n_con_observers = *n_con_observers + 1;
	}
	
	for (int inx = 0; inx < n_added_observers; inx++)
	{
		logical flag = false;
		
		for (int jnx = 0; jnx < n_existing_observers; jnx++)
		{
			if ( tc_strcmp(existing_observers_list[jnx], added_observers_list[inx]) == 0 )
			{
				flag = true;
				break;
			}
		}
		
		if( !flag )
		{
			*con_observers_list = (char **) MEM_realloc(*con_observers_list, (*n_con_observers+1)*sizeof(char *));
			(*con_observers_list)[*n_con_observers] = added_observers_list[inx];
			*n_con_observers = *n_con_observers + 1;
		}
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	getNewlyAddedObservers

*	Description		:	This Function is used for getting the newly added Observers

***************************************************************************************/
int getNewlyAddedObservers(int n_existing_observers,               /* <I> */
                           char **existing_observers_list,         /* <I> */
						   int n_added_observers,                  /* <I> */
						   char **added_observers_list,            /* <I> */
						   int *n_new_observers,                   /* <O> */
						   char ***new_observers_list              /* <OF> */
						  )
{
	int retcode = ITK_ok;
	
	*n_new_observers = 0;
	*new_observers_list = NULL;
	
	if ( n_existing_observers == 0 )
	{
		for (int inx = 0; inx < n_added_observers; inx++)
		{
			*new_observers_list = (char **) MEM_realloc(*new_observers_list, (*n_new_observers+1)*sizeof(char *));
			(*new_observers_list)[*n_new_observers] = added_observers_list[inx];
			*n_new_observers = *n_new_observers + 1;
		}
		return retcode;
	}
	
	for (int inx = 0; inx < n_added_observers; inx++)
	{
		logical flag = false;
		
		for (int jnx = 0; jnx < n_existing_observers; jnx++)
		{
			if ( tc_strcmp(existing_observers_list[jnx], added_observers_list[inx]) == 0 )
			{
				flag = true;
				break;
			}
		}
		
		if( !flag )
		{
			*new_observers_list = (char **) MEM_realloc(*new_observers_list, (*n_new_observers+1)*sizeof(char *));
			(*new_observers_list)[*n_new_observers] = added_observers_list[inx];
			*n_new_observers = *n_new_observers + 1;
		}
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	CreateObserverForms

*	Description		:	This Function is used for creating Form for Observers

***************************************************************************************/

int CreateObserverForms(tag_t revTag,                   /* <I> */
                        int n_new_observers,            /* <I> */
						char **new_observers_list,      /* <I> */
						char *logged_in_user            /* <I> */
					   )
{
	int retcode = ITK_ok;
	
	tag_t form_type_tag = NULLTAG;
	
	char *current_date_string = NULL;
	
	date_t current_date = NULLDATE;
	
	ITK(retcode,TCTYPE_find_type(CM_OBSERVER_FORM_TYPE, NULL, &form_type_tag));
	
	ITK(retcode,ITK_ask_default_date_format(&current_date_string));
	
	ITK(retcode,ITK_string_to_date(current_date_string, &current_date));
	
	for (int inx = 0; inx < n_new_observers; inx++)
	{
		tag_t formTag = NULLTAG;
		tag_t form_create_input_tag = NULLTAG;
		
		ITK(retcode,TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", new_observers_list[inx]));			
		ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "lbt9_AssignedBy", logged_in_user));
		ERROR_CHECK(AOM_set_value_date(form_create_input_tag, "lbt9_AssignedDate", current_date));
		
		printf("Form Name    : %s\n", new_observers_list[inx]);
		printf("Assigned By  : %s\n", logged_in_user);
		
		ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
		
		ERROR_CHECK(AOM_save(formTag));
		
		ERROR_CHECK(AOM_save_with_extensions(formTag));
		
		/* Attach the form to the Revision with LBT9_ECN_Observers_Rel relation*/
		ITK(retcode,attachObserverFormToRevision(formTag, revTag));		   
	}
	
	EMR_free(current_date_string);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	removeObservers

*	Description		:	This Function is used for removing Observers

***************************************************************************************/

int removeObservers(tag_t revTag,                   /* <I> */
                    int n_removed_observers,        /* <I> */
				    tag_t *removed_observer_tags,   /* <I> */
					char *logged_in_user            /* <I> */
				   )
{
	int retcode = ITK_ok;
	int n_existing_observers = 0;
	int n_new_observers = 0;
	int n_leftover_observers = 0;
	
	char **removed_observers_list = NULL;
	char **existing_observers_list = NULL;
	char **leftover_observers_list = NULL;
	char **new_observers_list = NULL;
	
	ITK(retcode,AOM_ask_value_strings(revTag, "lbt9_observers", &n_existing_observers, &existing_observers_list));
	
	for (int inx = 0; inx < n_removed_observers; inx++)
	{
		tag_t groupTag = NULLTAG;
		tag_t roleTag = NULLTAG;
		tag_t userTag = NULLTAG;
		
		char *groupName = NULL;
		char *roleName = NULL;
		char *userId = NULL;
		char *person_name = NULL;
		char *formName = NULL;
		
		ITK(retcode,SA_ask_groupmember_group(removed_observer_tags[inx], &groupTag));
		ITK(retcode,SA_ask_groupmember_role(removed_observer_tags[inx], &roleTag));
		ITK(retcode,SA_ask_groupmember_user(removed_observer_tags[inx], &userTag));
		
		ITK(retcode,SA_ask_group_full_name(groupTag, &groupName));
		ITK(retcode,SA_ask_role_name2(roleTag, &roleName));
		ITK(retcode,SA_ask_user_identifier2(userTag, &userId));
		ITK(retcode,SA_ask_user_person_name2(userTag, &person_name));
		
		TC_write_syslog("libWiproLiebert --- Assigner Observer [%d] Group/Role/User: %s/%s/%s\n", inx, groupName, roleName, userId);
		
		removed_observers_list = (char **)MEM_realloc( removed_observers_list, n_removed_observers*sizeof(char *));
		
		removed_observers_list[inx] = (char *) MEM_alloc((tc_strlen(groupName)+tc_strlen(roleName)+tc_strlen(userId)+3)*sizeof(char));
		
		tc_strcpy(removed_observers_list[inx], groupName);
		tc_strcat(removed_observers_list[inx], "/");
		tc_strcat(removed_observers_list[inx], roleName);
		tc_strcat(removed_observers_list[inx], "/");
		tc_strcat(removed_observers_list[inx], userId);
	}
		
	ITK(retcode,getLeftOverObservers(n_existing_observers, existing_observers_list, n_removed_observers, removed_observers_list, &n_leftover_observers, &leftover_observers_list));
	
	if ( n_leftover_observers > 0 )
	{
		ITK(retcode,AOM_lock(revTag));
		
		ITK(retcode,AOM_set_value_strings(revTag, "lbt9_observers", n_leftover_observers, leftover_observers_list));
		
		ITK(retcode,AOM_save(revTag));
		
		ITK(retcode,AOM_unlock(revTag));
	}
	else
	{
		logical isRemoved = false;
		
		ITK(retcode,LBT_removeValueFromMultiListString(revTag, "lbt9_observers", n_existing_observers, existing_observers_list, &isRemoved));
		
	}
	
	for (int inx = 0; inx < n_removed_observers; inx++)
	{
		tag_t observer_form_tag = NULLTAG;
		
		ITK(retcode,findObserverForm(revTag, removed_observers_list[inx], &observer_form_tag));
		
		if ( observer_form_tag != NULLTAG )
		{
			ITK(retcode,AOM_lock(revTag));
			
			ITK(retcode,AOM_delete_from_parent(observer_form_tag, revTag));
			
			ITK(retcode,AOM_save(revTag));
			
			ITK(retcode,AOM_unlock(revTag));
		}
	}
	
	EMR_free(existing_observers_list);
	EMR_free(leftover_observers_list);
	EMR_free(removed_observers_list);
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	getLeftOverObservers

*	Description		:	This Function is used for getting the remained observers

***************************************************************************************/

int getLeftOverObservers(int n_existing_observers,               /* <I> */
                         char **existing_observers_list,         /* <I> */
						 int n_removed_observers,                /* <I> */
						 char **removed_observers_list,          /* <I> */
						 int *n_leftover_observers,              /* <O> */
						 char ***leftover_observers_list         /* <OF> */
						)
{
	int retcode = ITK_ok;
	
	*n_leftover_observers = 0;
	*leftover_observers_list = NULL;
	
	if ( n_existing_observers == 0 )
	{
		printf("There are no observers for removal\n");
		return retcode;
	}
	
	for (int inx = 0; inx < n_existing_observers; inx++)
	{
		logical flag = false;
		
		printf("Existing Observer [%d] : %s\n", inx, existing_observers_list[inx]);
		
		for (int jnx = 0; jnx < n_removed_observers; jnx++)
		{
			printf("\tRemoved Observers List : %s\n", removed_observers_list[jnx]);
			if ( tc_strcmp(existing_observers_list[inx], removed_observers_list[jnx]) == 0 )
			{
				flag = true;
				break;
			}
		}
		
		if( !flag )
		{
			*leftover_observers_list = (char **) MEM_realloc(*leftover_observers_list, (*n_leftover_observers+1)*sizeof(char *));
			(*leftover_observers_list)[*n_leftover_observers] = existing_observers_list[inx];
			printf("Leftover Observer [%d] : %s\n", n_leftover_observers, existing_observers_list[inx]);
			*n_leftover_observers = *n_leftover_observers + 1;
		}
		
	}
		
	return retcode;
}

/**************************************************************************************
*	Function name	:	LBT_removeValueFromMultiListString

*	Description		:	This Function is used for removing value from multiline string 
						when observer is removed

***************************************************************************************/

extern int LBT_removeValueFromMultiListString(tag_t object,                        /* <I> */
											  char *multi_string_propertyname,     /* <I> */
											  int n_values_to_be_removed,          /* <I> */
                                              char **valueToBeRemoved,             /* <I> */
                                              logical *flag                        /* <O> */
                                             )
{
    int retcode = ITK_ok;
    int removedValues = 0;

    tag_t inst_class_id = NULLTAG;
    tag_t tPropertyAttrId = NULLTAG;
    tag_t *valueTags = NULL;

    char *classname = NULL;

    *flag = false;

    ITK(retcode,POM_class_of_instance(object, &inst_class_id));

    ITK(retcode,POM_name_of_class(inst_class_id, &classname));

    ITK(retcode,POM_attr_id_of_attr(multi_string_propertyname, classname, &tPropertyAttrId));
	
	ITK(retcode,AOM_lock(object));
	
	for (int inx = 0; inx < n_values_to_be_removed; inx++)
	{
		int values_index = -1;
		
		ITK(retcode,POM_ask_index_of_string(object, tPropertyAttrId, valueToBeRemoved[inx], &values_index));

		if( values_index != -1 )
		{
			ITK(retcode,POM_remove_from_attr(1, &object, tPropertyAttrId, values_index, 1));
			removedValues = removedValues + 1;
		}
	}
	
	if ( removedValues == removedValues )
	{
		*flag = false;
	}
	
	ITK(retcode,AOM_save(object));	
	ITK(retcode,AOM_unlock(object));
	
    EMR_free(classname);
    EMR_free(valueTags);

    return retcode;
}

/**************************************************************************************
*	Function name	:	findObserverForm

*	Description		:	This Function is used for Finding observer Form

***************************************************************************************/

int findObserverForm(tag_t revTag,      /* <I> */
			         char *formName,    /* <I> */
			         tag_t *formTag     /* <O> */
			        )
{
	int retcode = ITK_ok;
	
	tag_t referenceRelation = NULLTAG;
	
	*formTag = NULLTAG;
	
	ITK(retcode,GRM_find_relation_type(CLASS_ECN_APPROVER_FORM, &referenceRelation));
	
	if ( referenceRelation != NULLTAG )
	{
		int secCount = 0;
		tag_t *secObjects = NULL;
		
		ITK(retcode,GRM_list_secondary_objects_only(revTag, referenceRelation, &secCount, &secObjects));
		
		for(int inx = 0; inx < secCount; inx++)
		{
			char *secObjectName = NULL;
			char *secObjectType = NULL;
			
			ITK(retcode,AOM_ask_value_string(secObjects[inx], "object_name", &secObjectName));
			
			ITK(retcode,AOM_ask_value_string(secObjects[inx], "object_type", &secObjectType));
			
			if ( tc_strcmp(secObjectType, CM_OBSERVER_FORM_TYPE) == 0 && tc_strcmp(secObjectName, formName) == 0 )
			{
				*formTag = secObjects[inx];
				break;
			}
			
			EMR_free(secObjectName);
		}
		EMR_free(secObjects);
	}
	
	return retcode;
}

/**************************************************************************************
*	Function name	:	fnsubString

*	Description		:	This Function is used for getting Substring of a String

***************************************************************************************/

int  fnsubString	( char*  String,					/* <I> */ 
					  int endvalue,						/* <I> */
					  char ** subString					/* <OF> */
					)
{
	int retcode =	ITK_ok;

	//char String[40];
	char finalsubString[64];
	*subString = NULL;
	int position=1;
	int c=0;
	while(c<endvalue)
	{
		finalsubString[c]=String[position+c-1];
		c++;
	}
	finalsubString[c] = '\0';
	*subString = (char *)MEM_alloc(tc_strlen(finalsubString));
	tc_strcpy(*subString,finalsubString);

	return retcode;
}

/**************************************************************************************
*	Function name	:	fnAddressList

*	Description		:	This Function is used for getting the users from the Address list

***************************************************************************************/
int fnAddressList	(tag_t* ptTargetAttmnts ,						/* <I> */
					 int iAttchItemCount,							/* <I> */
					 tag_t* tAttchItemTag							/* <I> */
					)
{
	int retcode	=	ITK_ok;
	char * cObjecType = NULL;
	char *cpChangeAnalystUserID = NULL; 
	ITK(retcode,AOM_ask_value_string(ptTargetAttmnts[0],"lbt9_Change_Analyst",&cpChangeAnalystUserID));
	for(int i=0;i<iAttchItemCount;i++)
	{
		int n_product_line_count	=	0;
		char **cProductLineValue = NULL;
		char * cPlantsEffectedValue = NULL;
		char * cPCCValue = NULL;
		//char * cFinalString	= NULL;
		//cFinalString = (char*) MEM_alloc(( 30)* sizeof(char));

		ITK(retcode,WSOM_ask_object_type2(tAttchItemTag[i],&cObjecType));
		if(cObjecType !=NULL && tc_strcmp("EMR_CommrclPart Revision",cObjecType)==0)
		{
			char *cFinalString = NULL;
			ITK(retcode,AOM_ask_value_strings(tAttchItemTag[i],"lbt9_Product_Lines",&n_product_line_count,&cProductLineValue));
					
			ITK(retcode,AOM_ask_value_string(tAttchItemTag[i],"lbt9_Plant",&cPlantsEffectedValue));
			ITK(retcode,AOM_ask_value_string(tAttchItemTag[i],"lbt9_PCC",&cPCCValue));
					
			char  *cPlantTrimValue = NULL;
			char  *cPCCTrimValue = NULL;
			fnsubString(cPlantsEffectedValue,3,&cPlantTrimValue);
			fnsubString(cPCCValue,1,&cPCCTrimValue);
					
			for(int j=0;j<n_product_line_count;j++)
			{
				int iUserCount	=	0;
				char ** cpUserIdList	=	NULL;
				tag_t tAddressTag	=	NULLTAG;
						 
				int cValues	=	0;
				char ** cUserValue	=	NULL;
				char *cProductLineTrimValue = "";
				int iTemp = n_product_line_count;
				string strProductLine = "";
				string strTrimmedPL = "";
				char  *cProductlineTrimValue = NULL;
				fnsubString(cProductLineValue[j],10,&cProductlineTrimValue);
						
				cFinalString = (char *)MEM_alloc(25);
					
				tc_strcpy(cFinalString,cProductlineTrimValue);
				tc_strcat(cFinalString,"_");
				tc_strcat(cFinalString,cPlantTrimValue);
				tc_strcat(cFinalString,"_");
				tc_strcat(cFinalString,cPCCTrimValue);

				printf(" FinalString value is %s" ,cFinalString);
						
				ITK(retcode,MAIL_find_alias_list2(cFinalString,&tAddressTag));
				if(tAddressTag !=NULLTAG)
				{
					ITK(retcode,MAIL_ask_alias_list_members(tAddressTag,&iUserCount,&cpUserIdList));
				}
				if(iUserCount > 0 && cpUserIdList != NULL )
				{
					ITK(retcode,AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&cValues,&cUserValue));
				}
						 
					 
				if(cValues == 0)
				{
					int iPosCount = 0;			
					for (int inx = 0; inx < iUserCount; inx++)
					{
						if (tc_strlen(cpChangeAnalystUserID) > 0 && tc_strcmp(cpChangeAnalystUserID,cpUserIdList[inx]) == 0)
						{
							continue;
						}
						else
						{
							ITK(retcode,AOM_refresh(ptTargetAttmnts[0],TRUE));
							ITK(retcode,AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",iPosCount,cpUserIdList[inx]));	
							ITK(retcode,AOM_save(ptTargetAttmnts[0]));
							ITK(retcode,AOM_refresh(ptTargetAttmnts[0],FALSE));
							iPosCount++;
						}
						
					}
				}
				else
				{
					int n_of_reviewers  =  0;
					char ** cReviewers = NULL;
					logical flag = false;
					for(int m=0;m<iUserCount;m++)
					{
						AOM_ask_value_strings(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",&n_of_reviewers,&cReviewers);
						int n=n_of_reviewers;
						for(int l=0;l<n_of_reviewers;l++)
						{
							if(tc_strcmp(cpUserIdList[m],cReviewers[l])==0)				
							{
								flag = true;
								break;
							}
							else
							{
								flag = false;		
							}	
						}
						if(!flag)
						{
							if (tc_strlen(cpChangeAnalystUserID) > 0 && tc_strcmp(cpChangeAnalystUserID,cpUserIdList[m]) == 0)
							{
								continue;
							}
							else
							{
								ITK(retcode,AOM_refresh(ptTargetAttmnts[0],TRUE));
								ITK(retcode,AOM_set_value_string_at(ptTargetAttmnts[0],"lbt9_Proposed_Reviewers",n,cpUserIdList[m]));
								ITK(retcode,AOM_save(ptTargetAttmnts[0]));
								ITK(retcode,AOM_refresh(ptTargetAttmnts[0],FALSE));
							}
							
						}
					}
							
				}
				EMR_free(cProductLineValue[j]);
			}			
			EMR_free(cPlantsEffectedValue);
			EMR_free(cPCCValue);
			EMR_free(cObjecType);
		}		
	}
	EMR_free(cpChangeAnalystUserID);
	return retcode;
}

/**************************************************************************************
*	Function name	:	fnToSetProposedReviwers

*	Description		:	This Function is used for setting the users in proposed reviewers

***************************************************************************************/

int fnToSetProposedReviwers	(tag_t* TargtAttcmnt,			/* <I> */
							 tag_t* SecondryItemTag,		/* <I> */
							 int SecondryItemCount			/* <I> */
							)
{
	int retcode = ITK_ok;
	int	n_resp_per_count	    =	0;
	int iPosCount				=  0;
	char ** cResponsiblePersons	=	NULL;
	char *cpChangeAnalystUserID = NULL;
	ITK(retcode,AOM_ask_value_strings(TargtAttcmnt[0],RESPONSIBLE_PERSON,&n_resp_per_count,&cResponsiblePersons));
	ITK(retcode,AOM_ask_value_string(TargtAttcmnt[0],"lbt9_Change_Analyst",&cpChangeAnalystUserID));
	if(n_resp_per_count > 0 && cResponsiblePersons != NULL)
	{
		int	n_prop_reviewers		=	0;
		char ** prop_reviewers		=	NULL;
		ITK(retcode,AOM_ask_value_strings(TargtAttcmnt[0],"lbt9_Proposed_Reviewers",&n_prop_reviewers,&prop_reviewers));
		if(n_prop_reviewers == 0)
		{
			for(int x =0; x<n_resp_per_count; x++)
			{
				if (tc_strlen(cpChangeAnalystUserID) > 0 && tc_strcmp(cResponsiblePersons[x],cpChangeAnalystUserID) == 0)
				{
					continue;
				}
				else
				{
					ITK(retcode,AOM_refresh(TargtAttcmnt[0],TRUE));
					ITK(retcode,AOM_set_value_string_at(TargtAttcmnt[0],"lbt9_Proposed_Reviewers",iPosCount,cResponsiblePersons[x]));	
					ITK(retcode,AOM_save(TargtAttcmnt[0]));
					ITK(retcode,AOM_refresh(TargtAttcmnt[0],FALSE));
					iPosCount++;
				}
				
			}
		}

		LBT9_MEM_free_Strings(prop_reviewers,n_prop_reviewers );
		MEM_free(cpChangeAnalystUserID);
	}
			
			
	if(SecondryItemTag != NULL)
	{
	char * cObjecType = NULL;
				
		for(int i=0;i<SecondryItemCount;i++)
		{
			int n_product_line_count	=	0;
			char **cProductLineValue = NULL;
			char * cPlantsEffectedValue = NULL;
			char * cPCCValue = NULL;
		
			ITK(retcode,WSOM_ask_object_type2(SecondryItemTag[i],&cObjecType));
			if(cObjecType !=NULL && tc_strcmp("EMR_CommrclPart Revision",cObjecType)==0)
			{
				fnAddressList(TargtAttcmnt,SecondryItemCount ,SecondryItemTag);
				EMR_free(cObjecType);
			}	

		}			
		LBT9_MEM_free_Strings(cResponsiblePersons,n_resp_per_count );
	}
	
	return ITK_ok;
}

/**************************************************************************************
*	Function name	:	fnGetCommaSeperatedList

*	Description		:	This Function is used to get the comma seperated list of values
						of the user who have not completed their review task

***************************************************************************************/

int fnGetCommaSeperatedList (	int UserCount,		/* <I> */
								char **UserList,	/* <I> */
								char **Temp			/* <OF> */
							)
{
	int iFail = ITK_ok;
	char cptemp[SS_MAXLLEN] = "";
	if ( UserCount > 5 )
	{
		for (int inx = 0; inx < UserCount; inx++)
		{
						
			if (tc_strcmp(cptemp,"") <= 0 )
			{
				tc_strcpy(cptemp, UserList[inx]);
			}
			else
			{
				tc_strcat(cptemp, ";");
				tc_strcat(cptemp, UserList[inx]);
			}
		}
	}
	else
	{
		for (int inx = 0; inx < UserCount; inx++)
		{
		
			
			if (tc_strcmp(cptemp,"") <= 0 )
			{
				tc_strcpy(cptemp, UserList[inx]);
			}
			else
			{
				tc_strcat(cptemp, ";");
				tc_strcat(cptemp, UserList[inx]);
			}
		}
	}
	*Temp = (char *) MEM_alloc((tc_strlen(cptemp)+1)*sizeof(char));
	tc_strcpy(*Temp, cptemp);
	return ITK_ok;
}


/**************************************************************************************
*	Function name	:	fnGetCommaSeperatedList

*	Description		:	This Function is used to get the user list who have not completed their review task

***************************************************************************************/

int fnGetUserListforNotCompletedTask(char *AnalystId,		    /* <I> */
									 int FormCount,				/* <I> */
									 tag_t* FormTags,			/* <I> */
									 int *UserCount,			/* <O> */
									 char ***UserList			/* <OF> */
									)
{
	int iFail = ITK_ok;
	*UserCount = 0;
	*UserList = NULL;
	
	for(int i = 0; i < FormCount; i++)
	{
		char *cpApproverId = NULL;
		ITK(iFail,AOM_ask_value_string(FormTags[i],"lbt9_ApproverUserID",&cpApproverId));
		if(cpApproverId != NULL && tc_strcmp(cpApproverId,AnalystId) != 0)
		{
			char *cpApproverStatus = NULL;
			ITK(iFail,AOM_ask_value_string(FormTags[i],"lbt9_ApproverStatus",&cpApproverStatus));
			if(cpApproverStatus != NULL && tc_strcmp(cpApproverStatus,"Assigned") == 0)
			{
				*UserList = (char **) MEM_realloc(*UserList, (*UserCount+1)*sizeof(char *));
				(*UserList)[*UserCount] =cpApproverId;
				*UserCount = *UserCount + 1;
				EMR_free(cpApproverStatus);
			}
		}
	}
	return ITK_ok;
}


/**************************************************************************************
*	Function name	:	fnGetCommaSeperatedList

*	Description		:	This Function is used to get the Change Analyst Current decision 

***************************************************************************************/



int fnToGetTheLatestChangeAnalystResult(int FormCount,					/* <I> */
										tag_t *FormTags,				/* <I> */
										tag_t ECNRevisionTag,			/* <I> */
										char *AnalystId,				/* <I> */
										char **Result					/* <OF> */
									   )
{
	int iFail = ITK_ok;
	int iIterationValue = 0;
	*Result = NULL;
	ITK(iFail,AOM_ask_value_int(ECNRevisionTag,"lbt9_Iteration",&iIterationValue));

	for(int i = 0; i < FormCount; i++)
	{
		int iFormIterationValue = 0;
		ITK(iFail,AOM_ask_value_int(FormTags[i],"lbt9_Iteration",&iFormIterationValue));
		if(iFormIterationValue == iIterationValue)
		{
			char *cpApproverId = NULL;
			ITK(iFail,AOM_ask_value_string(FormTags[i],"lbt9_ApproverUserID",&cpApproverId));
			if(cpApproverId != NULL && tc_strcmp(cpApproverId,AnalystId) == 0)
			{
				char *cpFormResult = NULL;
				ITK(iFail,AOM_ask_value_string(FormTags[i],"lbt9_SignoffStatus",&cpFormResult));
				if(cpFormResult != NULL)
				{
					*Result =  (char *)MEM_alloc(tc_strlen(cpFormResult) + 2);
					tc_strcpy(*Result,"");
					tc_strcpy(*Result,cpFormResult);
				}
				EMR_free(cpApproverId);
			}
		}
	}
	return ITK_ok;
}


/**********************************************************************************************************************
*	Handler name	:	fnGetParticipantUsersList

*	Description		:	This is Function is used to the participant list in vector for different participant type  
												

***********************************************************************************************************************/

int fnGetParticipantUsersList(tag_t tTargetAttachment,										/* <I> */
							  const char *ParticipantType,									/* <I> */
							  std::vector<tag_t> &Vuser										/* <O> */
							 )
{
	int iFail							=	ITK_ok;
	int iParticipantCount				= 0;
	tag_t tParticipantType				= NULLTAG;
	tag_t tAssignee						= NULLTAG;
	tag_t tUserTag						= NULLTAG;
	tag_t *participant_list				= NULL;
	char *cpParticipantType				= NULL;
	
	cpParticipantType=(char *) MEM_alloc(tc_strlen(ParticipantType) + 2);
	tc_strcpy(cpParticipantType,"");
	tc_strcpy(cpParticipantType,ParticipantType);
	ITK(iFail,EPM_get_participanttype(cpParticipantType,&tParticipantType));
	if (tParticipantType != NULLTAG)
	{
		ITK(iFail,ITEM_rev_ask_participants(tTargetAttachment,tParticipantType,&iParticipantCount,&participant_list));
	}
	
	if (participant_list != NULL)
	{
		for (int i = 0; i < iParticipantCount; i++)
		{
			ITK(iFail,AOM_ask_value_tag(participant_list[i],ASSIGNEE_USER,&tAssignee));

			if (tAssignee != NULLTAG)
			{
				ITK(iFail,AOM_ask_value_tag(tAssignee,USER,&tUserTag));

				if (tUserTag != NULLTAG)
				{
					Vuser.push_back(tUserTag);
				}
			}
		}
	}
	EMR_free(participant_list);
	return ITK_ok;
}

/**************************************************************************************
*	Function name	:	LBT_get_unreleased_impacted_items

*	Description		:	This Function is used to find the unreleased impacted items in change object

***************************************************************************************/

int LBT_get_unreleased_impacted_items	(int n_imp_revs,				/* <I> */
										 tag_t *imp_rev_tags,			/* <I> */
										 int *n_unreleased_revs,        /* <O> */ 
										 tag_t **unreleased_rev_tags    /* <OF> */ 
										)
{
	int retcode = ITK_ok;
	
	*n_unreleased_revs = 0;
	*unreleased_rev_tags = NULL;
	
	for (int inx = 0; inx < n_imp_revs; inx++)
	{
		int statusCount = 0;
		
		tag_t *statusTags = NULL;
		
		ITK(retcode,AOM_ask_value_tags(imp_rev_tags[inx], "release_status_list", &statusCount, &statusTags));
		
		if ( statusCount > 0 )
		{
			char *status_value = NULL;
			ITK(retcode, AOM_ask_value_string(statusTags[0],"object_name",&status_value));
			if(status_value != NULL && tc_strcmp(status_value,RELEASE_STATUS) != 0)
			{
				*unreleased_rev_tags = (tag_t *) MEM_realloc(*unreleased_rev_tags,(*n_unreleased_revs+1)*sizeof(tag_t));
				(*unreleased_rev_tags)[*n_unreleased_revs] = imp_rev_tags[inx];
				*n_unreleased_revs = *n_unreleased_revs + 1;
				EMR_free(status_value);
			}
		}
		
		EMR_free(statusTags);
	}
	
	return retcode;
}

/****************************************************************************************************
*	Function name	:	fnToGetShortObjectNameForChangeObject

*	Description		:	This function takes the argument as object tag and written the change object name as
						ECN/MCO/Deviation/CR/Stopship/DCN

******************************************************************************************************/

int fnToGetShortObjectNameForChangeObject	(tag_t ObjectTag,			/* <I> */
											 char **Object_Name			/* <OF> */
											)
{
	int iFail = ITK_ok;
	char *OjectType = NULL;
	*Object_Name = NULL;
	*Object_Name = (char *)MEM_alloc(40);
	ITK(iFail,WSOM_ask_object_type2(ObjectTag,&OjectType));
	if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_ECNRevision") == 0)
	{
		tc_strcpy(*Object_Name,"ECN");
	}
	else if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_DCNRevision") == 0)
	{
		tc_strcpy(*Object_Name,"DCN");
	}
	else if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_MCORevision") == 0)
	{
		tc_strcpy(*Object_Name,"MCO");
	}
	else if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_ChgRequestRevision") == 0)
	{
		tc_strcpy(*Object_Name,"CR");
	}
	else if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_StopShipRevision") == 0)
	{
		tc_strcpy(*Object_Name,"Stopship");
	}
	else if(OjectType != NULL && tc_strcmp(OjectType,"LBT9_DeviationRevision") == 0)
	{
		tc_strcpy(*Object_Name,"Deviation");
	}
	EMR_free(OjectType);
	return iFail;
}


/**************************************************************************************
*	Function name	:	fnToGetDatabaseChangeAnalystUser

*	Description		:	This Function is to get the user having role as Database Change Analyst

***************************************************************************************/

int fnToGetDatabaseChangeAnalystUser	(tag_t tECNObjectTag,	/* <I> */
										 char **DBAUser			/* <OF> */
										)
{
	int iFail = ITK_ok;
	int iRolesCount = 0;
	int iMemberCount = 0;
	*DBAUser = NULL;
	tag_t *tRolesTag = NULL;
	tag_t tGroupTag = NULLTAG;
	tag_t *tGrpMemberTag = NULL;
	int iJobCount = 0;
	tag_t *tJobTags = NULLTAG;
	char *cpDBAUser = NULL;
	//Getting the User which is having Database Change Analyst role in Change Management group.
	ITK(iFail,EPM_ask_active_job_for_target(tECNObjectTag,&iJobCount,&tJobTags));
	if(tJobTags != NULLTAG && iJobCount > 0)
	{
		int iTaskCount = 0;
		tag_t *tTaskTags = NULL;
		ITK(iFail,EPM_get_type_tasks(tJobTags[0],eEPMConditionTask,&iTaskCount,&tTaskTags));
		if(tTaskTags != NULL && iTaskCount > 0)
		{
			for(int inx = 0; inx < iTaskCount; inx++)
			{
				char *cpTaskName = NULL;
				ITK(iFail,EPM_ask_name2(tTaskTags[inx],&cpTaskName));
				if(cpTaskName != NULL && (tc_strcmp(cpTaskName,"Data Base Analyst") == 0 || tc_strcmp(cpTaskName,"DBA Review Task") == 0))
				{
					tag_t tUserTag = NULLTAG;
					ITK(iFail,AOM_ask_value_tag(tTaskTags[inx],"fnd0Performer",&tUserTag));
					if(tUserTag != NULLTAG)
					{
						ITK(iFail,SA_ask_user_identifier2(tUserTag,&cpDBAUser));
						if(cpDBAUser != NULL)
						{
							*DBAUser = (char *)MEM_alloc(tc_strlen(cpDBAUser) + 2);
							tc_strcpy(*DBAUser,"");
							tc_strcpy(*DBAUser,cpDBAUser);
						}
					}
					EMR_free(cpTaskName);
				}
			}
			EMR_free(tTaskTags);
		}
		EMR_free(tJobTags);
		EMR_free(cpDBAUser);
	}
	return ITK_ok;
}


/**************************************************************************************
*	Function name	:	fnToValidateChangeObjectStatus

*	Description		:	This Function will return logical value based on the comparison between
						provided status and change object status

***************************************************************************************/


int fnToValidateChangeObjectStatus	(tag_t ChangeObjectTag,						/* <I> */
									 const char *StatusName,					/* <I> */
									 logical *ValidationStatus					/* <O> */
									)
{
	int iFail = ITK_ok;
	int iStatusCount = 0;
	tag_t *tStatusTags = NULL;
	*ValidationStatus = false;
	//Function will match the status of the change object with the provided status as the arguments and return a logical value
	//true if it matches and false if it doesn't
	ITK(iFail,AOM_ask_value_tags(ChangeObjectTag,"release_status_list",&iStatusCount,&tStatusTags));
	if(tStatusTags != NULL && iStatusCount > 0)
	{
		char *cpStatusValue = NULL; 
		ITK(iFail,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusValue));
		if(cpStatusValue != NULL && tc_strcmp(cpStatusValue,StatusName) == 0)
		{
			*ValidationStatus = true;
			EMR_free(cpStatusValue);
		}
		else
		{
			*ValidationStatus = false;
			EMR_free(cpStatusValue);
		}
	}
	EMR_free(tStatusTags);
	return ITK_ok;
}

/*******************************************************************************************************************
*	Function name	:	LBT_get_notALatestRev_impacted_items

*	Description		:	This Function is used to find the list of Released Item which are not in latest released State

********************************************************************************************************************/

int LBT_get_notALatestRev_impacted_items	(int n_imp_revs,				/* <I> */
										    tag_t *imp_rev_tags,			/* <I> */
										    int *n_notLatestRev_revs,       /* <O> */ 
										    tag_t **notLatest_rev_tags      /* <OF> */ 
										    )
{
	int retcode						=  ITK_ok;
	int iStatusCount				=  0;
	*n_notLatestRev_revs		    =  0;

	char *cStatusName				=  NULL;
	
	tag_t  tItemTag					=  NULLTAG;
	tag_t  tLatestRev				=  NULLTAG;
	tag_t *tStatusList				=  NULL;
	
	for (int inx = 0; inx < n_imp_revs; inx++)
	{		
		ITK(retcode,AOM_ask_value_tags(imp_rev_tags[inx], "release_status_list", &iStatusCount, &tStatusList));		
		if (iStatusCount > 0 && tStatusList!=NULL)
		{		
			ITK(retcode, AOM_ask_value_string(tStatusList[0],"object_name",&cStatusName));
			//Check if Commercial Part/Document present in Impacted Item is Released
			if(tc_strcmp(cStatusName,RELEASE_STATUS) == 0)
			{
				int iRevCount					=  0;
				int iDate						=  0;
				int iRevstatusCount             =  0;

				char *cRevStatusName			=  NULL;

				date_t dImpactedDateReleased	=  NULLDATE;
				date_t dChildDateReleased		=  NULLDATE;

				tag_t *tRevStatusList			=  NULL;
				tag_t *tRevList				    =  NULL;

				ITK(retcode,ITEM_ask_item_of_rev(imp_rev_tags[inx],&tItemTag));

				ITK(retcode,AOM_ask_value_date(imp_rev_tags[inx],"date_released",&dImpactedDateReleased));
			
				if(tItemTag!=NULLTAG)
				{
					ITK(retcode,ITEM_list_all_revs(tItemTag,&iRevCount,&tRevList));			
					if(iRevCount>0 && tRevList!= NULL)
					{
						//Compare Commercial Part/Document revision with other Revision of its parent,and check if it is latest Released
						for(int iny=0;iny<iRevCount;iny++)
						{							
							if(tRevList[iny]!=imp_rev_tags[inx])
							{
								ITK(retcode,AOM_ask_value_tags(tRevList[iny], "release_status_list", &iRevstatusCount, &tRevStatusList));
							    ITK(retcode, AOM_ask_value_string(tRevStatusList[0],"object_name",&cRevStatusName));
								if(tRevStatusList != NULL && tc_strcmp(cRevStatusName,RELEASE_STATUS) == 0)
								{
									ITK(retcode,AOM_ask_value_date(tRevList[iny],"date_released",&dChildDateReleased));

									ITK(retcode,POM_compare_dates(dImpactedDateReleased, dChildDateReleased, &iDate));
									//If Commercial Part/Document revision is not the latest revision then add it to notLatest_rev_tag
									if(iDate!=1)
									{
										*notLatest_rev_tags = (tag_t *) MEM_realloc(*notLatest_rev_tags,(*n_notLatestRev_revs+1)*sizeof(tag_t));
										(*notLatest_rev_tags)[*n_notLatestRev_revs] = imp_rev_tags[inx];
										*n_notLatestRev_revs = *n_notLatestRev_revs + 1;
										EMR_free(tRevStatusList);
										EMR_free(cRevStatusName);	
										break;
									}
								}
							 EMR_free(tRevStatusList);
							 EMR_free(cRevStatusName);
							}	
						}						
					}
					EMR_free(tRevList);
			    }			 
		    }		   
	    }	
    }
	EMR_free(cStatusName);
	EMR_free(tStatusList);
	return retcode;
}
/*******************************************************************************************************************
*	Function name	:	fnUpdateChangeHistoryForm

*	Description		:	This function update the release date on Change histoty form. This function is used in 
						LBT9_UPDATE_RELEASE_DATE_ON_REV_HISTORY_FORM Handler.
********************************************************************************************************************/
int fnUpdateChangeHistoryForm(tag_t change_rev_tag,      /* <I> */
							  int n_solution_items,      /* <I> */
							  tag_t *solution_rev_tags   /* <I> */
                             )
{
	int retcode = ITK_ok;
	
	date_t change_release_date;
	
	ITK(retcode,AOM_ask_value_date(change_rev_tag,"date_released",&change_release_date));

	if( DATE_IS_NULL(change_release_date) == 1 )
	{
		return retcode;
	}
	else
	{
		tag_t change_item = NULLTAG;
		
		char *cpChangeItemID = NULL;
	    char *cpChangeDesc   = NULL;
		char *cpDesc		 = NULL;

		ITK(retcode,ITEM_ask_item_of_rev(change_rev_tag, &change_item));
		
		ITK(retcode,ITEM_ask_id2(change_item, &cpChangeItemID));
		
		ITK(retcode,AOM_ask_value_string(change_rev_tag,"lbt9_Description",&cpChangeDesc));

		cpDesc = cpChangeDesc;

		cpDesc[230] ='\0';

		for (int inx = 0; inx < n_solution_items; inx++)
		{              
			int n_forms = 0;
			tag_t *form_tags = NULL;
			
			ITK(retcode,AOM_ask_value_tags(solution_rev_tags[inx], "lbt9_Change_History_List", &n_forms, &form_tags));

			for (int jnx = 0; jnx < n_forms; jnx++)
			{
				char *existing_form_name = NULL;

				ITK(retcode,AOM_ask_value_string(form_tags[jnx], "object_name", &existing_form_name));

				if( tc_strcmp(cpChangeItemID, existing_form_name) == 0 )
				{
					ITK(retcode,AOM_refresh(form_tags[jnx],TRUE));

					ITK(retcode,AOM_set_value_date(form_tags[jnx], "lbt9_Change_Release_Date", change_release_date));
					ITK(retcode,AOM_set_value_string(form_tags[jnx],"lbt9_Change_Description", cpDesc));
				
					ITK(retcode,AOM_save(form_tags[jnx]));					
					ITK(retcode,AOM_refresh(form_tags[jnx],FALSE));
				}
			}
			EMR_free(form_tags);
		}
		EMR_free(cpChangeItemID);
		EMR_free(cpChangeDesc);
	}

	return retcode;
}

int fnGetDeligationUser(tag_t tuserTag,	/*<I>*/
						char **DelegationUserID /*<OF>*/
					   )
{
	int iFail = ITK_ok;
	logical DelegationUserExist = false;
	tag_t tDelegateMemberTag			= NULLTAG;
	tag_t tDelegateUserTag				= NULLTAG;
	date_t DelegateUsetStartDate;
	date_t DelegateUsetEndDate;
	char *cpDelegateUserID				= NULL;
	
	ITK(iFail,EPM_ask_out_of_office(tuserTag,&tDelegateMemberTag,&DelegateUsetStartDate,&DelegateUsetEndDate));
	if (tDelegateMemberTag != NULLTAG)
	{
		ITK(iFail,SA_ask_groupmember_user(tDelegateMemberTag,&tDelegateUserTag));
		if (tDelegateUserTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tDelegateUserTag,&cpDelegateUserID));

			if (tc_strlen(cpDelegateUserID) > 0 && cpDelegateUserID != NULL)
			{
				*DelegationUserID = (char *)MEM_alloc(tc_strlen(cpDelegateUserID) + 1);	
				tc_strcpy(*DelegationUserID,"");
				tc_strcpy(*DelegationUserID,cpDelegateUserID);
			}
			
			/*if (tc_strlen(cpDelegateUserID) > 0)
			{
				DelegationUserExist = true;
			}*/
		}				
	}	
	MEM_free(cpDelegateUserID);
	return iFail;
}

/*******************************************************************************************************************
*	Function name	:	fnToGetCurrentUserId

*	Description		:	This function will get the current login userId

********************************************************************************************************************/
 int fnToGetCurrentUserId	(char **CurrentUserId					/* <OF> */
							)
 {
	int iFail = ITK_ok;
	tag_t tGrpMemberTag = NULLTAG;
	*CurrentUserId = NULL;
	char *cpUserId = NULL;
	ITK(iFail,SA_ask_current_groupmember(&tGrpMemberTag));
	if(tGrpMemberTag != NULLTAG)
	{
		tag_t tCurrentUserTag = NULLTAG;
		ITK(iFail,SA_ask_groupmember_user(tGrpMemberTag,&tCurrentUserTag));
		if(tCurrentUserTag != NULLTAG)
		{
			ITK(iFail,SA_ask_user_identifier2(tCurrentUserTag,&cpUserId));
			if(cpUserId != NULL)
			{
				*CurrentUserId = (char *)MEM_alloc((tc_strlen(cpUserId)+1)*sizeof(char));
				tc_strcpy(*CurrentUserId,cpUserId);
			}
			EMR_free(cpUserId);
		}
	}
	return ITK_ok;
 }


 /*******************************************************************************************************************
*	Function name	:	fnToCheckCurrentUserIsOriginator

*	Description		:	This function will check the login user is the originator of ECN or not

********************************************************************************************************************/

 int fnToCheckCurrentUserIsOriginator	(tag_t RevisionTag,						/* <I> */
										 logical *UserIsOriginator				/* <O> */
										)
 {
	int iFail = ITK_ok;
	tag_t tOriginatorTag = NULLTAG;
	*UserIsOriginator = false;
	ITK(iFail,fnGetParticipantList(RevisionTag,ORIGINATOR,&tOriginatorTag));
	if(tOriginatorTag != NULLTAG){
		char *cpOriginatorId = NULL;
		char *cpCurrentUserId = NULL;
		ITK(iFail, SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
		ITK(iFail, fnToGetCurrentUserId(&cpCurrentUserId));
		if(cpOriginatorId != NULL && cpCurrentUserId != NULL && tc_strcmp(cpOriginatorId,cpCurrentUserId) == 0){
			*UserIsOriginator = true;
		}
		EMR_free(cpCurrentUserId);
		EMR_free(cpOriginatorId);
	}
	return ITK_ok;
 }



/*******************************************************************************************************************
*	Function name	:	validateRevLRR

*	Description		:	This Function is used to find if the item in latest released State

********************************************************************************************************************/

logical validateRevLRR	(tag_t rev_tag)			 /* <I> */
					
{	
	int retcode						=  ITK_ok;
	int iStatusCount				=  0;

	char *cStatusName				=  NULL;
	
	tag_t  tItemTag					=  NULLTAG;
	tag_t  tLatestRev				=  NULLTAG;
	tag_t *tStatusList				=  NULL;

	logical revLRRValidation		=  true;
	
	if(rev_tag!=NULLTAG)
	{
		ITK(retcode,ITEM_ask_item_of_rev(rev_tag,&tItemTag));
		
		ITK(retcode,AOM_ask_value_tags(rev_tag, "release_status_list", &iStatusCount, &tStatusList));		
		if (iStatusCount > 0 && tStatusList!=NULL)
		{		
			ITK(retcode, AOM_ask_value_string(tStatusList[0],"object_name",&cStatusName));
			//Check if Commercial Part/Document present in Impacted Item is Released
			if(tc_strcmp(cStatusName,RELEASE_STATUS) == 0)
			{
				int iRevCount					=  0;
				int iDate						=  0;
				int iRevstatusCount             =  0;

				char *cRevStatusName			=  NULL;

				date_t dRevDateReleased			=  NULLDATE;
				date_t dChildDateReleased		=  NULLDATE;

				tag_t *tRevStatusList			=  NULL;
				tag_t *tRevList				    =  NULL;

				ITK(retcode,ITEM_ask_item_of_rev(rev_tag,&tItemTag));

				ITK(retcode,AOM_ask_value_date(rev_tag,"date_released",&dRevDateReleased));
			
				if(tItemTag!=NULLTAG)
				{
					ITK(retcode,ITEM_list_all_revs(tItemTag,&iRevCount,&tRevList));			
					if(iRevCount>0 && tRevList!= NULL)
					{
						//Compare Commercial Part/Document revision with other Revision of its parent,and check if it is latest Released
						for(int iny=0;iny<iRevCount;iny++)
						{							
							if(tRevList[iny]!=rev_tag)
							{
								ITK(retcode,AOM_ask_value_tags(tRevList[iny], "release_status_list", &iRevstatusCount, &tRevStatusList));
							    ITK(retcode, AOM_ask_value_string(tRevStatusList[0],"object_name",&cRevStatusName));
								if(tRevStatusList != NULL && tc_strcmp(cRevStatusName,RELEASE_STATUS) == 0)
								{
									ITK(retcode,AOM_ask_value_date(tRevList[iny],"date_released",&dChildDateReleased));
									ITK(retcode,POM_compare_dates(dRevDateReleased, dChildDateReleased, &iDate));

									//If Commercial Part/Document revision is not the latest revision
									if(iDate!=1)
									{
										revLRRValidation = false;	
										break;
									}
								}
								EMR_free(tRevStatusList);
								EMR_free(cRevStatusName);
							}	
						}						
					}
					EMR_free(tRevList);
			    }			 
		    }
			else if (tc_strcmp(cStatusName,RELEASE_STATUS) != 0)
			{
				revLRRValidation = false;				
			}
	    }	
	}
	EMR_free(cStatusName);
	EMR_free(tStatusList);
	return revLRRValidation;
}
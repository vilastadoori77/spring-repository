

/******************************************************************************************
File        :	LBT9_DEV_Validation.cpp

Description :	Workflow Rule handlers for Liebert.  

History Log:

Date          		Author                          Action

01/06/2015		  Ashok Raj S                  Added LBT9_DEV_RELEASE_VALIDATION

08/06/2015		  Ashok Raj S                  Added LBT9_DEV_CANCEL_VALIDATION						

					
******************************************************************************************/

#include "LBT9_Change_Handler.h"


/********************************************************************************************************************
*	Handler name	:	LBT9_DEV_RELEASE_VALIDATION

*	Description		:	Validates the Deviation revision when user submits the Deviation to Release Deviation workflow

	Below validation checks are performed,
	1) Validates if "Release Deviation workflow" is initiated on a "Deviation Revision" with "Pending" Status
    2) Validates if Impacted Item folder of the Deviation is empty
	3) Validates if "Effective To" date and "Effctive From" Date are not lesser than the current System Date
	4) Validates if "Effective To" date is not leser than "Effctive From" Date.
	5) Validates if Impacted Item folder has only latest released revision of Commercial Part/Document

**********************************************************************************************************************/

extern EPM_decision_t LBT9_DEV_RELEASE_VALIDATION(EPM_rule_message_t message)
{
	int iFail                         =  ITK_ok;
	int iTargetAttchmnt		          =	 0;
	int iRelStatCount				  =  0;

	char *cpLoginUserId			      =  NULL;
	char *cpOriginatorId			  =  NULL;
	char *cpObjectType				  =  NULL;
	char *cRelStatName				  =  NULL;
	
					
	tag_t tCurrentGrpMemberTag		  =  NULLTAG;
	tag_t tOriginatorTag			  =  NULLTAG;				
	tag_t tUserTag					  =  NULLTAG;
	tag_t tRootTask			          =	 NULLTAG;

	tag_t *tRelStatList				  =  NULL;
	tag_t *tAttchItemTag	          =	 NULL;
	
	logical ValidUser				  =  false;
	logical dateValidationFailed      =  false;
	logical impactedValidationFailed  =  false;


	EPM_decision_t decision = EPM_nogo;

	ITK(iFail,EPM_ask_root_task(message.task,&tRootTask));
	if(tRootTask != NULLTAG)
	{
		ITK(iFail,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	ITK(iFail,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
	if(tOriginatorTag != NULLTAG)
	{
		ITK(iFail,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
	}
	if(cpOriginatorId != NULL)
	{
	    ITK(iFail,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
		ITK(iFail,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
		ITK(iFail,SA_ask_user_identifier2(tUserTag,&cpLoginUserId));					
					
		// Checks if only Orginator initiating the Workflow
		if(cpLoginUserId != NULL && (tc_strcmp(cpLoginUserId,cpOriginatorId)==0))
		{
			ValidUser = true;
			decision = EPM_go;
		}
		else
		{
			ValidUser =	false;
			EMH_clear_errors();
			EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_RELEASE_WORKFLOW_USER);
			decision = EPM_nogo;
			EMR_free(tAttchItemTag);
		    EMR_free(cpOriginatorId);				
			EMR_free(cpLoginUserId);
			return decision;
		}
	}
	if(iTargetAttchmnt > 0  && tAttchItemTag != NULL)
	{
	  //Checks if selected change item revision is "Deviation Revision"
	  ITK(iFail,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));		
	  if(tc_strcmp(DEVIATION_REVISION,cpObjectType) == 0)
	  {
		ITK(iFail,WSOM_ask_release_status_list(tAttchItemTag[0],&iRelStatCount, &tRelStatList));
		if(iRelStatCount>0 && tRelStatList!=NULL)
		{
		  ITK(iFail,AOM_ask_value_string(tRelStatList[0],OBJECT_NAME,&cRelStatName));
		  //Checks if status of Deviation is in Pending state
		  if(tc_strcmp(cRelStatName,PENDING_STATUS)==0)
		  {
			 int iImpactedItemCount	     =	0;				
			 int iDate1                  =  0;
			 int iDate2                  =  0;
			 int iDate3                  =  0;

			 char* cCurrentDate			 =	NULL;
			 char* cTempDate             =  NULL;

			 tag_t *tImpactedItemTag	 =	NULL;
						
			 date_t dEffective_from	     =  NULLDATE;
			 date_t dEffective_to		 =  NULLDATE;
			 date_t dCurrent_Date		 =  NULLDATE;


			 ITK(iFail,AOM_ask_value_date(tAttchItemTag[0],EFFECTIVE_FROM,&dEffective_from));
			 //To ignore time check
			 dEffective_from.hour = 0;
			 dEffective_from.minute = 0;
			 dEffective_from.second = 0;

			 ITK(iFail,AOM_ask_value_date(tAttchItemTag[0],EFFECTIVE_TO,&dEffective_to));
			 //To ignore time check
			 dEffective_to.hour = 0;
			 dEffective_to.minute = 0;
			 dEffective_to.second = 0;
			
			 //Gets current system date in Date format
			 ITK(iFail,ITK_ask_default_date_format(&cCurrentDate));
			 ITK(iFail,ITK_string_to_date(cCurrentDate,&dCurrent_Date));
			 //To ignore time check
			 dCurrent_Date.hour = 0;
			 dCurrent_Date.minute = 0;
			 dCurrent_Date.second = 0;

			 //Checks if "Effective From" date is lesser than current system date
			 ITK(iFail,POM_compare_dates(dEffective_from, dCurrent_Date, &iDate1));

			 //Checks if "Effective To" date is lesser than current system date
			 ITK(iFail,POM_compare_dates(dEffective_to, dCurrent_Date, &iDate2));

			 //Checks if "Effective To" date is lesser than "Effective From"
			 ITK(iFail,POM_compare_dates(dEffective_to, dEffective_from, &iDate3));

			 if(iDate1==-1 || iDate2==-1 || iDate3==-1)
			 {
				dateValidationFailed = true;
				cTempDate = (char *)MEM_alloc(tc_strlen("Effective From date and Effective To date cannot be lesser than current date") + 2);
				tc_strcpy(cTempDate,"\n");

				//Below error message is thrown if both "Effective From" and "Effective To" dates are lesser than Today's date
				if (iDate1 ==-1 && iDate2 ==-1)
				{
					tc_strcat(cTempDate,"Effective From date and Effective To date cannot be lesser than current date");				
				}
				//Below error message is thrown if "Effective From" date is lesser than Today's date
				if (iDate1 ==-1 && iDate2 !=-1)
				{
					tc_strcat(cTempDate,"Effective From date cannot be lesser than current date");				
				}
				//Below error message is thrown if "Effective To" date is lesser than Today's date
				if (iDate1 !=-1 && iDate2 ==-1)
				{
					tc_strcat(cTempDate,"Effective To date cannot be lesser than current date");				
				}
				//Below error message is thrown if "Effective To" date is lesser than "Effective From" date
				if(iDate1!=-1 && iDate2!=-1 && iDate3==-1)
				{
					tc_strcat(cTempDate,"Effective To date cannot be lesser than Effective From date");
				}				
			 }
			 if(dateValidationFailed)
			 {
				EMH_store_initial_error_s1(EMH_severity_error,LBT9_DEV_INVALID_DATE,cTempDate);
				decision = EPM_nogo;	
				EMR_free(cTempDate);
				return decision;			
			 }
			 //Gets the tag of Commercial Part/Document is present in Impacted items folder
			 ITK(iFail,LBT_get_related_objects(tAttchItemTag[0],IMPACTED_ITEM,&iImpactedItemCount,&tImpactedItemTag));

			 EMR_free(tAttchItemTag);
			 EMR_free(cpObjectType);
			 EMR_free(cRelStatName);
			 EMR_free(tRelStatList);		
			
			 if(tImpactedItemTag != NULL && iImpactedItemCount > 0)
			 {
				int iUnreleasedItemCount    =  0;
				int iNotALatestRev		    =  0;

				char *cTempImpacted         =  NULL;
				char *cUnreleasedItemList   =  NULL;
				char *cNotALatestrevList    =  NULL;	

				tag_t *tUnreleasedItem	    =  NULL;			 
				tag_t *tNotALatestRev	    =  NULL;
			   	
				//Gets the tag of Commercial Part/Document which are not in Released Status
				ITK(iFail,LBT_get_unreleased_impacted_items(iImpactedItemCount,tImpactedItemTag, &iUnreleasedItemCount, &tUnreleasedItem));
				if(iUnreleasedItemCount > 0 && tUnreleasedItem != NULL)
				{			 
					ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iUnreleasedItemCount,tUnreleasedItem,&cUnreleasedItemList));
					decision = EPM_nogo;
					impactedValidationFailed = true;
				}
				EMR_free(tUnreleasedItem);

				//Gets the tag of Commercial Part/Document which is in Released Status and not latest Released Revision
				ITK(iFail,LBT_get_notALatestRev_impacted_items(iImpactedItemCount,tImpactedItemTag, &iNotALatestRev, &tNotALatestRev));
				if(iNotALatestRev > 0 && tNotALatestRev != NULL)
				{			 
					ITK(iFail,LBT_getCommaSeparatedListOfItemRevs(iNotALatestRev,tNotALatestRev,&cNotALatestrevList));
					decision = EPM_nogo;
					impactedValidationFailed = true;
				} 
				EMR_free(tNotALatestRev);

				if(impactedValidationFailed)
				{					
					cTempImpacted = (char *)MEM_alloc(15*iUnreleasedItemCount + 15*iNotALatestRev + 2);
					tc_strcpy(cTempImpacted,"");
					tc_strcat(cTempImpacted,"\n");
					
					//If unreleased items are present add comma seperated list of cUnreleasedItemList to error message
					if(iUnreleasedItemCount>0)
					{				      
						tc_strcat(cTempImpacted,cUnreleasedItemList);
					}
					//If Released items are present which are not the Latest Released Revision then add Comma seperated list of cNotALatestrevList to error message
					if(iNotALatestRev>0)
					{
						if(iUnreleasedItemCount>0)
						{
							tc_strcat(cTempImpacted,",");					  
						}
						tc_strcat(cTempImpacted,cNotALatestrevList);
					}				
					EMH_store_initial_error_s1(EMH_severity_error,LBT9_DEV_INVALID_IMPACTED_ITEMS,cTempImpacted);
					decision = EPM_nogo;
					EMR_free(cTempImpacted);
					return decision;			
				}			  
			 }
			 //If Impacted item folder of Deviation Revision is Empty, error is thrown to user
			 else if(tImpactedItemTag == NULL && iImpactedItemCount == 0)
			 {
				EMH_clear_errors();
				EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_NO_IMPACTED_ITEMS);
				decision = EPM_nogo;
				return decision;
			 }	
			 EMR_free(tImpactedItemTag);
		  }
		  //If selected Deviation Revision does not have Pending status, error is thrown to user 
		  else if(tc_strcmp(cRelStatName,PENDING_STATUS)!=0)
		  {	
			  EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_IS_NOT_IN_PENDING);
			  decision = EPM_nogo;
			  EMR_free(tAttchItemTag);
			  EMR_free(cpObjectType);
			  EMR_free(cRelStatName);
			  EMR_free(tRelStatList);
			  return decision;
		  }
		}
		//If selected Deviation Revision does not have any status, error is thrown to user 
	    else if(iRelStatCount==0 && tRelStatList==NULL)
	    {	
		   EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_STATUS_IS_EMPTY);
		   decision = EPM_nogo;
		   EMR_free(tAttchItemTag);
		   EMR_free(cpObjectType);
		   EMR_free(tRelStatList);
		   return decision;
	    }
	  }
	  //If selected Item Revision is not Deviation Revision, error is thrown to user
	  else if(tc_strcmp(DEVIATION_REVISION,cpObjectType)!=0)
	  {	
		   EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_ITEM_IS_NOT_SELECTED);
		   decision = EPM_nogo;
		   EMR_free(tAttchItemTag);
		   EMR_free(cpObjectType);
		   return decision;
	  }
	}
    if(!dateValidationFailed && !impactedValidationFailed)
	{
		 decision = EPM_go;
	}
   return decision;
}

/**********************************************************************************************************************
*	Handler Name	:	LBT9_DEV_CANCEL_VALIDATION

*	Description		:	Validates the Deviation before submitting it to "Cancel Deviation workflow"

	Below validation checks are performed,	
	1) Validates if "Cancel Deviation workflow" is initiated only by Originator and Change Analyst of the Deviaiton
	2) Validates if "Cancel Deviation workflow" is initiated on a "Deviation Revision" with "Pending" Status
																	
***********************************************************************************************************************/

extern EPM_decision_t LBT9_DEV_CANCEL_VALIDATION(EPM_rule_message_t message)
{
	int retcode					= ITK_ok;
	int iTargetAttchmnt			= 0;	

	char *cpObjectType			= NULL;
		
	tag_t tRootTask				= NULLTAG;
	tag_t *tAttchItemTag		= NULL;	

	EPM_decision_t decision		= EPM_nogo;

	ITK(retcode,EPM_ask_root_task (message.task, &tRootTask));	
	if (tRootTask != NULLTAG) 
	{
		ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if (iTargetAttchmnt > 0 && tAttchItemTag != NULL)
	{	
	ITK(retcode,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
	}
	//Check if selected change item revision is "Deviation Revision"
	if(cpObjectType != NULL && tc_strcmp(DEVIATION_REVISION,cpObjectType) == 0)
	{			
		//Get Originator and Change Analyst values and check with current login user
		char *cpLoginUserId			    = NULL;
		char *cpOriginatorId			= NULL;
		char *cpAnalystId				= NULL;

		tag_t tOriginatorTag			= NULLTAG;
		tag_t tAnalystTag				= NULLTAG;
		tag_t tCurrentGrpMemberTag		= NULLTAG;
		tag_t tUserTag					= NULLTAG;		
		
		ITK(retcode,fnGetParticipantList(tAttchItemTag[0],ORIGINATOR,&tOriginatorTag));
		if(tOriginatorTag != NULLTAG)
		{
			ITK(retcode,SA_ask_user_identifier2(tOriginatorTag,&cpOriginatorId));
		}
		ITK(retcode,fnGetParticipantList(tAttchItemTag[0],CHANGE_ANALYST,&tAnalystTag));
		if(tAnalystTag != NULLTAG)
		{
			ITK(retcode,SA_ask_user_identifier2(tAnalystTag,&cpAnalystId));
		}
		ITK(retcode,SA_ask_current_groupmember(&tCurrentGrpMemberTag));
		ITK(retcode,SA_ask_groupmember_user(tCurrentGrpMemberTag,&tUserTag));
		ITK(retcode,SA_ask_user_identifier2(tUserTag,&cpLoginUserId));
		// Checks if only Orginator/Change Analyst initiating the Workflow
		if(cpLoginUserId != NULL && (tc_strcmp(cpLoginUserId,cpOriginatorId)==0 || tc_strcmp(cpLoginUserId,cpAnalystId)==0 ))
		{			
			int iStatusCount   = 0;			
			tag_t *tStatusTags = NULL;

			ITK(retcode,WSOM_ask_release_status_list(tAttchItemTag[0],&iStatusCount,&tStatusTags));
			if(iStatusCount > 0 && tStatusTags != NULL)
			{
				char *cpStatusName	  =	NULL;
				ITK(retcode,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));
				//Check if status of Deviation is in Pending state
				if(cpStatusName	!= NULL && tc_strcmp(cpStatusName,PENDING_STATUS)==0)
				{					
					decision = EPM_go;
				}
				else
				{										
					EMH_clear_errors();
					EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_CANCEL_WORKFLOW_STATUS);
					decision = EPM_nogo;	
				}
				EMR_free(cpStatusName);
			}
			EMR_free(tStatusTags);			
		} 				
		// Throws Invalid Status error if Deviation has Status other then "Pending"				
		else
		{			
			EMH_clear_errors();
			EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_CANCEL_WORKFLOW_USER);			
			decision = EPM_nogo;
		}
		EMR_free(cpOriginatorId);
		EMR_free(cpAnalystId);
		EMR_free(cpLoginUserId);
	} 
	//Throws Invalid Item Revision error if selected revision is other than "Deviation Revision"	
	else if(tc_strcmp(DEVIATION_REVISION,cpObjectType)!= 0)
	{
		EMH_clear_errors();
		EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_INVALID_REVISION);
		decision = EPM_nogo;
	}
	EMR_free(tAttchItemTag);
	EMR_free(cpObjectType);
	
	return decision;
}

/********************************************************************************************************************
*	Handler name	:	LBT9_DEV_EXPIRE_VALIDATION

*	Description		:	Validates the Deviation revision when user submits the Deviation to Expire Deviation workflow

	Below validation checks are performed,
	1) Validates if "Expire Deviation workflow" is initiated on a "Deviation Revision" with "Released" Status
	2) Validates if "Expire Deviation workflow" is initiated only by CA\DCA

**********************************************************************************************************************/

extern EPM_decision_t LBT9_DEV_EXPIRE_VALIDATION(EPM_rule_message_t message)
{
	int retcode					= ITK_ok;
	int iTargetAttchmnt			= 0;	

	char *cpObjectType			= NULL;
		
	tag_t tRootTask				= NULLTAG;
	tag_t *tAttchItemTag		= NULL;	

	EPM_decision_t decision		= EPM_nogo;

	ITK(retcode,EPM_ask_root_task (message.task, &tRootTask));	
	if (tRootTask != NULLTAG) 
	{
		ITK(retcode,EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetAttchmnt, &tAttchItemTag));
	}
	if (iTargetAttchmnt > 0 && tAttchItemTag != NULL)
	{	
	ITK(retcode,WSOM_ask_object_type2(tAttchItemTag[0],&cpObjectType));
	}
	//Check if selected change item revision is "Deviation Revision"
	if(cpObjectType != NULL && tc_strcmp(DEVIATION_REVISION,cpObjectType) == 0)
	{	
		char *cUserRoleName				= NULL;

		tag_t current_role_tag			= NULLTAG;

		ITK(retcode,SA_ask_current_role(&current_role_tag)); 	

		ITK(retcode,SA_ask_role_name2(current_role_tag,&cUserRoleName));
	
		// Checks if only Orginator/Change Analyst initiating the Workflow
		if(cUserRoleName != NULL && (tc_strcmp(cUserRoleName,"Change Analyst Standard")==0 || tc_strcmp(cUserRoleName,"Database Change Analyst")==0 ))
		{			
			int iStatusCount   = 0;			
			tag_t *tStatusTags = NULL;

			ITK(retcode,WSOM_ask_release_status_list(tAttchItemTag[0],&iStatusCount,&tStatusTags));
			if(iStatusCount > 0 && tStatusTags != NULL)
			{
				char *cpStatusName	  =	NULL;
				ITK(retcode,AOM_ask_value_string(tStatusTags[0],OBJECT_NAME,&cpStatusName));
				//Check if status of Deviation is in Pending state
				if(cpStatusName	!= NULL && tc_strcmp(cpStatusName,RELEASE_STATUS)==0)
				{					
					decision = EPM_go;
				}
				else
				{										
					EMH_clear_errors();
					EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_EXPIRE_WORKFLOW_STATUS);
					decision = EPM_nogo;	
				}
				EMR_free(cpStatusName);
			}
			EMR_free(tStatusTags);			
		} 				
		// Throws Invalid Status error if Deviation has Status other then "Pending"				
		else
		{			
			EMH_clear_errors();
			EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_EXPIRE_WORKFLOW_USER);			
			decision = EPM_nogo;
		}
		EMR_free(cUserRoleName);
	} 
	//Throws Invalid Item Revision error if selected revision is other than "Deviation Revision"	
	else if(tc_strcmp(DEVIATION_REVISION,cpObjectType)!= 0)
	{
		EMH_clear_errors();
		EMH_store_initial_error(EMH_severity_user_error, LBT9_DEV_EXP_INVALID_REVISION);
		decision = EPM_nogo;
	}
	EMR_free(tAttchItemTag);
	EMR_free(cpObjectType);
	
	return decision;
}
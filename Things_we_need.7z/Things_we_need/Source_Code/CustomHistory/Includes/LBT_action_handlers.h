/******************************************************************************
 * Filename		    :   LBT_action_handlers.h
 * Description      :	Header file for LBT_action_handlers.c
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 * Description      :   Define all the action handler function proptotype here. 
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	  Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>

extern int LBT_register_action_handlers(int *decision, va_list args);
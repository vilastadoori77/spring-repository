/****************************************************************************
* Filename	    :   LBT_user_services.h			 	
* Description   :	Header file for LBT_user_services.c									
* ENVIRONMENT	:   C, C++, ITK	
* Description   :	Define all the user service function prototype here.
*									
* History							       
*--------------------------------------------------------------------------
* Date           	Name                Description of Change
* April 2015      Soumalya Sinha              Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/


#include <LBT_includes.h>

extern DLLAPI int Lbt9_consolidated_history( void *retValue );
int LBT_user_services(int *decision, va_list args);





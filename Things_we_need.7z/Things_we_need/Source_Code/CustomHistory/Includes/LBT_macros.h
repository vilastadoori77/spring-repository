/****************************************************************************
* Filename	    :    LBT_macros.h			 	
*									
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :    Define all the macros here.
*									
* History							       
*--------------------------------------------------------------------------
* Date         	Name                 Description of Change
* Apr 2015      Soumalya Sinha         Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/

#ifndef LBT_MACROS_H
#define LBT_MACROS_H

#ifdef __cplusplus
extern "C" {
#endif

#define CLEANUP(x)                                             \
{                                                              \
    if ( ifail == ITK_ok )                                     \
    {                                                          \
        if ( (ifail = (x)) != ITK_ok )                         \
        {                                                      \
           dump_itk_errors( ifail, #x, __LINE__, __FILE__ );   \
           goto CLEANUP;                                       \
        }                                                      \
    }                                                          \
}	

/* MACRO TO FREE THE MEMORY ALLOCATED TO A POINTER.... */
#define LBT_FREE(p) {\
    if ( p != NULL ) {\
        MEM_free(p);\
        p = NULL;\
    }\
}

// Free a string array, including all array elements
#define LBT_FREE_STRINGS(p) \
{\
   if ( p != NULL )\
   {\
      TC_free_strings(p);\
      p = NULL;\
   }\
}\




#ifdef __cplusplus
}
#endif

#endif  /* LBT_MACROS_H */


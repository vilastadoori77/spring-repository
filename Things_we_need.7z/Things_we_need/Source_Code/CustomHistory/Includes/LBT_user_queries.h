/****************************************************************************
* Filename	    :   LBT_user_queries.h			 	
* Description   :	Header file for LBT_user_services.c									
* ENVIRONMENT	:   C, C++, ITK	
* Description   :	Define all the user service function prototype here.
*									
* History							       
*--------------------------------------------------------------------------
* Date           	Name                Description of Change
* April 2015      Soumalya Sinha              Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/


#include <LBT_includes.h>


int LBT9_search_buss_doc_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_cr_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_cnr_based_on_ca(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_cnr_based_on_owning_user(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);

int LBT9_search_crr_based_on_ca(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);

int LBT9_search_crr_based_on_owning_user(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_comm_part_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_dcn_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_dev_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_ecn_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_mco_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);

int LBT9_search_mfg_part_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_manufacturer(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_prod_spec_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
int LBT9_search_stopship_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs);
/**************************************************************************************************************************************************
* Filename	    :   LBT_defines.h
*
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :   Define all the constants here.
*--------------------------------------------------------------------------------------------------------------------------------------------------
* Date         	Name				Description of Change
* June 2015     Soumalya Sinha		 Created.

***************************************************************************************************************************************************/


#ifndef LBT_DEFINES_H
#define LBT_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif



#define LBT_TC_SMTP_EXE_NAME         ("tc_mail_smtp")

// Lengths

#define LBT_ORIGINAL_FILENAME_LEN  (NX_MAX_LEN_FILENAME)
#define LBT_DATASET_NAME_LEN       (128)
#define MAX_COMMENT_SIZE          (5000)


#define LBT_FIND_NUMBER_INCREMENT (10)

#define LBT_REVISION_TYPE_SUFFIX  ("Revision")

#define LBT_UNREADABLE  ("UNREADABLE")

#define LBT_IS_NULL  ("IS_NULL")

#define LBT_NULL_VALUE  ("NULL")
#define LBT_NONE_VALUE  ("NONE")
#define LBT_TRUE_VALUE  ("TRUE")
#define LBT_FALSE_VALUE  ("FALSE")

#define LBT_GREEN_VALUE  ("GREEN")
#define LBT_YELLOW_VALUE ("YELLOW")
#define LBT_RED_VALUE    ("RED")

#define LBT_GlobalVALUE  ("Global")

#define LBT_DEFAULT_VALUE  ("DEFAULT")
#define LBT_Default_VALUE  ("Default")


#define LBT_ClosedVALUE  ("Closed")


// Argument value for LBT_parse_delimited_string()
#define LBT_TRIM_BLANKS  (TRUE)
#define LBT_NO_TRIM      (FALSE)

// Boolean values for functions that compare strings.
#define LBT_IGNORE_CASE (TRUE)
#define LBT_HONOR_CASE  (FALSE)

// Argument value for LBTMsgInfoTagsCache()
#define LBT_GET_CACHED_VALUES  (TRUE)
#define LBT_SET_CACHED_VALUES  (FALSE)




#define LBT_LINEFEED     ("\n")
#define LBT_DBL_LINEFEED ("\n\n")
#define LBT_DBL_TABFEED ("\t\t")
#define LBT_DOT         (".")
#define LBT_COMMA       (",")
#define LBT_COMMA_SPACE (", ")
#define LBT_COLON       (":")
#define LBT_DOLLAR      ("$") 
#define LBT_SEMICOLON   (";")
#define LBT_ASTERISK    ("*")
#define LBT_ATSIGN      ("@")
#define LBT_AMPERSAND   ("&")
#define LBT_BLANK       (" ")
#define BOM_INDENTATION ("      ")
#define LBT_SLASH       ("/")
#define LBT_DASH        ("-")
#define LBT_UNDERSCORE_CHAR    ('_')
#define LBT_UNDERSCORE         ("_")
#define LBT_DOUBLE_UNDERSCORE  ("__")
#define LBT_XLS         (".xls")
#define LBT_OPEN_CURLY_BRACKET ("{")
#define LBT_CLOSE_CURLY_BRACKET ("}")
#define LBT_OPEN_BRACKET ("(")
#define LBT_CLOSE_BRACKET (")")
#define LBT_PLUS       ("+")
#define LBT_PLUS_CHAR  ('+')
#define LBT_MINUS      ("-")
#define LBT_MINUS_CHAR ('-')
#define LBT_NULL_CHAR ('\0')
#define LBT_EFFECTIVITY_SPACE ("Effectivity ")
#define LBT_GO    ("EPM_go")
#define LBT_NOGO  ("EPM_nogo")
#define LBT_ZERO  ("0")
#define LBT_SPACE (" ")
#define LBT_BAR   ("|")
#define LBT_TRIPLE_CARET  ("^^^")
#define LBT_TRIPLE_BAR  ("|||")

// Boolean values for LBT_compare_dates
#define LBT_COMPARE_DATE_ONLY     (TRUE)
#define LBT_COMPARE_DATE_AND_TIME (FALSE)



#define LBT_WRITE_ACCESS ("WRITE")
#define LBT_READ_ACCESS ("READ")

// Boundary value used to prevent endless loop for some cases.
#define LBT_MAX_BOM_LEVELS (100)

// Values for BOM navigation utilities.
// Must be consistent with client-side LBTConstant values.
#define LBT_LEVEL_ZERO (0)
#define LBT_ONE_LEVEL  (1)
#define LBT_TWO_LEVELS (2)
#define LBT_ALL_LEVELS (-1)

#define LBT_UNLIMITED_CARDINALITY  (9999)

#define LBT_MM_DD_YYYY_DATEFORMAT ("%m-%d-%Y")

#define LBT_ALL_PICKLIST_STATUSES   ("ALL STATUSES")

//Values for YES and NO
#define LBT_YES  ("YES")
#define LBT_NO   ("NO")
#define LBT_Yes  ("Yes")
#define LBT_No   ("No")
#define LBT_Y    ("Y")
#define LBT_N    ("N")

#define LBT_AND_OPERATOR  ("AND")
#define LBT_OR_OPERATOR   ("OR")

#define FILEPATH_DELIMITER          ("\\")


// Math operators 

#define LBT_EQUAL_OP            ("=")
#define LBT_NOT_EQUAL_OP        ("!=")
#define LBT_GREATER_THAN_OP     (">")
#define LBT_GREATER_OR_EQUAL_OP (">=")
#define LBT_LESS_THAN_OP        ("<")
#define LBT_LESS_OR_EQUAL_OP    ("<=")
#define LBT_IS_NULL_OP          ("IS_NULL")
#define LBT_IS_NOT_NULL_OP      ("IS_NOT_NULL")


#define LBT_equals_DISPLAYOP ("equals")
#define LBT_not_equal_DISPLAYOP ("not_equal")
#define LBT_less_than_DISPLAYOP ("less_than")
#define LBT_greater_than_DISPLAYOP ("greater_than")
#define LBT_less_than_or_equal_DISPLAYOP ("less_than_or_equal")
#define LBT_greater_than_or_equal_DISPLAYOP ("greater_than_or_equal")
#define LBT_is_empty_DISPLAYOP ("is_empty")
#define LBT_is_not_empty_DISPLAYOP ("is_not_empty")
#define LBT_is_one_of_DISPLAYOP ("is_one_of")
#define LBT_is_not_one_of_DISPLAYOP ("is_not_one_of")
#define LBT_contains_DISPLAYOP ("contains")	
#define LBT_on_DISPLAYOP ("on")
#define LBT_not_on_DISPLAYOP ("not_on")
#define LBT_on_or_before_DISPLAYOP ("on_or_before")
#define LBT_on_or_after_DISPLAYOP ("on_or_after")
#define LBT_before_DISPLAYOP ("before")
#define LBT_after_DISPLAYOP ("after")
#define LBT_today_DISPLAYOP ("today")
#define LBT_yesterday_DISPLAYOP ("yesterday")
#define LBT_tomorrow_DISPLAYOP ("tomorrow")
#define LBT_before_today_DISPLAYOP ("before_today")
#define LBT_on_or_before_today_DISPLAYOP ("on_or_before_today")
#define LBT_after_today_DISPLAYOP ("after_today")
#define LBT_on_or_after_today_DISPLAYOP ("on_or_after_today")
#define LBT_last_7_days_DISPLAYOP ("last_7_days")
#define LBT_next_7_days_DISPLAYOP ("next_7_days")
#define LBT_more_than_7_days_DISPLAYOP ("more_than_7_days")
#define LBT_last_14_days_DISPLAYOP ("last_14_days")
#define LBT_next_14_days_DISPLAYOP ("next_14_days")
#define LBT_more_than_14_days_DISPLAYOP ("more_than_14_days")
#define LBT_last_30_days_DISPLAYOP ("last_30_days")
#define LBT_next_30_days_DISPLAYOP ("next_30_days")
#define LBT_more_than_30_days_DISPLAYOP ("more_than_30_days")	


#define DATE_FORMAT_REP			"%d-%b-%Y %H:%M:%S"
#define DATE_FORMAT_STR			"%Y%m%d_%H%M%S"
#define DATE_FORMAT_STR_FOOTER	"%m-%d-%Y Time %H:%M:%S"
#define CURRENT_DATE_FORMAT		"%m-%d-%Y"
#define DATE_FORMAT				"%d-%b-%Y"
#define DATE_FORMAT_YYYYMMDD    "%Y%m%d"
#define DATE_TIME_FORMAT	    "%d-%b-%Y %H:%M"

// OTB object types
#define MECfgLineTYPE            ("MECfgLine")
#define CfgAttachmentLineTYPE    ("CfgAttachmentLine")
#define DocumentTYPE             ("Document")
#define DocumentRevisionTYPE     ("DocumentRevision")
#define ItemTYPE                 ("Item")
#define ItemRevisionTYPE         ("ItemRevision")
#define SnapshotTYPE             ("Snapshot")
#define WorkspaceObjectTYPE      ("WorkspaceObject")
#define BOMLineTYPE              ("BOMLine")
#define ParmGrpDefTYPE           ("ParmGrpDef")
#define ParmGrpDefRevisionTYPE   ("ParmGrpDefRevision")
#define ParmDefTYPE              ("ParmDef")
#define ParmDefRevisionTYPE      ("ParmDefRevision")
#define AbsOccDataTYPE           ("AbsOccData")
#define PSOccurrenceTYPE         ("PSOccurrence")
#define PSOccurrenceThreadTYPE   ("PSOccurrenceThread")

#define TC_ProjectTYPE           ("TC_Project")
#define ImanFileTYPE             ("ImanFile")
#define DatasetTYPE              ("Dataset")
#define FullTextTYPE             ("FullText")
#define Web_LinkTYPE             ("Web Link")
#define PSBOMViewTYPE            ("PSBOMView")
#define PSBOMViewRevisionTYPE    ("PSBOMViewRevision")
#define BOMViewTYPE              ("BOMView")
#define BOMView_RevisionTYPE     ("BOMView Revision")
#define TableTYPE                ("Table")
#define TableDefinitionTYPE      ("TableDefinition")
#define TableLabelTYPE           ("TableLabel")
#define ProposedReviewerTYPE     ("ProposedReviewer")
#define SpecElementTYPE          ("SpecElement")
#define SpecElementRevisionTYPE  ("SpecElementRevision")
#define SpecificationTYPE        ("Specification")
#define SpecificationRevisionTYPE ("Specification Revision")
#define FormTYPE                 ("Form")
#define ItemRevisionMasterTYPE	 ("ItemRevision Master")

#define SignoffTYPE              ("Signoff")

// Custom object types

#define EMR_ManufacturingPartType                 ("EMR_VendorPart")

#define EMR_CommrclPartRevisionTYPE              ("EMR_CommrclPart Revision")
#define EMR_ManufacturingPartRevisionType        ("EMR_VendorPart Revision")
#define EMR_ManufacturerRevisionType              ("EMR_Vendor Revision")

#define EMR_DocumentRevisionTYPE                 ("EMR_Document Revision")
#define LBT9_BusDocRevisionTYPE                  ("LBT9_BusDocRevision")
#define LBT9_SpecDocRevisionTYPE                 ("LBT9_SpecDocRevision")

#define LBT9_DCNRevisionTYPE                      ("LBT9_DCNRevision")
#define LBT9_ECNRevisionTYPE                      ("LBT9_ECNRevision")
#define LBT9_MCORevisionTYPE                      ("LBT9_MCORevision")

#define LBT9_ChgRequestRevisionTYPE               ("LBT9_ChgRequestRevision")
#define LBT9_DeviationRevisionTYPE                ("LBT9_DeviationRevision")
#define LBT9_StopShipRevisionTYPE                 ("LBT9_StopShipRevision")
#define LBT9_JobTYPE                                  ("LBT9_Job")

//Custom Form Type


#define CHANGE_FORM_TYPE	                  ("LBT9_Change_History")
#define LBT9_Signoff_Form_TYPE                 ("LBT9_Signoff_Form")
#define LBT9_Attachment_FormTYPE               ("LBT9_Attachment_Form")



// Custom Relations



// OTB Relation types
#define IMANRelationTYPE            ("IMANRelation") // For GRM_find_relation_type() this must be IMANRelation -not- ImanRelation!
#define IMAN_specificationTYPE      ("IMAN_specification")
#define IMAN_referenceTYPE          ("IMAN_reference")
#define TC_AttachesTYPE             ("TC_Attaches")
#define IMAN_master_formTYPE        ("IMAN_master_form")
#define TC_Generic_ArchitectureTYPE ("TC_Generic_Architecture")
#define CMHasImpactedItemTYPE       ("CMHasImpactedItem")



// Classes
#define workspaceobjectCLASS        ("workspaceobject")
#define POM_application_objectCLASS ("POM_application_object")

// OTB properties
#define item_idPROP             ("item_id")
#define item_revision_idPROP    ("item_revision_id")
#define sequence_idPROP         ("sequence_id")
#define namePROP                ("name")
#define object_namePROP         ("object_name")
#define object_descPROP         ("object_desc")
#define object_stringPROP       ("object_string")
#define object_typePROP         ("object_type")
#define current_namePROP        ("current_name")
#define current_revPROP         ("current_revision_id")
#define item_for_formPROP		("item_for_form")
#define puidPROP                ("puid")
#define seq_noPROP              ("seq_no")
#define abs_occPROP             ("abs_occ")
#define occ_threadPROP          ("occ_thread")
#define instance_numberPROP     ("instance_number")
#define child_itemPROP          ("child_item")
#define data_qualifierPROP      ("data_qualifier")
#define qualifier_bvrPROP       ("qualifier_bvr")
#define representsPROP          ("represents")
#define revisionPROP            ("revision")
#define highest_revPROP         ("highest_rev")
#define keep_limitPROP          ("keep_limit")
#define revisionsPROP           ("revisions")
#define revision_numberPROP     ("revision_number")
#define revision_listPROP       ("revision_list")
#define item_master_tagPROP     ("item_master_tag")
#define release_status_listPROP ("release_status_list")
#define original_file_namePROP  ("original_file_name")
#define ref_listPROP            ("ref_list")
#define ref_namesPROP           ("ref_names")
#define primary_objectPROP      ("primary_object")
#define secondary_objectPROP    ("secondary_object")
#define project_idPROP          ("project_id")
#define project_namePROP        ("project_name")
#define project_descPROP        ("project_desc")
#define project_teamPROP        ("project_team")
#define project_listPROP        ("project_list")
#define projects_listPROP       ("projects_list")
#define project_membersPROP     ("project_members")
#define ip_classificationPROP   ("ip_classification")
#define test_sequence           ("sequence_id")
#define test_object             ("object_desc")
#define rowPROP                 ("row")
#define rowsPROP                ("rows")
#define colPROP                 ("col")
#define colsPROP                ("cols")
#define cellsPROP               ("cells")
#define valuePROP               ("value")
#define valuesPROP              ("values")
#define definitionPROP          ("definition")
#define labelPROP               ("label")
#define locationPROP            ("location")
#define active_seqPROP          ("active_seq")
#define ProjectNamePROP         ("ProjectName")
#define effectivity_unitsPROP   ("effectivity_units")
#define user_idPROP             ("user_id")
#define user_namePROP           ("user_name")
#define owning_userPROP         ("owning_user")
#define checked_out_userPROP    ("checked_out_user")
#define last_mod_userPROP       ("last_mod_user")
#define last_mod_datePROP       ("last_mod_date")
#define creation_datePROP       ("creation_date")
#define owning_groupPROP        ("owning_group")
#define owning_organizationPROP ("owning_organization")
#define CMImpactedItemsPROP     ("CMImpactedItems")
#define CMReferenceItemsPROP    ("CMReferenceItems")
#define absocc_specific_edit_modePROP ("absocc_specific_edit_mode")
#define absocc_ctxtlinePROP     ("absocc_ctxtline")
#define bl_item_object_typePROP ("bl_item_object_type")
#define bl_item_object_namePROP ("bl_item_object_name")
#define bl_rev_item_revision_idPROP ("bl_rev_item_revision_id")
#define bl_parentPROP           ("bl_parent")
#define assigneePROP	        ("assignee")
#define descPROP                ("desc")
#define validValuesPROP         ("validValues")
#define initialValuesPROP       ("initialValues")
#define minValuesPROP           ("minValues")
#define maxValuesPROP           ("maxValues")
#define parmValuesPROP          ("parmValues")
#define bitDefPROP              ("bitDef")
#define sizePROP                ("size")
#define meaningOf0PROP          ("meaningOf0")
#define meaningOf1PROP          ("meaningOf1")
#define namePROP                ("name")
#define bitPROP                 ("bit")
#define bytePROP                ("byte")
#define rule_unitPROP           ("rule_unit")
#define bl_revisionPROP         ("bl_revision")
#define bl_parentPROP           ("bl_parent")
#define task_templatePROP       ("task_template")
#define template_namePROP       ("template_name")
#define bl_line_objectPROP      ("bl_line_object")
#define bl_indented_titlePROP   ("bl_indented_title")
#define isSignedPROP            ("isSigned")
#define resolution_numeratorPROP   ("resolution_numerator")
#define resolution_denominatorPROP ("resolution_denominator")
#define precisionPROP           ("precision")
#define tolerancePROP           ("tolerance")
#define tableDefinitionPROP     ("tableDefinition")
#define bl_item_item_idPROP     ("bl_item_item_id")
#define USER_TASK_INBOX         ("taskinbox")
#define checked_outPROP         ("checked_out")
#define ccd0ConversionRulePROP  ("ccd0ConversionRule")
#define display_namePROP        ("display_name")
#define currentStatePROP        ("currentState")
#define serviceNamePROP         ("serviceName")
#define relation_typePROP       ("relation_type")
#define type_stringPROP         ("type_string")
#define body_textPROP           ("body_text")
#define body_cleartextPROP      ("body_cleartext")
#define full_namePROP           ("full_name")
#define contentsPROP            ("contents")
#define TypeNameProp			  ("type_name")

//Custom History Properties
#define StructureLogProp             ("fnd0StructureAuditLogs")
#define GeneralAuditLogProp          ("fnd0GeneralAuditLogs")
#define fnd0EventTypeNameProp        ("fnd0EventTypeName")
#define fnd0SecondaryObjDispNameProp ("fnd0SecondaryObjDispName")
#define fnd0LoggedDateProp           ("fnd0LoggedDate")
#define fnd0UserIdProp               ("fnd0UserId")


// Custom properties


#define lbt9_Attachment_HistoryPROP       ("lbt9_Attachment_History")
#define lbt9_Derived_toPROP               ("lbt9_Derived_to")
#define lbt9_Attachment_FormPROP          ("lbt9_Attachment_Form")
#define lbt9_PDX_HistoryPROP              ("lbt9_PDX_History")
#define lbt9_Request_DataPROP             ("lbt9_Request_Data")
#define lbt9_Request_Initiated_DatePROP   ("lbt9_Request_Initiated_Date")
#define lbt9_Request_InitiatorPROP        ("lbt9_Request_Initiator")
#define lbt9_Request_Completed_DatePROP   ("lbt9_Request_Completed_Date")
#define lbt9_Request_StatusPROP           ("lbt9_Request_Status")
#define lbt9_Signoff_HistoryPROP          ("lbt9_Signoff_History")


// Custom runtime properties


#define lbt9_history_typePROP             ("lbt9_history_type")
#define lbt9_history_userPROP             ("lbt9_history_user")
#define lbt9_history_statusPROP           ("lbt9_history_status")
#define lbt9_history_datePROP             ("lbt9_history_date")
#define lbt9_history_commentsPROP         ("lbt9_history_comments")



#define lbt9_ActorPROP                    ("lbt9_Actor")  
#define lbt9_RelationPROP                 ("lbt9_Relation")  
#define lbt9_ActionPROP                   ("lbt9_Action")  
#define lbt9_AttachmentPROP               ("lbt9_Attachment")  
#define lbt9_DatePROP                     ("lbt9_Date") 
		 
					 



// Runtime properties used by VSEM Views.

   
// Custom BOMLine properties
#define bl_representsPROP                  ("bl_represents")


// Custom note types - these are also BOMline properties



// Custom compound properties


// View types
#define viewVIEW               ("view")

// Release statuses
#define ReleasedSTATUS         ("Released")


// Dataset type names
#define DatasetTYPE            ("Dataset")
#define ZipTYPE                ("Zip")
#define MISCTYPE               ("MISC")


// Named references



// Tools
#define IExploreTOOL           ("IExplore")
#define NotepadTOOL            ("Notepad")
#define WordpadTOOL            ("Wordpad")
#define UnZipTOOL              ("UnZip")
#define ZipTOOL                ("Zip")

// Saved queries
#define Item_RevisionQUERY                 ("Item Revision...")


//User entry field names for query
#define LBT_ModifiedAfterFIELD              ("Modified After")
#define LBT_ModifiedBeforeFIELD             ("Modified Before")
#define LBT_OBJECT_TYPE                     ("Type")
#define IDENTRY                             ("ID") // item_id
#define Item_IDENTRY                        ("Item ID") // also item_id
#define NameENTRY                           ("Name")
#define OwningUserENTRY                     ("OwningUser")
#define REVENTRY                            ("Revision")

//property types
#define StringTYPE                        ("String")
#define IntTYPE                          ("Int")
#define DateTYPE                         ("Date")
#define Typed_ReferenceTYPE              ("Typed_Reference")
#define Untyped_ReferenceTYPE           ("Untyped_Reference")


//Folder names
#define HomeFOLDER              ("Home")
#define NewstuffFOLDER          ("Newstuff")

// BMIDE object type Constants
#define MaturityStatusesCONSTANT                  ("MaturityStatuses")


// Occurrence type names
#define NULL_OCCTYPE                      ("NULL")
#define NONE_OCCTYPE                      ("NONE")

// Revision rules
#define Latest_WorkingREVISIONRULE         ("Latest Working")
#define Any_Status_No_WorkingREVISIONRULE  ("Any Status; No Working")
#define Any_Status_WorkingREVISIONRULE      ("Any Status; Working")




#define LBT_GET_All_sequence                             ("All Sequences")
#define LBT_GET_server_name                              ("Mail_server_name")
#define LBT_GET_server_port                              ("Mail_server_port")
#define LBT_send_list									 ("-to_list_file=")
#define LBT_server										 ("-server=")
#define LBT_subject										 ("-subject=")
#define LBT_bdy											 ("-body=")
#define LBT_user										 ("-user=")
#define LBT_name										 ("-name=")
#define LBT_attachment									 ("-attachments=")


//Custom Preference


#define LBT_Commercial_Rev_history_attr_listPREF             ("LBT_Commercial_Rev_history_attr_list")
#define LBT_Manufacturing_Rev_history_attr_listPREF          ("LBT_Manufacturing_Rev_history_attr_list")
#define LBT_Document_Rev_history_attr_listPREF               ("LBT_Document_Rev_history_attr_list")
#define LBT_DCN_Rev_history_attr_listPREF                    ("LBT_DCN_Rev_history_attr_list")
#define LBT_ECN_Rev_history_attr_listPREF                    ("LBT_ECN_Rev_history_attr_list")
#define LBT_MCO_Rev_history_attr_listPREF                    ("LBT_MCO_Rev_history_attr_list")
#define LBT_CR_Rev_history_attr_listPREF                     ("LBT_CR_Rev_history_attr_list")
#define LBT_Deviation_Rev_history_attr_listPREF              ("LBT_Deviation_Rev_history_attr_list")
#define LBT_StopShip_Rev_history_attr_listPREF               ("LBT_StopShip_Rev_history_attr_list")

// ACL names
#define OBJECTACL   ("OBJECT")

// LOVs



//Workflow Property

#define PREVIOUS_TASK  "previous_task"
#define COMMENTS       "comments"
#define PREDECESSORS   "predecessors"
#define TASK_STATE     "task_state"
// Miscellaneous values


// Organization

#define dbaGROUP                          ("dba")
#define DbaROLE                           ("DBA")
#define	UserACCESSOR	                  ("User")
#define ParticipantTypeARG              ("ParticipantType")
#define AssignedToParticipantTypeARG    ("AssignedToParticipantType")



//ACL and Access Constants
#define LBT_WRITE_DELIMITER                ("_write")
#define LBT_FULL_DELIMITER                 ("_full")




// Additional Validation
#define LBT_PSChildrenPROP                ("ps_children")



//TC Env. variables

#define MAX_OPTION_VALUE_LENGTH   256



#ifdef __cplusplus
}
#endif

#endif  /* LBT_DEFINES_H */


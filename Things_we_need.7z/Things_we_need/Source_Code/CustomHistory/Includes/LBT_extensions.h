/****************************************************************************
* Filename	    :    LBT_extensions.h			 	
*									
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :    Define all the Pre/Post action function prototype here
*									
* History							       
*--------------------------------------------------------------------------
* Date         	Name              Description of Change
* April 2015   Soumalya Sinha         Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/


#ifndef LBT_EXTENSIONS_H
#define LBT_EXTENSIONS_H


#ifdef __cplusplus
extern "C" {
#endif

#include <LBT_includes.h>

	//Venus Code
	
#define ITK( argument )                                             \
{                                                                   \
	int retcode = argument;                                         \
	if ( retcode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retcode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retcode );                        \
	EMH_ask_error_text (retcode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	}                                                               \
}
#define ERROR_CHECK( argument )                                     \
{                                                                   \
	int retcode = argument;                                         \
	if ( retcode != ITK_ok ) {                                      \
	char* s;                                                        \
	printf( " "#argument "\n" );                                    \
	printf( "  returns [%d]\n", retcode );                          \
	TC_write_syslog( " "#argument "\n" );                                  \
	TC_write_syslog( "  returns [%d]\n", retcode );                        \
	EMH_ask_error_text (retcode, &s);                               \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);           \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);         \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );  \
	if (s != 0) MEM_free (s);                                       \
	return retcode;                                                 \
	}                                                               \
}


extern int deleteFormFromItem(tag_t item_tag,         /* <I> */
							  char *form_name         /* <I> */
			                 );
extern int attachFormToRevision(tag_t formTag,          /* <I> */
						        tag_t revTag            /* <I> */
						       );
extern int removeForm(tag_t object,        /* <I> */
                      char *form_name,     /* <I> */
					  tag_t *form_object   /* <O> */
					 );
extern int	deleteFormProperties (tag_t change_form     /* <I> */);
extern int LBT9_detachChangeFormFromRevision(tag_t relation_tag  /* <I> */
	                                         );
	//Venus Code ends




extern DLLAPI int LBT9_consolidated_history(METHOD_message_t* msg, va_list args);


extern DLLAPI int LBT9_store_attachment_history(tag_t itemRevTag,char* relation_type_name,char* object_string,logical is_added);
extern DLLAPI int LBT9_Store_history_Iman_delete_pre(METHOD_message_t* msg, va_list args );
extern DLLAPI int LBT9_Store_history_GRM_create_post(METHOD_message_t* msg, va_list args );
extern DLLAPI int LBT9_save_as_history(METHOD_message_t *message, va_list args);
extern DLLAPI int LBT9_revise_cleanup_properties(METHOD_message_t *message, va_list args);
extern DLLAPI int LBT9_Set_PDX_History_Job_create_postaction(METHOD_message_t* msg, va_list args);
extern DLLAPI int LBT_Set_PDX_HIstory(tag_t PDXJob,logical isGenerated);


extern int LBT_attachFormToRevision(tag_t formTag,tag_t revTag, const char *FormRefPropertyName);

extern int LBT9_create_attachment_form(tag_t itemRevTag,char* relation_type_name,char* object_string,logical is_added);


//Venus Code
extern int LBT9_attachChangeFormToRevision(tag_t change_rev_tag,    /* <I> */
                                           tag_t item_rev_tag       /* <I> */
                                          );

//Venus Code ends

#ifdef __cplusplus
}
#endif
#endif  /* LBT_EXTENSIONS_H */

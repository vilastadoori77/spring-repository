
/******************************************************************************
 * Filename		    :   LBT_prototype.h
 * Description      :	Header file for all common/Generic function (define all the
 *                      prototype for common/Generic function here)
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	  Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/




#include <LBT_includes.h>

#ifdef __cplusplus
extern "C" {
#endif

void AM__set_application_bypass(logical bypass_on);
void AM__ask_application_bypass(logical* has_bypass);


#ifdef __cplusplus
}
#endif

// System functions


//
// Custom functions. 
// Please define all functions with DLLAPI so they can be used externally in our Windows client programs.
//

void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName );

extern DLLAPI int LBT_strcat(char** string, char* addString);
extern DLLAPI int LBT_strdup(const char* inputString, char** outputString);
extern DLLAPI void LBT9_current_get_time_stamp(char* format, char** timestamp);
extern DLLAPI int LBT_check_property_exists(tag_t tagObject,char *propertyName);
extern int LBT_find_string_in_array(int stringCnt, char** stringArray, const char* compareString);
extern int LBT_find_string_in_array_ignore_case(int stringCnt, char** stringArray, const char* compareString);
extern int LBT_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag);
extern int LBT_find_tag_in_array_by_list(int tagCnt1, tag_t* tagArray1, int tagCnt2, tag_t* tagArray2);
extern int LBT_find_int_in_array(int intCnt, int* intArray, int compareInt);
extern int LBT_find_double_in_array(int doubleCnt, double* doubleArray, double compareDouble);

extern int LBT_copy_string_to_array(int* stringCnt, char*** stringArray, char* addString);
extern int LBT_parse_delimited_string(const char* delimitedString, char* delimiterChars, logical trim_blanks,
	                              int* stringCnt, char*** stringArray);
extern int LBT_parse_string_with_string(char* targetString, const char* delimiterString,
	                               int* stringCnt, char*** stringArray);
extern int LBT_strndup(const char* inputString, char** outputString, int charCnt);
extern int LBT_add_string_pointer_to_array(int* stringCnt, char*** stringArray, char* addString);
extern int LBT_ask_release_status(tag_t objectTag,char **status);
extern int LBT_object_is_typeof(tag_t objTag, char* type_name, logical* isType);
extern int LBT_typename_is_typeof_list(const char* typeName, int compareTypeCnt, char** compareTypenames, logical* answer);
extern int LBT_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag);
extern int LBT_add_tags_to_array(int* tagCnt, tag_t** tagArray, int addCnt, tag_t* addTagArray);
extern char* LBT_trim_blanks(char* inputStr);



/******************************************************************************
 * Filename		    :   LBT_register_callbacks.h
 * Description      :	Header file for LBT_register_callbacks.c
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	  Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/



#include "LBT_includes.h"


#ifdef __cplusplus
extern "C" {
#endif

		
extern DLLAPI int liblbt_register_callbacks();
extern int LBT_register_user_services(int *decision, va_list args);
extern int LBT_register_custom_handlers(int *decision, va_list args);
extern int LBT_custom_register_prop_method (int *decision, va_list args);

extern int LBT_register_user_queries (int *decision, va_list args);
#ifdef __cplusplus
}
#endif



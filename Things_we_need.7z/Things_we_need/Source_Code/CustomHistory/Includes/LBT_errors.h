/**************************************************************************************************************************************************
* Filename	    :   LBT_errors.h
*
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :   Define all the custom error code here.
*--------------------------------------------------------------------------------------------------------------------------------------------------
* Date         	Name				Description of Change
* June 2015     Soumalya Sinha		 Created.

***************************************************************************************************************************************************/


#ifndef LBT_RETURN_CODES_H
#define LBT_RETURN_CODES_H



#ifdef __cplusplus
extern "C" {
#endif



#define LBT_error_base (920000)



#ifdef __cplusplus
}
#endif

#endif  /* LBT_RETURN_CODES_H */



/****************************************************************************
* Filename	    :    LBT_includes.h			 	
*									
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :    Define all the includes here
*									
* History							       
*--------------------------------------------------------------------------
* Date         	Name              Description of Change
* April 2015   Soumalya Sinha         Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/


#ifndef LBT_INCLUDES_H
#define LBT_INCLUDES_H

#ifdef __cplusplus
extern "C" {
#endif

	/*
#if defined(_WIN32)
#include <windows.h>
#include <strsafe.h>
#else
#include <unistd.h>
#include <dirent.h>
#include <sys/wait.h>
#endif
#ifndef WIN32 
  #define stricmp strcasecmp 
  #define strnicmp strncasecmp 
#endif
  */

/*************************************************
*	System Header Files
**************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*************************************************
*	Iman Header Files
**************************************************/


#include <math.h>
#include <tc/iman.h>
#include <fclasses/iman_stdio.h> 
#include <sys/types.h>
#include <textsrv/textserver.h>	
#include <common/emh_const.h>
#include <tc/tc_macros.h>
#include <property/prop_errors.h>
#include <property/propdesc.h>
#include <cfm/cfm.h>
#include <pom/enq/enq.h>
#include <itk/mem.h>
#include <tccore/tctype.h>
#include <tccore/iman_msg.h>
#include <tccore/item_msg.h>
#include <tccore/tc_msg.h>	
#include <tccore/project_errors.h>
#include <tccore/workspaceobject.h> 	
#include <errno.h>
#include <sa/tcvolume.h>
#include <sa/sa.h>
#include <ae/vm_errors.h>
#include <ae/dataset.h>
#include <ae/shell_util.h>
#include <lov/lov.h>
#include <sa/tcfile.h>
#include <ctype.h>
#include <ps/ps_tokens.h>
#include <tc/folder.h>
#include <rdv/arch.h>
#include <constants/constants.h>
#include <res/res_itk.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <epm/cr.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/signoff.h>
#include <sub_mgr/tceventtype.h>
#include <sub_mgr/subscription.h>
#include <sub_mgr/standardtceventtypes.h>
#include <ps/vrule.h>
#include <qry/crf.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <ps/absocc.h>
#include <bom/bom.h>
#include <tc/emh.h>
#include <tc/emh_errors.h>
#include <epm/epm_toolkit_iman_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <tccore/grm.h>
#include <tccore/grm_errors.h>
#include <tccore/grmtype.h>
#include <form/form.h>
#include <itk/bmf.h>
#include <ict/ict_userservice.h>
#include <tc/tc.h>
#include <tc/tc_util.h>
#include <tccore/method.h>
#include <pom/pom/pom.h>
#include <pom/pom/pom_errors.h>
#include <sa/sa_errors.h>
#include <ss/ss_errors.h>
#include <tccore/custom.h>
#include <user_exits/user_exits.h>
#include <server_exits/user_server_exits.h>
#include <unidefs.h>
#include <base_utils/Mem.h>
#include <tccore/item.h>
#include <tc/preferences.h>
#include <ps/ps.h>
#include <ae/ae.h>
#include <sa/am.h>
#include <me/me.h>
#include <tc/envelope.h>
#include <sa/role.h>
#include <sa/user.h>
#include <tccore/project.h>
#include <ae/datasettype.h>

#include <time.h>
#include <sys/stat.h>
#include <varargs.h>
#include <fclasses/tc_date.h>
#include <fclasses/tc_string.h>
#include <mechatronics/pssignal.h>
#include <epm/epm_task_template_itk.h>
#include <tccoreext/gde.h>
#include <tccore/license.h>
#include<tccore/libimancore_exports.h>




/*************************************************
*	Custom Header Files
**************************************************/

#include <LBT_defines.h>
#include <LBT_errors.h>
#include <LBT_extensions.h>
#include <LBT_prototypes.h>
#include <LBT_register_callbacks.h>
#include <LBT_macros.h>
#include <LBT_user_services.h>
#include <LBT_action_handlers.h>
#include <LBT_rule_handlers.h>
#include <LBT_runtime_prop_methods.h>
#include <LBT_bomline_runtime_prop_methods.h>
#include <LBT_prop_methods.h>
#include <LBT_user_queries.h>

#ifdef __cplusplus
}
#endif

#endif  /* LBT_INCLUDES_H */


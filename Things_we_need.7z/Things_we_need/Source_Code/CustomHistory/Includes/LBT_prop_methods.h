/******************************************************************************
 * Filename		    :   LBT_prop_method.h
 * Description      :	Header file for LBT_register_prop_method.c(define all the
 *                      prototype for propmethod function here)
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	  Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>

int LBT_prop_methods();
int LBT9JOB_Request_completed_Date_set_method(METHOD_message_t *message, va_list args);
int lbt9_Request_Data_set_method(METHOD_message_t *message, va_list args);


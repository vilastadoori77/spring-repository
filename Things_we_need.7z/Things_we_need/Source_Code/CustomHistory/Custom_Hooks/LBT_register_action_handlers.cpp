/******************************************************************************
 * Filename		    :   LBT_register_action_handlers.c
 * Description      :	This file is for registering all the custom action handlers
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>


// Register custom LBT action workflow handlers.
// This is called by LBT_register_custom_handlers()
extern int LBT_register_action_handlers(int *decision, va_list args)
{
    int status          = ITK_ok;
    char* function_name = "LBT_register_action_handlers";
	
	
	*decision  = ALL_CUSTOMIZATIONS;
	

   
  return( status );
}


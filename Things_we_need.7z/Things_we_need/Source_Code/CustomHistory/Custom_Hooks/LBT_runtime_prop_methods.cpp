/******************************************************************************
 * Filename		    :   LBT_runtime_prop_methods.cpp
 * Description      :	This file is for writing all the runtime property method.
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/
#include <LBT_includes.h>


int LBT_runtime_prop_methods()
{
   int          ifail          = ITK_ok;
  
   char         *function_name = "LBT_runtime_prop_methods";
  

   
  
   
  return( ifail );
}
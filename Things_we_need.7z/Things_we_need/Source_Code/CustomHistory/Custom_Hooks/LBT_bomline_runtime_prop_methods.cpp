/******************************************************************************
 * Filename		    :   LBT_bomline_runtime_prop_methods
 * Description      :	This file is for writing all the property Method for BOMLIne
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/
#include <LBT_includes.h>


int LBT_bomline_runtime_prop_methods()
{
   int          ifail          = ITK_ok;
  
   char         *function_name = "LBT_bomline_runtime_prop_methods";
  

   


 return( ifail );
}

/******************************************************************************
 * Filename         :   LBT_user_services.c
 * ENVIRONMENT      :    C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date              Name              Description of Change
 * Apr 2015       Soumalya Sinha        Created.

*****************************************************************************/
#include <LBT_includes.h>
#include <LBT_user_services.h>

extern DLLAPI int Lbt9_consolidated_history( void *retValue );

extern DLLAPI int Lbt9_set_PDX_history( void *retValue );

// Register custom LBT user services.
// This is called by LBT_register_user_services().
int LBT_user_services(int *decision, va_list args)
{
   int   ifail         = ITK_ok;
   char* function_name = "LBT_user_services";
   int   argCnt        = 0;
   int*  inputArgTypes;
   
   
   *decision = ALL_CUSTOMIZATIONS;

   

   argCnt = 1;
   inputArgTypes = (int *)MEM_alloc( argCnt*sizeof(int));
   inputArgTypes[0] = USERARG_TAG_TYPE;
   ifail = USERSERVICE_register_method ("Lbt9_consolidated_history",
                                       (USER_function_t)Lbt9_consolidated_history,
                                       argCnt, inputArgTypes, USERARG_STRING_TYPE);
   LBT_FREE(inputArgTypes)

   argCnt = 1;
   inputArgTypes = (int *)MEM_alloc( argCnt*sizeof(int));
   inputArgTypes[0] = USERARG_TAG_TYPE + USERARG_ARRAY_TYPE;
   ifail = USERSERVICE_register_method ("Lbt9_set_PDX_history",
                                       (USER_function_t)Lbt9_set_PDX_history,
                                       argCnt, inputArgTypes, USERARG_INT_TYPE);
	LBT_FREE(inputArgTypes)
 
  
     return( ifail );
}


extern int Lbt9_consolidated_history( void *retValue )
{
   int      ifail                             = ITK_ok;
   int      GeneralHistoryCnt                 = 0;
   int      GeneralHistoryCnter               = 0;
   int      ITEM_GeneralHistoryCnt            = 0;
   int      StructureHistoryCnt               = 0;
   int      StructureHistoryCnter             = 0;
   int      PropCnt                           = 0;
   int      pref_counter                      = 0;
   int      attachment_history_cnt            = 0;
   int      attachment_history_cnter          = 0;
   int      has_attribute                     = 0;
   int      consolidated_history_cnt          = 0;
   int      consolidated_history_cnter        = 0;
   int      consolidated_history_next_cnter   = 0;
   int      answer                            = 0;
   int      has_attachment                    = 0;
   int      has_eventtype                     = 0;
   int      has_Prop                          = 0;
     

   //char    type_name[255+1]           = "";

   char*    type_name                 = NULL;
   char*    Mod_Date_str              = NULL;
   char*    Gen_Mod_str               = NULL;
   char*    Gen_mod_user              = NULL;
   char*    Gen_mod_person            = NULL;
   char*    Struct_Mod_str            = NULL;
   char*    Struct_mod_user           = NULL;
   char*    Struct_mod_person         = NULL;
   char*    Mod_user                  = NULL;
   char*    Mod_person                = NULL;
   char*    Prop_disp_name            = NULL;
   char*    Prop_new_disp_val         = NULL;
   char*    Prop_old_disp_val         = NULL;
   char*    Prop_EventType            = NULL;
   char*    Prop_BOMLine_Name         = NULL;
   char*    relation_type_name        = NULL;
   char*    attachment_string         = NULL;
   
	   
   char*    htmlfilecontain           = NULL;
   char*    htmlheadercontain         = NULL;
   char*    abs_path                  = NULL;
   char*    itemObjString             = NULL;
   char*    actiontype                = NULL;
   
   char**   attachment_history        = NULL;
   char**   Propnames                 = NULL;
   char**   Prop_disp_val             = NULL;
  

   tag_t    itemRevTag                = NULLTAG;
   tag_t    Gen_mod_userTag           = NULLTAG;
   tag_t    Struct_mod_userTag        = NULLTAG;
   tag_t    Mod_userTag               = NULLTAG;
   tag_t    TempTag                   = NULLTAG;
   tag_t    ItemTag                   = NULLTAG;
   tag_t*   GeneralHistoryListTags    = NULL;
   tag_t*   ITEM_GeneralHistoryListTags =NULL;
   tag_t*   StructureHistoryListTags  = NULL;
   tag_t*   attachment_historyTags    = NULL;
   tag_t*   consolidated_historyTags  = NULL;

   date_t   Gen_Mod_date              = NULLDATE;
   date_t   Struct_Mod_date           = NULLDATE;

   date_t   History_date              = NULLDATE;
   date_t   Next_History_date         = NULLDATE;
   date_t   Mod_date                  = NULLDATE;

 


   // Get the parameters from the IMAN_save
    CLEANUP(USERARG_get_tag_argument (&itemRevTag))

    //Get Object Type
	 CLEANUP(AOM_ask_value_string(itemRevTag, object_typePROP,&type_name))
	 //CLEANUP(ITEM_ask_rev_type(itemRevTag, type_name))

	//Get attribute list from the preference as per the object type
	if(strcmp(type_name,EMR_CommrclPartRevisionTYPE) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_Commercial_Rev_history_attr_listPREF,&PropCnt, &Propnames))
	   CLEANUP(ITEM_ask_item_of_rev	(itemRevTag,&ItemTag))

	   CLEANUP( AOM_ask_value_tags(ItemTag,GeneralAuditLogProp, &ITEM_GeneralHistoryCnt, &ITEM_GeneralHistoryListTags))
       if(ITEM_GeneralHistoryCnt>0) 
       CLEANUP(LBT_add_tags_to_array(&consolidated_history_cnt,&consolidated_historyTags,ITEM_GeneralHistoryCnt,ITEM_GeneralHistoryListTags))

    }

	if(strcmp(type_name,EMR_ManufacturingPartType) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_Manufacturing_Rev_history_attr_listPREF,&PropCnt, &Propnames))
    }
	
	if(strcmp(type_name,LBT9_BusDocRevisionTYPE ) ==  0|| (strcmp(type_name,LBT9_SpecDocRevisionTYPE)  ==  0))
	{
       CLEANUP (PREF_ask_char_values(LBT_Document_Rev_history_attr_listPREF,&PropCnt, &Propnames))

	   CLEANUP(ITEM_ask_item_of_rev	(itemRevTag,&ItemTag))

	   CLEANUP( AOM_ask_value_tags(ItemTag,GeneralAuditLogProp, &ITEM_GeneralHistoryCnt, &ITEM_GeneralHistoryListTags))
       if(ITEM_GeneralHistoryCnt>0) 
       CLEANUP(LBT_add_tags_to_array(&consolidated_history_cnt,&consolidated_historyTags,ITEM_GeneralHistoryCnt,ITEM_GeneralHistoryListTags))

   	}
   
    if(strcmp(type_name,LBT9_DCNRevisionTYPE ) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_DCN_Rev_history_attr_listPREF,&PropCnt, &Propnames))
   	}

    if(strcmp(type_name,LBT9_ECNRevisionTYPE) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_ECN_Rev_history_attr_listPREF,&PropCnt, &Propnames))
    }
	if(strcmp(type_name,LBT9_MCORevisionTYPE ) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_MCO_Rev_history_attr_listPREF,&PropCnt, &Propnames))
   	}

    if(strcmp(type_name,LBT9_ChgRequestRevisionTYPE) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_CR_Rev_history_attr_listPREF,&PropCnt, &Propnames))
    }
	if(strcmp(type_name,LBT9_DeviationRevisionTYPE ) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_Deviation_Rev_history_attr_listPREF,&PropCnt, &Propnames))
   	}

    if(strcmp(type_name,LBT9_StopShipRevisionTYPE) ==  0)
	{
       CLEANUP (PREF_ask_char_values(LBT_StopShip_Rev_history_attr_listPREF,&PropCnt, &Propnames))
    }


     if(PropCnt==0)
	 {
	   LBT_FREE(type_name)
	   goto CLEANUP;
	 }
	 //get general History information(Itemrev Modification)

  CLEANUP( AOM_ask_value_tags(itemRevTag,GeneralAuditLogProp, &GeneralHistoryCnt, &GeneralHistoryListTags))
  if(GeneralHistoryCnt>0) 
  CLEANUP(LBT_add_tags_to_array(&consolidated_history_cnt,&consolidated_historyTags,GeneralHistoryCnt,GeneralHistoryListTags))
	  
  CLEANUP( AOM_ask_value_tags(itemRevTag,StructureLogProp, &StructureHistoryCnt, &StructureHistoryListTags))
  if(StructureHistoryCnt>0)  	  
  CLEANUP(LBT_add_tags_to_array(&consolidated_history_cnt,&consolidated_historyTags,StructureHistoryCnt,StructureHistoryListTags)) 

  has_attribute = LBT_check_property_exists(itemRevTag , lbt9_Attachment_FormPROP);
  if(has_attribute == 0)
  {
     CLEANUP(AOM_ask_value_tags(itemRevTag,lbt9_Attachment_FormPROP,&attachment_history_cnt,&attachment_historyTags))
     if(attachment_history_cnt>0)
     CLEANUP(LBT_add_tags_to_array(&consolidated_history_cnt,&consolidated_historyTags,attachment_history_cnt,attachment_historyTags))
  }

    for (consolidated_history_cnter = 0; consolidated_history_cnter < consolidated_history_cnt; ++consolidated_history_cnter)
    {
        for (consolidated_history_next_cnter = consolidated_history_cnter + 1; consolidated_history_next_cnter < consolidated_history_cnt; ++consolidated_history_next_cnter)
        {    
			 has_attribute = 0;
             has_attribute = LBT_check_property_exists(consolidated_historyTags[consolidated_history_cnter] , fnd0LoggedDateProp);
             if(has_attribute == 0)
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_cnter], fnd0LoggedDateProp, &History_date))
			 else
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_cnter], lbt9_DatePROP, &History_date))


			 has_attribute = 0;
             has_attribute = LBT_check_property_exists(consolidated_historyTags[consolidated_history_next_cnter] , fnd0LoggedDateProp);
             if(has_attribute == 0)
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_next_cnter], fnd0LoggedDateProp, &Next_History_date))
			 else
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_next_cnter], lbt9_DatePROP, & Next_History_date))

			 answer = 0;
			 CLEANUP(POM_compare_dates(History_date,Next_History_date,&answer))
			if (answer == 1)
            {
				TempTag = NULLTAG;
				TempTag =  consolidated_historyTags[consolidated_history_cnter];
                consolidated_historyTags[consolidated_history_cnter] = consolidated_historyTags[consolidated_history_next_cnter];
                consolidated_historyTags[consolidated_history_next_cnter] = TempTag;
            }
        }
    }


	consolidated_history_cnter = 0;
	

    for(consolidated_history_cnter = consolidated_history_cnt - 1;consolidated_history_cnter >= 0;consolidated_history_cnter--) 
	{
		 has_eventtype = 0;
         has_eventtype = LBT_check_property_exists(consolidated_historyTags[consolidated_history_cnter] , fnd0EventTypeNameProp);
         if(has_eventtype == 0)
		 CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],fnd0EventTypeNameProp,&Prop_EventType))

		 has_attachment=0;
		 has_attachment = LBT_check_property_exists(consolidated_historyTags[consolidated_history_cnter] , lbt9_AttachmentPROP);

		if((has_eventtype == 0)&&(tc_strlen(Prop_EventType)> 0))
		{
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_cnter], fnd0LoggedDateProp, &Mod_date))
             CLEANUP(DATE_date_to_string(Mod_date, DATE_FORMAT_STR_FOOTER, &Mod_Date_str))
			
	
	         //Get the structure log modified user
	         CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],fnd0UserIdProp,&Mod_user))

		     CLEANUP(SA_find_user2(Mod_user,&Mod_userTag))
		     CLEANUP(SA_ask_user_person_name2(Mod_userTag,&Mod_person))
		     //Form the Header string for the HTML
		     CLEANUP(LBT_strcat(&htmlfilecontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
		     CLEANUP(LBT_strcat(&htmlfilecontain,"Modified By ")) 
	         CLEANUP(LBT_strcat(&htmlfilecontain,Mod_user))
             CLEANUP(LBT_strcat(&htmlfilecontain," On "))
             CLEANUP(LBT_strcat(&htmlfilecontain,Mod_Date_str))
	         CLEANUP(LBT_strcat(&htmlfilecontain, "</p></font>")) 

			 LBT_FREE(Mod_person)
			 LBT_FREE(Mod_Date_str)

			 CLEANUP(LBT_strcat(&htmlfilecontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
			 
		     if(tc_strcmp(Prop_EventType ,"__Component_Add") == 0)
		     {
			   CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],fnd0SecondaryObjDispNameProp,&Prop_BOMLine_Name))
			  
               CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
               CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain,"(BOMLine Added): "))
	           CLEANUP(LBT_strcat(&htmlfilecontain,"</b>"))
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</font>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
			   CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
			   CLEANUP(LBT_strcat(&htmlfilecontain,Prop_BOMLine_Name))
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>")) 

			   LBT_FREE(Prop_BOMLine_Name)
		     }
		     else if(tc_strcmp(Prop_EventType ,"__Component_Remove") == 0)
		     { 
			   CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],fnd0SecondaryObjDispNameProp,&Prop_BOMLine_Name))

               CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
               CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain,"(BOMLine Deleted): "))
	           CLEANUP(LBT_strcat(&htmlfilecontain,"</b>"))
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</font>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
			   CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
			   CLEANUP(LBT_strcat(&htmlfilecontain,Prop_BOMLine_Name))
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
			   CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>")) 
			    LBT_FREE(Prop_BOMLine_Name)
             }
			 else if(tc_strcmp(Prop_EventType ,"__Modify") == 0)
			 {
				 for(pref_counter=0;pref_counter<PropCnt;pref_counter = pref_counter + 2)
		         {
		     
				   has_Prop = 0;
                   has_Prop = LBT_check_property_exists(consolidated_historyTags[consolidated_history_cnter] , Propnames[pref_counter]);
                   if(has_Prop == 0)
				   {
	                  CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],Propnames[pref_counter],&Prop_new_disp_val)) 
				   
				      CLEANUP(AOM_UIF_ask_name(consolidated_historyTags[consolidated_history_cnter],Propnames[pref_counter],&Prop_disp_name))

				      CLEANUP(AOM_UIF_ask_value(consolidated_historyTags[consolidated_history_cnter],Propnames[pref_counter + 1],&Prop_old_disp_val)) 
				
				   if((strlen(Prop_new_disp_val)!=0)||(strlen(Prop_old_disp_val)!=0))
				   {
					 CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
                     CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
                     CLEANUP(LBT_strcat(&htmlfilecontain,Prop_disp_name))
	                 CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>"))
	                 CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Black\">"))
	                 CLEANUP(LBT_strcat(&htmlfilecontain,": has changed from "))
				     
				      if((strlen(Prop_new_disp_val)==0)&&(strlen(Prop_old_disp_val)!=0))
				      {
					    CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,Prop_old_disp_val))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b> to")) 
						CLEANUP(LBT_strcat(&htmlfilecontain,"</font>"))
					    CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,"(Empty)"))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 

					  }
				      else if((strlen(Prop_new_disp_val)!=0)&&(strlen(Prop_old_disp_val)==0))
					  {					
					    CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,"(Empty)"))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b> to")) 
						CLEANUP(LBT_strcat(&htmlfilecontain,"</font>"))
					    CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,Prop_new_disp_val))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
					  }
					  else if((strlen(Prop_new_disp_val)!=0)&&(strlen(Prop_old_disp_val)!=0))
					  {
						CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					    CLEANUP(LBT_strcat(&htmlfilecontain,Prop_old_disp_val))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b> to")) 

					    CLEANUP(LBT_strcat(&htmlfilecontain,"</font>"))
					    CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
				        CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
					    CLEANUP(LBT_strcat(&htmlfilecontain,Prop_new_disp_val))
					    CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
					  }
				  }
				    LBT_FREE(Prop_disp_name)
					LBT_FREE(Prop_old_disp_val)
				    LBT_FREE(Prop_new_disp_val)
				}
		      }//forloop ends here
              CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>"))
          }//Modify block ends here
		}

		else if(has_attachment == 0)
		{
			 CLEANUP(AOM_ask_value_date(consolidated_historyTags[consolidated_history_cnter], lbt9_DatePROP, &Mod_date))
            // CLEANUP(DATE_date_to_string(Mod_date, DATE_FORMAT_STR_FOOTER, &Mod_Date_str))
	             CLEANUP(ITK_date_to_string(Mod_date, &Mod_Date_str))
	         //Get the log modified user
	         CLEANUP(AOM_ask_value_string(consolidated_historyTags[consolidated_history_cnter],lbt9_ActorPROP,&Mod_person))

			 CLEANUP(AOM_ask_value_string(consolidated_historyTags[consolidated_history_cnter],lbt9_RelationPROP,&relation_type_name))
			 CLEANUP(AOM_ask_value_string(consolidated_historyTags[consolidated_history_cnter],lbt9_ActionPROP,&actiontype))
			 CLEANUP(AOM_ask_value_string(consolidated_historyTags[consolidated_history_cnter],lbt9_AttachmentPROP,&attachment_string))
			 

		     //Form the Header string for the HTML
		     CLEANUP(LBT_strcat(&htmlfilecontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
		     CLEANUP(LBT_strcat(&htmlfilecontain,"Modified By ")) 
	         CLEANUP(LBT_strcat(&htmlfilecontain,Mod_person))
             CLEANUP(LBT_strcat(&htmlfilecontain," On "))
             CLEANUP(LBT_strcat(&htmlfilecontain,Mod_Date_str))
	         CLEANUP(LBT_strcat(&htmlfilecontain, "</p></font>")) 

			 CLEANUP(LBT_strcat(&htmlfilecontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
			 CLEANUP(LBT_strcat(&htmlfilecontain, "</font>")) 
			 CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\"> <b>")) 
			 CLEANUP(LBT_strcat(&htmlfilecontain,relation_type_name))
			 CLEANUP(LBT_strcat(&htmlfilecontain,"</b>:")) 
	
			 if(tc_strcmp(actiontype ,"Added") == 0)
			 CLEANUP(LBT_strcat(&htmlfilecontain," added "))
			 else if(tc_strcmp(actiontype ,"Deleted") == 0)
			 CLEANUP(LBT_strcat(&htmlfilecontain," deleted "))

			 CLEANUP(LBT_strcat(&htmlfilecontain, "</font>")) 

			 CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
			 CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
			 CLEANUP(LBT_strcat(&htmlfilecontain,attachment_string))
			 CLEANUP(LBT_strcat(&htmlfilecontain,"</b>")) 
			 CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>")) 
			 CLEANUP(LBT_strcat(&htmlfilecontain, "</font>")) 
            


			   LBT_FREE(Mod_Date_str)
			   LBT_FREE(relation_type_name)
			   LBT_FREE(Mod_person)
			   LBT_FREE(actiontype)
			   LBT_FREE(attachment_string)
		}
		LBT_FREE(Prop_EventType)
	}





/*
	  
 if(GeneralHistoryCnt>0)   
 {		
	   
    for(GeneralHistoryCnter = GeneralHistoryCnt - 1;GeneralHistoryCnter >= 0;GeneralHistoryCnter--) 
	{
	    //Get General History Modification date
		CLEANUP(AOM_ask_value_date(GeneralHistoryListTags[GeneralHistoryCnter], fnd0LoggedDateProp, &Gen_Mod_date))
      
        CLEANUP(DATE_date_to_string(Gen_Mod_date, DATE_FORMAT_STR_FOOTER, &Gen_Mod_str))
	
	    //Get the General history Modified user
     	CLEANUP(AOM_UIF_ask_value(GeneralHistoryListTags[GeneralHistoryCnter],fnd0UserIdProp,&Gen_mod_user))
		CLEANUP(SA_find_user2(Gen_mod_user,&Gen_mod_userTag))
		CLEANUP(SA_ask_user_person_name2(Gen_mod_userTag,&Gen_mod_person))
		
		//Form the Header string for the HTML
		CLEANUP(LBT_strcat(&htmlfilecontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
		CLEANUP(LBT_strcat(&htmlfilecontain,"Modified By ")) 
	    CLEANUP(LBT_strcat(&htmlfilecontain,Gen_mod_person))
        CLEANUP(LBT_strcat(&htmlfilecontain," On "))
        CLEANUP(LBT_strcat(&htmlfilecontain,Gen_Mod_str))
		CLEANUP(LBT_strcat(&htmlfilecontain, "</font></p>")) 

		 CLEANUP(LBT_strcat(&htmlfilecontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\"></font>")) 
	    //Read General history information and form html string
		for(pref_counter=0;pref_counter<PropCnt;pref_counter = pref_counter + 2)
		 {
		     
	          CLEANUP(AOM_UIF_ask_value(GeneralHistoryListTags[GeneralHistoryCnter],Propnames[pref_counter],&Prop_new_disp_val)) 

				  if(strlen(Prop_new_disp_val)!=0)
				 {
					 CLEANUP(AOM_UIF_ask_name(GeneralHistoryListTags[GeneralHistoryCnter],Propnames[pref_counter],&Prop_disp_name))
					 CLEANUP(AOM_UIF_ask_value(GeneralHistoryListTags[GeneralHistoryCnter],Propnames[pref_counter + 1],&Prop_old_disp_val)) 

					
                     CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
                     CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
                     CLEANUP(LBT_strcat(&htmlfilecontain,Prop_disp_name))
	                 CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>"))
	                 CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Black\">"))
	                 CLEANUP(LBT_strcat(&htmlfilecontain,": has changed from "))
				     
				     if(strlen(Prop_old_disp_val)!=0)
				     {
						 CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					     CLEANUP(LBT_strcat(&htmlfilecontain,Prop_old_disp_val))
					     CLEANUP(LBT_strcat(&htmlfilecontain,"</b> to")) 
						 				   
					 }
				     else
					 {					
					   CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
					   CLEANUP(LBT_strcat(&htmlfilecontain,"(Empty)"))
					   CLEANUP(LBT_strcat(&htmlfilecontain,"</b> to")) 
					 }
					 CLEANUP(LBT_strcat(&htmlfilecontain,"</font>"))
					 CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
				     CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
					 CLEANUP(LBT_strcat(&htmlfilecontain,Prop_new_disp_val))
					 CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
					 


					  LBT_FREE(Prop_disp_name)
					  LBT_FREE(Prop_old_disp_val)
				 }
               LBT_FREE(Prop_new_disp_val)
		 }
		 CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>"))

		   LBT_FREE(Gen_Mod_str)
		   LBT_FREE(Gen_mod_user)
		   LBT_FREE(Gen_mod_person)
	}

 }
 //Get Structure addition and deletion information from fnd0structure Log
 CLEANUP( AOM_ask_value_tags(itemRevTag,StructureLogProp, &StructureHistoryCnt, &StructureHistoryListTags))

 if(StructureHistoryCnt>0)   
 {
	    
    for(StructureHistoryCnter = StructureHistoryCnt - 1;StructureHistoryCnter >= 0;StructureHistoryCnter--)
	{
		CLEANUP(AOM_ask_value_date(StructureHistoryListTags[StructureHistoryCnter], fnd0LoggedDateProp, &Struct_Mod_date))
        CLEANUP(DATE_date_to_string(Struct_Mod_date, DATE_FORMAT_STR_FOOTER, &Struct_Mod_str))
	
	    //Get the structure log modified user
	    CLEANUP(AOM_UIF_ask_value(StructureHistoryListTags[StructureHistoryCnter],fnd0UserIdProp,&Struct_mod_user))

		CLEANUP(SA_find_user2(Struct_mod_user,&Struct_mod_userTag))
		CLEANUP(SA_ask_user_person_name2(Struct_mod_userTag,&Struct_mod_person))
		//Form the Header string for the HTML
		CLEANUP(LBT_strcat(&htmlfilecontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
		CLEANUP(LBT_strcat(&htmlfilecontain,"Modified By ")) 
	    CLEANUP(LBT_strcat(&htmlfilecontain,Struct_mod_person))
        CLEANUP(LBT_strcat(&htmlfilecontain," On "))
        CLEANUP(LBT_strcat(&htmlfilecontain,Struct_Mod_str))
	    CLEANUP(LBT_strcat(&htmlfilecontain, "</p></font>")) 

		//Read structure history information and form html string
		 CLEANUP(AOM_UIF_ask_value(StructureHistoryListTags[StructureHistoryCnter],fnd0EventTypeNameProp,&Prop_EventType))
		 CLEANUP(AOM_UIF_ask_value(StructureHistoryListTags[StructureHistoryCnter],fnd0SecondaryObjDispNameProp,&Prop_BOMLine_Name))
		 if(tc_strcmp(Prop_EventType ,"__Component_Add") == 0)
		 {
			  CLEANUP(LBT_strcat(&htmlfilecontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
              CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
              CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain,"(BOMLine Added): "))
	          CLEANUP(LBT_strcat(&htmlfilecontain,"</b>"))
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</font>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
			  CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
			  CLEANUP(LBT_strcat(&htmlfilecontain,Prop_BOMLine_Name))
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>")) 
		 }
		 else if(tc_strcmp(Prop_EventType ,"__Component_Remove") == 0)
		 {
			  CLEANUP(LBT_strcat(&htmlfilecontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
              CLEANUP(LBT_strcat(&htmlfilecontain,"<LI><font size=\"2\" color=\"black\">")) 
              CLEANUP(LBT_strcat(&htmlfilecontain,"<b>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain,"(BOMLine Deleted): "))
	          CLEANUP(LBT_strcat(&htmlfilecontain,"</b>"))
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</font>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain," <font size=\"2\" color=\"Red\">"))  
			  CLEANUP(LBT_strcat(&htmlfilecontain," <b>"))
			  CLEANUP(LBT_strcat(&htmlfilecontain,Prop_BOMLine_Name))
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</b></font>")) 
			  CLEANUP(LBT_strcat(&htmlfilecontain,"</UL>")) 

		 }

		 LBT_FREE(Prop_EventType)
         LBT_FREE(Prop_BOMLine_Name)

		 LBT_FREE(Struct_Mod_str)
		 LBT_FREE(Struct_mod_user)
		 LBT_FREE(Struct_mod_person)
	}


 }


*/
  has_attribute = 0;
  has_attribute = LBT_check_property_exists(itemRevTag , lbt9_Attachment_FormPROP);
  if(has_attribute != 0)
  {
	 has_attribute = 0;
	 has_attribute = LBT_check_property_exists(itemRevTag , lbt9_Attachment_HistoryPROP);
          
	 if(has_attribute == 0)
	 {
	    //Read attachment History Information from  attachement history property,this property value is filled by pre post action on GRM create and delete
	    CLEANUP(AOM_ask_value_strings(itemRevTag,lbt9_Attachment_HistoryPROP,&attachment_history_cnt,&attachment_history))
	  
	   if(attachment_history_cnt>0)
	   {
		   for(attachment_history_cnter = attachment_history_cnt - 1;attachment_history_cnter >= 0;attachment_history_cnter--)
		   {
			 CLEANUP(LBT_strcat(&htmlfilecontain,attachment_history[attachment_history_cnter]))
		   }
	   }
	   LBT_FREE_STRINGS(attachment_history)
     }
  }

    if(htmlfilecontain)
     { 

	   CLEANUP(AOM_ask_value_string(itemRevTag, object_stringPROP, &itemObjString))
	   
	   //Printing Html Oprning tags
	   LBT_strcat(&htmlheadercontain,"<HTML>");
	  
	   LBT_strcat(&htmlheadercontain,"<p style=\"background-color:green;\"> <font color=\"white\">");
	   LBT_strcat(&htmlheadercontain," <b>History for # ");
	   LBT_strcat(&htmlheadercontain,itemObjString);
	   LBT_strcat(&htmlheadercontain,"</b> </p></font>");
	   LBT_strcat(&htmlheadercontain,"</HTML>");
	   LBT_strcat(&htmlheadercontain,htmlfilecontain);
    
	    // Return the History value back to the client
	   *((char**)retValue) = htmlheadercontain;	 
	}
	else
	{
		LBT_strcat(&htmlheadercontain,"No History to Display");
		// Return the History value back to the client
	   *((char**)retValue) = htmlheadercontain;	 
	}
  CLEANUP:
   LBT_FREE(htmlfilecontain)
   LBT_FREE(Propnames)
   LBT_FREE(GeneralHistoryListTags)
   LBT_FREE(ITEM_GeneralHistoryListTags)
   LBT_FREE(StructureHistoryListTags)
   LBT_FREE(attachment_historyTags)
   LBT_FREE(itemObjString)
   LBT_FREE(Prop_new_disp_val)
   LBT_FREE(Prop_disp_name)
   LBT_FREE(Prop_old_disp_val)
    
   LBT_FREE(Gen_Mod_str)
   LBT_FREE(Gen_mod_user)
   LBT_FREE(Prop_EventType)
   LBT_FREE(Prop_BOMLine_Name)



   return ifail;
}


//User Service for pdx history..
extern int Lbt9_set_PDX_history( void *retValue )
{
	 int      ifail                = ITK_ok;
	 int      itemRevCount         = 0;
	 int      itemRevCounter       = 0;
	 int      has_attribute        = 0;
	 int      num_of_history       = 0;

	 char*   current_user_name     = NULL;
	 char*   current_person_name   = NULL;
	 char*   current_time          = NULL;
	 char*   htmlcontain           = NULL;

	 tag_t    current_user_tag     = NULLTAG;

	 tag_t*   itemRevTags          = NULL;
	  
	 
	 CLEANUP(USERARG_get_tag_array_argument (&itemRevCount,&itemRevTags))
 
	 if(itemRevCount>0)
	 {
	     //Get current user tag
	     CLEANUP(POM_get_user(&current_user_name,&current_user_tag))
	     //Get current person name	
	     CLEANUP(SA_ask_user_person_name2(current_user_tag,&current_person_name))
         //Get current time
	     LBT9_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &current_time);

    	 CLEANUP(LBT_strcat(&htmlcontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
	     CLEANUP(LBT_strcat(&htmlcontain,"Modified By ")) 
	     CLEANUP(LBT_strcat(&htmlcontain,current_person_name))
         CLEANUP(LBT_strcat(&htmlcontain," On "))
         CLEANUP(LBT_strcat(&htmlcontain,current_time))
		 CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 
	     CLEANUP(LBT_strcat(&htmlcontain, "</p>")) 

	     CLEANUP(LBT_strcat(&htmlcontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
		 CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 
         CLEANUP(LBT_strcat(&htmlcontain,"<LI><font size=\"2\" color=\"black\"> <b>")) 
         CLEANUP(LBT_strcat(&htmlcontain,"SEND TO PDX"))
	     CLEANUP(LBT_strcat(&htmlcontain,"</b>"))
		 CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 
		 CLEANUP(LBT_strcat(&htmlcontain,"</UL>")) 
		 
	    for(itemRevCounter =0; itemRevCounter < itemRevCount ;itemRevCounter ++)
	    {
	       has_attribute = LBT_check_property_exists(itemRevTags[itemRevCounter] , lbt9_PDX_HistoryPROP);
          
		   if(has_attribute == 0)
	       {
	           CLEANUP(AOM_ask_num_elements(itemRevTags[itemRevCounter] ,lbt9_PDX_HistoryPROP,&num_of_history))
		 
	           CLEANUP(AOM_refresh(itemRevTags[itemRevCounter],TRUE))
               CLEANUP(AOM_set_value_string_at(itemRevTags[itemRevCounter] , lbt9_PDX_HistoryPROP, num_of_history, htmlcontain))
               CLEANUP(AOM_save(itemRevTags[itemRevCounter] ))
               CLEANUP(AOM_refresh(itemRevTags[itemRevCounter],FALSE))
		   }
	     }
       }

     CLEANUP:
      
	  LBT_FREE(current_user_name)
	  LBT_FREE(current_time)
	  LBT_FREE(htmlcontain)

      return ifail;
}
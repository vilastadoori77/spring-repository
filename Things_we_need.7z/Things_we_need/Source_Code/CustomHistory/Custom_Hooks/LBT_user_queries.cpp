/******************************************************************************
 * Filename		    :   LBT_user_services.cpp
 * Description      :	This file is for writing all the User Queries
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * July 23, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/
#include <LBT_includes.h>
#include<LBT_user_services.h>

int LBT9_search_cnr_based_on_owning_user(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_cnr_based_on_owning_user";
	tag_t   query_tag            = NULLTAG;
	  
	  	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Change Notice Based On Owning User...",&Qry_Name))
  
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  


CLEANUP:
		
	return ifail;
}



int LBT9_search_buss_doc_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_buss_doc_adv";
	tag_t   query_tag            = NULLTAG;
	  
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Business Document - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_cr_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_cr_adv";
	tag_t   query_tag            = NULLTAG;
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search CR - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}

int LBT9_search_cnr_based_on_ca(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_cnr_based_on_ca";
	tag_t   query_tag            = NULLTAG;
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Change Notice Based On CA...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_crr_based_on_ca(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_crr_based_on_ca";
	tag_t   query_tag            = NULLTAG;
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Change Request Based On CA...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_crr_based_on_owning_user(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_crr_based_on_owning_user";
	tag_t   query_tag            = NULLTAG;
		 		 
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Change Request Based On Owning User...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_comm_part_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_comm_part_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Commercial Part - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_dcn_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_dcn_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search DCN - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_dev_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_dev_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Deviation - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_ecn_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_ecn_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search ECN - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_mco_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_mco_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search MCO - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_mfg_part_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_mfg_part_adv";
	tag_t   query_tag            = NULLTAG;
		 		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Manufacturer Part - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_manufacturer(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_manufacturer";
	tag_t   query_tag            = NULLTAG;
		 
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Manufacturer...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}



int LBT9_search_prod_spec_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_prod_spec_adv";
	tag_t   query_tag            = NULLTAG;
	
		  
	  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search Product Specification - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}


int LBT9_search_stopship_adv(int entry_cnt, char ** entry_names,
											char ** inputs, int * num_rev,
											tag_t ** revs)
{
	int ifail                    = ITK_ok;
	char * Qry_Name              = NULL;
	char*  functionName          = "LBT9_search_stopship_adv";
	tag_t   query_tag            = NULLTAG;
	
		  
    query_tag = NULLTAG;
	CLEANUP (LBT_strdup("__Search StopShip - Advanced...",&Qry_Name))
 
    CLEANUP(QRY_find(TC_text (Qry_Name), &query_tag))
    LBT_FREE(Qry_Name)

   if(!query_tag)
   {
	   
	  goto CLEANUP;

   }
   else
   {
     CLEANUP(QRY_execute ( query_tag, entry_cnt, entry_names, inputs, num_rev, revs))

   }
  
CLEANUP:
		
	return ifail;
}

/******************************************************************************
 * Filename		    :   LBT_generic_methods.cpp
 * Description      :	This file is for writing all the Generic Method
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>
#include<LBT_extensions.h>

// Given an input string and a delimiter string,
// parse the input string and return an array of strings.
// NOTE: This does NOT use strtok, it uses strstr.
//       The match is done on the *entire* input string.
// Values for input arg trim_blanks...
//  - LBT_TRIM_BLANKS: leading and trailing blanks are trimmed from returned strings.
//  - LBT_NO_TRIM: blanks are not trimmed
extern int LBT_parse_string_with_string(char* targetString, const char* delimiterString,
	                               int* stringCnt, char*** stringArray)
{
    int     ifail = ITK_ok;
    char*   foundString = NULL;
    char*   parsedStr = NULL;
    unsigned int     delimiterLen = 0;

   // This is a recursive function. Do NOT initialize returned values.

   if ((targetString == NULL) || (delimiterString == NULL))
      goto CLEANUP;

   if (tc_strlen(targetString) == 0)
      goto CLEANUP;

   delimiterLen = tc_strlen(delimiterString);
   if (delimiterLen == 0)
      goto CLEANUP;

   foundString = tc_strstr(targetString, delimiterString);

   // If no delimiter found, add string tail to array. 
   if (foundString == NULL)
   {
      CLEANUP(LBT_copy_string_to_array(stringCnt, stringArray, targetString)) 
   }
   else
   {
      CLEANUP(LBT_strndup(targetString, &parsedStr, foundString-targetString))
      CLEANUP(LBT_add_string_pointer_to_array(stringCnt, stringArray, parsedStr)) 
      parsedStr = NULL;

      // Recurse if there's more string beyond the delimiter string.
      if (tc_strlen(foundString) > delimiterLen)
         CLEANUP(LBT_parse_string_with_string(foundString+delimiterLen, delimiterString, stringCnt, stringArray))
   }

CLEANUP:

    return (ifail);
}


// If input object is a type -or- subtype of the input typename then return TRUE.
// NOTE: If user does not have read access on the object, then it can't be loaded.
//       If object can't be loaded, then its type cannot be read and AOM_is_type_of() fails.
//       To prevent failure, this function detects an unreadable object and returns FALSE.
//       In the future we might want to use AM__set_application_bypass to force load, 
//       then unload a force-loaded object before exiting function.
extern int LBT_object_is_typeof(tag_t objTag, char* type_name, logical* isType)
{
    int      ifail = ITK_ok;
    char*    function_name = "LBT_object_is_typeof";
    char*    noLoadtype_names[3] = {MECfgLineTYPE, BOMLineTYPE, CfgAttachmentLineTYPE};
    tag_t*   loadTags = NULL;
    tag_t    typeTag = NULLTAG;
    int      loadCnt = 0;
    logical  isLoaded = false;

    *isType = FALSE;

    if ((objTag != NULLTAG)||(type_name != NULL))
	{   

        // If caller thinks object is a type of bomline or attachment line, then do NOT check if
       // object is loaded. POM_is_loaded() fails on those object types, so assume it's already loaded.
       CLEANUP(LBT_typename_is_typeof_list((const char*) type_name, 3, noLoadtype_names, &isLoaded))
       if (!isLoaded)
       {
          CLEANUP(POM_is_loaded(objTag, &isLoaded))
          if (!isLoaded)
          {
             // Load object if user has read access, else do NOT throw error.
             CLEANUP(POM_load_instances_possible(1, &objTag, &loadCnt, &loadTags))
             isLoaded = (logical)(loadCnt > 0);
           }	       
       }	       

      if (isLoaded)
      {
         CLEANUP(TCTYPE_find_type(type_name, NULL, &typeTag))
         CLEANUP(AOM_is_type_of(objTag, typeTag, isType))
      }
	}
CLEANUP:
    LBT_FREE(loadTags)

    return ifail;
}

// Given a typename and a list of typenames, if input typename
// is a type/subtype of a typename in the list then return TRUE.
extern int LBT_typename_is_typeof_list(const char* typeName, int compareTypeCnt, char** compareTypenames, logical* answer)
{
    int   ifail = ITK_ok;
    char*   function_name = "LBT_typename_is_typeof_list";
    tag_t type_tag = NULLTAG;
    tag_t compare_type_tag = NULLTAG;
    int   typeIdx = 0;

    *answer = FALSE;

    if (compareTypeCnt < 1)
       goto CLEANUP;

    if( (typeName == NULL)||(compareTypenames == NULL))
	{
     
	   CLEANUP(TCTYPE_find_type(typeName, NULL, &type_tag))

      for (typeIdx=0; typeIdx<compareTypeCnt; typeIdx++)
      {
          if (compareTypenames[typeIdx] != NULL)
          {
             CLEANUP(TCTYPE_find_type(compareTypenames[typeIdx], NULL, &compare_type_tag))

             CLEANUP(TCTYPE_is_type_of(type_tag, compare_type_tag, answer))
             if (*answer)
                goto CLEANUP;
          }
      }
	}

CLEANUP:
    return ifail;
}


// Given an input string and a string of delimiter chars (e.g., ","),
// parse the input string and return an array of strings.
// WARNING! This uses strtok, so only *one* char in delimiterChars needs to match.
//          Do not call this function within another strtok loop!
// Values for input arg trim_blanks...
//  - LBT_TRIM_BLANKS: leading and trailing blanks are trimmed from returned strings.
//  - LBT_NO_TRIM: blanks are not trimmed
extern int LBT_parse_delimited_string(const char* delimitedString, char* delimiterChars, logical trim_blanks,
	                              int* stringCnt, char*** stringArray)
{
    int     ifail = ITK_ok;
    char*   parseBuffer = NULL;
    char*   token = NULL;

    *stringArray = NULL;
    *stringCnt = 0;

    if (!delimitedString || (tc_strlen(delimitedString) < 1))
       goto CLEANUP;

    CLEANUP(LBT_strdup(delimitedString, &parseBuffer))
    if (trim_blanks == LBT_TRIM_BLANKS)
       LBT_trim_blanks(parseBuffer);

    token = tc_strtok(parseBuffer, delimiterChars);
    while (token)
    {
       CLEANUP(LBT_copy_string_to_array(stringCnt, stringArray, token))

       // Optionally trim blanks in *copied* string.
       if (trim_blanks)
          LBT_trim_blanks((*stringArray)[*stringCnt-1]);

       token = tc_strtok(NULL, delimiterChars);
    }

   

CLEANUP:
    LBT_FREE(parseBuffer)

    return (ifail);
}


// Get status type for an object. If multiple statuses, returns last one in list.
extern int LBT_ask_release_status(tag_t objectTag,char **status)
{
   int     status_count = 0;
   char*   function_name = "LBT_ask_release_status";
   int     statusIdx = 0;
   int     ifail = 0;
   //char    release_status_type[WSO_name_size_c+1]={'\0'};
   char*  release_status_name = NULL;
   tag_t*  status_list  = NULL;

   *status = NULL;

   if (objectTag != NULLTAG)
   {

      CLEANUP(WSOM_ask_release_status_list(objectTag,&status_count,&status_list))

      for(statusIdx=0;statusIdx<status_count;statusIdx++)
      {
		 CLEANUP(AOM_ask_value_string(status_list[statusIdx],object_stringPROP,&release_status_name))
        // CLEANUP(CR_ask_release_status_type(status_list[statusIdx] ,release_status_type))
         *status = (char*) MEM_realloc(*status,((int)tc_strlen(release_status_name)+1)* sizeof(char));
         tc_strcpy(status[statusIdx],release_status_name);
      }
   }
CLEANUP:
   LBT_FREE(status_list);
   return ifail;
}



// Get current time in the specified format.

void LBT9_current_get_time_stamp(char* format, char** timestamp)
{
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
}

// Add a string pointer to an array. This does NOT allocate memory for the added element string.
// This allocates/reallocates the input/output array.
// I/O argument stringCnt is incremented on exit.
// Handles out-of-memory error.
extern int LBT_add_string_pointer_to_array(int* stringCnt, char*** stringArray, char* addString)
{
   int   ifail = ITK_ok;
   char* function_name = "LBT_add_string_pointer_to_array";

    // Do not initialize stringArray. It can be extended (reallocated).

   // Allocate or reallocate the array.
   *stringArray = (char**) MEM_realloc(*stringArray, sizeof(char*) * (*stringCnt+1));

   // Add the string in the next element of the array.
   if (*stringArray != NULL)
   {
      (*stringArray)[*stringCnt] = addString;
      (*stringCnt)++;
   }
   
   return (ifail);
}

// Allocate a buffer and copy a string which can be freed using a Teamcenter MEM_ api.
// String does not need to be null-terminated. Input arg charCnt determines how many chars are copied.
// This function appends a NULL terminator if not present in the copied string.
// Handles out-of-memory error.
// The caller is responsible for freeing returned outputString with MEM_free(). 
extern int LBT_strndup(const char* inputString, char** outputString, int charCnt)
{
   int   ifail = ITK_ok;
   char* function_name = "LBT_strndup";

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   if (inputString[charCnt-1] != '\0')
      *outputString =(char*) MEM_alloc(sizeof(char)*(charCnt+1));
   else
      *outputString =(char*) MEM_alloc(sizeof(char)*charCnt);

   if (*outputString != NULL)
   {
      if (inputString[charCnt-1] != '\0')
      {
         tc_strncpy(*outputString, inputString, charCnt);
         (*outputString)[charCnt] = '\0';
      }
      else
      {
         tc_strcpy(*outputString, inputString);
      }
   }
   

   return (ifail);
}
 /*******************************************************************************
 * NAME: dump_itk_errors
 *
 * DESCRIPTION
 *  Function to dump the ITK errors. This function has been inheritted from
 *  Teamcenter sample code.
 *
 * ARGUMENTS
 *   Argument               In/Out     Description
 *
 * RETURNS
 *   0                    - Success
 *   1                    - Failure
 *
 * NOTES
 ******************************************************************************/
void dump_itk_errors( int stat, const char * prog_name, int lineNumber, const char * fileName )
{
    int          n_ifails=0;
    const int   *severities=NULL;
    const int   *ifails=NULL;
    const char **texts=NULL;
    char        *errstring=NULL;

    EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
    if ( n_ifails && texts != NULL )
    {
        if ( ifails[n_ifails-1] == stat )
        {
           TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, texts[n_ifails-1] );
        }
        else
        {
            EMH_ask_error_text (stat, &errstring );
            TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
            MEM_free( errstring );
        }
    }
    else
    {
        EMH_ask_error_text (stat, &errstring );
        TC_write_syslog( "%s: Error %d: %s\n", prog_name, stat, errstring );
        MEM_free( errstring );
    }
    TC_write_syslog( "%s: Error: Line %d in %s\n", prog_name, lineNumber, fileName );
}


// Add a string to a string.
// This allocates/reallocates the input/output string and concatenates input addString to it.
extern int LBT_strcat(char** string, char* addString)
{
   int   ifail = ITK_ok;
    
	if ((*string) == NULL)
	{
		// Since the string is empty use mem alloc
		(*string) = (char *)MEM_alloc((int)(tc_strlen(addString)+1)*sizeof(char) );
		 tc_strcpy ((*string), addString);
		 tc_strcat ((*string), '\0');
	}
	else
	{
		// Reallocate the string
		(*string) = (char*) MEM_realloc((*string), sizeof(char) * ( ((int) (tc_strlen (*string))) + ((int) (tc_strlen (addString))) + 1 ));

		tc_strcat ((*string), addString);
		tc_strcat ((*string), '\0');
	}

   return (ifail);
}

// Allocate a buffer and copy a null-terminated string which can be freed using a Teamcenter MEM_ api.
// Handles out-of-memory error.
// The caller is responsible for freeing returned outputString with MEM_free(). 
//
// IMPORTANT: Use this function instead of tc_strdup().
// tc_strdup() is just a wrapper around C strdup() and the string it returns must deallocated using the C free() function.
// (This is not documented anywhere - learned by trial and error.)
//
extern int LBT_strdup(const char* inputString, char** outputString)
{
   int   ifail = ITK_ok;
   char* function_name = "LBT_strdup";

   *outputString = NULL;

   if (inputString == NULL)
      return ITK_ok;

   *outputString =(char*) MEM_alloc(sizeof(char)*(tc_strlen(inputString)+1));

   if (*outputString != NULL)
   {
      tc_strcpy(*outputString, inputString);
   }
   else
   {
	  TC_write_syslog("ERROR in %s: LBT Memory Allocation Failure.\n", function_name);
   }

   return (ifail);
}

/* Method: LBT_check_property_exists
 Below method checks the attributes on the argument object and when the attribute matches with the
 argument then
 Attribute found : Returns 0
 Attribute not found : Returns 1*/

extern int LBT_check_property_exists(tag_t tagObject,char *propertyName)
{
	char **propNames	= {NULL};

	int numberOfProps	= 0;
	int returnValue		= 1;
	int iCnt            = 0;
	int ifail           = 0;



	CLEANUP(AOM_ask_prop_names(tagObject,&numberOfProps,&propNames));

	for (iCnt = 0; iCnt < numberOfProps; iCnt ++)
	{
		if (tc_strcmp(propertyName,propNames[iCnt]) == 0 )
		{
			returnValue--;
			break;
		}
	}
	

	LBT_FREE_STRINGS(propNames)

	CLEANUP:
	return returnValue;
}


// Find a string in an array of strings.
// Returns index in array of found string. If not found, returns -1.
// NOTE: this will match NULL compareString.
extern int LBT_find_string_in_array(int stringCnt, char** stringArray, const char* compareString)
{
    char* function_name = "LBT_find_string_in_array";
    int   strIdx = 0;
    int   foundIdx = -1;

    if (stringCnt < 1)
       goto CLEANUP;

    // Special case: compareString and stringArray match if both NULL. 
    
    if ((stringCnt == 1) && (stringArray[0] == NULL))
    {
       if ((compareString == NULL) || (tc_strlen(compareString) == 0))
       {
          foundIdx = 0;
       }
       goto CLEANUP;
    }

    for (strIdx=0; strIdx<stringCnt; strIdx++)
    {
        // Attempt to match non-null strings.
        if (compareString != NULL)
	{
           if ((stringArray[strIdx] != NULL) && 
	       (tc_strlen(stringArray[strIdx]) == tc_strlen(compareString)) &&
       	       (tc_strcmp(stringArray[strIdx], compareString) == 0))
           {
              foundIdx = strIdx;
	           goto CLEANUP;
           }
	}
	// Attempt to match NULL strings.
	else if (stringArray[strIdx] == NULL) 
        {
            
              foundIdx = strIdx;
	          goto CLEANUP;
        }
    }

CLEANUP:
	
    return foundIdx;
}

// Find a string in an array of strings, ignoring case.
// Returns index in array of found string. If not found, returns -1.
// NOTE: this will match NULL compareString.
extern int LBT_find_string_in_array_ignore_case(int stringCnt, char** stringArray, const char* compareString)
{
    char* function_name = "LBT_find_string_in_array_ignore_case";
    int   strIdx = 0;
    int   foundIdx = -1;


    if (stringCnt < 1)
       goto CLEANUP;

    // Special case: compareString and stringArray match if both NULL. 

    if ((stringCnt == 1) && (stringArray[0] == NULL))
    {
       if ((compareString == NULL) || (tc_strlen(compareString) == 0))
       {
         
          foundIdx = 0;
       }
       goto CLEANUP;
    }

    for (strIdx=0; strIdx<stringCnt; strIdx++)
    {
        // Attempt to match non-null strings.
        if (compareString != NULL)
	{
           if ((stringArray[strIdx] != NULL) && 
	       (tc_strlen(stringArray[strIdx]) == tc_strlen(compareString)) &&
       	       (tc_strcasecmp(stringArray[strIdx], compareString) == 0))
           {
              foundIdx = strIdx;
	          goto CLEANUP;
           }
	}
	// Attempt to match NULL strings.
	else if (stringArray[strIdx] == NULL) 
        {
           
              foundIdx = strIdx;
	          goto CLEANUP;
        }
    }

CLEANUP:

    return foundIdx;
}

// Returns index in array of first tag found. If not found, returns -1.
extern int LBT_find_tag_in_array(int tagCnt, tag_t* tagArray, tag_t tag)
{
    int   i = 0;
    int foundIdx = -1;

    if (!tagArray || (tagCnt < 1))
       goto CLEANUP;

    for (i=0; i<tagCnt; i++)
    {
        if (tagArray[i] == tag)
        {
           foundIdx = i;
	   goto CLEANUP;
        }
    }

CLEANUP:
    return foundIdx;
}

// Given two arrays of tags, searches first array for each tag in second array.
// Returns index in first array of first tag found. If none found, returns -1.
extern int LBT_find_tag_in_array_by_list(int tagCnt1, tag_t* tagArray1, int tagCnt2, tag_t* tagArray2)
{
    int   tagIdx = 0;
    int   foundIdx = -1;

    if (!tagArray1 || (tagCnt1 < 1) || !tagArray2 || (tagCnt2 < 1) )
       goto CLEANUP;

    for (tagIdx=0; tagIdx<tagCnt2; tagIdx++)
    {
        foundIdx = LBT_find_tag_in_array(tagCnt1, tagArray1, tagArray2[tagIdx]);
        if (foundIdx >= 0)
           break;
    }

CLEANUP:
    return foundIdx;
}

// Find an integer in an array of integers.
// Returns index in array of found integer. If not found, returns -1.
extern int LBT_find_int_in_array(int intCnt, int* intArray, int compareInt)
{
    int   i = 0;
    int foundIdx = -1;

    if (!intArray || (intCnt < 1))
       goto CLEANUP;

    for (i=0; i<intCnt; i++)
    {
        if (intArray[i] == compareInt) 
        {
           foundIdx = i;
	   goto CLEANUP;
        }
    }

CLEANUP:
    return foundIdx;
}


// Find an double in an array of doubles.
// Returns index in array of found double. If not found, returns -1.
extern int LBT_find_double_in_array(int doubleCnt, double* doubleArray, double compareDouble)
{
    int   i = 0;
    int foundIdx = -1;
    double  LBT_EPSILON = 0.00000001; // Replace with standard utility for getting machine epsilon

    if (!doubleArray || (doubleCnt < 1))
       goto CLEANUP;

    for (i=0; i<doubleCnt; i++)
    {
        // TODO: Not confident about this double comparison!! Need generic utility.
        if (fabs(doubleArray[i] - compareDouble) < LBT_EPSILON)
        {
           foundIdx = i;
	   goto CLEANUP;
        }
    }

CLEANUP:
    return foundIdx;
}


// Add a copy of a string to an array.
// This allocates/reallocates the input/output array -and- allocates the added array element string.
// I/O argument stringCnt is incremented on exit.
// Handles out-of-memory error.
extern int LBT_copy_string_to_array(int* stringCnt, char*** stringArray, char* addString)
{
   int   ifail = ITK_ok;
   char* function_name = "LBT_copy_string_to_array";

    // Do not initialize stringArray. It can be extended (reallocated).

   // Allocate or reallocate the array.
   *stringArray = (char**)MEM_realloc(*stringArray, sizeof(char*) * (*stringCnt+1));

   // Duplicate the string in the next element of the array.
   if (*stringArray != NULL)
   {
      CLEANUP(LBT_strdup(addString, &((*stringArray)[*stringCnt])))
      (*stringCnt)++;
   }
 

CLEANUP:

   return (ifail);
}

// Remove leading and trailing blank characters from input string.
// WARNING! This modifies and returns the input string so make sure it is not static!!
extern char* LBT_trim_blanks(char* inputStr)
{  
  char* end = NULL;
  char* bufferPtr = NULL;
  char* nextPtr = NULL;

  if (inputStr == NULL)
     return inputStr;

  // Save pointer to string buffer.
  bufferPtr = inputStr;

  end=strrchr(inputStr, '\0'); // Find null terminator

  while (inputStr<end && isspace(*inputStr)) // Scan forward
    ++inputStr;

  while (end>inputStr && isspace(*(end-1))) // scan back from end
    --end; 

  *end='\0'; // terminate modified string

  // If string had leading blanks, then shift string left until pointer is back to original position.
  if (inputStr != bufferPtr)
  {
     nextPtr = inputStr;
     inputStr = bufferPtr;
     while (*nextPtr)   
           *bufferPtr++ = *nextPtr++;
     *bufferPtr++ = '\0';
  }

  return inputStr;
}


// This allocates/reallocates the array and adds the tag to the end of the array.
// I/O argument tagCnt is incremented on exit.
// Handles out-of-memory error.
extern int LBT_add_tag_to_array(int* tagCnt, tag_t** tagArray, tag_t addTag)
{
   int   ifail = ITK_ok;
   char* function_name = "LBT_add_tag_to_array";

   *tagArray =(tag_t*) MEM_realloc(*tagArray, sizeof(tag_t) * (*tagCnt+1));

   if (*tagArray != NULL)
   {
      (*tagArray)[*tagCnt] = addTag; 
      (*tagCnt)++;
   }
   else
   {
       goto CLEANUP;
   }

CLEANUP:   
   return (ifail);
}


// This allocates/reallocates the array and adds the tags to the end of the input/output array.
// I/O argument tagCnt is incremented on exit.
// Handles out-of-memory error.
extern int LBT_add_tags_to_array(int* tagCnt, tag_t** tagArray, int addCnt, tag_t* addTagArray)
{
    int ifail = ITK_ok;
    char* function_name = "LBT_add_tags_to_array";
    int addIdx = 0;

    if (addCnt > 0)
    {
       *tagArray =(tag_t *) MEM_realloc(*tagArray, sizeof(tag_t) * ((*tagCnt)+addCnt));

       if (*tagArray != NULL)
       {
          for (addIdx=0; addIdx<addCnt; addIdx++)
	  {
            (*tagArray)[*tagCnt] = addTagArray[addIdx];
	    (*tagCnt)++;
	  }
       }
       else
       {
                 goto CLEANUP;
       }      
   }

CLEANUP:   
   return (ifail);
}


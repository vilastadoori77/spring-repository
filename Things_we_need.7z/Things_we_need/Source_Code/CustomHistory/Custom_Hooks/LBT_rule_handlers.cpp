/******************************************************************************
 * Filename		    :   LBT_rule_handlers.c
 * Description      :	This file is for writing all the rule handlers function
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>

/******************************************************************************
 * Filename         :    LBT_register_callbacks.c
 * Description      :    Register all the custom exit programs in this file
 * Module           :    LBT.dll
 * ENVIRONMENT      :    C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date             Name              Description of Change
 * June 04, 2015    Soumalya Sinha     Initial Code

 *****************************************************************************/

/* LBT include */
#include <LBT_includes.h>
#include <ict/ict_userservice.h>
#include <LBT_register_callbacks.h>



extern DLLAPI int liblbt_register_callbacks()
{
   int iFail = ITK_ok;

   CUSTOM_register_exit ( "liblbt", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)LBT_register_user_services);
	
   CUSTOM_register_exit ( "liblbt", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)LBT_register_custom_handlers);

   CUSTOM_register_exit ( "liblbt", "USER_init_module", (CUSTOM_EXIT_ftn_t) LBT_custom_register_prop_method);
     
   CUSTOM_register_exit ( "liblbt", "USER_execute_saved_query", (CUSTOM_EXIT_ftn_t) LBT_register_user_queries);
   
   
   
   return ITK_ok;
}

/******************************************************************************
 * Function Name    :   LBT_register_user_queries
 * Description      :   Register server exit
 * INPUT PARAMS     :
 * RETURN VALUE     :   returnStatus = ITK success/failure status
 * ALGORITHM        :   Register custom queries
 *****************************************************************************/
extern int LBT_register_user_queries(int *decision, va_list args)
{
	int ifail                 = ITK_ok;
   	int num_args	          = 0;
	int * numFound	          = NULL;

	char ** entries_names     = NULL;
	char ** entries_values    = NULL;
	const char * name         = NULL;

	tag_t ** tFound = NULL;

	/* Getting Input from custom query */
	name = va_arg( args, const char *);	// the name of the query
	num_args = va_arg(args,int);		// the number of search criteria
	entries_names = va_arg(args,char**);	// the names of search criteria
	entries_values = va_arg(args,char**);	// the values of search criteria
	numFound = va_arg(args,int *);		// the number of results
	tFound = va_arg(args,tag_t **);	// the array of results


	if( (name != NULL) && (tc_strcmp(name, "Search Business Document - Advanced...") == 0))
	{
		ifail = LBT9_search_buss_doc_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

     if( (name != NULL) && (tc_strcmp(name, "Search CR - Advanced...") == 0))
	{
		ifail = LBT9_search_cr_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Change Notice Based On CA...") == 0))
	{
		ifail = LBT9_search_cnr_based_on_ca(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Change Notice Based On Owning User...") == 0))
	{
		ifail = LBT9_search_cnr_based_on_owning_user(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Change Request Based On CA...") == 0))
	{
		ifail = LBT9_search_crr_based_on_ca(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Change Request Based On Owning User...") == 0))
	{
		ifail = LBT9_search_crr_based_on_owning_user(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Commercial Part - Advanced...") == 0))
	{
		ifail = LBT9_search_comm_part_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search DCN - Advanced...") == 0))
	{
		ifail = LBT9_search_dcn_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

     if( (name != NULL) && (tc_strcmp(name, "Search Deviation - Advanced...") == 0))
	{
		ifail = LBT9_search_dev_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search ECN - Advanced...") == 0))
	{
		ifail = LBT9_search_ecn_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search MCO - Advanced...") == 0))
	{
		ifail = LBT9_search_mco_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	  if( (name != NULL) && (tc_strcmp(name, "Search Manufacturer Part - Advanced...") == 0))
	{
		ifail = LBT9_search_mfg_part_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

     if( (name != NULL) && (tc_strcmp(name, "Search Manufacturer...") == 0))
	{
		ifail = LBT9_search_manufacturer(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search Product Specification - Advanced...") == 0))
	{
		ifail = LBT9_search_prod_spec_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 if( (name != NULL) && (tc_strcmp(name, "Search StopShip - Advanced...") == 0))
	{
		ifail = LBT9_search_stopship_adv(num_args, entries_names,
			entries_values, numFound, tFound);
	}

	 
	*decision  = ALL_CUSTOMIZATIONS;
    return ifail;
}


/******************************************************************************
 * Function Name    :   LBT_register_user_services
 * Description      :   Register server exit
 * INPUT PARAMS     :
 * RETURN VALUE     :   returnStatus = ITK success/failure status
 * ALGORITHM        :   Register custom user services
 *****************************************************************************/
extern int LBT_register_user_services(int *decision, va_list args)
{
   int ifail = ITK_ok;
   
    LBT_user_services(decision, args);
	
	*decision  = ALL_CUSTOMIZATIONS;
    return ifail;


}

/******************************************************************************
 * Function Name    :   LBT_custom_register_prop_method
 * Description      :   Register server exit
 * INPUT PARAMS     :
 * RETURN VALUE     :   returnStatus = ITK success/failure status
 * ALGORITHM        :   Register custom Prop Method
 *****************************************************************************/

extern int LBT_custom_register_prop_method ( int *decision, va_list args )
{
    int status                   = ITK_ok;

    *decision                    = ALL_CUSTOMIZATIONS;

	 char  *function_name        = "LBT_custom_register_prop_method";
	
	
   
   TC_write_syslog("\n Entering  %s",function_name);

    status = LBT_prop_methods();
    status = LBT_runtime_prop_methods();
    status = LBT_bomline_runtime_prop_methods();

	TC_write_syslog("\n Exiting  %s",function_name);

    return status;
}

/******************************************************************************
 * Function Name    :   LBT_register_custom_handlers
 * Description      :   Register server exit
 * INPUT PARAMS     :
 * RETURN VALUE     :   returnStatus = ITK success/failure status
 * ALGORITHM        :   Register custom handlers
 *****************************************************************************/

extern int LBT_register_custom_handlers(int *decision, va_list args)
{
    int status = ITK_ok;

    
    LBT_register_action_handlers(decision, args);

	LBT_register_rule_handlers(decision, args);

	
	*decision  = ALL_CUSTOMIZATIONS;
    return ITK_ok;
}


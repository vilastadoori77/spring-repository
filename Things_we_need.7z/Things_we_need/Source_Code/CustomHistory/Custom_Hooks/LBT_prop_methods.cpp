/******************************************************************************
 * Filename		    :   LBT_prop_methods.c
 * Description      :	This file is for writing all the property Method
 * Module  		    :   LBT.dll
 * ENVIRONMENT		:   C, C++, ITK
 *
 * History
 *------------------------------------------------------------------------------
 * Date         		 Name              Description of Change
 * June 04, 2015  	  Soumalya Sinha	      Initial Code
 * -----------------------------------------------------------------------------

 *****************************************************************************/

#include <LBT_includes.h>
#include<LBT_extensions.h>





int LBT_prop_methods()
{
   int          ifail          = ITK_ok;
  
   char         *function_name = "LBT_prop_methods";
  
  
   TC_write_syslog("\n Entering  %s",function_name);
   
   METHOD_id_t LBT9JOB_Request_completed_Date_set_method_id;
   METHOD_id_t lbt9_Request_Data_set_method_id;

 
   CLEANUP (METHOD_find_prop_method (LBT9_JobTYPE, lbt9_Request_Completed_DatePROP,
                                        PROP_set_value_date_msg,
                                       &LBT9JOB_Request_completed_Date_set_method_id))
	 
   CLEANUP (METHOD_add_action (LBT9JOB_Request_completed_Date_set_method_id,METHOD_post_action_type,
                                       LBT9JOB_Request_completed_Date_set_method, 0))
   
   CLEANUP (METHOD_find_prop_method (LBT9_JobTYPE, lbt9_Request_DataPROP,
                                        PROP_set_value_string_msg,
                                       &lbt9_Request_Data_set_method_id))
	 
   CLEANUP (METHOD_add_action (lbt9_Request_Data_set_method_id,METHOD_post_action_type,
                                       lbt9_Request_Data_set_method, 0))

 CLEANUP:
    TC_write_syslog("\n Exiting  %s",function_name);
	

 return( ifail );
}

/****************************************************************************
*
*  Function Name:   LBT9JOB_Request_completed_Date_set_method
*
*
*  Description:    
*
*  Input
*  Parameters:      1. Proprty Tag
*                   2. Property Value
*
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name              Description of Change
* 14-July-2015	  Soumalya Sinha		    Method written
*
****************************************************************************/
int LBT9JOB_Request_completed_Date_set_method(METHOD_message_t *message, va_list args)
{
    int        ifail                               = ITK_ok;
	char*	   function_name                       = "LBT9JOB_Request_completed_Date_set_method";
	tag_t      Job                                 = NULLTAG;
	tag_t      propTag                             = NULLTAG; 
	date_t	   newDate							   = NULLDATE;
	date_t	   dateValue						   = NULLDATE;
	

    logical      is_generated                       = true;
   // Get the arguments
   propTag = va_arg(args, tag_t);  
   dateValue    = va_arg( args, date_t );

   // Get the owning IR
   CLEANUP (PROP_ask_owning_object( propTag, &Job))

	   
	CLEANUP(LBT_Set_PDX_HIstory(Job,is_generated))

   CLEANUP:
   
  
   return ifail;
}


/****************************************************************************
*
*  Function Name:   LBT9JOB_Request_completed_Date_set_method
*
*
*  Description:    
*
*  Input
*  Parameters:      1. Proprty Tag
*                   2. Property Value
*
*--------------------------------------------------------------------------
* History
*--------------------------------------------------------------------------
* Date         	    Name              Description of Change
* 14-July-2015	  Soumalya Sinha		    Method written
*
****************************************************************************/
int lbt9_Request_Data_set_method(METHOD_message_t *message, va_list args)
{
    int        ifail                               = ITK_ok;
	char*	   function_name                       = "lbt9_Request_Data_set_method";
	char*      Request_data_value                  = NULL;
	tag_t      Job                                 = NULLTAG;
	tag_t      propTag                             = NULLTAG; 
	date_t	   newDate							   = NULLDATE;
	date_t	   dateValue						   = NULLDATE;
	

    logical      is_generated                       = false;
  
  // Get the arguments
   propTag             = va_arg(args, tag_t);  
   Request_data_value    = (char*)va_arg(args, char*);

   // Get the owning obj
   CLEANUP (PROP_ask_owning_object( propTag, &Job))

	   
   CLEANUP(LBT_Set_PDX_HIstory(Job,is_generated))

   CLEANUP:
   
  
   return ifail;
}

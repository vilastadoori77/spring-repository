/****************************************************************************
* Filename	    :    LBT_extensions.h			 	
*									
* ENVIRONMENT	:    C, C++, ITK
*
* Description   :    Define all the Pre/Post action function prototype here
*									
* History							       
*--------------------------------------------------------------------------
* Date         	Name              Description of Change
* April 2015   Soumalya Sinha         Created.
* -------------------------------------------------------------------------
*							
****************************************************************************/

#include <LBT_includes.h>
#include<LBT_extensions.h>





/* *********************************************************************************************
*  PostAction extension for the GRM_create message attached to IMAN_Specification/CMHasProblemItem
*  /CMHasImpactedItem/CMReferences.
*  *  
*  -Update the  history if any dataset added to the commercial_part_revision 
*
 * HISTORY 
 * *************************************************************************************************
 * Date              Name                 Description
 * *************************************************************************************************
 * 13-05-2015      Soumalya Sinha.        Created.
  ***************************************************************************************************/



extern int LBT9_Store_history_GRM_create_post(METHOD_message_t* msg, va_list args )
{
	int  ifail                    = ITK_ok;

		
	char*    function_name		  = "LBT9_Store_history_GRM_create_post";
	char*    msg_name             = "GRM_create";
    char*    extension_point      = "PostAction";

	char*    object_string_value  = NULL;
	char*    relation_type_name   = NULL;
	
	  
	tag_t	 primary_objectTag	  = NULLTAG;
	tag_t    secondary_objectTag  = NULLTAG;
	tag_t    relation_typeTag     = NULLTAG;
	tag_t    typeTag              = NULLTAG;


	tag_t   primary_obj_typetag       = NULLTAG;

	
    char primary_obj_type[TCTYPE_name_size_c+1] = "";

	logical  isCommercialRevision     = false;
	logical  is_added                 = true;
	
	
    /* Get the parameters from the grm_create_msg */
	primary_objectTag   = va_arg( args, tag_t);
	secondary_objectTag = va_arg( args, tag_t);
    relation_typeTag    = va_arg( args, tag_t);

	  //Added by Venu for Change History form update
	  ITK(LBT9_attachChangeFormToRevision(primary_objectTag, secondary_objectTag));

	    CLEANUP(TCTYPE_ask_display_name(relation_typeTag, &relation_type_name))

		CLEANUP(TCTYPE_ask_object_type(primary_objectTag, &primary_obj_typetag))
        CLEANUP(TCTYPE_ask_name(primary_obj_typetag, primary_obj_type))
		
		if(strcmp(primary_obj_type,EMR_CommrclPartRevisionTYPE ) ==  0)
		{
			goto CLEANUP;
		}


		if(tc_strcmp(relation_type_name,"Impacted Items" ) == 0)
		{
			if(strcmp(primary_obj_type,LBT9_StopShipRevisionTYPE ) ==  0|| 
			  (strcmp(primary_obj_type,LBT9_DeviationRevisionTYPE)  ==  0)||
			  (strcmp(primary_obj_type,LBT9_ChgRequestRevisionTYPE)  ==  0))
			 {
				 CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
                 CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
				 CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
			 }
		}
		else if(tc_strcmp(relation_type_name,"Solution Items" ) == 0)
		{
		    if(strcmp(primary_obj_type,LBT9_ECNRevisionTYPE ) ==  0|| 
			  (strcmp(primary_obj_type,LBT9_MCORevisionTYPE)  ==  0)||
			  (strcmp(primary_obj_type,LBT9_DCNRevisionTYPE)  ==  0))
			 {
				CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
                CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
			    CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
			 }
		}
				
		else
		{
			CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
            CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
			CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
		}
	    
		
	

    CLEANUP:
    LBT_FREE(relation_type_name)
    LBT_FREE(object_string_value)

    
	return ifail;
}


/* *********************************************************************************************
*  PostAction extension for the IMAN_delete message attached to IMAN_Specification/CMHasProblemItem
*  /CMHasImpactedItem/CMReferences.
*  *  
*  -Update the history if any dataset deleted from the commercial part 
*
* HISTORY 
* *************************************************************************************************
* Date              Name                 Description
* *************************************************************************************************
* 23-07-2014      Soumalya Sinha.        Created.
***************************************************************************************************/

extern int LBT9_Store_history_Iman_delete_pre(METHOD_message_t* msg, va_list args )
{
    int  ifail                          = ITK_ok;
   	
	char*    function_name		        = "LBT9_Store_history_Iman_delete_pre";
	char*    msg_name                   = "IMAN_delete";
    char*    extension_point            = "PreAction";

    char*    relation_type_name         = NULL;
	char*    object_string_value        = NULL;

	char     primary_obj_type[TCTYPE_name_size_c+1]  = "";

    tag_t	 primary_objectTag		    = NULLTAG;
	tag_t    secondary_objectTag	    = NULLTAG;
	tag_t    relation_typeTag           = NULLTAG;
   	tag_t    primary_obj_typetag        = NULLTAG;
	
	
	
	logical  is_added                   = false;


	tag_t  relationTag  = va_arg(args, tag_t);
   
		     
	CLEANUP(GRM_ask_relation_type(relationTag,&relation_typeTag))
	CLEANUP(GRM_ask_primary(relationTag,&primary_objectTag))
	CLEANUP(GRM_ask_secondary(relationTag,&secondary_objectTag))
	  
  
   CLEANUP(TCTYPE_ask_display_name(relation_typeTag, &relation_type_name))

   //Venus Code
   CLEANUP(LBT9_detachChangeFormFromRevision(relationTag))

        CLEANUP(TCTYPE_ask_object_type(primary_objectTag, &primary_obj_typetag))
        CLEANUP(TCTYPE_ask_name(primary_obj_typetag, primary_obj_type))
		
		if(strcmp(primary_obj_type,EMR_CommrclPartRevisionTYPE ) ==  0)
		{
			goto CLEANUP;
		}

			
		if(tc_strcmp(relation_type_name,"Impacted Items" ) == 0)
		{
			if(strcmp(primary_obj_type,LBT9_StopShipRevisionTYPE ) ==  0|| 
			  (strcmp(primary_obj_type,LBT9_DeviationRevisionTYPE)  ==  0)||
			  (strcmp(primary_obj_type,LBT9_ChgRequestRevisionTYPE)  ==  0))
			 {
				 CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
                 CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
				 CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
			 }
		}
		else if(tc_strcmp(relation_type_name,"Solution Items" ) == 0)
		{
			
			if(strcmp(primary_obj_type,LBT9_ECNRevisionTYPE ) ==  0|| 
			  (strcmp(primary_obj_type,LBT9_MCORevisionTYPE)  ==  0)||
			  (strcmp(primary_obj_type,LBT9_DCNRevisionTYPE)  ==  0))
			 {
				 CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
                 CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
				 CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
				 
			 }
		}
				
		else
		{
			CLEANUP(AOM_ask_value_string(secondary_objectTag,object_stringPROP,&object_string_value))
            CLEANUP(LBT9_store_attachment_history(primary_objectTag,relation_type_name,object_string_value,is_added))
			CLEANUP(LBT9_create_attachment_form(primary_objectTag,relation_type_name,object_string_value,is_added))
		}
	       
     

  CLEANUP:
    LBT_FREE(relation_type_name)
    LBT_FREE(object_string_value)
   
	return ifail;
}

//this function is to store history for attachment
//13/05/2015      Soumalya Sinha

extern int LBT9_store_attachment_history(tag_t itemRevTag,char* relation_type_name,char* object_string,logical is_added)
{
	int   ifail                    = 0;
	int   num_of_history           = 0;
	int   has_attribute            = 0;

	char*   current_person_name    = NULL;
	    
    char*    function_name		         = "LBT9_store_attachment_history";
	char*    current_user_name           = NULL;
	char*    htmlcontain                 = NULL;
	char*    current_time                = NULL;
	char*    userid                      = NULL;

	tag_t    current_user_tag            = NULLTAG;

	
    has_attribute = LBT_check_property_exists(itemRevTag , lbt9_Attachment_HistoryPROP);
	if(has_attribute == 0)
	{

    CLEANUP(POM_get_user(&current_user_name,&current_user_tag))
			
	CLEANUP(SA_ask_user_identifier2(current_user_tag,&userid))

	CLEANUP(SA_ask_user_person_name2(current_user_tag,&current_person_name))
    
	LBT9_current_get_time_stamp(DATE_FORMAT_STR_FOOTER, &current_time);

   
	CLEANUP(LBT_strcat(&htmlcontain,"<p style=\"background-color:gray;\"> <font size=\"2\" color=\"black\">")) 
	
	CLEANUP(LBT_strcat(&htmlcontain,"Modified By ")) 
	CLEANUP(LBT_strcat(&htmlcontain,userid))
    CLEANUP(LBT_strcat(&htmlcontain," On "))
    CLEANUP(LBT_strcat(&htmlcontain,current_time))
	CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 

	CLEANUP(LBT_strcat(&htmlcontain, "</p>")) 

    
    CLEANUP(LBT_strcat(&htmlcontain,"<UL TYPE=\"DISC\"> <font size=\"2\" color=\"black\">")) 
	CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 
    CLEANUP(LBT_strcat(&htmlcontain,"<LI><font size=\"2\" color=\"black\"> <b>")) 
    CLEANUP(LBT_strcat(&htmlcontain,relation_type_name))
	CLEANUP(LBT_strcat(&htmlcontain,"</b>:")) 
	
	if(is_added)
	CLEANUP(LBT_strcat(&htmlcontain," added "))
	else 
    CLEANUP(LBT_strcat(&htmlcontain," deleted "))

	CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 

	CLEANUP(LBT_strcat(&htmlcontain," <font size=\"2\" color=\"Red\">"))  
	CLEANUP(LBT_strcat(&htmlcontain," <b>"))
	CLEANUP(LBT_strcat(&htmlcontain,object_string))
	CLEANUP(LBT_strcat(&htmlcontain,"</b>")) 
	CLEANUP(LBT_strcat(&htmlcontain,"</UL>")) 
	CLEANUP(LBT_strcat(&htmlcontain, "</font>")) 

 
	   CLEANUP(AOM_ask_num_elements(itemRevTag,lbt9_Attachment_HistoryPROP,&num_of_history))
     
	
	   CLEANUP(AOM_refresh(itemRevTag, TRUE))
       CLEANUP(AOM_set_value_string_at(itemRevTag, lbt9_Attachment_HistoryPROP, num_of_history, htmlcontain))
       CLEANUP(AOM_save(itemRevTag))
       CLEANUP(AOM_refresh(itemRevTag, FALSE))
     
	}
	 
    CLEANUP:
	LBT_FREE(current_user_name)
	LBT_FREE(current_time)
	LBT_FREE(htmlcontain)
	LBT_FREE(userid)

	
	return ifail;
}



extern int LBT9_create_attachment_form(tag_t itemRevTag,char* relation_type_name,char* object_string,logical is_added)
{
	int   ifail                    = 0;
	int   num_of_history           = 0;
	int   has_attribute            = 0;
	int*  Type                     = NULL;

	char*   current_person_name    = NULL;
    
    char*    function_name		         = "LBT9_create_attachment_form";
	char*    current_user_name           = NULL;
	char*    htmlcontain                 = NULL;
	char*    current_time                = NULL;
	char*    userid                      = NULL;
	char*    item_id                     = NULL;
	char*    ItemRevStatus               = NULL;

	tag_t    current_user_tag            = NULLTAG;
	tag_t    Attachment_form_tag         = NULLTAG;
	tag_t*   tComp                          = NULL;

	date_t  currentDate                  = NULLDATE;

    has_attribute = LBT_check_property_exists(itemRevTag , lbt9_Attachment_FormPROP);
	if(has_attribute == 0)
	{

		CLEANUP(POM_get_user(&current_user_name,&current_user_tag))
		
		CLEANUP(SA_ask_user_identifier2(current_user_tag,&userid))

		CLEANUP(SA_ask_user_person_name2(current_user_tag,&current_person_name))

		CLEANUP(ITK_ask_default_date_format(&current_time))
		CLEANUP(ITK_string_to_date(current_time, &currentDate))
    
		CLEANUP(AOM_ask_value_string (itemRevTag, item_idPROP, &item_id))

		CLEANUP(FORM_create(item_id,NULL,LBT9_Attachment_FormTYPE,&Attachment_form_tag))
		
		if(Attachment_form_tag!=NULLTAG)
		{
		   //CLEANUPAOM_ask_value_string(FormTag, "current_name",&cpformId));
			 CLEANUP(AOM_refresh(Attachment_form_tag,true))
		
			 CLEANUP(AOM_set_value_string(Attachment_form_tag, lbt9_ActorPROP, userid))
			 CLEANUP(AOM_set_value_string(Attachment_form_tag, lbt9_RelationPROP, relation_type_name))
			 CLEANUP(AOM_set_value_string(Attachment_form_tag, lbt9_AttachmentPROP, object_string))
			 CLEANUP(AOM_set_value_date(Attachment_form_tag, lbt9_DatePROP,currentDate))
			 if(is_added)
			 CLEANUP(AOM_set_value_string(Attachment_form_tag, lbt9_ActionPROP, "Added"))
			 else 
			 CLEANUP(AOM_set_value_string(Attachment_form_tag, lbt9_ActionPROP, "Deleted"))

			 CLEANUP(AOM_save(Attachment_form_tag))
			 CLEANUP(AOM_refresh(Attachment_form_tag,false))
	
			 CLEANUP(LBT_ask_release_status(itemRevTag,&ItemRevStatus))
			 if(tc_strcmp(ItemRevStatus,"Released")== 0)
			 { 
							 
			   tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*2);
			   Type = (int*) MEM_alloc(sizeof(int)*2);
			   
			   tComp[0] = itemRevTag;
			   tComp[1] = Attachment_form_tag;
			    Type[0] = EPM_target_attachment;
			    Type[1] = EPM_reference_attachment;
							 
				//tComp[1] = new_rev[0];		
		        tag_t tProctemplate = NULLTAG;
		        tag_t tProcess = NULLTAG;
		        CLEANUP(EPM_find_process_template("QuickReleaseNoStatus",&tProctemplate))
		        CLEANUP(EPM_create_process("Test","Test",tProctemplate,2, tComp,Type,&tProcess))

			 }
			 else
			 {
			 CLEANUP(LBT_attachFormToRevision(Attachment_form_tag,itemRevTag,lbt9_Attachment_FormPROP))
			 }
	         LBT_FREE(ItemRevStatus)
		}
	
	
     
	}
	 
    CLEANUP:
	LBT_FREE(current_user_name)
	LBT_FREE(userid)
	LBT_FREE(current_person_name)
	LBT_FREE(current_time)
	LBT_FREE(item_id)
	
	
	return ifail;
}


/* Post Action on save_as for Save_as History*/
extern int LBT9_save_as_history(METHOD_message_t *message, va_list args)
{
	int      ifail                = ITK_ok;
	int      num_derived_revision = 0;
	int      has_attribute        = 0;
	char*    function_name        = "LBT9_save_as_history";
	char*    msg_name             = "ITEM_create_from_rev";
	char*    extension_point      = "PostAction";
	char*    newRevObjectString   = NULL;
	char*    oldRevObjectString   = NULL;
	
	tag_t old_item = NULLTAG;
	tag_t old_rev = NULLTAG;
	char* new_item_id = NULL;
	char* new_rev_id = NULL;
	tag_t* new_item = NULL;
	tag_t* new_rev = NULL;

	old_item = va_arg(args, tag_t);
	old_rev = va_arg(args, tag_t);
	new_item_id = va_arg(args, char*);
	new_rev_id = va_arg(args, char*);
	new_item = va_arg(args, tag_t*);
	new_rev = va_arg(args, tag_t*);

	
	if(NULLTAG != *new_rev)
	{

		has_attribute = LBT_check_property_exists(old_rev , lbt9_Derived_toPROP);
		if(has_attribute == 0)
		{
		   CLEANUP(AOM_ask_value_string(*new_rev, object_stringPROP, &newRevObjectString))
		   CLEANUP(AOM_ask_num_elements(old_rev,lbt9_Derived_toPROP,&num_derived_revision))
	       /*CLEANUP(AOM_refresh(old_rev, TRUE))
           CLEANUP(AOM_set_value_string_at(old_rev,lbt9_Derived_toPROP, num_derived_revision, newRevObjectString))
           CLEANUP(AOM_save(old_rev))
           CLEANUP(AOM_refresh(old_rev, FALSE))*/
		
		   CLEANUP(AOM_refresh(*new_rev, TRUE))
		   CLEANUP(AOM_set_value_strings(*new_rev,lbt9_Derived_toPROP,0,NULL))
           CLEANUP(AOM_save(*new_rev))
           CLEANUP(AOM_refresh(*new_rev, FALSE))
		}
		
	}
	

CLEANUP:
	LBT_FREE(newRevObjectString)

	return ifail;
}




//Post action on revise to clear derived to list

extern int LBT9_revise_cleanup_properties(METHOD_message_t *message, va_list args)
{
	int      ifail                = ITK_ok;
	int      has_attribute        = 0;
	char*    function_name        = "LBT9_revise_cleanup_properties";
	char*    msg_name             = "ITEM_copy_rev";
	char*    extension_point      = "PostAction";
	
	tag_t old_item = NULLTAG;
	char* rev_id = NULL;
	tag_t* new_rev = NULL;

	old_item = va_arg(args, tag_t);
	rev_id = va_arg(args, char*);
	new_rev = va_arg(args, tag_t*);

	if(NULLTAG != *new_rev)
	{

		has_attribute = LBT_check_property_exists(*new_rev, lbt9_Derived_toPROP);
		if(has_attribute == 0)
		{
		   CLEANUP(AOM_refresh(*new_rev, TRUE))
		   CLEANUP(AOM_set_value_strings(*new_rev,lbt9_Derived_toPROP,0,NULL))
           CLEANUP(AOM_save(*new_rev))
           CLEANUP(AOM_refresh(*new_rev, FALSE))
		}
		
	}
	

CLEANUP:

	return ifail;
}

//create signoff form and set PDX History on lbt9_Job item create

int LBT9_Set_PDX_History_Job_create_postaction(METHOD_message_t* msg, va_list args)
{
    int      ifail                        = ITK_ok;

	logical  is_generated                 = false;

    char*   item_id      = va_arg( args, char*);
	char*   item_name    = va_arg( args, char*);
	char*   type_name    = va_arg( args, char*);
	char*   rev_id       = va_arg( args, char*);
	tag_t*  Job          = va_arg( args, tag_t*);
	


	//CLEANUP(LBT_Set_PDX_HIstory(*  Job,is_generated))

//CLEANUP:
	return ifail;
}

//Set PDX History
int LBT_Set_PDX_HIstory(tag_t PDXJob,logical isGenerated)
{
    int      ifail                          = ITK_ok;;
	int      Request_data_at_count          = 0;
	int      PDX_Object_count               = 0;
	int      PDX_Object_counter             = 0;
	int      PDX_Object_info_count          = 0;
	int      has_attribute                  = 0;
	int      initiator_String_count         = 0;
	int      intiator_useid_count           = 0;
	int*     Type                           = NULL;

	char*    Request_data                   = NULL;
	char*    PDX_Initiator                  = NULL;
	char*    PDX_Object_id                  = NULL;
	char*    PDX_Object_Rev                 = NULL;
	char*    item_id                        = NULL;
	char*    request_status                 = NULL;
	char*    comment                        = NULL;
	char*    PDXObjStatus                   = NULL;
	char*    hasbracket                     = NULL;

    char**   Request_data_at_string_arr     = NULL;
	char**   PDX_Object_string_arr          = NULL;
	char**   PDX_Object_info_string_arr     = NULL;
	char**   initiator_String_values        = NULL;
	char**   intiator_useid_values          = NULL;

	tag_t    PDXObject_tag                  = NULLTAG;
	tag_t    PDXObjectRev_tag               = NULLTAG;
	tag_t    Signoff_form_tag               = NULLTAG;
	tag_t*   tComp                          = NULL;

	date_t   PDX_Initiated_date			    = NULLDATE;
	date_t   PDX_Completed_date             = NULLDATE;

  	if(PDXJob != NULLTAG)
	{
	    CLEANUP(AOM_ask_value_string (PDXJob, item_idPROP, &item_id))
	   //Get initiated date
       CLEANUP(AOM_ask_value_date(PDXJob, lbt9_Request_Initiated_DatePROP, &PDX_Initiated_date))
	   //Get Completed date
	   CLEANUP(AOM_ask_value_date(PDXJob, lbt9_Request_Completed_DatePROP, &PDX_Completed_date))
	  
	   //get initiator user name
       CLEANUP(AOM_ask_value_string(PDXJob, lbt9_Request_InitiatorPROP, &PDX_Initiator))
	  
	    hasbracket=tc_strstr(PDX_Initiator,LBT_OPEN_BRACKET);
	    if(hasbracket != NULL)
	    {
	      CLEANUP(LBT_parse_string_with_string(PDX_Initiator,LBT_OPEN_BRACKET,&initiator_String_count,&initiator_String_values))
		  if(initiator_String_values[1])
	      {
            CLEANUP(LBT_parse_string_with_string(initiator_String_values[1],LBT_CLOSE_BRACKET,&intiator_useid_count,&intiator_useid_values))
		  }
		}

	   //Ask request data value
	   CLEANUP(AOM_ask_value_string(PDXJob, lbt9_Request_DataPROP, &Request_data))
	   // get request value before @ sign LBT9_ECNRevision|E000003|A,LBT9_ECNRevision|E000004|A,LBT9_DCNRevision|DCN000001|A,LBT9_MCORevision|M000001|A
	   CLEANUP(LBT_parse_string_with_string(Request_data,LBT_ATSIGN,&Request_data_at_count,&Request_data_at_string_arr))
	   //get PDX object information separated by comma ,sign
	   if(Request_data_at_count > 0)
	   {
	      CLEANUP(LBT_parse_string_with_string(Request_data_at_string_arr[0],LBT_COMMA,&PDX_Object_count,&PDX_Object_string_arr))
	   
			  CLEANUP(LBT_strcat(&comment,"PDX Request "))
			  CLEANUP(LBT_strcat(&comment,item_id))

			  if(isGenerated)
			  {
				  CLEANUP(AOM_ask_value_string (PDXJob, lbt9_Request_StatusPROP, &request_status))
				  if (tc_strcmp (request_status, "Failed") == 0)
				  {
					  CLEANUP(LBT_strcat(&comment," process completed - FAIL"))
				  }
				  else if (tc_strcmp (request_status, "Success") == 0)
				  {
                      CLEANUP(LBT_strcat(&comment," process completed - SUCCESS"))
				  }
				 
				  else
				  {
				     CLEANUP(LBT_strcat(&comment," process completed"))
				  }
                   LBT_FREE(request_status)
			  }
			  else
			  {
				  CLEANUP(LBT_strcat(&comment," created"))
			  }

	      for(PDX_Object_counter = 0;PDX_Object_counter<PDX_Object_count;PDX_Object_counter++)
	      {
	         //Get item id and revid from the parsed string format assumed ObjectType|Item_id|Rev_id
			  PDX_Object_info_count = 0;
			  PDX_Object_info_string_arr = NULL;
		     CLEANUP(LBT_parse_string_with_string(PDX_Object_string_arr[PDX_Object_counter],LBT_BAR,&PDX_Object_info_count,&PDX_Object_info_string_arr))
             if((tc_strlen(PDX_Object_info_string_arr[1])!=0) && (tc_strlen(PDX_Object_info_string_arr[2])!= 0))
			 {
			  

				 CLEANUP(ITEM_find_item(PDX_Object_info_string_arr[1],&PDXObject_tag))
				 if(PDXObject_tag != NULLTAG)
			     {
				     CLEANUP(ITEM_find_revision(PDXObject_tag,PDX_Object_info_string_arr[2],&PDXObjectRev_tag))
				     if(PDXObjectRev_tag!=NULLTAG)
					 {
						 CLEANUP(FORM_create(item_id,NULL,LBT9_Signoff_Form_TYPE,&Signoff_form_tag))
						 if(Signoff_form_tag!=NULLTAG)
						 {
							 //CLEANUPAOM_ask_value_string(FormTag, "current_name",&cpformId));
	                         CLEANUP(AOM_refresh(Signoff_form_tag,true))
							 if(hasbracket != NULL)
							 {
							   CLEANUP(AOM_set_value_string(Signoff_form_tag, lbt9_history_userPROP, intiator_useid_values[0]))
							 }
							 else if(PDX_Initiator!= NULL)
							 {
							   CLEANUP(AOM_set_value_string(Signoff_form_tag, lbt9_history_userPROP, PDX_Initiator))
							 }
							 
							 
							 if(isGenerated)
							 {
                              CLEANUP(AOM_set_value_date(Signoff_form_tag, lbt9_history_datePROP, PDX_Completed_date))
														 }
							 else
							 {
							    CLEANUP(AOM_set_value_date(Signoff_form_tag, lbt9_history_datePROP, PDX_Initiated_date))
							 }
							 CLEANUP(LBT_ask_release_status(PDXObjectRev_tag,&PDXObjStatus))
                             CLEANUP(AOM_set_value_string(Signoff_form_tag, lbt9_history_statusPROP, PDXObjStatus))
							 CLEANUP(AOM_set_value_string(Signoff_form_tag, lbt9_history_commentsPROP, comment))
							 CLEANUP(AOM_set_value_string(Signoff_form_tag, lbt9_history_typePROP, "PDX"))
							 CLEANUP(AOM_save(Signoff_form_tag))
	                         CLEANUP(AOM_refresh(Signoff_form_tag,false))
							 has_attribute = 0;
							 has_attribute = LBT_check_property_exists(PDXObjectRev_tag , lbt9_Signoff_HistoryPROP);
		                     if(has_attribute == 0)
							 {
								 logical usersPrivilege = false;
								 AM_check_privilege(PDXObjectRev_tag,"WRITE",&usersPrivilege);
								 if(!usersPrivilege)
				                 { 
									 
								   tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*2);
					               Type = (int*) MEM_alloc(sizeof(int)*2);
					               tComp[0] = PDXObjectRev_tag;
					
					               tComp[1] = Signoff_form_tag;
					               Type[0] =  EPM_target_attachment;
					               Type[1] =  EPM_reference_attachment;
							 
					               //tComp[1] = new_rev[0];		
		
					               tag_t tProctemplate = NULLTAG;
					               tag_t tProcess = NULLTAG;
					               CLEANUP(EPM_find_process_template("QuickReleaseNoStatus",&tProctemplate))
					               CLEANUP( EPM_create_process("Test","Test",tProctemplate,2, tComp,Type,&tProcess))

								 }
								 else
								 {
									 CLEANUP(LBT_attachFormToRevision(Signoff_form_tag,PDXObjectRev_tag,lbt9_Signoff_HistoryPROP))
							     }
								 LBT_FREE(PDXObjStatus)
							 }


							 
						 }

						
					 }

				 }
				
			    // LBT_FREE(PDX_Object_info_string_arr[0])
				// LBT_FREE(PDX_Object_info_string_arr[1])
				 //LBT_FREE(PDX_Object_info_string_arr[2])

			 }
			LBT_FREE_STRINGS( PDX_Object_info_string_arr)
	      }//End of For loop
		  LBT_FREE_STRINGS(PDX_Object_string_arr)
	   }
	   LBT_FREE(comment);
	   LBT_FREE(PDX_Initiator);
	   LBT_FREE_STRINGS(Request_data_at_string_arr)
	   LBT_FREE_STRINGS(initiator_String_values) 
	   LBT_FREE_STRINGS(intiator_useid_values)
	}

   CLEANUP:

	return ifail;
}


/**************************************************************************************
*	Function name	:	attachFormToRevision

*	Description		:	This Function is used for attaching the Form  to the Object

***************************************************************************************/

int LBT_attachFormToRevision(tag_t formTag,tag_t revTag, const char *FormRefPropertyName)
{
	int ifail = ITK_ok;
	int iExistingFormCount = 0;
	
	CLEANUP(AOM_ask_num_elements(revTag,FormRefPropertyName,&iExistingFormCount))
	CLEANUP(AOM_refresh(revTag,TRUE))
	CLEANUP(AOM_set_value_tag_at(revTag,FormRefPropertyName,iExistingFormCount,formTag))
	CLEANUP(AOM_save(revTag))
	CLEANUP(AOM_refresh(revTag,FALSE))

	
	CLEANUP:
	

	return ifail;
}



//Venus Code for Revision History


/*******************************************************************************
 * Function Name	:  attachFormToRevision
 * Description		:  This function attaches given form to the given revision with given relation.                      
 *
 * PARAMS			:  	args   - @param tag_t       formTag
 *								 @param tag_t		revTag
 *
 * RETURN VALUE	:   returnStatus = ITK success/failure status
 ******************************************************************************/
/*extern int attachFormToRevision(tag_t formTag,          /* <I> */
						      /*  tag_t revTag            /* <I> */
	/*					       )
{
	int retcode = ITK_ok;
	
	if( revTag != NULLTAG && formTag != NULLTAG )
	{
		int n_forms = 0;
		tag_t *form_tags = NULL;
		
		//Attach the form to Revision
		//Find out if any forms are attached already. Since the property is a list of typed references, we need to add the form as a last element to the list
		ITK(AOM_ask_value_tags(revTag, "lbt9_Change_History_List", &n_forms, &form_tags));
		
		if ( retcode == ITK_ok )
		{
			ITK(AOM_refresh(revTag, TRUE));
			ITK(AOM_set_value_tag_at(revTag, "lbt9_Change_History_List", n_forms, formTag));
			ITK(AOM_save(revTag));
			ITK(AOM_refresh(revTag, FALSE));
		}
		
		//Attach the form to Item as well
		tag_t itemTag =  NULLTAG;
		
		ITK(ITEM_ask_item_of_rev(revTag, &itemTag));
		
		ITK(AOM_ask_value_tags(itemTag, "lbt9_Change_History_List", &n_forms, &form_tags));
		
		if( retcode == ITK_ok )
		{
			ITK(AOM_refresh(itemTag, TRUE));
			ITK(AOM_set_value_tag_at(itemTag, "lbt9_Change_History_List", n_forms, formTag));
			ITK(AOM_save(itemTag));
			ITK(AOM_refresh(itemTag, FALSE));
		}
		MEM_free(form_tags);
	}
	
	return retcode;
}*/

extern int attachFormToRevision(tag_t formTag,          /* <I> */
								tag_t revTag            /* <I> */
							   )
{
	int retcode = ITK_ok;
   
	if( revTag != NULLTAG && formTag != NULLTAG )
	{
		int n_forms = 0;
	   
		tag_t itemTag =  NULLTAG;
		tag_t *form_tags = NULL;

		char *form_name = NULL;
	   
		ITK(ITEM_ask_item_of_rev(revTag, &itemTag));
	   
		ITK(AOM_ask_value_string(formTag, "object_name", &form_name));
	   
		// Remove the form if already existing
		ITK(deleteFormFromItem(itemTag, form_name));
	   
		//Attach the form to Revision
		//Find out if any forms are attached already. Since the property is a list of typed references, we need to add the form as a last element to the list
		ITK(AOM_ask_value_tags(revTag, "lbt9_Change_History_List", &n_forms, &form_tags));
	   
		if ( retcode == ITK_ok )
		{
			ITK(AOM_refresh(revTag, TRUE));
			ITK(AOM_set_value_tag_at(revTag, "lbt9_Change_History_List", n_forms, formTag));
			ITK(AOM_save(revTag));
			ITK(AOM_refresh(revTag, FALSE));
		}
	   
		//Attach the form to Item as well
		ITK(AOM_ask_value_tags(itemTag, "lbt9_Change_History_List", &n_forms, &form_tags));
	   
		if( retcode == ITK_ok )
		{
			ITK(AOM_refresh(itemTag, TRUE));
			ITK(AOM_set_value_tag_at(itemTag, "lbt9_Change_History_List", n_forms, formTag));
			ITK(AOM_save(itemTag));
			ITK(AOM_refresh(itemTag, FALSE));
		}
		MEM_free(form_tags);
		MEM_free(form_name);
	}
   
	return retcode;
}


/*******************************************************************************
 * Function Name	:  deleteForm
 * Description		:  This function deletes the form attached to the given revision which is attached with given property and with the given name
 *
 * PARAMS			:   args   - @param tag_t item revision tag
 *								 @param char  form name to delete
 *
 * RETURN VALUE	:   returnStatus = ITK success/failure status
 ******************************************************************************/
extern int deleteFormFromItem(tag_t item_tag,         /* <I> */
							  char *form_name         /* <I> */
			                 )
{
	int retcode = ITK_ok;
	int rev_count = 0;
	
	tag_t form_tag = NULLTAG;
	tag_t *rev_tags = NULL;
	
	ITK(ITEM_list_all_revs(item_tag, &rev_count, &rev_tags));
	
	//remove form from all revisions
	for (int inx = 0; inx < rev_count; inx++)
	{
		ITK(removeForm(rev_tags[inx], form_name, &form_tag));
	}
	//remove form from item
	ITK(removeForm(item_tag, form_name, &form_tag))
	
	//delete the form from the database
	if( form_tag != NULLTAG )
	{
		ITK(AOM_refresh(form_tag, TRUE));
		
		ITK(AOM_delete(form_tag));
	}
	
	return retcode;
}


//Remove Form
extern int removeForm(tag_t object,        /* <I> */
                      char *form_name,     /* <I> */
					  tag_t *form_object   /* <O> */
					 )
{
	int retcode = ITK_ok;
	int n_forms = 0;
	
	tag_t *form_tags = NULL;
	
	*form_object = NULLTAG;
	
	ITK(AOM_ask_value_tags(object, "lbt9_Change_History_List", &n_forms, &form_tags));
	
	for (int inx = 0; inx < n_forms; inx++)
	{
		char *existing_form_name = NULL;
		
		ITK(AOM_ask_value_string(form_tags[inx], "object_name", &existing_form_name));
		
		if( tc_strcmp(form_name, existing_form_name) == 0 )
		{
			int values_index = -1;
			
			char *classname = NULL;
			
			tag_t inst_class_id = NULLTAG;
			tag_t chg_history_attr_id = NULLTAG;
			
			ITK(POM_class_of_instance(object, &inst_class_id));

			ITK(POM_name_of_class(inst_class_id, &classname));

			ITK(POM_attr_id_of_attr("lbt9_Change_History_List", classname, &chg_history_attr_id));
		
			if ( chg_history_attr_id != NULLTAG )
			{
				ITK(AOM_lock(object));

				ITK(POM_ask_index_of_tag(object, chg_history_attr_id, form_tags[inx], &values_index));
				
				if( values_index != -1 )
				{
					ITK(POM_remove_from_attr(1, &object, chg_history_attr_id, values_index, 1));
				}
				
				ITK(AOM_save(object));

				ITK(AOM_unlock(object));
			}
			ITK(deleteFormProperties(form_tags[inx]));
			*form_object = form_tags[inx];
			
			MEM_free(classname);
		}
		MEM_free(existing_form_name);
	}
	
	MEM_free(form_tags);
	
	return retcode;
}


// Delete Form Properties

int deleteFormProperties(tag_t change_form     /* <I> */)
{
	int retcode = ITK_ok;
   
	tag_t part_rev_tag_attr_id = NULLTAG;
	tag_t chg_rev_tag_attr_id = NULLTAG;
	tag_t form_storage_tag = NULLTAG;
	tag_t storage_class_id = NULLTAG;
   
	char *storage_classname = NULL;
   
	ITK(AOM_ask_value_tag(change_form, "data_file", &form_storage_tag));
	
	ITK(POM_class_of_instance(form_storage_tag, &storage_class_id));

	ITK(POM_name_of_class(storage_class_id, &storage_classname));
	
	printf("From Storage Class Name : %s\n", storage_classname);
	printf("From ID : %d\t Storage Form ID : %d\n", change_form, form_storage_tag);
	
	ITK(POM_attr_id_of_attr("lbt9_Part_Revs_Tag", "LBT9_Change_HistoryStorage", &part_rev_tag_attr_id));
   
	ITK(POM_attr_id_of_attr("lbt9_Change_Revs_Tag", "LBT9_Change_HistoryStorage", &chg_rev_tag_attr_id));
   
	ITK(AOM_lock(form_storage_tag));
   
	ITK(POM_set_attr_null(1, &form_storage_tag, chg_rev_tag_attr_id));
   
	ITK(POM_set_attr_null(1, &form_storage_tag, part_rev_tag_attr_id));
   
	ITK(AOM_save(form_storage_tag));

	ITK(AOM_unlock(form_storage_tag));
   
	MEM_free(storage_classname);
   
	return retcode;
}

/*******************************************************************************
 * Function Name	:  LBT9_attachChangeFormToRevision
 * Description		:  when a revision is added as a solution item or impacted item to any of the change objects
					   this extension will be triggered and it does the following operations.
					   a. Create a LBT9_Change_Form object and attach it to the revision
					   b. Set the following properties on the LBT9_Change_Form
							lbt9_part_revs_tag - item revision tag
							lbt9_change_revs_tag - change revision tag
 *
 * PARAMS			:   method - IMAN_save_msg method is overriden by the
 *					                custom extension on save action of CMHasImpactedItem and CMHasSolutionItem relations
 *
 *						args   - @param tag_t       object
 *								 @param logical		isNew?
 *
 * RETURN VALUE	:   returnStatus = ITK success/failure status
 ******************************************************************************/
// extern DLLAPI int LBT9_attachChangeFormToRevision(METHOD_message_t *msg, va_list args)
// {
    // int retcode = ITK_ok;
   
    // tag_t relation_tag = NULLTAG;
	
	// logical isNew = false;

    // relation_tag = va_arg (args, tag_t);
	// isNew = va_arg (args, logical);
	
	// TC_write_syslog("Entering Extension --> LBT9_attachChangeFormToRevision\n");
	
	// if( isNew )
	// {
		// TC_write_syslog("Entering Extension --> New Relation\n");
	// }
	// else
	// {
		// TC_write_syslog("Entering Extension --> Modified Relation\n");
	// }

    // if( relation_tag != NULLTAG && isNew )
    // {
		// tag_t change_rev_tag = NULLTAG;
		// tag_t item_rev_tag = NULLTAG;
		
		// char *item_rev_type = NULL;
		
		// ITK(GRM_ask_primary(relation_tag, &change_rev_tag));
		
		// ITK(GRM_ask_secondary(relation_tag, &item_rev_tag));
		
		// ITK(AOM_ask_value_string(item_rev_tag, "object_type", &item_rev_type));
		
		// TC_write_syslog("Secondary Revision Type : %s\n", item_rev_type);
		
		// if( tc_strcmp(item_rev_type, "EMR_CommrclPart Revision") == 0 || tc_strcmp(item_rev_type, "EMR_Document Revision") == 0 || tc_strcmp(item_rev_type, "LBT9_BusDocRevision") == 0 || tc_strcmp(item_rev_type, "LBT9_SpecDocRevision") == 0 )
		// {
			// char *change_number = NULL;
			
			// tag_t formTag = NULLTAG;
			// tag_t change_item_tag = NULLTAG;
			// tag_t form_type_tag = NULLTAG;
			// tag_t form_create_input_tag = NULLTAG;
			
			// ITK(ITEM_ask_item_of_rev(change_rev_tag, &change_item_tag));
			
			// ITK(ITEM_ask_id2(change_item_tag, &change_number));
			
			//Create Form Input Object
			// ITK(TCTYPE_find_type(CHANGE_FORM_TYPE, NULL, &form_type_tag));

			// ITK(TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

			//Set Form Properties. Create the form with same name as the change object.
			// ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", change_number));			
			// ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Part_Revs_Tag", item_rev_tag));
			// ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Change_Revs_Tag", change_rev_tag));
			
			// TC_write_syslog("Form Name : %s\n", change_number);

			//Create Form Object
			// ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
			
			// ERROR_CHECK(AOM_save(formTag));
			
			// ERROR_CHECK(AOM_save_with_extensions(formTag));
			
			//attach form to the item revision and item
			// ERROR_CHECK(attachFormToRevision(formTag, item_rev_tag));
			
			// MEM_free(change_number);
		// }
		// else
		// {
			// TC_write_syslog("Extension cannot be invoked for %s. The Only allowable types are EMR_CommrclPart Revision & EMR_Document Revision\n", item_rev_type);
		// }
		// MEM_free(item_rev_type);
    // }
	// TC_write_syslog("Exiting Extension --> LBT9_attachChangeFormToRevision\n");
    // return retcode;
// }

extern int LBT9_attachChangeFormToRevision(tag_t change_rev_tag,    /* <I> */
                                           tag_t item_rev_tag       /* <I> */
                                          )
{
    int retcode = ITK_ok;
	
	TC_write_syslog("Entering Extension --> LBT9_attachChangeFormToRevision\n");
	
	if( change_rev_tag != NULLTAG && item_rev_tag != NULLTAG )
    {
		char *item_rev_type = NULL;
		
		ITK(AOM_ask_value_string(item_rev_tag, "object_type", &item_rev_type));
		
		TC_write_syslog("Secondary Revision Type : %s\n", item_rev_type);
		
		if( tc_strcmp(item_rev_type, "EMR_CommrclPart Revision") == 0 || tc_strcmp(item_rev_type, "EMR_Document Revision") == 0 || tc_strcmp(item_rev_type, "LBT9_BusDocRevision") == 0 || tc_strcmp(item_rev_type, "LBT9_SpecDocRevision") == 0 )
		{
			int iRelStatCount			  = 0;

			char* cRelStatName			  = NULL;

			tag_t *ptRelStatList		  = NULL;

			ITK(WSOM_ask_release_status_list(item_rev_tag,&iRelStatCount, &ptRelStatList));
		    if(ptRelStatList!=NULL)
		    {
				ITK(AOM_ask_value_string(ptRelStatList[0],"object_name",&cRelStatName));
			    //if status is "Released" call exe
				if(tc_strcmp(cRelStatName,"EMR_Released")== 0)
				{
					tag_t formTag = NULLTAG;
					tag_t change_item_tag = NULLTAG;
					tag_t form_type_tag = NULLTAG;
					tag_t form_create_input_tag = NULLTAG;
					char * change_number = NULL;
			
					ITK(ITEM_ask_item_of_rev(change_rev_tag, &change_item_tag));
			
					ITK(ITEM_ask_id2(change_item_tag, &change_number));
			
					//Create Form Input Object
					ITK(TCTYPE_find_type(CHANGE_FORM_TYPE, NULL, &form_type_tag));

					ITK(TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

					//Set Form Properties. Create the form with same name as the change object.
					ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", change_number));			
					ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Part_Revs_Tag", item_rev_tag));
					ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Change_Revs_Tag", change_rev_tag));
			
					TC_write_syslog("Form Name : %s\n", change_number);

					//Create Form Object
					ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
			
					ERROR_CHECK(AOM_save(formTag));
			
					ERROR_CHECK(AOM_save_with_extensions(formTag));

					int * Type= NULL;
					tag_t *tComp = NULL;
					tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*2);
					Type = (int*) MEM_alloc(sizeof(int)*2);
					tComp[0] = item_rev_tag;
					
					tComp[1] = formTag;
					Type[0] =  EPM_target_attachment;
					Type[1] =  EPM_reference_attachment;
							
					//tComp[1] = new_rev[0];		
		
					tag_t tProctemplate = NULLTAG;
					tag_t tProcess = NULLTAG;
					EPM_find_process_template("QuickReleaseNoStatus",&tProctemplate);
					EPM_create_process("Test","Test",tProctemplate,2, tComp,Type,&tProcess);
				}
				else if(tc_strcmp(cRelStatName,"EMR_Released")!= 0)
				{					   
					char *change_number = NULL;
			
					tag_t formTag = NULLTAG;
					tag_t change_item_tag = NULLTAG;
					tag_t form_type_tag = NULLTAG;
					tag_t form_create_input_tag = NULLTAG;
			
					ITK(ITEM_ask_item_of_rev(change_rev_tag, &change_item_tag));
			
					ITK(ITEM_ask_id2(change_item_tag, &change_number));
			
					//Create Form Input Object
					ITK(TCTYPE_find_type(CHANGE_FORM_TYPE, NULL, &form_type_tag));

					ITK(TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));

					//Set Form Properties. Create the form with same name as the change object.
					ERROR_CHECK(AOM_set_value_string(form_create_input_tag, "object_name", change_number));			
					ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Part_Revs_Tag", item_rev_tag));
					ERROR_CHECK(AOM_set_value_tag(form_create_input_tag, "lbt9_Change_Revs_Tag", change_rev_tag));
			
					TC_write_syslog("Form Name : %s\n", change_number);

					//Create Form Object
					ERROR_CHECK(TCTYPE_create_object(form_create_input_tag, &formTag));
			
					ERROR_CHECK(AOM_save(formTag));
			
					ERROR_CHECK(AOM_save_with_extensions(formTag));
			
					//attach form to the item revision and item
					ERROR_CHECK(attachFormToRevision(formTag, item_rev_tag));
			
					MEM_free(change_number);
				}						
		    }
		}
		else
		{
			TC_write_syslog("Extension cannot be invoked for %s. The Only allowable types are EMR_CommrclPart Revision, EMR_Document Revision, LBT9_BusDocRevision and LBT9_SpecDocRevision\n", item_rev_type);
		}
		MEM_free(item_rev_type);
    }
	TC_write_syslog("Exiting Extension --> LBT9_attachChangeFormToRevision\n");
    return retcode;
}


/*******************************************************************************
 * Function Name	:  LBT9_detachChangeFormFromRevision
 * Description		:  when a revision is removed from solution item or impacted item of any of the the change objects
                       this extension will be triggered and it does the following operations.
				       a. delete the LBT9_Change_Form object.
 *
 * PARAMS			:   method - IMAN_delete_msg method is overriden by the custom extension
 *
 *						args   - @param tag_t       object
 *
 * RETURN VALUE	:   returnStatus = ITK success/failure status
 ******************************************************************************/
extern int LBT9_detachChangeFormFromRevision(tag_t relation_tag)
{
    int retcode = ITK_ok;
	
	TC_write_syslog("Entering Extension --> LBT9_detachChangeFormFromRevision\n");

    if( relation_tag != NULLTAG )
    {
		char *item_rev_type = NULL;
		
		tag_t change_rev_tag = NULLTAG;
		tag_t item_rev_tag = NULLTAG;
		
		ITK(GRM_ask_primary(relation_tag, &change_rev_tag));
		
		ITK(GRM_ask_secondary(relation_tag, &item_rev_tag));
		
		ITK(AOM_ask_value_string(item_rev_tag, "object_type", &item_rev_type));
		
		TC_write_syslog("Secondary Revision Type : %s\n", item_rev_type);
		
		if( tc_strcmp(item_rev_type, "EMR_CommrclPart Revision") == 0 || tc_strcmp(item_rev_type, "EMR_Document Revision") == 0 || tc_strcmp(item_rev_type, "LBT9_BusDocRevision") == 0 || tc_strcmp(item_rev_type, "LBT9_SpecDocRevision") == 0 )
		{
			char *change_number = NULL;
			
			tag_t item_tag = NULLTAG;
			tag_t change_item_tag = NULLTAG;
			
			ITK(ITEM_ask_item_of_rev(change_rev_tag, &change_item_tag));
			
			ITK(ITEM_ask_id2(change_item_tag, &change_number));
			
			ITK(ITEM_ask_item_of_rev(item_rev_tag, &item_tag));
			
			//remove the form from Item and all its revisions and then delete it.
			ITK(deleteFormFromItem(item_tag, change_number));
			
			MEM_free(change_number);
		}
		else
		{
			TC_write_syslog("Extension cannot be invoked for %s. The Only allowable types are EMR_CommrclPart Revision & EMR_Document Revision\n", item_rev_type);
		}
		
		MEM_free(item_rev_type);
    }
	
	TC_write_syslog("Exiting Extension --> LBT9_detachChangeFormFromRevision\n");
    return retcode;
}



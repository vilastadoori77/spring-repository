
/******************************************************************************************

File			:	LBT9_extensions.cpp

Description		:	Extensions code for Liebert

Author			:   Ashok Raj S

Date created	:   20/04/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

20/04/2015		Ashok Raj S				Inital version

20/04/2015		Ashok Raj S             Added LBT9_revisionCreationValidationForCommerclPart

22/04/2015		Ashok Raj S             Added LBT9_setPreliminaryStatus

22/04/2015		Ashok Raj S             Added LBT9_setPendingStatus

23/04/2015		Ashok Raj S             Added LBT9_setActiveStatus

23/04/2015		Ashok Raj S             Added LBT9_validateObsoleteBOMLineAdd

24/04/2015		Ashok Raj S             Added LBT9_validateSaveAs

24/04/2015		Ashok Raj S 			Added LBT9_validateSaveAsPostAction

25/04/2015		Ashok Raj S				Added LBT9_copyNameFromDesc

29/04/2015		Krupakar Reddy G		Added fnPendingForm

29/04/2015		Ashok Raj S				Added EMR_free

02/07/2015		Subbu G					Added LBT9_setApprovedStatus

06/07/2015      Ashok Raj S				Added LBT9_reviseRestrictionForChangeObjects

11/07/2015		VenuBabu Avala			Added function removeChangeForms
01/08/2015		Rahul Reddy A			Modified LBT9_validateCommrclPartRevisionId function
01/08/2015		Rahul Reddy A			Added fnRevIDFirstPartValidation function
01/08/2015		Rahul Reddy A			Added fnRevIDSecondPartValidation function

13/08/2015		Krupakar Reddy G		Added LBT9_SolutionItem_Validation
27/08/2015		Rahul Reddy A			Added LBT9_copyNameFromDescOnRefresh as part of defect fix 157
					
******************************************************************************************/
#include <metaframework/CreateInput.hxx>
#include "LBT9_extensions.h"


using namespace std;
using namespace Teamcenter;
/*******************************************************************************
 * Function Name	:  LBT9_revisionCreationValidationForCommerclPart
   Method           :  ITEM_create_rev & ITEM_copy_rev
   Description      :  Revise the Design for Porotype/Obsolete/Revise status
   Action           :  PreCondition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_revisionCreationValidationForCommerclPart(METHOD_message_t *msg, va_list args)
{
	int iFail				      = ITK_ok;
	int iRelStatCount			  = 0;

	const char* rev_id            = NULL;
	char* cRelStatName			  = NULL;

	tag_t existing_rev            = NULLTAG;
	tag_t new_rev				  = NULLTAG;
	tag_t *ptRelStatList		  = NULL;

	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t );

	// Adding code to validate Commercial part minor revision
	if (tc_strlen(rev_id) > 0 && rev_id != NULL && existing_rev != NULLTAG)
	{
		tag_t tItemTag		= NULLTAG;
		tag_t *tItemRevList	= NULL;
		char *cpLatestReleasedRevID = NULL;
		int iItemRevCount	= 0;
		tag_t tLatetsRelRevTag	=	NULLTAG;
		
		if (tc_strstr(rev_id,".M"))
		{
			int iParseCount = 0;
			char **cpParseList = NULL;			
			EPM__parse_string(rev_id,".M",&iParseCount,&cpParseList);
			ITK(ITEM_ask_item_of_rev(existing_rev,&tItemTag));
			
			if (tItemTag != NULLTAG)
			{
				ITEM_list_all_revs(tItemTag,&iItemRevCount,&tItemRevList);
			}
			if (iItemRevCount > 0 && tItemRevList != NULL)
			{
				ITK(fnToCheckLRRofItem(tItemTag,&tLatetsRelRevTag));
				ITK(ITEM_ask_rev_id2(tLatetsRelRevTag, &cpLatestReleasedRevID));
				//ITK(fnGetLatestReleasedRevID(tItemRevList,iItemRevCount,&cpLatestReleasedRevID));
			}
			if (tc_strlen(cpLatestReleasedRevID) > 0 && cpLatestReleasedRevID != NULL && iParseCount > 0 && cpParseList != NULL)
			{
				printf("cpLatestReleasedRevID: <%s>\n",cpLatestReleasedRevID);
				
				int iLatestPaseCount = 0;
				char **cpLatestParseList = NULL;
				EPM__parse_string(cpLatestReleasedRevID,".M",&iLatestPaseCount,&cpLatestParseList);
				if (tc_strlen(cpParseList[0]) > 0 && tc_strcmp(cpParseList[0],cpLatestParseList[0]) != 0)
				{
					EMH_store_initial_error_s2(EMH_severity_error,MINOR_Rev_VALIDATION,cpLatestReleasedRevID,cpLatestReleasedRevID);
					return MINOR_Rev_VALIDATION;
				}
				EMR_free(cpLatestParseList);
			}
			EMR_free(cpLatestReleasedRevID);			
			EMR_free(cpParseList);
			
		}		
	}

	if( existing_rev != NULLTAG )
	{
		ITK(WSOM_ask_release_status_list(existing_rev,&iRelStatCount, &ptRelStatList));
		if(ptRelStatList!=NULL)
		{
			ITK(AOM_ask_value_string(ptRelStatList[0],OBJECT_NAME,&cRelStatName));
			if (iRelStatCount > 0 && ptRelStatList != NULL)
			{	
				// If Status is Preliminary/Inactive throws Error
				if (tc_strcmp(cRelStatName,OBSOLETE_STATUS)!= 0 && tc_strcmp(cRelStatName,RELEASED_STATUS)!= 0 && tc_strcmp(cRelStatName,PROTOTYPE_STATUS)!= 0)
				{
				   if(tc_strcmp(cRelStatName,PRELIMINARY_STATUS)== 0)
				   {
					   //To Display Name as "Preliminary" instead of LBT9_Preliminary"
					   tc_strcpy(cRelStatName,PRELIMINARY);
					   EMH_store_initial_error_s1(EMH_severity_error,PRELIMINARY_STATUS_REVISE,cRelStatName);
					   EMR_free(ptRelStatList);
					   EMR_free(cRelStatName);
					   return PRELIMINARY_STATUS_REVISE;
				   }
				   else if(tc_strcmp(cRelStatName,INACTIVE_STATUS)== 0)
				   {
					   //To Display Name as "Inactive" instead of LBT9_Inactive"
					   tc_strcpy(cRelStatName,INACTIVE);
					   EMH_store_initial_error_s1(EMH_severity_error,INACTIVE_STATUS_REVISE,cRelStatName);
					   EMR_free(ptRelStatList);
					   EMR_free(cRelStatName);
				       return INACTIVE_STATUS_REVISE;
				   }				   
				}
			}
		}
		// If Status is Empty throw error
		if (iRelStatCount = 0 || ptRelStatList == NULL)
		{
			ITK(EMH_store_initial_error(EMH_severity_error,STATUS_IS_EMPTY));
			EMR_free(ptRelStatList);
			return STATUS_IS_EMPTY;
		}
	}
	EMR_free(ptRelStatList);
	EMR_free(cRelStatName);
	return iFail;
}
int fnGetLatestReleasedRevID(tag_t *tItemRevTagsList,	/* <I> */
							 int iCount,				/* <I> */
							 char **cpItemReleasedRevID /* <OF>*/
							 )
{
	int iFail = ITK_ok;
	*cpItemReleasedRevID = NULL;
	logical Flag = false;
	int i  = iCount - 1;
	for (i; i < iCount; i--)
	{
		int iRelStatCount			  = 0;
		tag_t *ptRelStatList		  = NULL;
		ITK(WSOM_ask_release_status_list(tItemRevTagsList[i],&iRelStatCount, &ptRelStatList));

		if (ptRelStatList != NULL && iRelStatCount > 0)
		{
			char* cRelStatName			  = NULL;
			ITK(AOM_ask_value_string(ptRelStatList[0],OBJECT_NAME,&cRelStatName));
			if (tc_strcmp(cRelStatName,OBSOLETE_STATUS) == 0 || tc_strcmp(cRelStatName,RELEASED_STATUS) == 0 || tc_strcmp(cRelStatName,PROTOTYPE_STATUS) == 0)
			{
				char *cpRevId = NULL;
				ITEM_ask_rev_id2(tItemRevTagsList[i],&cpRevId);

				if (tc_strlen(cpRevId) > 0 && cpRevId != NULL)
				{
					*cpItemReleasedRevID = (char *) MEM_alloc((tc_strlen(cpRevId)+1)*sizeof(char));
					tc_strcpy(*cpItemReleasedRevID,cpRevId);
					Flag = true;
				}	
				EMR_free(cpRevId);
			}
			if (Flag)
			{
				break;
			}
		}
	}

	return iFail;	
}
/*******************************************************************************
 * Function Name	:  LBT9_setPreliminaryStatus
   Method           :  ITEM_create_rev & ITEM_copy_rev
   Description      :  Add Preliminary status to Part and Document
   Action           :  Post Action
 *******************************************************************************/
extern USER_EXT_DLL_API int LBT9_setPreliminaryStatus(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	const char* rev_id		     = NULL;

	tag_t tRelStatus			 = NULLTAG;
	tag_t existing_rev           = NULLTAG;

	tag_t *new_rev               = NULL;

  	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t *);

	if( new_rev != NULLTAG )
	{  
		//When an a part is being revised remove the property "lbt9_Change_History_List"
		ITK(removeChangeForms(*new_rev)); //added by Venu
		// Create Status with Name as "LBT9_Preliminary"
		ITK(RELSTAT_create_release_status(PRELIMINARY_STATUS, &tRelStatus));
		if(tRelStatus != NULLTAG)
		{
			// Add created Preliminary Status to the new revision
			ITK(RELSTAT_add_release_status(tRelStatus,1,new_rev,TRUE));
		}
	}	
	return iFail;
}


/*******************************************************************************
 * Function Name	:  LBT9_setPendingStatus
   Method           :  ITEM_create_rev
   Description      :  Add Pending status to ECN Revision
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_setPendingStatus(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	const char* rev_id		     = NULL;

	tag_t tRelStatus			 = NULLTAG;
	tag_t existing_rev           = NULLTAG;
	tag_t *new_rev               = NULL;
	  
  	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t *);

	if( new_rev != NULLTAG )
	{
		// Create Status with Name as "Pending"
		ITK(RELSTAT_create_release_status(PENDING_STATUS, &tRelStatus));
		if(tRelStatus != NULLTAG)
		{
			tag_t tRev=new_rev[0];
			// Add created Pending Status to the new revision
			ITK(RELSTAT_add_release_status(tRelStatus,1,new_rev,TRUE));
			fnPendingForm(tRev);
		}
	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_setActiveStatus
   Method           :  ITEM_create_rev & ITEM_copy_rev
   Description      :  Add Active status to Manufaturer Revision
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_setActiveStatus(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	const char* rev_id		     = NULL;

	tag_t tRelStatus			 = NULLTAG;
	tag_t existing_rev           = NULLTAG;
	tag_t Item                   = NULLTAG;
	tag_t *new_rev               = NULL;
	  
  	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t *);

	if( new_rev != NULLTAG )
	{
		// Create Status with Name as "LBT9_Active"
		ITK(RELSTAT_create_release_status(ACTIVE_STATUS, &tRelStatus));
		if(tRelStatus != NULLTAG)
		{
			// Add created Active Status to the new revision
			ITK(ITEM_ask_item_of_rev(*new_rev,&Item));
			ITK(RELSTAT_add_release_status(tRelStatus,1,&Item,TRUE));
		}
	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_setApprovedStatus
   Method           :  ITEM_create_rev 
   Description      :  Add Approved status to Manufaturer Revision
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_setApprovedStatus(METHOD_message_t *msg, va_list args)
{
	int iFail = ITK_ok;
	int count = 0;
	 
	const char* rev_id     = NULL;
	 
	tag_t tRelStatus 			 = NULLTAG;
	tag_t existing_rev           = NULLTAG;
	tag_t Item                   = NULLTAG;
	tag_t *new_rev               = NULL;
	 
	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t *);
	 
	if( new_rev != NULLTAG )
	{
		ITK(RELSTAT_create_release_status(APPROVED_STATUS, &tRelStatus));
		if(tRelStatus != NULLTAG)
			{
			// Add created Approved Status to the new revision
				ITK(ITEM_ask_item_of_rev(*new_rev,&Item));
				ITK(RELSTAT_add_release_status(tRelStatus,1,&Item,TRUE));
			}
	}
return iFail;
}

/**********************************************************************************************************
 * Function Name	:  LBT9_validateObsoleteBOMLineAdd
   Method           :  BOMLine_add
   Description      :  When Commercial Part/Document is added below checks are performed
						a.	Checks if Commercial Part/Document added to BOMline has obsolete status,if yes 
							throws error.
					    b.  If user adding Commercial Part/Document with same ID, if yes throws error.
   Action           :  Pre Condition
 *********************************************************************************************************/

extern USER_EXT_DLL_API int LBT9_validateObsoleteBOMLineAdd(METHOD_message_t *msg, va_list args)
{
	 int iFail					=   ITK_ok;
	 int iRelStatCount			=   0;
	 int iChildCount			=   0;

	 char *cRelStatName			=   NULL;
	 char *cItemRev				=   NULL;
	 char *cObjType				=   NULL;
	 char *cItemId				=   NULL;
	 char *cBomLineItemId		=   NULL;
	 char *cBomLineName			=   NULL;
	 char *cObjectName          =   NULL;
	 char *cParentObjType		=   NULL;

	 tag_t   parent_tag         =   NULLTAG;
     tag_t   item_tag           =   NULLTAG;
     tag_t   itemRev_tag        =   NULLTAG;
	 
	 tag_t *newBomline_tag		=	NULL;  // This Variable is added as part of Minor Rev BOM validations
  	 tag_t *ptRelStatList	    =   NULL;
	 tag_t *ptChildTag			=   NULL;
      
	 parent_tag                 =   va_arg(args,tag_t);
     item_tag                   =   va_arg(args,tag_t);
	 itemRev_tag                =   va_arg(args,tag_t);
	 newBomline_tag				=	va_arg(args,tag_t*);  // This argument is added as part of minor rev validations

	  if(itemRev_tag!=NULLTAG)
	  {
		  ITK(AOM_ask_value_string(parent_tag,"bl_item_object_type",&cParentObjType));
		  ITK(AOM_ask_value_string (itemRev_tag, OBJECT_TYPE, &cObjType));
		  // Added to check if Design Item is added to a Commerical Part BOM
		  if(tc_strcmp(cParentObjType,COMMCL_PART)== 0)
		  {			
		  if(tc_strcmp(cObjType,DESIGN)== 0 || tc_strcmp(cObjType,EMR_DESIGN)== 0)
		  {
				ITK(EMH_store_initial_error(EMH_severity_error,INVALID_DESIGN));
				EMR_free(cParentObjType);
				EMR_free(cObjType);
				return INVALID_DESIGN;
			 }			 
		  }
		  EMR_free(cParentObjType);
		  ITK(WSOM_ask_release_status_list(itemRev_tag,&iRelStatCount,&ptRelStatList));
		  if(ptRelStatList!=NULL)
		  {
			 ITK(AOM_ask_value_string(ptRelStatList[0],OBJECT_NAME,&cRelStatName));
			 if (iRelStatCount > 0 && ptRelStatList != NULL)
			 {
			     // Checks if Status of Commercial Part/ Document is Obsolete. If Status is Obsolete throws error
				 if(tc_strcmp(cRelStatName,OBSOLETE_STATUS)== 0)
				 {					   
					   ITK(AOM_ask_value_string(itemRev_tag,object_stringPROP,&cItemRev));
					   // Check if Business object is BUSSINESS Document or PSD Document
					   if(tc_strcmp(cObjType,BUS_DOC_REVISION)== 0 || tc_strcmp(cObjType,SPEC_DOC_REVISION)== 0)
					   {
						   ITK(EMH_store_initial_error_s1(EMH_severity_error,DOCUMENT_IS_OBSOLETE,cItemRev));
						   EMR_free(ptRelStatList);
						   EMR_free(cRelStatName);
						   EMR_free(cItemRev);
						   EMR_free(cObjType);
						   return DOCUMENT_IS_OBSOLETE;
					   }
					   // Check if Business object is EMR_Commercial Part Revision					
					   else if(tc_strcmp(cObjType,COMMCL_REVISION)== 0)
					   {
							ITK(EMH_store_initial_error_s1(EMH_severity_error,COMMERCIALPART_IS_OBSOLETE,cItemRev));
							EMR_free(ptRelStatList);
							EMR_free(cRelStatName);
							EMR_free(cItemRev);
							EMR_free(cObjType);
							return COMMERCIALPART_IS_OBSOLETE;
					   }
					   // Check if Business object is other than Document/Commercial Part
					   else if(tc_strcmp(cObjType,BUS_DOC_REVISION)!= 0 && tc_strcmp(cObjType,SPEC_DOC_REVISION)!= 0 && tc_strcmp(cObjType,COMMCL_REVISION)!= 0)
					   {
						    ITK(EMH_store_initial_error_s2(EMH_severity_error,PART_IS_OBSOLETE,cObjType,cItemRev));
							EMR_free(ptRelStatList);
							EMR_free(cRelStatName);
							EMR_free(cItemRev);
							EMR_free(cObjType);
							return PART_IS_OBSOLETE;
					   }
				}
				//Checks if similar commercial Part/Document getting added in Bom Line, throws error if similar item found in Bom Line
				if(tc_strcmp(cRelStatName,OBSOLETE_STATUS)!= 0)
				{
					ITK(AOM_ask_value_string(itemRev_tag,"item_id",&cItemId));
					ITK(BOM_line_ask_child_lines(parent_tag,&iChildCount,&ptChildTag));
					if(ptChildTag != NULLTAG)
					{		
						//Checks the Item Id with each Child Id in BOM Line
						for(int ii = 0; ii < iChildCount; ii++)
						{	
						    ITK(AOM_ask_value_string(ptChildTag[ii],BOM_ITEM_ID,&cBomLineItemId));
						    if(cBomLineItemId!=NULL)
						    {
						        if(tc_strcmp(cItemId,cBomLineItemId)==0)
						        {	    							           
									ITK(AOM_ask_value_string(itemRev_tag,"object_string",&cObjectName));
									ITK(AOM_ask_value_string(ptChildTag[ii],BOM_LINE_NAME,&cBomLineName));
									//Checks if both Item ID and Revision ID matches with any of the child ID in BOM Line
									//If yes displays error message to increase "Quantity" value insted of adding the same item twice
									/*if(tc_strcmp(cObjectName,cBomLineName)==0) // Commented the code as part of UAT Defect Fix
									{
										ITK(EMH_store_error_s1(EMH_severity_error,ITEM_REVISION_EXISTS,cBomLineName));
										EMR_free(cItemId);
										EMR_free(ptChildTag);
										EMR_free(cBomLineItemId);
										EMR_free(cObjectName);
										EMR_free(cBomLineName); 
										EMR_free(ptRelStatList);
										EMR_free(cRelStatName);
										EMR_free(cObjType);
										return ITEM_REVISION_EXISTS;	
									}*/
									// If Item ID matches and revision is different, then displays error message as
									// Multiple revisions of a same item cannot exists.
									if(tc_strcmp(cObjectName,cBomLineName)!=0)
									{
										ITK(EMH_store_error_s1(EMH_severity_error,ITEM_EXISTS,cBomLineName));
										EMR_free(cItemId);
										EMR_free(ptChildTag);
										EMR_free(cBomLineItemId);
										EMR_free(cObjectName);
										EMR_free(cBomLineName);																	
										EMR_free(ptRelStatList);
										EMR_free(cRelStatName);
										EMR_free(cObjType);
										return ITEM_EXISTS;
									}
							    }
						    }						 
					     }
				      }
				  }					   
			   }
		   }		
	 }
	 EMR_free(cObjType);
	 EMR_free(ptRelStatList);
	 EMR_free(cRelStatName);
	 EMR_free(cItemId);
	 EMR_free(ptChildTag);
	 EMR_free(cBomLineItemId);
	 return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_validateSaveAs
   Method           :  ITEM_create_from_rev
   Description      :  Checks status of Item before Save As 
   Action           :  Pre Condition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_validateSaveAs(METHOD_message_t *msg, va_list args)
{
	int iFail					= ITK_ok;
	int iRelStatCount		    = 0;
	
	char * cRelStatName         = NULL;
	
    const char* new_item_id		= NULL;
    const char* new_rev_id		= NULL;

	tag_t   tRelStatus          = NULLTAG;
    tag_t   old_item			= NULLTAG;
    tag_t   old_rev				= NULLTAG;

	tag_t*  ptRelStatList       = NULL; 
	tag_t*  new_item            = NULL;
    tag_t*  new_rev             = NULL;

	old_item                    = va_arg(args,tag_t);
    old_rev                     = va_arg(args,tag_t);
	new_item_id                 = va_arg(args,char*);
	new_rev_id                  = va_arg(args,char*);
	new_item					= va_arg(args,tag_t*);
    new_rev                     = va_arg(args,tag_t*);

	if(new_item_id != NULL)
	{
		ITK(WSOM_ask_release_status_list ( old_rev,&iRelStatCount, &ptRelStatList));
		if(ptRelStatList!=NULL)
		{
			ITK(AOM_ask_value_string(ptRelStatList[0],OBJECT_NAME,&cRelStatName));	
			// If Status is Obsolete/Inactive throws Error
			if(tc_strcmp(cRelStatName,PRELIMINARY_STATUS)!= 0 && tc_strcmp(cRelStatName,RELEASED_STATUS)!= 0 && tc_strcmp(cRelStatName,PROTOTYPE_STATUS)!= 0)
			{
				// If Status is Obsolete throws below specific Error
				if(tc_strcmp(cRelStatName,OBSOLETE_STATUS)==0)
				{
					EMH_store_initial_error_s1(EMH_severity_error,INVALID_STATUS_SAVEAS,OBSOLETE_STATUS);
					EMR_free(ptRelStatList);
					EMR_free(cRelStatName);
					return INVALID_STATUS_SAVEAS;
				}
				// If Status is Inactive throws below specific Error
				else if(tc_strcmp(cRelStatName,INACTIVE_STATUS)==0)
				{
					EMH_store_initial_error_s1(EMH_severity_error,INVALID_STATUS_SAVEAS,INACTIVE);
					EMR_free(ptRelStatList);
					EMR_free(cRelStatName);
					return INVALID_STATUS_SAVEAS;
				}
			}					
		}
	}
	EMR_free(ptRelStatList);
	EMR_free(cRelStatName);
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_ValidateSelectionOnCreate
   Method           :  GRM_create
   Description      :  Checks the placeholder for creation
   Action           :  Pre Condition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_ValidateSelectionOnCreate(METHOD_message_t *msg, va_list args)
{
	int iFail					= ITK_ok;
	tag_t tPrimaryObjectTag		= NULLTAG;
	tag_t tSecondaryObjectTag   = NULLTAG;

	tPrimaryObjectTag    = va_arg (args, tag_t);
	tSecondaryObjectTag  = va_arg (args, tag_t);

	if(tSecondaryObjectTag != NULLTAG)
	{
		tag_t tClassID = NULLTAG;
		char* cClassName = NULL;
		POM_class_of_instance (tSecondaryObjectTag, &tClassID);
		POM_name_of_class(tClassID, &cClassName);
		if(tc_strcmp(cClassName,"Dataset")!= 0)
		{
			ITK(EMH_store_error(EMH_severity_error,INVALID_SELECTION));
			     //EMR_free(Temp);				 
			return INVALID_SELECTION;
		}
	}


	return iFail;

}
/*******************************************************************************
 * Function Name	:  LBT9_validateSaveAsPostAction
   Method           :  ITEM_create_from_rev
   Description      :  Create part with status 
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_validateSaveAsPostAction(METHOD_message_t *msg, va_list args)
{
	int iFail					= ITK_ok;
	int iRelStatCount		    = 0;
	int num_derived_revision    = 0;

	char * cRelStatName         = NULL;

    const char* new_item_id		= NULL;
    const char* new_rev_id		= NULL;

	tag_t   tRelStatus          = NULLTAG;
    tag_t   old_item			= NULLTAG;
    tag_t   old_rev				= NULLTAG;
	tag_t	tItemTag			= NULLTAG;
	tag_t	tItem_rev			= NULLTAG;

	tag_t*  new_item            = NULL;
    tag_t*  new_rev             = NULL;

	old_item                    = va_arg(args,tag_t);
    old_rev                     = va_arg(args,tag_t);
	new_item_id                 = va_arg(args,char*);
	new_rev_id                  = va_arg(args,char*);
	new_item					= va_arg(args,tag_t*);
    new_rev                     = va_arg(args,tag_t*);
	
	
	if(new_item_id != NULL)
	{
		ITEM_find_item(new_item_id,&tItemTag);
		if(tItemTag != NULLTAG)
		{
			ITEM_ask_latest_rev(tItemTag,&tItem_rev);			
			if(tItem_rev != NULLTAG)
			{
				//when a part is being revised, remove the property "lbt9_Change_History_List"
				ITK(removeChangeForms(tItem_rev)); //Added by Venu
				// Creates Preliminary Status
				ITK(RELSTAT_create_release_status(PRELIMINARY_STATUS, &tRelStatus));
				if(tRelStatus != NULLTAG)
				{
					// Adds below status below to the new revision
					ITK(RELSTAT_add_release_status(tRelStatus,1,new_rev,TRUE));
				}				
			}
		}
	}
	if (old_rev != NULLTAG)
	{
		printf("Good to call SystemFunction here..!\n");

		//char * command = NULL;

		//char*cInString = NULL;
		//command =(char*) MEM_alloc(1024);
		//cInString =(char*) MEM_alloc(512);

		//tag_t tItem = NULLTAG;
		//char *cOldItemId = NULL;
		//char*cOldRevId   = NULL;
		//AOM_ask_value_tag(old_rev, "items_tag", &tItem);
		//if(tItem != NULLTAG)
		//{
		//	AOM_ask_value_string(tItem, "item_id", &cOldItemId);
		//}
		//AOM_ask_value_string(old_rev, "item_revision_id", &cOldRevId);

		//if(cOldItemId != NULL && cOldRevId != NULL)
		//{
		//	tc_strcpy(cInString ,cOldItemId);
		//	tc_strcat(cInString , "|");
		//	tc_strcat(cInString ,cOldRevId);
		//	tc_strcat(cInString , "|");
		//	if(new_item_id != NULL)
		//	tc_strcat(cInString , new_item_id);
		//	tc_strcat(cInString , "|");
		//	if(new_item_id != NULL)
		//	tc_strcat(cInString , new_rev_id);
		//	
		//}

		//char * cPrefVal = NULL;
		//PREF_set_search_scope(TC_preference_site);
		//PREF_ask_char_value("LBT_BUS_EXE_LOC",0,&cPrefVal );
		//printf("Prefernece value is %s \n",cPrefVal);
		//tc_strcpy(command ,cPrefVal);
		//tc_strcat(command , " derivedto");
		//tc_strcat(command , " ");
		//tc_strcat(command , "\"");
		//tc_strcat(command , cInString);
		//tc_strcat(command , "\"");

		//printf("command is %s \n", command);
		//if (system(command) != 0 )
		//{
		//	printf("System command Operation failed..!\n");
		//}
		//else
		//{
		//	printf("System command Operation Success..!\n");
		//}
		//EMR_free(command);
		//EMR_free(cInString);
		int * Type= NULL;
		tag_t *tComp = NULL;
		tComp = (tag_t*) MEM_alloc(sizeof(tag_t)*2);
		Type = (int*) MEM_alloc(sizeof(int)*2);
		tComp[0] = old_rev;
		if(new_item_id != NULL)
		{
			ITEM_find_item(new_item_id,&tItemTag);
			if(tItemTag != NULLTAG)
			{
				ITEM_ask_latest_rev(tItemTag,&tItem_rev);			
				if(tItem_rev != NULLTAG)
				{
					tComp[1] = tItem_rev;
					Type[0] =  EPM_target_attachment;
					Type[1] =  EPM_reference_attachment;
				}
			}
		}
		//tComp[1] = new_rev[0];
		
		
		tag_t tProctemplate = NULLTAG;
		tag_t tProcess = NULLTAG;
		EPM_find_process_template("QuickReleaseNoStatus",&tProctemplate);
		EPM_create_process("Test","Test",tProctemplate,2, tComp,Type,&tProcess);

		//tag_t tBJob = NULLTAG;
		//// create background JOB
		//LBT9_createBackGroundJOB(old_rev, new_item_id, new_rev_id, &tBJob);
		//if(tBJob != NULLTAG)
		//{
		//	printf("job Creation Successful..!\n");
		//}
		//else
		//{
		//	printf("job Creation Failed..!\n");
		//}
	}
	if(new_rev != NULL)
	{
		tag_t tAttachRelTag	=	NULLTAG;
		ITK(GRM_find_relation_type("TC_Attaches",&tAttachRelTag));
		if(tAttachRelTag)
		{
			int iSecObjCount	=	0;
			tag_t * tSecObjTags	=	NULL;
			ITK(GRM_list_secondary_objects_only(*new_rev,tAttachRelTag,&iSecObjCount,&tSecObjTags));
			if(iSecObjCount > 0 && tSecObjTags != NULL)
			{
				for(int inx = 0; inx < iSecObjCount ;inx++)
				{
					tag_t tRelationTag	=	NULLTAG;
					ITK(GRM_find_relation(*new_rev,tSecObjTags[inx],tAttachRelTag,&tRelationTag));
					if(tRelationTag != NULLTAG)
					{
						ITK(GRM_delete_relation(tRelationTag));
					}
				}
			 EMR_free(tSecObjTags);
			}
		
		}
	}

	EMR_free(cRelStatName);
	

	return iFail;
}

/*************************************************************************************************
 * Function Name	:  LBT9_copyNameFromDesc
   Method           :  ITEM_create
   Description      :  Copy Description field of Change Object to synopsis field of Change Object
   Action           :  Post Action
 *************************************************************************************************/

extern USER_EXT_DLL_API int LBT9_copyNameFromDesc(METHOD_message_t *msg, va_list args)
{
	int iFail                  = ITK_ok;
	
	char* cDescProp			   = NULL;
	char* cNameProp			   = NULL;

	const char* item_id        = NULL;     
	const char* item_name      = NULL; 
	const char* type_name      = NULL;
	const char* rev_id         = NULL;
		
	tag_t  tItemTag            = NULLTAG;
	tag_t* new_item            = NULL;
	tag_t* new_rev			   = NULL;

	item_id        = va_arg (args, char *);
    item_name      = va_arg (args, char *);
    type_name      = va_arg (args, char *);
    rev_id         = va_arg (args, char *);
    new_item       = va_arg (args, tag_t *);
    new_rev        = va_arg (args, tag_t *);

	METHOD_PROP_MESSAGE_OBJECT(msg, tItemTag);

	if(tItemTag!=NULL)
	{
		ITK(AOM_ask_value_string(new_rev[0],DESCRIPTION,&cDescProp));
		if(cDescProp!=NULL)
		{
			// Copies Description field text to Synopsis field
			cNameProp=cDescProp;
			// Trims Synopsis Field length to 30 
			cNameProp[30] ='\0';
			ITK(AOM_set_value_string(tItemTag,OBJECT_NAME,cNameProp));			
		    ITK(AOM_set_value_string(new_rev[0],OBJECT_NAME,cNameProp));	
		}
	}
	EMR_free(cDescProp);
	return iFail;
}

/*************************************************************************************************
 * Function Name	:  LBT9_copyNameFromDescOnSaveromDesc
   Method           :  IMAN_save_msg
   Description      :  Copy Description field of Change Object to synopsis field of Change Object
   Action           :  Post Action
 *************************************************************************************************/

extern USER_EXT_DLL_API int LBT9_copyNameFromDescOnSave(METHOD_message_t *msg, va_list args)
{
	int iFail                  = ITK_ok;
	//TC_save_msg
	char* cDescProp			   = NULL;
	char* cNameProp			   = NULL;

		
	tag_t  tItemTag            = NULLTAG;
	tag_t* new_item            = NULL;
	tag_t new_rev			   = NULL;
	logical is_new			   = false;

    new_rev        = va_arg (args, tag_t );
	is_new		   = va_arg (args, logical );

	if(new_rev!=NULLTAG && !is_new)
	{
		ITK(AOM_ask_value_string(new_rev,DESCRIPTION,&cDescProp));
		ITK(ITEM_ask_item_of_rev(new_rev, &tItemTag));
		if(cDescProp!=NULL)
		{
			// Copies Description field text to Synopsis field
			cNameProp=cDescProp;
			// Trims Synopsis Field length to 30 
			cNameProp[30] ='\0';
			//ITK(AOM_refresh(tItemTag ,POM_modify_lock));
			ITK(AOM_refresh(new_rev ,POM_modify_lock));
			//ITK(AOM_set_value_string(tItemTag,OBJECT_NAME,cNameProp));			
		    ITK(AOM_set_value_string(new_rev,OBJECT_NAME,cNameProp));
			//ITK(AOM_save(tItemTag));
			ITK(AOM_save(new_rev));
			ITK(AOM_refresh(new_rev ,POM_no_lock));
			//ITK(AOM_refresh(tItemTag ,POM_no_lock));
		}
	}
	EMR_free(cDescProp);
	return iFail;
}
/*************************************************************************************************
 * Function Name	:  LBT9_copyNameFromDescOnRefresh
   Method           :  IMAN_refresh
   Description      :  Copy revision name to item name of the change object
   Action           :  Post Action
 *************************************************************************************************/
extern USER_EXT_DLL_API int LBT9_copyNameFromDescOnRefresh(METHOD_message_t *msg, va_list args)
{
	int iFail						= ITK_ok;
	char* cRevDescProp				= NULL;
	char* cpItemName			    = NULL;
	char* cNameProp					= NULL;
	char *cpRevName					= NULL;		
	tag_t  tItemTag					= NULLTAG;
	tag_t* new_item					= NULL;
	tag_t tRevTag					= NULLTAG;
	logical lock					= false;

    tRevTag        = va_arg (args, tag_t );
	lock		   = va_arg (args, logical );
	
	if(tRevTag!=NULLTAG && !lock)
	{		
		TC_write_syslog("\n entering into function <LBT9_copyNameFromDescOnRefresh>..!\n");
		ITK(AOM_ask_value_string(tRevTag,DESCRIPTION,&cRevDescProp));
		ITK(AOM_ask_value_string(tRevTag,OBJECT_NAME,&cpRevName));
		ITK(ITEM_ask_item_of_rev(tRevTag, &tItemTag));
		ITK(AOM_ask_value_string(tItemTag,OBJECT_NAME,&cpItemName));
		if(cRevDescProp != NULL && cpRevName != NULL && cpItemName != NULL && tc_strlen(cpRevName) > 0 && tc_strlen(cRevDescProp) > 0 && tc_strlen(cpItemName) > 0)
		{
			if (tc_strcmp(cpRevName,cpItemName) != 0)
			{				
				ITK(AOM_refresh(tItemTag ,POM_modify_lock));
				ITK(AOM_set_value_string(tItemTag,OBJECT_NAME,cpRevName));
				ITK(AOM_save(tItemTag));
				ITK(AOM_refresh(tItemTag ,POM_no_lock));
			}
		}		
	}
	EMR_free(cRevDescProp);
	EMR_free(cpItemName);
	EMR_free(cpRevName);
	return iFail;
}

/*******************************************************************************
 * Function Name	:  fnPendingForm
   Description      :  Adding Pending Form to ECN
 *******************************************************************************/

int fnPendingForm(tag_t ecn_rev)
{
	int retcode						=	ITK_ok;
	int iExistingFormCount			=	0;

	char *current_date_string		=	NULL;
	char *userId					=	NULL;
	char *cpformId					=	NULL;
	char *userid					=	NULL;
	char *formName					=	NULL;

	tag_t formTag					=	NULLTAG;
	tag_t form_create_input_tag		=	NULLTAG;
	tag_t current_groupmember_tag	=	NULLTAG;
	tag_t userTag					=	NULLTAG;
	tag_t form_type_tag				=	NULLTAG;
	tag_t *tAllFormTags				=	NULL;

	formName = (char *)MEM_alloc(tc_strlen(PENDING_STATUS) + 1);
	
	date_t currentDate				=	NULLDATE;
		
	if(ecn_rev!=NULLTAG)
	{
		SA_ask_current_groupmember  (&current_groupmember_tag );  
		SA_ask_groupmember_user(current_groupmember_tag, &userTag);
		SA_ask_user_identifier2  (userTag,&userid); 
		tc_strcpy(formName,PENDING_STATUS);

		ITK(FORM_create(formName, "", SIGNOFF_FORM, &formTag));	
		ITK(TCTYPE_find_type(SIGNOFF_FORM, NULL, &form_type_tag));	
		ITK(TCTYPE_construct_create_input(form_type_tag, &form_create_input_tag));
		ITK(TCTYPE_create_object(form_create_input_tag, &formTag));
		ITK(AOM_save(formTag));
		ITK(AOM_save_with_extensions(formTag));

		ITK(ITK_ask_default_date_format(&current_date_string));
		ITK(ITK_string_to_date(current_date_string, &currentDate));
	
		ITK(AOM_lock(formTag));
		ITK(AOM_set_value_string(formTag, LBT9_HISTORY_TYPE, "Sign-Off"));
		ITK(AOM_set_value_string(formTag, LBT9_HISTORY_USER,userid ));
		ITK(AOM_set_value_string(formTag, LBT9_HISTORY_STATUS, PENDING_STATUS));
		ITK(AOM_set_value_date(formTag, LBT9_HISTORY_DATE, currentDate));
		ITK(AOM_save(formTag));
		ITK(AOM_unlock(formTag));
		
		ITK(AOM_ask_value_tags(ecn_rev,SIGNOFF_HISTORY,&iExistingFormCount,&tAllFormTags));
		ITK(AOM_refresh(ecn_rev,TRUE));
		ITK(AOM_set_value_tag_at(ecn_rev,SIGNOFF_HISTORY,iExistingFormCount,formTag));
		ITK(AOM_save(ecn_rev));
		ITK(AOM_refresh(ecn_rev,FALSE));
	}
	EMR_free(tAllFormTags);
	EMR_free(current_date_string);
	EMR_free(userId);
	EMR_free(cpformId);
	EMR_free(userid);
	EMR_free(formName);	
	return ITK_ok;
}
/*******************************************************************************
 * Function Name	:  LBT9_ValidateBomSave
   Method           :  BOMWindow_save
   Description      :  Validate BOM before it changes get saved ()
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_ValidateBomSave(METHOD_message_t *msg, va_list args)
{
	int iFail                  = ITK_ok;

	//tag_t   window_tag	= NULLTAG;
	//tag_t	tParentBL	= NULLTAG;
	//window_tag        = va_arg (args, tag_t);

	////Don not allow BOM changes if the parent of the BOM is a minor revision

	//if (window_tag != NULLTAG)
	//{
	//	ITK(BOM_ask_window_top_line(window_tag,&tParentBL));

	//	if (tParentBL != NULLTAG)
	//	{
	//		int iRevision_Attribute	= 0;
	//		char *cpRevisionId = NULL;
	//		char *cpMinorRevFinder = NULL;

	//		//printf("Parent BOM line found..!\n");
	//		BOM_line_look_up_attribute("bl_rev_current_revision_id",&iRevision_Attribute);
	//		//printf("iRevision_Attribute: <%d>\n",iRevision_Attribute);
	//		if (iRevision_Attribute != 0)
	//		{
	//			BOM_line_ask_attribute_string(tParentBL,iRevision_Attribute,&cpRevisionId);
	//			//printf("cpRevisionId: <%s>\n",cpRevisionId);

	//			if (tc_strlen(cpRevisionId) > 0 && cpRevisionId != NULL)
	//			{
	//				cpMinorRevFinder = (char *)MEM_alloc(tc_strlen(cpRevisionId) + 1);
	//				tc_strcpy(cpMinorRevFinder,"");
	//				tc_strcpy(cpMinorRevFinder,tc_strstr(cpRevisionId,"."));
	//			}
	//			//printf("cpMinorRevFinder: <%s>\n",cpMinorRevFinder);
	//			if (tc_strlen(cpMinorRevFinder) > 0 && tc_strcmp(cpMinorRevFinder,"") != 0)
	//			{
	//				EMH_store_initial_error_s1(EMH_severity_error,BOM_Save_MSG,cpRevisionId);
	//				return BOM_Save_MSG;
	//			}
	//		}

	//		if (cpRevisionId != NULL)
	//		{
	//			MEM_free(cpRevisionId);
	//		}
	//		if (cpMinorRevFinder != NULL)
	//		{
	//			MEM_free(cpMinorRevFinder);
	//		}
	//	}
	//}

	return iFail;
}


/*******************************************************************************
 * Function Name	:  LBT9_CRSetChangeAnalyst
   Method           :  ITEM_create_rev
   Description      :  Add Change Analyst value from the preference
   Action           :  Post Action
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_CRSetChangeAnalyst(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	const char* rev_id		     = NULL;

	tag_t tRelStatus			 = NULLTAG;
	tag_t existing_rev           = NULLTAG;
	tag_t *new_rev               = NULL;
	  
  	existing_rev    = va_arg (args, tag_t);
	rev_id          = va_arg (args, char *);
	new_rev         = va_arg (args, tag_t *);

	if( new_rev != NULLTAG )
	{
		char *cpObjectType = NULL;
		//Checking the Object Type
		ITK(WSOM_ask_object_type2(new_rev[0],&cpObjectType));
		if(cpObjectType != NULL && tc_strcmp(cpObjectType,CHANGE_REQUEST_REVISION) == 0)
		{
			char *cpBUValue = NULL;
			char *cpAnalystId = NULL;
			ITK(AOM_ask_value_string(new_rev[0],LBT9_BUSINESS_UNIT,&cpBUValue));
			if(cpBUValue != NULL)
			{
				//Getting the Preference value based on Business Unit value
				if(tc_strcmp(cpBUValue,"Thermal Management") == 0)
				{
					ITK(PREF_ask_char_value(THERMAL_MANAGEMENT_CHANGE_ANALYST,0,&cpAnalystId));
					
				}
				else if(tc_strcmp(cpBUValue,"AC Power") == 0)
				{
					ITK(PREF_ask_char_value(AC_POWER_CHANGE_ANALYST,0,&cpAnalystId));
				}
				else if(tc_strcmp(cpBUValue,"Solutions") == 0)
				{
					ITK(PREF_ask_char_value(SOLUTIONS_CHANGE_ANALYST,0,&cpAnalystId));
				}
				else if(tc_strcmp(cpBUValue,"Alber") == 0)
				{
					ITK(PREF_ask_char_value(ALBER_CHANGE_ANALYST,0,&cpAnalystId));
				}
				//Setting the Change Analyst based on the Preference value
				if(cpAnalystId != NULL)
				{
					ITK(iFail,AOM_refresh(new_rev[0],TRUE));
					ITK(AOM_set_value_string(new_rev[0],"lbt9_Change_Analyst",cpAnalystId));
					ITK(iFail,AOM_save(new_rev[0]));
					ITK(iFail,AOM_refresh(new_rev[0],FALSE));
					MEM_free(cpAnalystId);
				}
				MEM_free(cpBUValue);
			}
			MEM_free(cpObjectType);	
		}
	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_bopsAssociationWithCommercialPartRevision
   Method           :  PROP_set_value_tags
   Description      :  Checks if Item added to BOMline has obsolete status 
   Action           :  PreCondition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_bopsAssociationWithCommercialPartRevision(METHOD_message_t *msg, va_list args)
{
	int		iFail              = ITK_ok;
	
	// Requirement is no more used, function will be removed once the hook point is removed from BMIDE

	return iFail;
}
/*******************************************************************************
*	Function name	:	EMR_free
*	Description		:	Frees the memory allocated to the pointer 'ptr'
*	Return type		:	void
*	Outputs 		:	N/A
 *******************************************************************************/

void EMR_free(void* ptr)	/* <I> */
{
	if(ptr != NULL)
	{
		MEM_free(ptr);
	}
}
/*******************************************************************************
 * Function Name	:  LBT9_ValidateMinorRev
   Method           :  BOMLINE_cut
   Description      :  No BOM modification allowed if Rev belongs to a minor revision 
   Action           :  PreCondition
 *******************************************************************************/
extern USER_EXT_DLL_API int LBT9_ValidateMinorRev(METHOD_message_t *msg, va_list args)
{
	int iFail                  = ITK_ok;
	/*tag_t line_tag	 = NULLTAG;
	tag_t tWindowTag  = NULLTAG;
	tag_t	tParentBL	= NULLTAG;
	line_tag        = va_arg (args, tag_t);
	
	if (line_tag != NULL)
	{
		printf("Enter into LBT9_ValidateMinorRev...<line_tag> found...\n");
		BOM_line_ask_window(line_tag,&tWindowTag);
		
		if (tWindowTag != NULLTAG)
		{
			ITK(BOM_ask_window_top_line(tWindowTag,&tParentBL));
			if (tParentBL != NULLTAG)
			{
				int iRevision_Attribute	= 0;
				char *cpRevisionId = NULL;
				char *cpMinorRevFinder = NULL;
				
				BOM_line_look_up_attribute("bl_rev_current_revision_id",&iRevision_Attribute);
				
				if (iRevision_Attribute != 0)
				{
					BOM_line_ask_attribute_string(tParentBL,iRevision_Attribute,&cpRevisionId);					

					if (tc_strlen(cpRevisionId) > 0 && cpRevisionId != NULL)
					{
						cpMinorRevFinder = (char *)MEM_alloc(tc_strlen(cpRevisionId) + 1);
						tc_strcpy(cpMinorRevFinder,"");
						tc_strcpy(cpMinorRevFinder,tc_strstr(cpRevisionId,"."));
					}				
					if (tc_strlen(cpMinorRevFinder) > 0 && tc_strcmp(cpMinorRevFinder,"") != 0)
					{
						EMH_store_initial_error_s1(EMH_severity_error,BOM_Save_MSG,cpRevisionId);
						return BOM_Save_MSG;
					}
				}

				if (cpRevisionId != NULL)
				{
					MEM_free(cpRevisionId);
				}
				if (cpMinorRevFinder != NULL)
				{
					MEM_free(cpMinorRevFinder);
				}
			}
		}
	}*/
	return iFail;
}
/*******************************************************************************
 * Function Name	:  fnRevIDFirstPartValidation
   Method           :  
   Description      :  This function will validate Major Rev ID for commercial parts
   Action           :  PreCondition
 *******************************************************************************/
logical fnRevIDFirstPartValidation(char *RevID_firstPart)
{
	int iTempCount = 0;
	logical IsRevValid = false;
	char *Temp = NULL;
	Temp = (char *)MEM_alloc(tc_strlen(RevID_firstPart) + 1);
	tc_strcpy(Temp,"");
	tc_strcpy(Temp,RevID_firstPart);
	iTempCount = tc_strlen(Temp);
	for (int x = 0; x < iTempCount; x++)
	{		
		if (isalpha(Temp[x]))
		{
			IsRevValid = true;
			break;
		}
		//else if (x == 0)
		//{			
		//	char cpStringFinder[2] = "\0";							
		//	tc_strncpy(cpStringFinder,Temp,1);
		//	int number = atoi(cpStringFinder);		
		//	
		//	if (number == 0)
		//	{
		//		IsRevValid = true;
		//		break;
		//	}				
		//}
	}
	MEM_free(Temp);
	return IsRevValid;
}
/*******************************************************************************
 * Function Name	:  fnRevIDSecondPartValidation
   Method           :  ItemCreationInput
   Description      :  This function will validate Minor Rev ID for commercial parts
   Action           :  PreCondition
 *******************************************************************************/
logical fnRevIDSecondPartValidation(char *RevID_secondPart)
{
	int iTempCount = 0;
	logical IsRevInValid = false;	
	char Temp[10] = "";
	tc_strcpy(Temp,"");
	tc_strcpy(Temp,RevID_secondPart);
	iTempCount = tc_strlen(Temp);
	for (int i  = 0; i < iTempCount; i++)
	{
		if (i == 0 )
		{
			if (isalpha(Temp[0]))
			{
				char cpStringFinder[2] = "";
				cpStringFinder[0] = Temp[0];
				if (tc_strcmp(cpStringFinder,"M") != 0)
				{
					IsRevInValid = true;
					break;
				}
				else if (Temp[1] == NULL)
				{
					IsRevInValid = true;
					break;
				}


			}

			else if (!isalpha(Temp[0]))
			{
				IsRevInValid = true;
					break;

			}
	/*		else
			{				
				char cpStringFinder[2] = "\0";					
				cpStringFinder[0] = Temp[0];
				int number = atoi(cpStringFinder);				
				
				if (number == 0)
				{
					IsRevInValid = true;
					break;
				}	
			}*/		
		}
		else if (i != 0)
		{
			int out = 0;
			char cpStringFinder[2] = "";
			if (isalpha(Temp[i]))
			{
				//cpStringFinder[0] = Temp[i];
				//STRNG_is_integer(cpStringFinder,&out);
				//if (out == 0)
				//{
					IsRevInValid = true;
					break;				
				//}
			}
		//	else
		//	{
		//		IsRevInValid = true;
		//			break;
		//	}
		}
		/*else if (i > 1)
		{
			if (isalpha(Temp[i]))
			{
				IsRevInValid = true;
					break;
			}
		}*/
	}	
	return IsRevInValid;
}
/*******************************************************************************
 * Function Name	:  LBT9_validateCommrclPartRevisionId
   Method           :  ItemCreationInput
   Description      :  This function will validate Major and Minor Rev ID for commercial parts
   Action           :  PreCondition
 *******************************************************************************/
extern USER_EXT_DLL_API int LBT9_validateCommrclPartRevisionId(METHOD_message_t *msg, va_list args)
{

	//printf ("\n \n JMK Enter LBT9_validateCommercialPartRevisionId \n \n ");
	int iFail				     = ITK_ok;
	int iRelStatCount			 = 0;

	char* cpRevID            = NULL;
	char **cpParseStringList = NULL;
	//char* cRevId                  = NULL;
	char* cLatestRevId			  = NULL;
	char* cRelStatName			  = NULL;
	
	tag_t * ptRelStatList		  = NULL;

	tag_t existing_rev            = NULLTAG;
	tag_t new_rev				  = NULLTAG;
	tag_t partItem				  = NULLTAG;
	tag_t tLatestRevId			  = NULLTAG;

	std::string itemRevId;
	bool isNull;
			
	
    CreateInput *pRevCreInput = va_arg(args, CreateInput*);    
    
    pRevCreInput->getString("item_revision_id",itemRevId,isNull); 


	logical IsRevIdInValid = false;
	char Finder1[10] = "";
	cpRevID = (char *) MEM_alloc ( tc_strlen ( itemRevId.c_str()  ) + 1);

	tc_strcpy(cpRevID,itemRevId.c_str());
	if (tc_strlen(cpRevID) > 0 && cpRevID != NULL)
	{

		int iNewcount  = 10;
		int iCount     = 0;
		char **cpStringList   = NULL;
		EPM__parse_string(cpRevID,".",&iCount,&cpStringList);
		//iNewcount = 1;
		//if (iCount == 1)
		//{
		//	iNewcount = 1;
		//}
		if (iCount == 2)
		{
			if (tc_strlen(cpStringList[1]) > 1 )
			{			
				iNewcount = 2;
			}
			else 
			{
				IsRevIdInValid = true;
			}
		}		
		else if (iCount > 2)
		{
			IsRevIdInValid = true;
		}
		/*else
		{
			iNewcount == 1;
		}*/
		//if (iNewcount == 1 && !IsRevIdInValid)
		//{
		//	IsRevIdInValid = fnRevIDFirstPartValidation(cpStringList[0]);			
		//}
		if (iNewcount == 2 && !IsRevIdInValid)
		{
			IsRevIdInValid = fnRevIDFirstPartValidation(cpStringList[0]);

			if (!IsRevIdInValid)
			{
				IsRevIdInValid = fnRevIDSecondPartValidation(cpStringList[1]);
			}
		}					

		if (IsRevIdInValid)
		{
			EMH_store_initial_error_s1(EMH_severity_error,Minor_Validation_Error_MSG,cpRevID);
			return Minor_Validation_Error_MSG;
		}
	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_validateCommrclPartRevisionId
   Method           :  ItemCreationInput
   Description      :  This function will validate Major and Minor Rev ID for commercial parts
   Action           :  PreCondition
 *******************************************************************************/
extern USER_EXT_DLL_API int LBT9_ValidateCommrclPartRevIDOnCreation(METHOD_message_t *msg, va_list args)
{
	int iFail						= ITK_ok;
	char* cpRevID					= NULL;	
	int iCount						= 0;
	char **cpStringList				= NULL;
	logical IsRevIdInValid			= false;
	std::string itemRevId;
	bool isNull;
	TC_write_syslog("\n entering into function <LBT9_ValidateCommrclPartRevIDOnCreation>..!\n");	
    CreateInput *pRevCreInput = va_arg(args, CreateInput*);    
    
    pRevCreInput->getString("item_revision_id",itemRevId,isNull);

	cpRevID = (char *) MEM_alloc ( tc_strlen ( itemRevId.c_str()  ) + 1);
	tc_strcpy(cpRevID,itemRevId.c_str());	

	if (tc_strlen(cpRevID) > 0 && cpRevID != NULL)
	{
		EPM__parse_string(cpRevID,".",&iCount,&cpStringList);

		if (iCount != 1 )
		{
			IsRevIdInValid  = true;
		}
		MEM_free(cpStringList);
	}
	else
	{
		IsRevIdInValid  = true;
	}

	if (IsRevIdInValid)
	{
		EMH_store_initial_error_s1(EMH_severity_error,Major_Validation_Error_MSG,cpRevID);
		return Major_Validation_Error_MSG;
	}

	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_reviseRestrictionForChangeObjects
   Method           :  ITEM_copy_rev
   Description      :  If any Change object is revised throw custom Error message
   Action           :  PreCondition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_reviseRestrictionForChangeObjects(METHOD_message_t *msg, va_list args)
{
	int iFail				      = ITK_ok;

	tag_t existing_rev            = NULLTAG;

	existing_rev    = va_arg (args, tag_t);

	if( existing_rev != NULLTAG )
	{
		char * cObjectType = NULL;
		AOM_ask_value_string(existing_rev ,"object_type",&cObjectType);
		if(cObjectType != NULL && tc_strlen(cObjectType) > 0)
		{
			if(tc_strcmp(cObjectType ,"EMR_Vendor Revision") == 0)
			{
				ITK(EMH_store_initial_error(EMH_severity_error,INVALID_REVISE_MANUFACTURER));
				return INVALID_REVISE_MANUFACTURER;
			}
			else if(tc_strcmp(cObjectType ,"EMR_VendorPart Revision") == 0)
			{
				ITK(EMH_store_initial_error(EMH_severity_error,INVALID_REVISE_MANUFACTURER_PART));
				return INVALID_REVISE_MANUFACTURER_PART;
			}
			else
			{
				ITK(EMH_store_initial_error(EMH_severity_error,INVALID_REVISE));
				return INVALID_REVISE;	
			}
		}
	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_reviseRestrictionForChangeObjects
   Method           :  ITEM_copy_rev
   Description      :  If any Change object is revised throw custom Error message
   Action           :  PreCondition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_Validate_Secondary_Objects_DesignOrDrawings(METHOD_message_t *msg, va_list args)
{
	int iFail				      = ITK_ok;

	tag_t tPrimaryObjectTag		= NULLTAG;
	tag_t tSecondaryObjectTag   = NULLTAG;

	tPrimaryObjectTag    = va_arg (args, tag_t);
	tSecondaryObjectTag  = va_arg (args, tag_t);

	if(tSecondaryObjectTag != NULLTAG)
	{
		char *cObjectType           =   NULL;
		ITK(AOM_ask_value_string(tSecondaryObjectTag,"object_type",&cObjectType));
		if(cObjectType != NULL && tc_strlen(cObjectType) !=0 && tc_strcasecmp((const char*)cObjectType,"EMR_Design Revision") != 0 && tc_strcasecmp((const char*)cObjectType,"EMR_Drawing Revision") != 0)
		{
			EMH_clear_errors();
			EMH_store_initial_error(EMH_severity_error, LBT9_INVALID_DESIGN_ITEMS);
			return LBT9_INVALID_DESIGN_ITEMS;
		}
	}
	if(tSecondaryObjectTag == NULLTAG)
	{
		printf("\n Could not find secondary object\n");
	}
	
	return iFail;
}

extern int removeChangeForms(tag_t item_rev_tag        /* <I> */
					        )
{
	int retcode = ITK_ok;
	
	char *item_rev_type = NULL;
	
	ITK(AOM_ask_value_string(item_rev_tag, "object_type", &item_rev_type));
	
	if( tc_strcmp(item_rev_type, "EMR_CommrclPart Revision") == 0 || tc_strcmp(item_rev_type, "EMR_Document Revision") == 0 || tc_strcmp(item_rev_type, "LBT9_SpecDocRevision") == 0 ||tc_strcmp(item_rev_type, "LBT9_BusDocRevision") == 0)
	{
		int n_forms = 0;
	
		tag_t *form_tags = NULL;
		
		ITK(AOM_ask_value_tags(item_rev_tag, "lbt9_Change_History_List", &n_forms, &form_tags));
	
		for (int inx = 0; inx < n_forms; inx++)
		{
			int values_index = -1;
			
			char *classname = NULL;
			
			tag_t inst_class_id = NULLTAG;
			tag_t chg_history_attr_id = NULLTAG;
			
			ITK(POM_class_of_instance(item_rev_tag, &inst_class_id));

			ITK(POM_name_of_class(inst_class_id, &classname));

			ITK(POM_attr_id_of_attr("lbt9_Change_History_List", classname, &chg_history_attr_id));
		
			if ( chg_history_attr_id != NULLTAG )
			{
				ITK(AOM_lock(item_rev_tag));

				ITK(POM_ask_index_of_tag(item_rev_tag, chg_history_attr_id, form_tags[inx], &values_index));
				
				if( values_index != -1 )
				{
					ITK(POM_remove_from_attr(1, &item_rev_tag, chg_history_attr_id, values_index, 1));
				}
				
				ITK(AOM_save(item_rev_tag));

				ITK(AOM_unlock(item_rev_tag));
			}
			MEM_free(classname);
		}
		MEM_free(form_tags);
	}
	MEM_free(item_rev_type);
	
	return retcode;
}

/*******************************************************************************
 * Function Name	:  LBT9_SolutionItem_Validation
   Method           :  GRM_Create
   Description      :  Allowing Minor Revisions into  MCO only
   Action           :  Pre Condition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_SolutionItem_Validation(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	char *cpPrimaryObjectType	=	NULL;
	char *cpSecondaryObjectType	=	NULL;
    tag_t  primary_object		= NULLTAG;
    tag_t  secondary_object		= NULLTAG;
    tag_t  relation_type		= NULLTAG;
    tag_t  user_data			= NULLTAG;
    tag_t* new_relation			= NULLTAG;

	primary_object = va_arg (args, tag_t);
	secondary_object = va_arg (args, tag_t);
	relation_type = va_arg (args, tag_t);

	if(primary_object != NULLTAG && secondary_object != NULLTAG)
	{
		WSOM_ask_object_type2(secondary_object,&cpSecondaryObjectType);
		WSOM_ask_object_type2(primary_object,&cpPrimaryObjectType);
		if(cpSecondaryObjectType != NULL && tc_strcmp(cpSecondaryObjectType,"EMR_CommrclPart Revision")==0)
		{
			char * cpRevId	=	NULL;
			ITEM_ask_rev_id2(secondary_object,&cpRevId);
			if(cpRevId != NULL && tc_strcmp(cpRevId,"")!=0)
			{
				char * cpIsExists	=	NULL;
				cpIsExists = (char *)MEM_alloc(tc_strlen(cpRevId) + 1);
				cpIsExists	= tc_strstr(cpRevId,".");
				if(cpIsExists != NULL)
				{
					if(cpPrimaryObjectType != NULL && tc_strcmp(cpPrimaryObjectType,"LBT9_MCORevision")==0)
					{
						return ITK_ok;
					}
					else
					{
						EMH_store_initial_error_s1(EMH_severity_error,SOLUTION_ITEM_VALIDATION,"");
						return SOLUTION_ITEM_VALIDATION;
					}
				}
				EMR_free(cpIsExists);
			}

			EMR_free(cpRevId);
		}
		EMR_free(cpSecondaryObjectType);
		EMR_free(cpPrimaryObjectType);
		

	}
	return iFail;
}

/*******************************************************************************
 * Function Name	:  LBT9_SolutionItem_Validation
   Method           :  GRM_Create
   Description      :  Allowing Minor Revisions into  MCO only
   Action           :  Pre Condition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_DetachRemovedSolutionItems(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	char *cpPrimaryObjectType	=	NULL;
	char *cpSecondaryObjectType	=	NULL;
	tag_t relation_object       =   NULLTAG;
	tag_t primary_obj 			=	NULLTAG;
	tag_t sec_obj 				=	NULLTAG;
	
	printf("Enetred function \n");
	
	relation_object = va_arg (args, tag_t);
	
	if(relation_object != NULLTAG)
	{
		printf("Found Relation tag \n");
		GRM_ask_primary(relation_object, &primary_obj);
		if(primary_obj != NULLTAG)
		{
			printf("primary object found\n");
		}
		GRM_ask_secondary(relation_object, &sec_obj);
		if(sec_obj != NULLTAG)
		{
			printf("secondary object found\n");
		}
	}
	
	return iFail;

}

/*******************************************************************************
 * Function Name	:  LBT9_DetachRemovedSolutionItem_pre
   Method           :  IMAN_Delete
   Description      :  Detach Sol Items when the Solution Items removed from ECN
   Action           :  Pre Condition
 *******************************************************************************/

extern USER_EXT_DLL_API int LBT9_DetachRemovedSolutionItem_pre(METHOD_message_t *msg, va_list args)
{
	int iFail					 = ITK_ok;
	int count					 = 0;

	char *cpPrimaryObjectType	=	NULL;
	char *cpSecondaryObjectType	=	NULL;
	tag_t relation_object       =   NULLTAG;
	tag_t primary_obj 			=	NULLTAG;
	tag_t sec_obj 				=	NULLTAG;
	
	printf("Enetred function \n");
	
	relation_object = va_arg (args, tag_t);
	
	if(relation_object != NULLTAG)
	{
		printf("Found Relation tag \n");
		GRM_ask_primary(relation_object, &primary_obj);
		if(primary_obj != NULLTAG)
		{
			printf("primary object found\n");
		}
		GRM_ask_secondary(relation_object, &sec_obj);
		if(sec_obj != NULLTAG)
		{
			int iProcessCount = 0;
		logical flag = false;
		tag_t * tProcess = NULL;
		ITK(EPM_ask_active_job_for_target(primary_obj, &iProcessCount, &tProcess));
		if(iProcessCount > 0 && tProcess != NULL)
			{
				tag_t tRootTask = NULLTAG;
				int iCount = 0;
				int *iAttTypes = NULL;
				tag_t *tAttchMnts = NULL;
				ITK(EPM_ask_root_task(tProcess[0], &tRootTask));
				ITK(EPM_ask_all_attachments(tRootTask,&iCount, &tAttchMnts, &iAttTypes));
				int iNx = 0;
				for(iNx = 0; iNx < iCount; iNx ++)
				{
					if(tAttchMnts[iNx] == sec_obj)
					{
						flag = true;
					}
				}
				if(flag == true)
				{
					//remove attachments from target
					EPM_remove_attachments(tRootTask, 1, &sec_obj);
				}
			}
		}
	}
	
	return iFail;

}

/*******************************************************************************************
*	Function Name : fnToCheckLRRofItemMassChange

*	Description   :	This function finds latest released revision of the given part or item
********************************************************************************************/
int fnToCheckLRRofItem	(tag_t tPartTag,							/* <I> */
						 tag_t *PartLRRTag							/* <O> */
						)
{
	int iFail = ITK_ok;
	int iStatusCount = 0;
	int iAllRevisionCount = 0;
	int iRevStatusCount = 0;
	tag_t *tRevStatusTags = NULL;
	tag_t *tStatusTags = NULL;
	tag_t *AllRevisionTags = NULL;
	logical LRRItemFound = false;
	logical DateValidation = false;
	int iPreviousDateCount = 0;
	*PartLRRTag = NULLTAG;
	std :: vector<date_t> AllPreviousRevisionDate; 
	date_t LRRRevisonDate;
	tag_t tLrr = NULLTAG;
	ITK(ITEM_list_all_revs(tPartTag,&iAllRevisionCount,&AllRevisionTags));
	if(AllRevisionTags != NULL && iAllRevisionCount > 0)
	{
		ITK(AOM_ask_value_tags(AllRevisionTags[iAllRevisionCount-1],"release_status_list",&iStatusCount,&tStatusTags));
		if(tStatusTags != NULL && iStatusCount > 0)
		{
			char *cpStatusName = NULL;
			ITK(AOM_ask_value_string(tStatusTags[0],"object_name",&cpStatusName));
			if(cpStatusName != NULL && (tc_strcmp(cpStatusName,OBSOLETE_STATUS)== 0 || tc_strcmp(cpStatusName,RELEASED_STATUS)== 0 || tc_strcmp(cpStatusName,PROTOTYPE_STATUS)== 0))
			{
				LRRItemFound = true;
				ITK(AOM_ask_value_date(tStatusTags[0],"date_released",&LRRRevisonDate));
				tLrr = AllRevisionTags[iAllRevisionCount-1];
				MEM_free(cpStatusName);
			}
		}
		//getting the date of LRR and validating it with the previous released revisions 
		for(int j = iAllRevisionCount-2; j >= 0; j--)
		{
			//NoMoreRevisionExist = false;
			ITK(AOM_ask_value_tags(AllRevisionTags[j],"release_status_list",&iRevStatusCount,&tRevStatusTags));
			if(tRevStatusTags != NULL && iRevStatusCount > 0)
			{
				char *cpRevStatusName = NULL;
				ITK(AOM_ask_value_string(tRevStatusTags[0],"object_name",&cpRevStatusName));
				if(cpRevStatusName != NULL && (tc_strcmp(cpRevStatusName,OBSOLETE_STATUS)== 0 || tc_strcmp(cpRevStatusName,RELEASED_STATUS)== 0 || tc_strcmp(cpRevStatusName,PROTOTYPE_STATUS)== 0))
				{
							
					date_t PreviousRevisionDate;
					int answer = 0;
					ITK(AOM_ask_value_date(tRevStatusTags[0],"date_released",&PreviousRevisionDate));

					ITK(POM_compare_dates(LRRRevisonDate,PreviousRevisionDate,&answer));

					if(answer == -1)
					{
						tLrr = AllRevisionTags[j];
						LRRRevisonDate = PreviousRevisionDate;
						
					}
					if(answer == 0 &&tLrr == NULLTAG )
					{
						tLrr = AllRevisionTags[j];
						LRRRevisonDate = PreviousRevisionDate;
						
					}
					MEM_free(cpRevStatusName);
				}
						
			}
		}
	}
		*PartLRRTag = (tag_t) MEM_alloc(sizeof(tag_t));
		*PartLRRTag = tLrr;
		MEM_free(tStatusTags);
		MEM_free(tRevStatusTags);
		
	return ITK_ok;
}
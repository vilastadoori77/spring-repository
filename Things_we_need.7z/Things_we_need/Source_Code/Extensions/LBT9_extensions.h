/******************************************************************************************

File			:	LBT9_extensions.h

Description		:	Header Files added for LBT9_extensions.cpp

Author			:   Ashok Raj S

Date created	:   20/04/2015
	

*******************************************************************************************
History Log:

  Date            Author                           Action

20/04/2015		Ashok Raj S				Inital version

20/04/2015		Ashok Raj S             Added Header files

11/07/2015		VenuBabu Avala			Added function removeChangeForms
******************************************************************************************/

#include <string.h>
#include <tc/tc.h>
#include <sa\am.h>
#include <form/form.h>
#include <tccore/custom.h>
#include <pom/pom/pom.h>
#include <tccore/tctype.h>
#include <sa/groupmember.h>
#include <sa/group.h>
#include <sa/user.h>
#include <bom/bom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <tccore/custom.h>
#include <itk/mem.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/signoff.h>
#include <epm/epm_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <fclasses/tc_date.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <tc/iman_util.h>
#include <sa/tcfile.h>
#include <stdlib.h>
#include <tccore\workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <epm\epm_toolkit_tc_utils.h>
#include <tc\aliaslist.h>
#include <time.h>
#include <tccore/releasestatus.h>
#include <conio.h>
#include <ae/ae.h>
#include <stdio.h>
#include <fclasses/tc_basic.h>
#include <fclasses/tc_string.h>
#include <res/res_itk.h>
#include <cfm\cfm.h>
#include <time.h>
#include <string.h>
#include <fclasses/tc_date.h>
#include <unidefs.h>
#include <tccore/workspaceobject.h>
#include <bmf/libuserext_exports.h>
#include <ae/dataset.h>
#include <sa/am.h>

#define ITK( argument )                                                   \
{                                                                         \
	int retcode = argument;                                               \
	if ( retcode != ITK_ok ) {                                            \
	char* s;                                                              \
	printf( " "#argument "\n" );                                          \
	printf( "  returns [%d]\n", retcode );                                \
	TC_write_syslog( " "#argument "\n" );                                 \
	TC_write_syslog( "  returns [%d]\n", retcode );                       \
	EMH_ask_error_text (retcode, &s);                                     \
	printf( "  Teamcenter Engineering ERROR: [%s]\n", s);                 \
	printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );          \
	TC_write_syslog( "  Teamcenter Engineering ERROR: [%s]\n", s);        \
	TC_write_syslog( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ ); \
	if (s != 0) MEM_free (s);                                             \
	}                                                                     \
}

// Constants for Status

#define PRELIMINARY_STATUS          "LBT9_Preliminary"
#define RELEASED_STATUS             "EMR_Released"
#define PROTOTYPE_STATUS            "LBT9_Prototype"
#define ACTIVE_STATUS               "LBT9_Active"
#define APPROVED_STATUS             "Approved"
#define INACTIVE_STATUS             "LBT9_Inactive"
#define OBSOLETE_STATUS             "Obsolete"
#define PENDING_STATUS              "Pending"

#define PRELIMINARY		            "Preliminary"
#define INACTIVE		            "Inactive"

//Constants for Business objects

#define COMMCL_PART		 			"EMR_CommrclPart"
#define COMMCL_REVISION				"EMR_CommrclPart Revision"
#define BUS_DOC_REVISION			"LBT9_BusDocRevision"
#define SPEC_DOC_REVISION			"LBT9_SpecDocRevision"
#define DESIGN						"Design Revision"
#define EMR_DESIGN				    "EMR_Design Revision"
#define	SIGNOFF_FORM				"LBT9_Signoff_Form"
#define CHANGE_REQUEST_REVISION		"LBT9_ChgRequestRevision"

//Constants for Business object properties

#define ITEM_ID						"item_id"
#define REVISION_ID					"item_revision_id"
#define OBJECT_NAME					"object_name"
#define OBJECT_TYPE					"object_type"
#define object_stringPROP           "object_string"
#define object_typePROP             "object_type"
#define SIGNOFF_HISTORY				"lbt9_Signoff_History"
#define DESCRIPTION					"lbt9_Description"
#define lbt9_Derived_toPROP         "lbt9_Derived_to"
#define LBT9_HISTORY_TYPE			"lbt9_history_type"
#define LBT9_HISTORY_USER			"lbt9_history_user"
#define LBT9_HISTORY_STATUS			"lbt9_history_status"
#define LBT9_HISTORY_DATE			"lbt9_history_date"
#define LBT9_BUSINESS_UNIT			"lbt9_Business_Unit"
#define BOM_ITEM_ID					"bl_item_item_id"
#define BOM_LINE_NAME				"bl_line_name"

//Constants for Preference Name

#define THERMAL_MANAGEMENT_CHANGE_ANALYST				"Thermal_Management_Change_Analyst"
#define AC_POWER_CHANGE_ANALYST							"AC_Power_Change_Analyst"
#define	SOLUTIONS_CHANGE_ANALYST						"Solutions_Change_Analyst"
#define ALBER_CHANGE_ANALYST							"Alber_Change_Analyst"

// Error messages that will be added in ue_errors.xml

#define LBT9_user_error_base	        (EMH_USER_error_base )
#define PRELIMINARY_STATUS_REVISE       (EMH_USER_error_base + 2 )
#define DOCUMENT_IS_OBSOLETE            (EMH_USER_error_base + 3 )
#define NOT_A_LATEST_REVISION			(EMH_USER_error_base + 4 )
#define INVALID_STATUS_SAVEAS			(EMH_USER_error_base + 5 )
#define STATUS_IS_EMPTY					(EMH_USER_error_base + 6 )
#define PART_IS_OBSOLETE				(EMH_USER_error_base + 7 )
#define INACTIVE_STATUS_REVISE			(EMH_USER_error_base + 8 )
#define COMMERCIALPART_IS_OBSOLETE		(EMH_USER_error_base + 9 )
#define INVALID_DESIGN					(EMH_USER_error_base + 20)
#define BOM_Save_MSG					(EMH_USER_error_base + 84)
#define Minor_Validation_Error_MSG		(EMH_USER_error_base + 85)
#define Major_Validation_Error_MSG		(EMH_USER_error_base + 200)
#define INVALID_REVISE					(EMH_USER_error_base + 86)
#define ITEM_REVISION_EXISTS			(EMH_USER_error_base + 87)
#define ITEM_EXISTS						(EMH_USER_error_base + 88)
#define LBT9_INVALID_DESIGN_ITEMS		(EMH_USER_error_base + 401)
#define INVALID_REVISE_MANUFACTURER		(EMH_USER_error_base + 402)
#define INVALID_REVISE_MANUFACTURER_PART (EMH_USER_error_base + 403)
#define SOLUTION_ITEM_VALIDATION		(EMH_USER_error_base + 404)
#define INVALID_SELECTION				(EMH_USER_error_base + 504)
#define MINOR_Rev_VALIDATION			(EMH_USER_error_base + 506)


#ifdef __cplusplus
extern "C" {
#endif
extern USER_EXT_DLL_API int LBT9_validateCommrclPartRevisionId(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_revisionCreationValidationForCommerclPart(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_setPreliminaryStatus(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_setPendingStatus(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_setActiveStatus(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_setApprovedStatus(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_validateObsoleteBOMLineAdd(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_validateSaveAs(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_validateSaveAsPostAction(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_CRSetChangeAnalyst(METHOD_message_t *msg, va_list args);						//added by Tanay
extern USER_EXT_DLL_API int LBT9_bopsAssociationWithCommercialPartRevision(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_copyNameFromDesc(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_ValidateBomSave(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int fnPendingForm(tag_t  ecn_rev);
extern USER_EXT_DLL_API int LBT9_ValidateMinorRev(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_reviseRestrictionForChangeObjects(METHOD_message_t *msg, va_list args);
extern int removeChangeForms(tag_t item_rev_tag); //Added by Venu
extern USER_EXT_DLL_API int LBT9_Validate_Secondary_Objects_DesignOrDrawings(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_copyNameFromDescOnSave(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_SolutionItem_Validation(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_ValidateCommrclPartRevIDOnCreation(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_copyNameFromDescOnRefresh(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_ValidateSelectionOnCreate(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_DetachRemovedSolutionItems(METHOD_message_t *msg, va_list args);
extern USER_EXT_DLL_API int LBT9_DetachRemovedSolutionItem_pre(METHOD_message_t *msg, va_list args);
int fnGetLatestReleasedRevID(tag_t *tItemRevTagsList,	/* <I> */
							 int iCount,				/* <I> */
							 char **cpItemReleasedRevID /* <OF>*/
							 );
int fnToCheckLRRofItem	(tag_t tPartTag,							/* <I> */
						 tag_t *PartLRRTag							/* <O> */
						);
void EMR_free(void* ptr);

#ifdef __cplusplus
}
#endif
